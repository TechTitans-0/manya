<?php
require_once 'config/config.php';

// Clear the project type from session
unset($_SESSION['project_type']);

// Redirect to project selection
redirect('index.php');
?>
