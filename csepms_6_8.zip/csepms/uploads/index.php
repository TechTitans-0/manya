<?php
// Prevent directory access to the uploads folder.
header('Location: /csepms/index.php');
exit;
