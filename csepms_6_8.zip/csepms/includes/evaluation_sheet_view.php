<?php
// Middle content for evaluation sheet view (VIEW ONLY)
// Expects these variables via GET or in-scope: group_id, review (e.g. 'Review-1'), academic_year
require_once __DIR__ . '/../config/config.php';

$groupId = intval($_GET['group_id'] ?? ($group_id ?? 0));
$review = $_GET['review'] ?? ($review ?? null);
$phase = isset($_GET['phase']) ? intval($_GET['phase']) : (isset($phase) ? intval($phase) : 0);
$evaluationSheetId = isset($_GET['evaluation_sheet_id']) ? intval($_GET['evaluation_sheet_id']) : (isset($evaluation_sheet_id) ? intval($evaluation_sheet_id) : 0);
$academicYear = $_GET['academic_year'] ?? ($academic_year ?? null);
$department = $_GET['department'] ?? ($department ?? 'CSE');

if (!$groupId) {
    echo '<div class="alert alert-warning">Group not specified.</div>'; return;
}

// Fetch group / project details with academic year
$stmt = $conn->prepare("SELECT g.id, g.batch, g.project_title, g.guide_id, g.coordinator_guide_id, g.academic_year_id,
                       gd.id as guide_row_id, u.username as guide_name,
                       cd.id as coord_row_id, cu.username as coordinator_name, cd.department,
                       ay.year_label
                       FROM pgroups g
                       LEFT JOIN guides gd ON g.guide_id = gd.id
                       LEFT JOIN users u ON gd.user_id = u.id
                       LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
                       LEFT JOIN users cu ON cd.user_id = cu.id
                       LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
                       WHERE g.id = ? LIMIT 1");
$stmt->bind_param('i', $groupId);
$stmt->execute();
$group = $stmt->get_result()->fetch_assoc();

// if no guide assigned but coordinator is, use coordinator name
if (empty($group['guide_name']) && !empty($group['coordinator_guide_id'])) {
    $group['guide_name'] = $group['coordinator_name'];
}

$departmentLabel = '';
if (!empty($group['department'])) {
    $departmentLabel = strtoupper(trim($group['department']));
} elseif (!empty($department)) {
    $departmentLabel = strtoupper(trim($department));
}
if (empty($departmentLabel)) {
    $departmentLabel = 'COMPUTER SCIENCE AND ENGINEERING';
}

// Fetch students
$stmt = $conn->prepare("SELECT s.id, s.usn, COALESCE(s.name, u.username) as name FROM students s INNER JOIN users u ON s.user_id = u.id WHERE s.group_id = ? ORDER BY s.is_team_lead DESC, u.username ASC");
$stmt->bind_param('i', $groupId);
$stmt->execute();
$students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Resolve evaluation_sheet_id: prefer explicit id, else try phase+review numeric for Major Projects
// For Mini Projects, just fetch the first active evaluation sheet
if (!$evaluationSheetId) {
    if (getCurrentProjectType() === 'mini') {
        // For mini projects: fetch the first active evaluation sheet (no phase/review)
        $q = $conn->prepare("SELECT id FROM evaluation_sheets WHERE status IN ('active', 'draft') LIMIT 1");
        $q->execute();
        $row = $q->get_result()->fetch_assoc();
        if ($row) $evaluationSheetId = intval($row['id']);
    } else {
        // For major projects: Accept review as numeric or strings like 'Review-1' or '1'
        $reviewNum = 0;
        if ($review !== null) {
            $reviewNum = intval(preg_replace('/[^0-9]/', '', (string)$review));
        }
        if ($phase > 0 && $reviewNum > 0) {
            $q = $conn->prepare("SELECT id FROM evaluation_sheets WHERE phase = ? AND review = ? AND status = 'active' LIMIT 1");
            $q->bind_param('ii', $phase, $reviewNum);
            $q->execute();
            $row = $q->get_result()->fetch_assoc();
            if ($row) $evaluationSheetId = intval($row['id']);
        }
    }
}

// Fetch evaluation criteria for this evaluation sheet
$criteria = [];
if ($evaluationSheetId) {
    $critQuery = "SELECT ec.id, ec.criterion_name, ec.max_marks, ec.display_order
                  FROM evaluation_criteria ec
                  WHERE ec.evaluation_sheet_id = ?
                  ORDER BY ec.display_order ASC, ec.id ASC";
    $stmt = $conn->prepare($critQuery);
    $stmt->bind_param('i', $evaluationSheetId);
    $stmt->execute();
    $criteria = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

    // Determine display phase and review for header
$displayPhase = null;
$displayReview = null;
$isMini = (getCurrentProjectType() === 'mini');

if ($evaluationSheetId) {
    if ($isMini) {
        // Minim project has no phase/review in schema
        $q = $conn->prepare("SELECT subject_code FROM evaluation_sheets WHERE id = ? LIMIT 1");
        $q->bind_param('i', $evaluationSheetId);
        $q->execute();
        $srow = $q->get_result()->fetch_assoc();
        if ($srow) {
            $sheetSubjectCode = isset($srow['subject_code']) ? trim($srow['subject_code']) : '';
        }
    } else {
        $sstmt = $conn->prepare("SELECT phase, review, subject_code FROM evaluation_sheets WHERE id = ? LIMIT 1");
        $sstmt->bind_param('i', $evaluationSheetId);
        $sstmt->execute();
        $srow = $sstmt->get_result()->fetch_assoc();
        if ($srow) {
            $displayPhase = intval($srow['phase']);
            $displayReview = intval($srow['review']);
            $sheetSubjectCode = isset($srow['subject_code']) ? trim($srow['subject_code']) : '';
        }
    }
}

if (!$isMini) {
    if ($displayReview === null && $review !== null) {
        $displayReview = intval(preg_replace('/[^0-9]/', '', (string)$review));
    }
    if ($displayPhase === null) $displayPhase = 2; // fallback for major workflow
    if ($displayReview === null) $displayReview = 1;
}


    // Fetch marks from student_grades / student_grade_details for this evaluation sheet and group
    // Use only the latest grade row per student to avoid duplicate criteria if multiple grade rows exist
    $marks = [];
    $remarks = '';
    $gradedDate = ''; // date when grades were entered by guide/coord
    // Determine academic year to show (prefer explicit param, else session, else ACTIVE)
    $academicYearId = null;
    if (!empty($academicYear)) {
        $academicYearId = intval($academicYear);
    } elseif (isset($_SESSION['academic_year_id'])) {
        $academicYearId = intval($_SESSION['academic_year_id']);
    } else {
        $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        if ($ayRow && isset($ayRow['id'])) $academicYearId = intval($ayRow['id']);
    }
    if ($evaluationSheetId) {
        // Fetch overall remarks from the most recent grade record for this evaluation sheet and group
        $remarksQuery = "SELECT overall_remarks FROM student_grades 
                         WHERE evaluation_sheet_id = ? AND group_id = ? 
                           AND TRIM(COALESCE(overall_remarks, '')) <> ''
                         ORDER BY CHAR_LENGTH(TRIM(COALESCE(overall_remarks, ''))) DESC, updated_at DESC
                         LIMIT 1";
        $rstmt = $conn->prepare($remarksQuery);
        $rstmt->bind_param('ii', $evaluationSheetId, $groupId);
        $rstmt->execute();
        $rrow = $rstmt->get_result()->fetch_assoc();
        if ($rrow && trim($rrow['overall_remarks']) !== '') {
            $remarks = html_entity_decode(trim($rrow['overall_remarks']), ENT_QUOTES | ENT_HTML5);
        }

        // Fallback: if the primary query misses the remark value, try any grade row for this evaluation sheet/group
        if ($remarks === '') {
            $fallbackQuery = "SELECT overall_remarks FROM student_grades 
                              WHERE evaluation_sheet_id = ? AND group_id = ? 
                              ORDER BY CHAR_LENGTH(TRIM(COALESCE(overall_remarks, ''))) DESC, updated_at DESC
                              LIMIT 1";
            $fallbackStmt = $conn->prepare($fallbackQuery);
            $fallbackStmt->bind_param('ii', $evaluationSheetId, $groupId);
            $fallbackStmt->execute();
            $fallbackRow = $fallbackStmt->get_result()->fetch_assoc();
            if ($fallbackRow && trim($fallbackRow['overall_remarks']) !== '') {
                $remarks = html_entity_decode(trim($fallbackRow['overall_remarks']), ENT_QUOTES | ENT_HTML5);
            }
        }
        
        // determine graded date using max graded_at from student_grades
                $gdStmt = $conn->prepare("SELECT MAX(graded_at) AS dt FROM student_grades 
                                                                     WHERE evaluation_sheet_id = ? AND group_id = ? ".($academicYearId?" AND academic_year_id = ?":"")." 
                                                                         AND status IN ('submitted','approved')");
                if ($academicYearId) $gdStmt->bind_param('iii', $evaluationSheetId, $groupId, $academicYearId); else $gdStmt->bind_param('ii', $evaluationSheetId, $groupId);
        $gdStmt->execute();
        $gdr = $gdStmt->get_result()->fetch_assoc();
        if ($gdr && !empty($gdr['dt'])) {
            $gradedDate = date('d-m-Y', strtotime($gdr['dt']));
        }

        // Fetch marks using latest grade row per student to avoid duplicates
        // Include academic year in latest selection to avoid mixing old years
        $marksQuery = "SELECT sg.student_id, sgd.criterion_id, sgd.marks_obtained
                       FROM student_grades sg
                       INNER JOIN (
                           SELECT student_id, MAX(id) AS latest_grade_id
                           FROM student_grades
                           WHERE group_id = ? AND evaluation_sheet_id = ?";
        if ($academicYearId) {
            $marksQuery .= " AND academic_year_id = ?";
        }
        $marksQuery .= " GROUP BY student_id, evaluation_sheet_id
                       ) latest ON sg.id = latest.latest_grade_id
                       LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
                       WHERE sg.group_id = ? AND sg.evaluation_sheet_id = ?";
        if ($academicYearId) $marksQuery .= " AND sg.academic_year_id = ?";

        $stmt = $conn->prepare($marksQuery);
        if ($academicYearId) {
            // placeholders: subquery (group_id, evaluation_sheet_id, academic_year_id) + outer where (sg.group_id, sg.evaluation_sheet_id, sg.academic_year_id)
            $stmt->bind_param('iiiiii', $groupId, $evaluationSheetId, $academicYearId, $groupId, $evaluationSheetId, $academicYearId);
        } else {
            $stmt->bind_param('iiii', $groupId, $evaluationSheetId, $groupId, $evaluationSheetId);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) {
            if ($r['criterion_id'] !== null && $r['marks_obtained'] !== null) {
                // store as float; overwriting ensures latest value used
                $marks[intval($r['student_id'])][intval($r['criterion_id'])] = floatval($r['marks_obtained']);
            }
        }
    }

// Helper: format mark or Not Evaluated
function markOrNA($val) {
    if ($val === null || $val === '' || !isset($val)) return '<span class="text-muted">Not Evaluated</span>';
    return htmlspecialchars(number_format(floatval($val),2));
}

// Calculate total max marks
$totalMax = 0;
foreach ($criteria as $c) $totalMax += floatval($c['max_marks']);

// BEGIN OUTPUT: middle content only
?>
<div class="evaluation-sheet middle-content">
        <div class="evaluation-content">
    <?php
    // Build dynamic heading based on phase/review and subject code
    // For Mini Projects: Show generic project evaluation heading
    // For Major Projects: Show phase/review specific heading
    $subjectDisplay = isset($sheetSubjectCode) && $sheetSubjectCode !== '' ? ' (' . htmlspecialchars($sheetSubjectCode) . ')' : '';
    $heading = '';
    
    if (getCurrentProjectType() === 'mini') {
        // For mini projects: no phase/review distinction
        $heading = 'PROJECT EVALUATION SHEET' . $subjectDisplay;
    } else {
        // For major projects: show phase/review in heading
        if ($displayPhase == 1 && $displayReview == 1) {
            $heading = 'PROJECT WORK Phase -1 Review-1' . $subjectDisplay;
        } elseif ($displayPhase == 1 && $displayReview == 2) {
            $heading = 'PROJECT WORK Phase -1 Review-2' . $subjectDisplay . ' FINAL EVALUATION SHEET';
        } elseif ($displayPhase == 2 && $displayReview == 1) {
            $heading = 'PROJECT WORK Phase -2 Review-1' . $subjectDisplay;
        } elseif ($displayPhase == 2 && $displayReview == 2) {
            $heading = 'PROJECT WORK Phase -2 Review-2' . $subjectDisplay . ' FINAL EVALUATION SHEET';
        } else {
            $heading = 'PROJECT WORK' . $subjectDisplay;
        }
    }
    ?>
    <div class="department-title">DEPARTMENT OF <?php echo htmlspecialchars($departmentLabel); ?></div>
    <div class="sheet-heading">
        <h2><?php echo $heading; ?></h2>
    </div>

    <!-- Unified Evaluation Sheet Table -->
    <table class="evaluation-table">
        <!-- Project Title Row -->
        <tr>
            <td colspan="<?php echo 3 + count($students); ?>" class="label-cell"><strong>Project Title:</strong> <?php echo htmlspecialchars($group['project_title'] ?? ''); ?></td>
        </tr>
        <!-- Batch No and Date Row -->
        <tr>
            <td colspan="<?php echo 3 + count($students); ?>" class="label-cell" style="padding:0;border:none;">
                <table style="width:100%;table-layout:fixed;border-collapse:collapse;">
                    <tr>
                        <td style="width:60%;padding:8px 6px;border:1px solid #000;vertical-align:middle;white-space:nowrap;">
                            <strong>Batch No:</strong>
                            <span><?php 
                                $batchDisplay = htmlspecialchars($group['batch'] ?? '');
                                if (!empty($group['year_label'])) {
                                    $batchDisplay .= ' (' . htmlspecialchars(formatAcademicYear($group['year_label'])) . ')';
                                }
                                echo $batchDisplay;
                            ?></span>
                        </td>
                        <td style="width:40%;padding:8px 6px;border:1px solid #000;vertical-align:middle;text-align:left;white-space:nowrap;">
                            <strong style="display:inline-block;margin-right:6px;">Date:</strong>
                            <span><?php echo $gradedDate ?: date('d-m-Y'); ?></span>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <!-- Guide Row -->
        <tr>
            <td colspan="<?php echo 3 + count($students); ?>" class="label-cell"><strong>Name of the Project Guide:</strong> <?php echo htmlspecialchars($group['guide_name'] ?? ''); ?></td>
        </tr>
        <!-- Student Name Row -->
        <tr>
            <td colspan="3" class="label-cell" style="text-align:center;font-weight:700;"><strong>Student Name</strong></td>
            <?php foreach($students as $s): ?>
            <td style="text-align:center;"><?php echo htmlspecialchars($s['name']); ?></td>
            <?php endforeach; ?>
        </tr>
        <!-- USN Row -->
        <tr>
            <td colspan="3" class="label-cell" style="text-align:center;font-weight:700;"><strong>USN</strong></td>
            <?php foreach($students as $s): ?>
            <td style="text-align:center;"><?php echo htmlspecialchars($s['usn']); ?></td>
            <?php endforeach; ?>
        </tr>
        <!-- Evaluation Table Header Row -->
        <tr>
            <th>Sl.No</th>
            <th>Particulars</th>
            <th>Max Marks</th>
            <?php foreach($students as $s): ?>
            <th>Obtained Marks</th>
            <?php endforeach; ?>
        </tr>
        <!-- Criteria Rows -->
        <?php
        if (count($criteria) === 0) {
            echo '<tr><td colspan="' . (3 + count($students)) . '" style="padding:8px;border:1px solid #000;text-align:center">No criteria defined for this review.</td></tr>';
        } else {
            $i = 1;
            $studentTotals = [];
            foreach ($students as $s) $studentTotals[$s['id']] = 0;

            foreach ($criteria as $c) {
                echo '<tr>';
                echo '<td style="text-align:center;">' . $i . '</td>';
                echo '<td style="text-align:left;">' . htmlspecialchars($c['criterion_name']) . '</td>';
                echo '<td style="text-align:center;">' . htmlspecialchars($c['max_marks']) . '</td>';
                
                // Obtained Marks columns (dynamic per student)
                foreach ($students as $s) {
                    $mark = isset($marks[$s['id']][$c['id']]) ? $marks[$s['id']][$c['id']] : null;
                    if ($mark !== null) $studentTotals[$s['id']] += floatval($mark);
                    echo '<td style="text-align:center;">';
                    if ($mark !== null) echo htmlspecialchars(number_format(floatval($mark), 2));
                    echo '</td>';
                }
                echo '</tr>';
                $i++;
            }

            // TOTAL MARKS row
            echo '<tr style="font-weight:700;">';
            echo '<td colspan="2" style="text-align:right;">TOTAL MARKS</td>';
            echo '<td style="text-align:center;">' . htmlspecialchars(number_format($totalMax, 2)) . '</td>';
            foreach ($students as $s) {
                $val = $studentTotals[$s['id']] ?? 0;
                echo '<td style="border:1px solid #000;padding:6px;text-align:center;">' . htmlspecialchars(number_format($val, 2)) . '</td>';
            }
            echo '</tr>';
        }
        ?>
    </table>

    <?php
    // Show final marks table for Review 2 instead of remarks
    if ($displayReview == 2) {
        // compute review1 totals and student marks
        $totalMax1 = 0;
        $marks1 = [];
        if ($displayPhase && $displayPhase > 0) {
            $q = $conn->prepare("SELECT id FROM evaluation_sheets WHERE phase = ? AND review = 1 AND status = 'active' LIMIT 1");
            $q->bind_param('i', $displayPhase);
            $q->execute();
            $row1 = $q->get_result()->fetch_assoc();
            if ($row1 && isset($row1['id'])) {
                $sheet1 = intval($row1['id']);
                // total max marks for review1
                $stmt1 = $conn->prepare("SELECT max_marks FROM evaluation_criteria WHERE evaluation_sheet_id = ?");
                $stmt1->bind_param('i', $sheet1);
                $stmt1->execute();
                $res1 = $stmt1->get_result();
                while ($r1 = $res1->fetch_assoc()) {
                    $totalMax1 += floatval($r1['max_marks']);
                }
                // fetched student obtained totals for review1
                $marksQuery1 = "SELECT sg.student_id, SUM(sgd.marks_obtained) AS total_marks
                                FROM student_grades sg
                                LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
                                WHERE sg.evaluation_sheet_id = ? AND sg.group_id = ? AND sg.status IN ('submitted','approved')";
                if ($academicYear) {
                    $marksQuery1 .= " AND sg.academic_year_id = ?";
                }
                $stmt1 = $conn->prepare($marksQuery1);
                if ($academicYear) $stmt1->bind_param('iii', $sheet1, $groupId, $academicYear);
                else $stmt1->bind_param('ii', $sheet1, $groupId);
                $stmt1->execute();
                $res1 = $stmt1->get_result();
                while ($r1 = $res1->fetch_assoc()) {
                    $marks1[$r1['student_id']] = floatval($r1['total_marks']);
                }
            }
        }
        // build summary table
        ?>
        <div style="margin-bottom:6mm;">
            <h4 style="margin:6px 0 8px 0;font-size:14px;font-weight:700;">Final Marks</h4>
        
        <div style="margin-bottom:40px;">
            <table style="width:100%;border-collapse:collapse;margin-bottom:15px;border:1px solid #000;font-size:13px;">
                <tr>
                    <th style="border:1px solid #000;padding:6px;text-align:center;">Student Name</th>
                    <th style="border:1px solid #000;padding:6px;text-align:center;">USN</th>
                    <th style="border:1px solid #000;padding:6px;text-align:center;">Review 1<br><small><?php echo htmlspecialchars(number_format($totalMax1,2)); ?> Marks</small></th>
                    <th style="border:1px solid #000;padding:6px;text-align:center;">Review 2<br><small><?php echo htmlspecialchars(number_format($totalMax,2)); ?> Marks</small></th>
                    <th style="border:1px solid #000;padding:6px;text-align:center;">Final Marks<br><small><?php echo htmlspecialchars(number_format($totalMax1 + $totalMax,2)); ?> Marks</small></th>
                </tr>
                <?php
                foreach ($students as $s) {
                    $obt1 = isset($marks1[$s['id']]) ? floatval($marks1[$s['id']]) : 0;
                    $obt2 = isset($studentTotals[$s['id']]) ? floatval($studentTotals[$s['id']]) : 0;
                    $final = $obt1 + $obt2;
                    echo '<tr>';
                    echo '<td style="border:1px solid #000;padding:6px;text-align:center;">' . htmlspecialchars($s['name']) . '</td>';
                    echo '<td style="border:1px solid #000;padding:6px;text-align:center;">' . htmlspecialchars($s['usn']) . '</td>';
                    echo '<td style="border:1px solid #000;padding:6px;text-align:center;">' . htmlspecialchars(number_format($obt1,2)) . '</td>';
                    echo '<td style="border:1px solid #000;padding:6px;text-align:center;">' . htmlspecialchars(number_format($obt2,2)) . '</td>';
                    echo '<td style="border:1px solid #000;padding:6px;text-align:center;">' . htmlspecialchars(number_format($final,2)) . '</td>';
                    echo '</tr>';
                }
                ?>
            </table>
        </div>
    <?php } else { ?>
    <!-- Remarks Section -->
    <div class="remarks-section">
        <strong>Remarks:</strong>
        <div class="remarks-box"><?php echo !empty($remarks) ? nl2br(htmlspecialchars($remarks)) : '&nbsp;'; ?></div>
    </div>
    <?php } ?>

        </div> <!-- .evaluation-content -->

        <div class="signature-container">
            <!-- Signature section -->
            <?php if (getCurrentProjectType() === 'mini'): ?>
                <div class="signature-row">
            <div class="signature-field">
                <div class="signature-line"></div>
                <div class="signature-label">Signature of Guide</div>
            </div>
            <div class="signature-field">
                <div class="signature-line"></div>
                <div class="signature-label">Signature of Coordinator</div>
            </div>
        </div>
    <?php else: ?>
        <div class="signature-row">
            <div class="signature-field">
                <div class="signature-line"></div>
                <div class="signature-label">Signature of Guide</div>
            </div>
            <div class="signature-field">
                <div class="signature-line"></div>
                <div class="signature-label">Signature of Coordinator</div>
            </div>
            <div class="signature-field">
                <div class="signature-line"></div>
                <div class="signature-label">Signature of HOD - CSE</div>
            </div>
        </div>
    <?php endif; ?>
        </div> <!-- .signature-container -->
    </div> <!-- .evaluation-sheet -->

<?php
// END middle content

?>
