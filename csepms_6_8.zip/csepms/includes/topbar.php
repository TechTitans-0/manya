<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
             <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fa fa-bars"></i>
            </button>
                        <!-- Academic Year: students see fixed label; guides/coordinators see dropdown -->
                        <?php if (hasRole('student')): ?>
                            <?php
                                // For students, display the academic year label only (no selection)
                                $studentAyearId = isset($_SESSION['academic_year_id']) ? $_SESSION['academic_year_id'] : null;
                                if (!$studentAyearId && isset($_SESSION['role_id'])) {
                                    $tmp = $conn->prepare("SELECT academic_year_id FROM students WHERE id = ?");
                                    $tmp->bind_param('i', $_SESSION['role_id']);
                                    $tmp->execute();
                                    $res = $tmp->get_result();
                                    if ($r = $res->fetch_assoc()) $studentAyearId = $r['academic_year_id'];
                                }
                                $studentAyearLabel = 'Unknown';
                                if ($studentAyearId) {
                                    $ay = $conn->prepare("SELECT year_label FROM academic_years WHERE id = ?");
                                    $ay->bind_param('i', $studentAyearId);
                                    $ay->execute();
                                    $res = $ay->get_result();
                                    if ($row = $res->fetch_assoc()) $studentAyearLabel = formatAcademicYear($row['year_label']);
                                }
                            ?>
                            <div class="mr-3">
                                <button class="btn btn-outline-secondary" type="button" disabled>
                                    <?php echo htmlspecialchars($studentAyearLabel); ?>
                                </button>
                            </div>
                        <?php else: ?>
                        <!-- Academic Year Dropdown for guides and coordinators -->
                        <div class="dropdown mr-3">
                            <button class="btn btn-outline-primary dropdown-toggle" type="button" id="academicYearDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span id="selectedAcademicYear">Loading...</span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="academicYearDropdown" id="academicYearList">
                                <a class="dropdown-item" href="#">Loading...</a>
                            </div>
                        </div>
                        <?php endif; ?>
           
            
            <!-- Topbar Title -->
            <div class="d-none d-sm-inline-block mr-auto">
                <h5 class="mb-0 text-gray-800" id="topbarTitle">
                <?php
                // Only show title for major projects
                if (getCurrentProjectType() !== 'mini') {
                    // Get current phase from global settings
                    $phaseQuery = "SELECT setting_value FROM global_settings WHERE setting_key = 'current_phase'";
                    $phaseStmt = $conn->prepare($phaseQuery);
                    $phaseStmt->execute();
                    $phaseResult = $phaseStmt->get_result();
                    $phase = 1; // default
                    if ($phaseRow = $phaseResult->fetch_assoc()) {
                        $phase = $phaseRow['setting_value'];
                    }
                    echo "Project Management – Phase " . $phase;
                }
                // For mini projects, display nothing
                ?>
                </h5>
            </div>
            
            <!-- Topbar Search removed -->
            
            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">
                <?php $notifCount = $notifCount ?? 0; ?>
                <?php if (!hasRole('coordinator')): ?>
                <!-- Notifications Dropdown (hidden for coordinator) -->
                <li class="nav-item dropdown no-arrow mx-1">
                    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" 
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell fa-fw"></i>
                        <span id="topbar-notif-count" class="badge badge-danger badge-counter"><?php echo ($notifCount > 0) ? $notifCount : ''; ?></span>
                    </a>
                    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" 
                         aria-labelledby="alertsDropdown">
                        <h6 class="dropdown-header">Notifications</h6>
                        <div id="notificationsList">
                            <a class="dropdown-item text-center small text-gray-500" href="#">Loading...</a>
                        </div>
                        <a class="dropdown-item text-center small text-gray-500" 
                           href="<?php echo hasRole('student') ? 'notifications.php' : (hasRole('guide') ? '../guide/notifications.php' : '../coordinator/notifications.php'); ?>">
                            Show All Notifications
                        </a>
                    </div>
                </li>
                
                <div class="topbar-divider d-none d-sm-block"></div>
                <?php endif; ?>
                
                <!-- User Dropdown -->
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </span>
                        <i class="fas fa-user-circle fa-2x text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" 
                         aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="profile.php">
                            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                            Profile
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                            Logout
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <!-- End of Topbar -->

        <script>
        // Academic Year Dropdown Logic (with status, session, and UI rules)
        const isStudentRole = <?php echo hasRole('student') ? 'true' : 'false'; ?>;
        const isCoordinatorRole = <?php echo hasRole('coordinator') ? 'true' : 'false'; ?>;
        let selectedAcademicYearId = sessionStorage.getItem('academic_year_id') || '';
        let selectedAcademicYearStatus = sessionStorage.getItem('academic_year_status') || '';
        let academicYearsCache = [];
        function fetchAcademicYears() {
            fetch('<?php echo BASE_URL; ?>api/get-academic-years.php')
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.years.length > 0) {
                        academicYearsCache = data.years;
                        const yearList = document.getElementById('academicYearList');
                        yearList.innerHTML = '';
                        // Sort: ACTIVE first, then COMPLETED descending
                        data.years.sort((a, b) => {
                            if (a.status === 'ACTIVE' && b.status !== 'ACTIVE') return -1;
                            if (a.status !== 'ACTIVE' && b.status === 'ACTIVE') return 1;
                            return b.year_label.localeCompare(a.year_label);
                        });
                        data.years.forEach(year => {
                            const a = document.createElement('a');
                            a.className = 'dropdown-item';
                            a.href = '#';
                            let label = year.formatted_label || year.year_label;
                            if (year.status === 'ACTIVE') label += ' (Current Year)';
                            if (year.status === 'COMPLETED') label += ' <i class="fas fa-lock text-secondary"></i>';
                            a.innerHTML = label;
                            a.onclick = function() {
                                setAcademicYear(year.id, label.replace(' (Current Year)', '').replace(' <i class="fas fa-lock text-secondary"></i>', ''), year.status);
                                return false;
                            };
                            yearList.appendChild(a);
                        });
                        // No Add Academic Year button; handled by Close Academic Year only
                        // Set default if not set
                        if (!selectedAcademicYearId || !data.years.some(y => y.id == selectedAcademicYearId)) {
                            const active = data.years.find(y => y.status === 'ACTIVE');
                            if (active) {
                                const label = (active.formatted_label || active.year_label);
                                setAcademicYear(active.id, label, active.status, false);
                            } else {
                                const label = (data.years[0].formatted_label || data.years[0].year_label);
                                setAcademicYear(data.years[0].id, label, data.years[0].status, false);
                            }
                        } else {
                            const sel = data.years.find(y => y.id == selectedAcademicYearId);
                            if (sel) {
                                const label = (sel.formatted_label || sel.year_label);
                                document.getElementById('selectedAcademicYear').innerHTML = label + (sel.status === 'ACTIVE' ? ' (Current Year)' : ' <i class="fas fa-lock text-secondary"></i>');
                            }
                        }
                        // After choosing or defaulting, manage visibility of close option
                        updateCloseOptionVisibility(academicYearsCache);
                    }
                }).catch(error => {
                    console.error('Academic year load failed:', error);
                    const selected = document.getElementById('selectedAcademicYear');
                    if (selected) selected.innerText = 'Error loading';
                });
        }
        function setAcademicYear(id, label, status, reload = true) {
            selectedAcademicYearId = id;
            selectedAcademicYearStatus = status;
            sessionStorage.setItem('academic_year_id', id);
            sessionStorage.setItem('academic_year_status', status);
            document.getElementById('selectedAcademicYear').innerHTML = label + (status === 'ACTIVE' ? ' (Current Year)' : ' <i class="fas fa-lock text-secondary"></i>');
            // update close option visibility when selection changes
            updateCloseOptionVisibility(academicYearsCache);
            
            if (reload) {
                if (!isStudentRole) {
                    // For coordinators: call the coordinator API which may perform administrative actions
                    if (isCoordinatorRole) {
                        fetch('<?php echo BASE_URL; ?>api/set-academic-year.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: 'year_id=' + id
                        }).then(res => res.json()).then(data => {
                            if (data.success) {
                                location.reload();
                            } else {
                                alert('Failed to update academic year: ' + data.message);
                            }
                        }).catch(err => {
                            console.error('Error:', err);
                            location.reload();
                        });
                    } else {
                        // For guides/other non-coordinator roles: update server session only (no activation)
                        fetch('<?php echo BASE_URL; ?>api/set-academic-year-session.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: 'year_id=' + id
                        }).then(res => res.json()).then(data => {
                            if (data.success) {
                                location.reload();
                            } else {
                                alert('Failed to update academic year: ' + data.message);
                            }
                        }).catch(err => {
                            console.error('Error:', err);
                            location.reload();
                        });
                    }
                } else {
                    location.reload(); // For students, just reload (they can't change)
                }
            }
        }
        function addAcademicYear() {
            // Disabled: Academic year is only created by closing the current year
            alert('To add a new academic year, please use the "Close Academic Year" button on the dashboard.');
        }
        document.addEventListener('DOMContentLoaded', function() {
            if (!isStudentRole) fetchAcademicYears();
            else {
                // For students, set selectedAcademicYear from server-side session if present
                const sid = '<?php echo isset($_SESSION['academic_year_id']) ? (int)$_SESSION['academic_year_id'] : ''; ?>';
                const sstatus = '<?php echo isset($_SESSION['academic_year_status']) ? $_SESSION['academic_year_status'] : ''; ?>';
                if (sid) {
                    sessionStorage.setItem('academic_year_id', sid);
                    sessionStorage.setItem('academic_year_status', sstatus);
                }
            }
        });

        // Helper for view-only mode
        function isViewOnlyMode() {
            return selectedAcademicYearStatus === 'COMPLETED';
        }
        window.isViewOnlyMode = isViewOnlyMode;

        // Coordinator action: close academic year
        function closeAcademicYear() {
            // Confirm using similar flow as dashboard
            // Fetch years to get active label
            fetch('<?php echo BASE_URL; ?>api/get-academic-years.php')
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.years && data.years.length > 0) {
                        const active = data.years.find(y => y.status === 'ACTIVE');
                        if (!active) {
                            Swal.fire('Error', 'No active academic year found.', 'error');
                            return;
                        }
                        Swal.fire({
                            title: 'Close Academic Year?',
                            html: 'Current Active Year: <b>' + (active.formatted_label || active.year_label) + '</b><br>This will mark it as COMPLETED and create the next academic year. This action cannot be undone.',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: 'Yes, Close Year',
                            cancelButtonText: 'Cancel'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                fetch('<?php echo BASE_URL; ?>api/close-academic-year.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                                }).then(res => res.json()).then(resp => {
                                    if (resp.success) {
                                        sessionStorage.setItem('academic_year_id', resp.new_year.id);
                                        sessionStorage.setItem('academic_year_status', resp.new_year.status);
                                        if (typeof fetchAcademicYears === 'function') fetchAcademicYears();
                                        Swal.fire('Closed!', resp.message, 'success').then(() => {
                                            location.reload();
                                        });
                                    } else {
                                        Swal.fire('Error', resp.message, 'error');
                                    }
                                }).catch(() => {
                                    Swal.fire('Error', 'Failed to close academic year.', 'error');
                                });
                            }
                        });
                    } else {
                        Swal.fire('Error', 'Could not fetch academic years.', 'error');
                    }
                });
        }

        // Manage showing/hiding of close option in dropdown
        function updateCloseOptionVisibility(years) {
            // fallback to cache if none provided
            if (!years) years = academicYearsCache;
            // Determine status of currently selected year
            const selYear = years && selectedAcademicYearId ? years.find(y => y.id == selectedAcademicYearId) : null;
            const show = isCoordinatorRole && selYear && selYear.status !== 'COMPLETED';
            let existing = document.getElementById('closeAcademicYearOption');
            if (show) {
                if (!existing) {
                    const yearList = document.getElementById('academicYearList');
                    const divider = document.createElement('div');
                    divider.className = 'dropdown-divider';
                    yearList.appendChild(divider);
                    const a = document.createElement('a');
                    a.className = 'dropdown-item text-danger';
                    a.href = '#';
                    a.id = 'closeAcademicYearOption';
                    a.innerHTML = '<i class="fas fa-lock"></i> Close Academic Year';
                    a.onclick = function() { closeAcademicYear(); return false; };
                    yearList.appendChild(a);
                }
            } else if (existing) {
                // remove divider + option - simplest is remove existing and any preceding divider
                const prev = existing.previousElementSibling;
                if (prev && prev.classList.contains('dropdown-divider')) prev.remove();
                existing.remove();
            }
        }
        </script>
        
        <!-- Begin Page Content -->
        <div class="container-fluid">
