        </div>
        <!-- End of Page Content -->
    </div>
    <!-- End of Main Content -->
    
    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Project Management System Developed by <br>Chandana B C (4GW23CS020) and Manya V(4GW23CS058) <br>
                under the guidence of Dr. Rajashekar M B, Associate Professor and 
                Mr. Mahadevappa N, System Analyst, Department of CSE </span>
            </div>
        </div>
    </footer>
</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?php echo BASE_URL; ?>api/logout.php">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/js/sb-admin-2.min.js"></script>

<!-- DataTables -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>

<script>
    // Project fields show/hide logic for group creation
    $(document).ready(function() {
        if ($('#projectFieldsContainer').length) {
            $('#projectFieldsContainer').show();
            $('#projectDomain').on('change', function() {
                if ($(this).val() === 'Any others') {
                    $('#customDomainContainer').show();
                } else {
                    $('#customDomainContainer').hide();
                }
            });
        }
    });
    // Load notifications in dropdown
    function loadNotifications() {
        // Determine notifications page based on role
        var notifPage = '<?php echo BASE_URL; ?>' + (<?php echo json_encode(isset($_SESSION['role']) ? $_SESSION['role'] : ''); ?> === 'student' ? 'student/notifications.php' : (<?php echo json_encode(isset($_SESSION['role']) ? $_SESSION['role'] : ''); ?> === 'guide' ? 'guide/notifications.php' : 'coordinator/notifications.php'));

        $.ajax({
            url: '<?php echo BASE_URL; ?>api/get-notifications.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var unread = (data.notifications && Array.isArray(data.notifications)) ? data.notifications.length : 0;
                $('#topbar-notif-count').text(unread > 0 ? unread : '');

                if (data.success && data.notifications.length > 0) {
                    let html = '';
                    data.notifications.slice(0, 5).forEach(function(notif) {
                        // If attachment exists, provide a small download icon
                        let attachHtml = '';
                        if (notif.attachment_path) {
                            attachHtml = `<a href="<?php echo BASE_URL; ?>${notif.attachment_path}" class="ml-2 text-primary" target="_blank" title="View attachment"><i class="fas fa-paperclip"></i></a>`;
                        }

                        html += `
                            <a class="dropdown-item d-flex align-items-center notif-item" href="#" data-id="${notif.id}">
                                <div class="mr-3">
                                    <div class="icon-circle bg-primary">
                                        <i class="fas fa-bell text-white"></i>
                                    </div>
                                </div>
                                <div style="flex:1">
                                    <div class="small text-gray-500">${notif.created_at}</div>
                                    <span class="font-weight-bold">${notif.title}</span>
                                </div>
                                <div>${attachHtml}</div>
                            </a>
                        `;
                    });
                    $('#notificationsList').html(html);

                    // Attach click handler: mark as read then redirect to notifications page
                    $('.notif-item').on('click', function(e) {
                        e.preventDefault();
                        var nid = $(this).data('id');
                        $.ajax({
                            url: '<?php echo BASE_URL; ?>api/mark-notification-read.php',
                            method: 'POST',
                            data: { notification_id: nid },
                            dataType: 'json',
                            complete: function() {
                                // Redirect to notifications page
                                window.location.href = notifPage;
                            }
                        });
                    });

                } else {
                    $('#notificationsList').html('<a class="dropdown-item text-center small text-gray-500" href="#">No new notifications</a>');
                }
            }
        });
    }
    
    // Load notifications on page load
    $(document).ready(function() {
        loadNotifications();
        
        // Refresh notifications every 30 seconds
        setInterval(loadNotifications, 30000);
    });

    // Update sidebar unread badges (messages + notifications)
    function updateSidebarUnread() {
        $.ajax({
            url: '<?php echo BASE_URL; ?>api/get-unread-counts.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    // Messages badge
                    var m = parseInt(data.messages || 0);
                    var chatBadgeSpan = $('#sidebar-unread-chat-badge');
                    chatBadgeSpan.empty();
                    if (m > 0) {
                        chatBadgeSpan.html('<span class="badge badge-primary ml-2">' + m + '</span>');
                    }

                    // Notifications badge
                    var n = parseInt(data.notifications || 0);
                    var notifBadgeSpan = $('#sidebar-unread-notif-badge');
                    notifBadgeSpan.empty();
                    if (n > 0) {
                        notifBadgeSpan.html('<span class="badge badge-danger ml-2">' + n + '</span>');
                    }
                }
            }
        });
    }

    // Poll unread counts every 10 seconds
    $(document).ready(function() {
        updateSidebarUnread();
        setInterval(updateSidebarUnread, 10000);

        // Intercept sidebar notifications click to mark all as read then navigate
        $(document).on('click', 'a.nav-link[href$="notifications.php"]', function(e) {
            e.preventDefault();
            var href = $(this).attr('href');
            $.ajax({
                url: '<?php echo BASE_URL; ?>api/mark-all-notifications-read.php',
                method: 'POST',
                dataType: 'json'
            }).always(function() {
                // update badge immediately and go to page
                $('#sidebar-unread-notif-badge').empty();
                window.location.href = href;
            });
        });

        // Intercept sidebar chat/messages click to mark all messages as read then navigate
        $(document).on('click', 'a.nav-link[href$="chat.php"], a.nav-link[href$="messages.php"]', function(e) {
            e.preventDefault();
            var href = $(this).attr('href');
            $.ajax({
                url: '<?php echo BASE_URL; ?>api/mark-all-messages-read.php',
                method: 'POST',
                dataType: 'json'
            }).always(function() {
                $('#sidebar-unread-chat-badge').empty();
                window.location.href = href;
            });
        });
    });
</script>

</body>
</html>
