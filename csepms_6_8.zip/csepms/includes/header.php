<?php
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get unread notification count

// Only count unread circulars from coordinator
$notifCount = 0;
$notifQuery = "SELECT COUNT(*) as count
    FROM notification_read_status nrs
    INNER JOIN notifications n ON n.id = nrs.notification_id
    INNER JOIN users u ON n.sender_id = u.id
    WHERE nrs.user_id = ? AND nrs.is_read = 0 AND n.title LIKE 'Circular:%' AND u.role = 'coordinator'";
$stmt = $conn->prepare($notifQuery);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$notifResult = $stmt->get_result();
if ($row = $notifResult->fetch_assoc()) {
    $notifCount = $row['count'];
}

// Get unread chat/messages count for current user
$unreadMsgCount = 0;
$msgQuery = "SELECT COUNT(*) as cnt FROM chat_messages WHERE receiver_id = ? AND is_read = 0 AND sender_id != receiver_id";
$mstmt = $conn->prepare($msgQuery);
$mstmt->bind_param('i', $_SESSION['user_id']);
$mstmt->execute();
$mres = $mstmt->get_result();
if ($mrow = $mres->fetch_assoc()) {
    $unreadMsgCount = $mrow['cnt'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $pageTitle ?? 'Dashboard'; ?> - FYPM System</title>
    
    <!-- SB Admin 2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    
    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css" rel="stylesheet">
    
    <!-- Custom responsive tweaks -->
    <link href="../assets/css/responsive.css" rel="stylesheet">
    
    <!-- jQuery (must be loaded before any scripts that use $) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    
    <style>
        .sidebar {
            background: linear-gradient(180deg, #4e73df 10%, #224abe 100%);
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #e74a3b;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body id="page-top">
    <div id="wrapper">
