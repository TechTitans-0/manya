<script>
function downloadEvaluationSheetPDF(opts) {
    // opts: { group_id, evaluation_sheet_id, phase, review, academic_year }
    const params = { group_id: opts.group_id };
    if (opts.evaluation_sheet_id) params.evaluation_sheet_id = opts.evaluation_sheet_id;
    if (typeof opts.phase !== 'undefined') params.phase = opts.phase;
    if (typeof opts.review !== 'undefined') params.review = opts.review;
    if (opts.academic_year) params.academic_year = opts.academic_year;

    $.ajax({
        url: '../api/download-evaluation-sheet.php',
        method: 'GET',
        data: params,
        dataType: 'json',
        success: function(resp) {
            if (resp.success) {
                // Ensure html2pdf is loaded, then generate direct PDF download (no print preview, no new tab)
                function generatePdf(htmlContent) {
                    // create container
                    const container = document.createElement('div');
                    container.style.position = 'fixed';
                    container.style.left = '-10000px';
                    container.style.top = '0';
                    container.innerHTML = htmlContent;
                    document.body.appendChild(container);

                    // select the pdf-wrapper div which contains header + sheet
                    const pdfEl = container.querySelector('.pdf-wrapper') || container;

                    // wait for all images to load
                    function waitForImages(el) {
                        const imgs = Array.from(el.querySelectorAll('img'));
                        if (imgs.length === 0) return Promise.resolve();
                        
                        return Promise.race([
                            Promise.all(imgs.map(img => 
                                new Promise(resolve => {
                                    if (img.complete) {
                                        resolve();
                                    } else {
                                        img.onload = img.onerror = resolve;
                                    }
                                })
                            )),
                            new Promise(resolve => setTimeout(resolve, 2000)) // 2 second max wait
                        ]);
                    }

                    waitForImages(pdfEl).then(() => {
                        setTimeout(() => {
                            const opt = {
                                filename: resp.filename || 'evaluation_sheet.pdf',
                                image: { type: 'jpeg', quality: 0.98 },
                                html2canvas: {
                                    scale: 1.4,
                                    useCORS: true,
                                    allowTaint: true,
                                    logging: false,
                                    backgroundColor: '#ffffff'
                                },
                                jsPDF: {
                                    unit: 'mm',
                                    format: 'a4',
                                    orientation: 'portrait'
                                },
                                margin: [2,2,2,2],
                                pagebreak: { mode: ['avoid-all','css'] }
                            };
                            
                            html2pdf().set(opt).from(pdfEl).save()
                                .then(() => {
                                    if (document.body.contains(container)) {
                                        document.body.removeChild(container);
                                    }
                                })
                                .catch((err) => {
                                    console.error('PDF error:', err);
                                    if (document.body.contains(container)) {
                                        document.body.removeChild(container);
                                    }
                                    Swal.fire('Error', 'PDF generation failed', 'error');
                                });
                        }, 500);
                    });
                }

                // Load html2pdf if not present
                if (typeof html2pdf === 'undefined') {
                    const s = document.createElement('script');
                    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js';
                    s.onload = function() { generatePdf(resp.html); };
                    s.onerror = function() { Swal.fire('Error', 'Failed to load PDF library', 'error'); };
                    document.head.appendChild(s);
                } else {
                    generatePdf(resp.html);
                }
            } else {
                Swal.fire('Error', resp.message || 'Failed to generate sheet', 'error');
            }
        },
        error: function(xhr, status, err) {
            console.error('Download sheet AJAX error:', status, err, xhr.responseText);
            // Try to parse JSON error message from server output (in case of PHP warnings / stack trace)
            try {
                var parsed = JSON.parse(xhr.responseText);
                Swal.fire('Error', parsed.message || 'Failed to generate sheet', 'error');
            } catch (e) {
                // fallback: show a trimmed portion of server response to help debugging
                var text = (xhr.responseText || '').trim();
                if (text.length > 0) {
                    var short = text.length > 800 ? text.substring(0, 800) + '...' : text;
                    Swal.fire({ title: 'Error', html: '<pre style="font-size:12px;white-space:pre-wrap;max-height:320px;overflow:auto">' + $('<div/>').text(short).html() + '</pre>', icon: 'error' });
                } else {
                    Swal.fire('Error', 'Failed to generate sheet', 'error');
                }
            }
        }
    });
}
</script>
