<!-- Sidebar for Student -->
<?php if (hasRole('student')): ?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <div class="sidebar-brand-text mx-3">FYPM System</div>
    </a>
    
    <hr class="sidebar-divider my-0">
    
    <li class="nav-item <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">Project Management</div>
    
    <li class="nav-item <?php echo ($currentPage == 'profile') ? 'active' : ''; ?>">
        <a class="nav-link" href="profile.php">
            <i class="fas fa-fw fa-user"></i>
            <span>My Profile</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'group') ? 'active' : ''; ?>">
        <a class="nav-link" href="group.php">
            <i class="fas fa-fw fa-users"></i>
            <span>My Group</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'uploads') ? 'active' : ''; ?>">
        <a class="nav-link" href="uploads.php">
            <i class="fas fa-fw fa-upload"></i>
            <span>Uploads</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'grades') ? 'active' : ''; ?>">
        <a class="nav-link" href="grades.php">
            <i class="fas fa-fw fa-star"></i>
            <span>My Grades</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">Communication</div>
    
    <?php if (getCurrentProjectType() !== 'mini'): ?>
    <li class="nav-item <?php echo ($currentPage == 'chat') ? 'active' : ''; ?>">
        <a class="nav-link" href="chat.php">
            <i class="fas fa-fw fa-comments"></i>
            <span>Chat</span>
            <span id="sidebar-unread-chat-badge">
                <?php if (!empty($unreadMsgCount) && $unreadMsgCount > 0): ?>
                    <span class="badge badge-primary ml-2"><?php echo $unreadMsgCount; ?></span>
                <?php endif; ?>
            </span>
        </a>
    </li>
    <?php endif; ?>
    
    <li class="nav-item <?php echo ($currentPage == 'notifications') ? 'active' : ''; ?>">
        <a class="nav-link" href="notifications.php">
            <i class="fas fa-fw fa-bell"></i>
            <span>Notifications</span>
            <span id="sidebar-unread-notif-badge">
                <?php if (!empty($notifCount) && $notifCount > 0): ?>
                    <span class="badge badge-danger ml-2"><?php echo $notifCount; ?></span>
                <?php endif; ?>
            </span>
        </a>
    </li>
    
    <hr class="sidebar-divider d-none d-md-block">
    
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>

<?php elseif (hasRole('guide')): ?>
<!-- Sidebar for Guide -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-chalkboard-teacher"></i>
        </div>
        <div class="sidebar-brand-text mx-3">FYPM System</div>
    </a>
    
    <hr class="sidebar-divider my-0">
    
    <li class="nav-item <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">Management</div>
    
    <li class="nav-item <?php echo ($currentPage == 'profile') ? 'active' : ''; ?>">
        <a class="nav-link" href="profile.php">
            <i class="fas fa-fw fa-user"></i>
            <span>My Profile</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'groups') ? 'active' : ''; ?>">
        <a class="nav-link" href="groups.php">
            <i class="fas fa-fw fa-users"></i>
            <span>My Groups</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'reviews') ? 'active' : ''; ?>">
        <a class="nav-link" href="reviews.php">
            <i class="fas fa-fw fa-tasks"></i>
            <span>Review Uploads</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'grading') ? 'active' : ''; ?>">
        <a class="nav-link" href="grading.php">
            <i class="fas fa-fw fa-clipboard-check"></i>
            <span>Grading</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">Communication</div>
    
    <?php if (getCurrentProjectType() !== 'mini'): ?>
    <li class="nav-item <?php echo ($currentPage == 'chat') ? 'active' : ''; ?>">
        <a class="nav-link" href="chat.php">
            <i class="fas fa-fw fa-comments"></i>
            <span>Chat</span>
            <?php if (!empty($unreadMsgCount) && $unreadMsgCount > 0): ?>
                <span class="badge badge-primary ml-2"><?php echo $unreadMsgCount; ?></span>
            <?php endif; ?>
        </a>
    </li>
    <?php endif; ?>
    
    <li class="nav-item <?php echo ($currentPage == 'notifications') ? 'active' : ''; ?>">
        <a class="nav-link" href="notifications.php">
            <i class="fas fa-fw fa-bell"></i>
            <span>Notifications</span>
        </a>
    </li>
    
    <hr class="sidebar-divider d-none d-md-block">
    
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>

<?php elseif (hasRole('coordinator')): ?>
<!-- Sidebar for Coordinator -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-user-shield"></i>
        </div>
        <div class="sidebar-brand-text mx-3">FYPM System</div>
    </a>
    
    <hr class="sidebar-divider my-0">
    
    <li class="nav-item <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">User Management</div>
    <li class="nav-item <?php echo ($currentPage == 'profile') ? 'active' : ''; ?>">
        <a class="nav-link" href="profile.php">
            <i class="fas fa-fw fa-user"></i>
            <span>My Profile</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'students') ? 'active' : ''; ?>">
        <a class="nav-link" href="students.php">
            <i class="fas fa-fw fa-user-graduate"></i>
            <span>Students</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'staff') ? 'active' : ''; ?>">
        <a class="nav-link" href="staff.php">
            <i class="fas fa-fw fa-chalkboard-teacher"></i>
            <span>Staff/Guides</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo ($currentPage == 'groups') ? 'active' : ''; ?>">
        <a class="nav-link" href="groups.php">
            <i class="fas fa-fw fa-users"></i>
            <span>Groups</span>
        </a>
    </li>
    <li class="nav-item <?php echo ($currentPage == 'my-groups') ? 'active' : ''; ?>">
        <a class="nav-link" href="my-groups.php">
            <i class="fas fa-fw fa-user-friends"></i>
            <span>My Groups</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">Project Configuration</div>
    
    <li class="nav-item <?php echo ($currentPage == 'evaluation-sheets') ? 'active' : ''; ?>">
        <a class="nav-link" href="evaluation-sheets.php">
            <i class="fas fa-fw fa-file-alt"></i>
            <span>Evaluation Sheets</span>
        </a>
    </li>
    <li class="nav-item <?php echo ($currentPage == 'reports') ? 'active' : ''; ?>">
        <a class="nav-link" href="reports.php">
            <i class="fas fa-fw fa-chart-bar"></i>
            <span>Reports</span>
        </a>
    </li>
    
    <hr class="sidebar-divider">
    
    <div class="sidebar-heading">Communication</div>
    
    <li class="nav-item <?php echo ($currentPage == 'circulars') ? 'active' : ''; ?>">
        <a class="nav-link" href="circulars.php">
            <i class="fas fa-fw fa-bullhorn"></i>
            <span>Circulars</span>
        </a>
    </li>
    
    <?php if (getCurrentProjectType() !== 'mini'): ?>
    <li class="nav-item <?php echo ($currentPage == 'chat') ? 'active' : ''; ?>">
        <a class="nav-link" href="chat.php">
            <i class="fas fa-fw fa-comments"></i>
            <span>Messages</span>
            <?php if (!empty($unreadMsgCount) && $unreadMsgCount > 0): ?>
                <span class="badge badge-primary ml-2"><?php echo $unreadMsgCount; ?></span>
            <?php endif; ?>
        </a>
    </li>
    <?php endif; ?>
    
    <hr class="sidebar-divider d-none d-md-block">
    
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<?php endif; ?>
