<?php
// Prevent directory access to the includes folder.
header('Location: /csepms/index.php');
exit;
