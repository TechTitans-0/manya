<script>
// Shared group details / grades / uploads scripts reused by guide and coordinator
function viewGroupDetails(groupId, detailsOnly = false) {
    $('#groupDetailsModal').modal('show');
    let html = `<div id="detailsContent"></div>`;
    $('#groupDetailsContent').html(html);

    $.ajax({
        url: '../api/get-group-details.php',
        type: 'GET',
        data: { group_id: groupId },
        success: function(response) {
            if (response.success) {
                const group = response.group;
                const members = response.members;

                let detailsHtml = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Group Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Group Name:</strong></td><td>${group.group_name}</td></tr>
                                <tr><td><strong>Batch:</strong></td><td>${group.batch} ${group.academic_year_label ? '(' + group.academic_year_label + ')' : ''}</td></tr>
                                ${window.isMiniProject ? '' : `<tr><td><strong>Current Phase:</strong></td><td>Phase ${group.current_phase || '1'}</td></tr>`}
                                ${window.isMiniProject ? '' : `<tr><td><strong>Current Review:</strong></td><td>Review ${group.current_review || '1'}</td></tr>`}
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Project Information</h6>
                            <table class="table table-sm">
                                <tr><td><strong>Title:</strong></td><td>${group.project_title || 'Not set'}</td></tr>
                                <tr><td colspan="2"><strong>Description:</strong><br><span class="text-muted">${group.project_description || 'Not set'}</span></td></tr>
                            </table>
                        </div>
                    </div>
                    <hr>
                    <h6 class="font-weight-bold">Group Members</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead><tr><th>Name</th><th>USN</th><th>Email</th><th>Phone</th><th>Role</th></tr></thead>
                            <tbody>`;

                members.forEach(member => {
                    detailsHtml += `
                        <tr>
                            <td>${member.full_name || member.username}</td>
                            <td>${member.usn}</td>
                            <td>${member.email}</td>
                            <td>${member.phone || 'N/A'}</td>
                            <td>${member.is_team_lead == 1 ? '<span class="badge badge-primary">Team Lead</span>' : 'Member'}</td>
                        </tr>`;
                });

                detailsHtml += `</tbody></table></div>`;
                $('#detailsContent').html(detailsHtml);
            } else {
                $('#detailsContent').html('<div class="alert alert-danger">Failed to load group details</div>');
            }
        },
        error: function() {
            $('#detailsContent').html('<div class="alert alert-danger">Error loading group details</div>');
        }
    });

    // If not details-only, load grades and uploads into the same modal as in guide implementation
    if (!detailsOnly) {
        // Grades
        $.ajax({
            url: '../api/get-group-grades.php',
            type: 'GET',
            data: { group_id: groupId },
            dataType: 'json',
            success: function(response) {
                // append or show grades section similar to guide implementation
                if (response.success) {
                    const grades = response.grades;
                    // Build grades HTML (reuse guide formatting)
                    let gradesHtml = '';
                    if (!grades || grades.length === 0) {
                        gradesHtml = '<div class="alert alert-info mt-3">No grades available yet.</div>';
                    } else {
                        let phaseReviewMap = {};
                        for (let i = 0; i < grades.length; i++) {
                            const grade = grades[i];
                            const sheetKey = grade.phase + '-' + grade.review + '-' + grade.sheet_title;
                            if (!phaseReviewMap[sheetKey]) phaseReviewMap[sheetKey] = [];
                            phaseReviewMap[sheetKey].push({grade, idx: i});
                        }
                        Object.keys(phaseReviewMap).forEach(sheetKey => {
                            const groupArr = phaseReviewMap[sheetKey];
                            const firstGrade = groupArr[0].grade;
                            // Add Edit button for phase/review (both guides and coordinators can edit) - disabled if academic year is COMPLETED
                            const editBtnClass = (typeof academicYearStatus !== 'undefined' && academicYearStatus === 'COMPLETED') ? 'disabled' : '';
                            const editBtnState = (typeof academicYearStatus !== 'undefined' && academicYearStatus === 'COMPLETED') ? 'disabled' : '';
                            gradesHtml += `<div class="d-flex justify-content-between align-items-center mt-3"><h6 class="font-weight-bold mb-0">Phase ${firstGrade.phase} - Review ${firstGrade.review} - ${firstGrade.sheet_title}</h6><button class="btn btn-sm btn-primary edit-grade-btn ${editBtnClass}" data-sheetkey="${sheetKey}" ${editBtnState}>Edit</button></div>`;
                            gradesHtml += '<div class="mb-2"><strong>Overall Remarks:</strong> ' + (firstGrade.overall_remarks ? firstGrade.overall_remarks : '<span class="text-muted">-</span>') + '</div>';
                            gradesHtml += '<div class="table-responsive"><table class="table table-bordered table-sm"><thead><tr class="bg-light"><th>Student Name</th><th>USN</th><th>Criteria</th><th>Total Marks</th><th>Status</th><th>Graded On</th></tr></thead><tbody>';
                            groupArr.forEach(({grade}) => {
                                let statusBadge = (grade.status === 'submitted' || grade.status === 'approved') ? '<span class="badge badge-success">Submitted</span>' : '<span class="badge badge-warning">Draft</span>';
                                gradesHtml += `<tr><td>${grade.student_name}</td><td>${grade.usn}</td><td>${(grade.criteria && grade.criteria.length>0)?'<ul class="mb-0 pl-3>'+grade.criteria.map(c=>'<li>'+c.criterion_name+': <strong>'+parseFloat(c.marks_obtained).toFixed(2)+'</strong>/'+parseFloat(c.max_marks).toFixed(2)+'</li>').join('')+'</ul>':'<span class="text-muted">-</span>'}</td><td>${grade.total_marks.toFixed(2)}</td><td>${statusBadge}</td><td>${grade.graded_at?new Date(grade.graded_at).toLocaleDateString():'-'}</td></tr>`;
                            });
                            gradesHtml += '</tbody></table></div>';
                        });
                    }
                    $('#detailsContent').append(`<hr><h6 class="font-weight-bold">Grades</h6>` + gradesHtml);

                    // Attach handler to Edit buttons for each phase/review
                    $('#detailsContent').find('.edit-grade-btn').each(function() {
                        const sheetKey = $(this).data('sheetkey');
                        const group = phaseReviewMap[sheetKey];
                        // Fallback for groupId
                        let groupIdVal = group[0].grade.group_id || group[0].grade.groupId || group[0].grade.id || '';
                        if (!groupIdVal) {
                            console.error('No group_id found in grade object:', group[0].grade);
                            return;
                        }
                        $(this).on('click', function() {
                            openPhaseReviewEditModal(group, groupIdVal);
                        });
                    });
                } else {
                    $('#detailsContent').append('<hr><div class="alert alert-info">No grades available yet</div>');
                }
            },
            error: function() {
                $('#detailsContent').append('<hr><div class="alert alert-danger">Error loading grades</div>');
            }
        });

        // Uploads
        $.ajax({
            url: '../api/get-uploads.php',
            type: 'GET',
            data: { group_id: groupId },
            dataType: 'json',
            success: function(resp) {
                if (resp.success && resp.uploads && resp.uploads.length>0) {
                    let uploadsHtml = '<div class="table-responsive"><table class="table table-sm table-bordered"><thead><tr><th>File</th><th>Uploaded On</th><th>Status</th></tr></thead><tbody>';
                    resp.uploads.forEach(u => {
                        uploadsHtml += `<tr><td><a href="../uploads/${u.file_path}" target="_blank">${u.file_name}</a></td><td>${u.uploaded_at}</td><td>${u.status}</td></tr>`;
                    });
                    uploadsHtml += '</tbody></table></div>';
                    $('#detailsContent').append('<hr><h6 class="font-weight-bold">Uploads</h6>' + uploadsHtml);
                } else {
                    $('#detailsContent').append('<hr><h6 class="font-weight-bold">Uploads</h6><div class="alert alert-info">No uploads found.</div>');
                }
            },
            error: function() {
                $('#detailsContent').append('<hr><div class="alert alert-danger">Error loading uploads</div>');
            }
        });
    }
}

function viewGroupGrades(groupId) {
    // reuse same modal and load grades only
    $('#groupDetailsModal').modal('show');
    $('#groupDetailsContent').html('<div class="text-center py-4"><div class="spinner-border" role="status"></div><p class="mt-2">Loading grades...</p></div>');
    $.ajax({
        url: '../api/get-group-grades.php',
        type: 'GET',
        data: { group_id: groupId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const grades = response.grades;
                if (!grades || grades.length === 0) {
                    $('#groupDetailsContent').html('<div class="text-center py-4"><i class="fas fa-info-circle fa-2x"></i><p class="mt-2">No grades available yet.</p></div>');
                    return;
                }
                let gradesHtml = '';
                let phaseReviewMap = {};
                for (let i = 0; i < grades.length; i++) {
                    const grade = grades[i];
                    const sheetKey = grade.phase + '-' + grade.review + '-' + grade.sheet_title;
                    if (!phaseReviewMap[sheetKey]) phaseReviewMap[sheetKey] = [];
                    phaseReviewMap[sheetKey].push({grade, idx: i});
                }
                Object.keys(phaseReviewMap).forEach(sheetKey => {
                    const groupArr = phaseReviewMap[sheetKey];
                    const firstGrade = groupArr[0].grade;
                    gradesHtml += `<div class="d-flex justify-content-between align-items-center mt-3"><h6 class="font-weight-bold mb-0">Phase ${firstGrade.phase} - Review ${firstGrade.review} - ${firstGrade.sheet_title}</h6><button class="btn btn-sm btn-primary edit-grade-btn ${(typeof academicYearStatus !== 'undefined' && academicYearStatus === 'COMPLETED') ? 'disabled' : ''}" data-sheetkey="${sheetKey}" ${(typeof academicYearStatus !== 'undefined' && academicYearStatus === 'COMPLETED') ? 'disabled' : ''}>Edit</button></div>`;
                    gradesHtml += '<div class="table-responsive"><table class="table table-bordered table-sm"><thead><tr class="bg-light"><th>Student Name</th><th>USN</th><th>Criteria</th><th>Total Marks</th><th>Status</th><th>Graded On</th></tr></thead><tbody>';
                    groupArr.forEach(({grade}) => {
                        let statusBadge = (grade.status === 'submitted' || grade.status === 'approved') ? '<span class="badge badge-success">Submitted</span>' : '<span class="badge badge-warning">Draft</span>';
                        gradesHtml += `<tr><td>${grade.student_name}</td><td>${grade.usn}</td><td>${(grade.criteria && grade.criteria.length>0)?'<ul class="mb-0 pl-3">'+grade.criteria.map(c=>'<li>'+c.criterion_name+': <strong>'+parseFloat(c.marks_obtained).toFixed(2)+'</strong>/'+parseFloat(c.max_marks).toFixed(2)+'</li>').join('')+'</ul>':'<span class="text-muted">-</span>'}</td><td>${grade.total_marks.toFixed(2)}</td><td>${statusBadge}</td><td>${grade.graded_at?new Date(grade.graded_at).toLocaleDateString():'-'}</td></tr>`;
                    });
                    gradesHtml += '</tbody></table></div>';
                    // Show overall remarks for this evaluation sheet if present
                    if (firstGrade.overall_remarks && firstGrade.overall_remarks.trim() !== '') {
                        gradesHtml += `<div class="alert alert-info mt-3 mb-0">
                            <h6 class="font-weight-bold mb-2">Overall Remarks:</h6>
                            <p class="mb-0" style="white-space: pre-wrap;">${firstGrade.overall_remarks}</p>
                        </div>`;
                    }
                });
                $('#groupDetailsContent').html(gradesHtml);

                // Attach handler to Edit buttons in grades view
                $('#groupDetailsContent').find('.edit-grade-btn').each(function() {
                    const sheetKey = $(this).data('sheetkey');
                    const group = phaseReviewMap[sheetKey];
                    let groupIdVal = group[0].grade.group_id || group[0].grade.groupId || group[0].grade.id || '';
                    if (!groupIdVal) return;
                    $(this).on('click', function() {
                        openPhaseReviewEditModal(group, groupIdVal);
                    });
                });
            } else {
                $('#groupDetailsContent').html('<div class="alert alert-info">No grades available yet</div>');
            }
        },
        error: function() {
            $('#groupDetailsContent').html('<div class="alert alert-danger">Error loading grades</div>');
        }
    });
}

// Modal to edit all students for a phase/review (shared)
function openPhaseReviewEditModal(groupGrades, groupId) {
    const initialRemarks = groupGrades[0].grade.overall_remarks || '';
    let html = `
        <div class="modal-header">
            <h5 class="modal-title">Edit Grades - Phase ${groupGrades[0].grade.phase} / Review ${groupGrades[0].grade.review} / ${groupGrades[0].grade.sheet_title}</h5>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="phaseReviewGradeForm">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered">
                        <thead>
                            <tr><th>Student</th><th>USN</th><th>Criteria</th><th class="text-center">Current Total</th></tr>
                        </thead>
                        <tbody>
    `;
    groupGrades.forEach(({grade}, idx) => {
        const totalMarks = (typeof grade.total_marks !== 'undefined' && grade.total_marks !== null) ? parseFloat(grade.total_marks).toFixed(2) : '0.00';
        const maxMarks = (typeof grade.max_marks !== 'undefined' && grade.max_marks !== null) ? parseFloat(grade.max_marks).toFixed(2) : '0.00';
        html += `<tr><td>${grade.student_name}</td><td>${grade.usn}</td><td>`;
        (grade.criteria || []).forEach(function(c) {
            const val = (typeof c.marks_obtained !== 'undefined') ? parseFloat(c.marks_obtained).toFixed(2) : '';
            const max = (typeof c.max_marks !== 'undefined') ? parseFloat(c.max_marks).toFixed(2) : '';
            html += `<div class="mb-2">${c.criterion_name} <small class='text-muted'>(Max: ${max})</small>: <input type="number" step="0.5" min="0" max="${max}" class="form-control d-inline-block w-auto criterion-input" data-student-idx="${idx}" data-criterion-id="${c.criterion_id}" value="${val}"></div>`;
        });
        html += `</td><td class="text-center">${totalMarks}/${maxMarks}</td></tr>`;
    });
    html += `</tbody></table></div>`;
    html += `<div class="form-group mt-3">
                <label for="phaseOverallRemarks">Overall Remarks <span class="text-danger">*</span></label>
                <textarea class="form-control" id="phaseOverallRemarks" rows="4" placeholder="Enter overall remarks for this evaluation...">${initialRemarks}</textarea>
                <small class="form-text text-muted">These remarks will be included when the grade is saved.</small>
            </div>`;
    html += `</form></div>`;
    html += `<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success" id="submitPhaseReviewGradeBtn">Save & Submit</button>
    </div>`;

    let modal = $('#gradeDetailModal');
    if (!modal.length) {
        $('body').append(`
            <div class="modal fade" id="gradeDetailModal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content" id="gradeDetailContent"></div>
                </div>
            </div>
        `);
        modal = $('#gradeDetailModal');
    }
    $('#gradeDetailContent').html(html);
    modal.modal('show');
    modal.parents().addBack().removeAttr('aria-hidden');

    $('#submitPhaseReviewGradeBtn').on('click', function() {
        const students = [];
        groupGrades.forEach(({grade}, idx) => {
            const criteria = [];
            $(`#gradeDetailContent .criterion-input[data-student-idx='${idx}']`).each(function() {
                const critId = $(this).data('criterion-id');
                const marks = parseFloat($(this).val()) || 0;
                criteria.push({ criterion_id: critId, obtained_marks: marks });
            });
            if (criteria.length > 0) {
                students.push({ student_id: grade.student_id, criteria });
            }
        });

        const overallRemarks = $('#phaseOverallRemarks').val().trim();
        if (!overallRemarks) {
            Swal.fire('Error', 'Overall remarks are required when submitting grades.', 'error');
            $('#phaseOverallRemarks').focus();
            return;
        }

        const payload = {
            group_id: String(groupId),
            evaluation_sheet_id: String(groupGrades[0].grade.evaluation_sheet_id),
            status: 'submitted',
            students: JSON.stringify(students),
            overall_remarks: overallRemarks
        };
        console.log('Submitting grades payload:', payload);
        $.ajax({
            url: '../api/save-student-grades.php',
            type: 'POST',
            data: payload,
            dataType: 'json',
            success: function(resp) {
                if (resp.success) {
                    Swal.fire('Success', resp.message, 'success').then(() => {
                        modal.modal('hide');
                        viewGroupGrades(groupId);
                    });
                } else {
                    Swal.fire('Error', resp.message || 'Failed to submit grade', 'error');
                }
            },
            error: function(xhr) {
                console.error('Submit error:', xhr.responseText);
                Swal.fire('Error', 'Failed to submit grade', 'error');
            }
        });
    });
}
</script>
