# Final Year Project Management System (FYPM System)

A comprehensive web-based application for managing final year projects in academic institutions, built with PHP, MySQL, and SB Admin 2 Bootstrap template.

## Features

### Authentication Module
- **Login**: Role-based login (Student/Guide/Coordinator)
- **Registration**: Dynamic registration forms based on user type
- **Password Recovery**: Email-based password reset functionality
- **Authorization**: USN verification for students against coordinator-uploaded list

### Student Module
- Dashboard with project overview and progress tracking
- Profile management with password change
- Group creation and management
- Project submission (title, description, team details)
- File uploads (PDF, PPT, DOC) for different phases and reviews
- Chat with guide and coordinator
- Grades viewing and download
- Notifications from coordinators and guides

### Guide Module
- Dashboard with assigned groups overview
- Review student uploads
- Approve/request changes on submissions
- Grade students using evaluation sheets
- Chat with students and coordinator
- Notification management

### Coordinator Module
- Comprehensive admin dashboard
- Upload and manage authorized student/guide lists (Excel/CSV)
- Manage batches and assign guides to teams
- Create evaluation sheets for different phases and reviews
- View detailed statistics (submission status, grades, progress)
- Send circulars and notifications with attachments
- Export data as Excel or PDF

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap (SB Admin 2)
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Server**: XAMPP (Apache + MySQL)
- **Additional Libraries**: 
  - Chart.js for data visualization
  - DataTables for table management
  - Font Awesome for icons

## Installation

### Prerequisites
- XAMPP installed on your system
- Web browser (Chrome, Firefox, Edge, Safari)

### Setup Instructions

1. **Start XAMPP**
   - Open XAMPP Control Panel
   - Start Apache and MySQL services

2. **Database Setup**
   - Open phpMyAdmin: http://localhost/phpmyadmin
   - Create a new database or use the provided SQL file:
     - Click on "Import" tab
     - Choose file: `database/fypm_database.sql`
     - Click "Go" to execute

3. **Configuration**
   - The system is already configured for localhost
   - If needed, update database credentials in `config/config.php`:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'root');
     define('DB_PASS', '');
     define('DB_NAME', 'fypm_system');
     ```

4. **File Permissions**
   - Ensure the `uploads/` directory has write permissions:
     ```
     chmod 755 uploads/
     ```

5. **Access the System**
   - Open browser and navigate to: http://localhost/finalproject
   - You will be redirected to the login page

## Default Login Credentials

### Coordinator (Admin)
- **Username**: COORD001
- **Password**: password

Use this account to:
1. Upload authorized student and guide lists
2. Create evaluation sheets
3. Manage batches and assign guides

## Directory Structure

```
finalproject/
├── api/                    # API endpoints
│   ├── login.php
│   ├── register.php
│   ├── logout.php
│   ├── forgot-password.php
│   └── get-notifications.php
├── config/                 # Configuration files
│   └── config.php
├── includes/              # Reusable components
│   ├── header.php
│   ├── sidebar.php
│   ├── topbar.php
│   ├── footer.php
│   └── auth.class.php
├── database/              # Database SQL files
│   └── fypm_database.sql
├── student/               # Student module
│   ├── dashboard.php
│   ├── profile.php
│   ├── group.php
│   ├── project.php
│   ├── uploads.php
│   ├── chat.php
│   ├── grades.php
│   └── notifications.php
├── guide/                 # Guide module
│   ├── dashboard.php
│   ├── profile.php
│   ├── groups.php
│   ├── reviews.php
│   ├── grading.php
│   ├── chat.php
│   └── notifications.php
├── coordinator/           # Coordinator module
│   ├── dashboard.php
│   ├── students.php
│   ├── staff.php
│   ├── batches.php
│   ├── evaluation-sheets.php
│   ├── statistics.php
│   ├── circulars.php
│   └── chat.php
├── uploads/               # File upload directory
├── login.php
├── register.php
├── forgot-password.php
└── index.php
```

## Database Schema

### Main Tables
- **users**: Common user information for all roles
- **students**: Student-specific data (USN, branch, year)
- **guides**: Guide-specific data (employee_id, domain)
- **coordinators**: Coordinator-specific data
- **groups**: Project groups/teams
- **project_uploads**: File uploads for reviews
- **evaluation_sheets**: Evaluation templates
- **evaluation_criteria**: Criteria for each evaluation
- **grades**: Grades given by guides
- **grade_details**: Individual criterion marks
- **chat_messages**: Chat communication
- **notifications**: System notifications
- **notification_read_status**: Notification read tracking
- **authorized_students**: Coordinator-uploaded student list
- **authorized_guides**: Coordinator-uploaded guide list

## Usage Workflow

1. **Coordinator Setup**
   - Login with default credentials
   - Upload authorized student list (Excel/CSV with USN column)
   - Upload authorized guide list (Excel/CSV with Employee ID column)
   - Create evaluation sheets for each phase and review

2. **Student Registration**
   - The Coordinator uploads a CSV file containing the list of students along with their basic information
   - Students whose details are present in the uploaded CSV file can register in the system by setting a password and providing additional personal information
   - Students whose details are not included in the CSV file uploaded by the Coordinator are not allowed to register (ensures system security and proper authorization)
   - Once the registration process is completed, the student can access the system at any time using their login credentials

3. **Guide Registration**
   - Guides register using their Employee ID
   - Complete profile information

4. **Group Formation**
   - Team lead creates a group
   - Adds team members (from authorized list)
   - Selects project domain

5. **Guide Assignment**
   - Coordinator assigns guides to groups based on domain/batch

6. **Project Execution**
   - Students submit project ideas and descriptions
   - Upload documents for each review
   - Guides review and approve submissions
   - Guides grade using evaluation sheets
   - Students can view grades and feedback

7. **Communication**
   - Chat feature for student-guide-coordinator communication
   - Coordinators send circulars to batches/teams
   - Notifications for important updates

## Key Features Explanation

### Role-Based Access Control
- Each user role (Student/Guide/Coordinator) has specific permissions
- Dashboards and menus are customized based on role
- Unauthorized access attempts are redirected

### Authorization System
- Students can only register if their USN is uploaded by coordinator
- Case-insensitive USN validation
- Prevents unauthorized registrations

### Group Management
- Team lead can create groups and add members
- Members from other groups are automatically disabled
- Supports lone students (can be added to existing teams)
- Maximum team size configurable

### Phase and Review System
- Configurable number of phases (default: 2)
- Phase 1: 2 reviews
- Phase 2: 3 reviews
- Each review requires file upload and guide approval

### Grading System
- Coordinator creates evaluation sheets
- Guides use templates to grade consistently
- Automatic calculation of total marks
- Support for saving drafts before final submission

### File Upload Management
- Supports PDF, PPT, DOC formats
- File size limit: 10MB (configurable)
- Status tracking: Pending, Approved, Changes Required
- Edit/delete allowed until approved

### Notification System
- Targeted notifications (all students, specific batch, specific team)
- Attachment support
- Read/unread tracking
- Real-time notification count in topbar

## Security Features

- Password hashing using PHP's password_hash()
- SQL injection prevention using prepared statements
- Session management with secure cookies
- Input sanitization and validation
- CSRF token protection (can be enhanced)
- XSS prevention using htmlspecialchars()

## Customization

### Changing Color Scheme
Edit the sidebar gradient in `includes/header.php`:
```css
.sidebar {
    background: linear-gradient(180deg, #4e73df 10%, #224abe 100%);
}
```

### Modifying Project Phases
Update in database table `project_config`:
```sql
UPDATE project_config SET config_value = '3' WHERE config_key = 'phases_count';
```

### Email Configuration
Implement email sending in `includes/auth.class.php` for password reset functionality using PHPMailer or similar library.

## Troubleshooting

### Database Connection Error
- Check if MySQL service is running in XAMPP
- Verify database credentials in `config/config.php`
- Ensure database name matches

### File Upload Not Working
- Check `uploads/` directory exists
- Verify write permissions on uploads directory
- Check `MAX_FILE_SIZE` in config.php

### Session Issues
- Clear browser cookies
- Check session.save_path in php.ini
- Restart Apache service

### Page Not Found (404)
- Ensure files are in correct directory: `C:\xampp\htdocs\finalproject\`
- Check .htaccess if using URL rewriting

## Browser Compatibility

- Google Chrome (Recommended)
- Mozilla Firefox
- Microsoft Edge
- Safari

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review database logs in phpMyAdmin
3. Check Apache error logs in XAMPP

## Future Enhancements

- Email notification integration
- PDF report generation for grades
- Real-time chat using WebSocket
- Mobile responsive improvements
- Advanced analytics and charts
- Export functionality (Excel/PDF)
- File preview without download
- Version control for uploaded files

## License

This project is developed for academic purposes.

## Credits

- **SB Admin 2**: Bootstrap admin template
- **Font Awesome**: Icon library
- **Chart.js**: Charting library
- **DataTables**: Table plugin

---

**Developed**: January 2026  
**Version**: 1.0.0
