<?php
require_once 'config/config.php';

// If already logged in, redirect to dashboard. If project type exists (from last entry), keep showing selection page
// to allow the user to change project type or re-enter.
// Project type is still respected on form submission
// and login page will still require current project_type.
// (If user wants to reset project type, they can use logout-project.php.)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Project Selection - FYPM System</title>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .project-selection-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(180deg, #4e73df 10%, #224abe 100%);
            padding: 20px;
        }
        .project-card {
            background: #ffffff;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 / 15%);
            padding: 40px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: default;
            border: 1px solid #e3e6f0;
            width: 100%;
            max-width: 300px;
        }
        .project-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 0.5rem 1rem -0.25rem rgba(78,115,223,0.65);
            border-color: #d1d3e2;
        }
        .project-card i {
            font-size: 48px;
            color: #4e73df;
            margin-bottom: 20px;
            display: block;
        }
        .project-card h3 {
            font-size: 24px;
            margin: 15px 0;
            color: #4e73df;
            font-weight: 600;
        }
        .project-card p {
            color: #6c757d;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 25px;
        }
        .btn-project {
            background: #4e73df;
            color: white;
            border: none;
            padding: 10px 30px;
            border-radius: 0.35rem;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        .btn-project:hover {
            background: #2e59d9;
            color: white;
            text-decoration: none;
        }
        .cards-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            justify-items: center;
        }
        .header-section {
            text-align: center;
            margin-bottom: 50px;
            color: white;
        }
        .header-section h1 {
            font-size: 42px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .header-section p {
            font-size: 18px;
            opacity: 0.9;
        }
        @media (max-width: 768px) {
            .cards-grid {
                grid-template-columns: 1fr;
                gap: 20px;
                padding: 0 20px;
            }
            .header-section h1 {
                font-size: 32px;
            }
        }
    </style>
</head>
<body>
    <div class="project-selection-container">
        <div>
            <div class="header-section">
                <h1>Project Management System</h1>
                <p>Select the project type you want to work with</p>
            </div>
            
            <div class="cards-grid">
                <!-- Major Project Card -->
                <div class="project-card">
                    <i class="fas fa-graduation-cap"></i>
                    <h3>Major Project</h3>
                    <button class="btn-project" onclick="selectProject('major');">
                        Select
                    </button>
                </div>

                <!-- Mini Project Card -->
                <div class="project-card">
                    <i class="fas fa-project-diagram"></i>
                    <h3>Mini Project</h3>
                    <button class="btn-project" onclick="selectProject('mini');">
                        Select
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function selectProject(type) {
            window.location.href = 'select-project.php?type=' + type;
        }
    </script>
</body>
</html>
