<?php
require_once '../config/config.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>HOD Project Selection - FYPM System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(180deg, #4e73df 10%, #224abe 100%);
            min-height: 100vh;
        }
        .selection-card {
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 / 15%);
            padding: 40px;
            background: white;
        }
        .selection-card .project-card {
            border: 1px solid #e3e6f0;
            border-radius: 0.35rem;
            padding: 30px;
            transition: transform 0.25s ease, box-shadow 0.25s ease;
            text-align: center;
        }
        .selection-card .project-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 0.5rem 1rem -0.25rem rgba(78,115,223,0.65);
        }
        .project-card i {
            font-size: 46px;
            color: #4e73df;
            margin-bottom: 20px;
        }
        .project-card h3 {
            margin-bottom: 15px;
            color: #4e73df;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="container d-flex align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="selection-card col-md-8 col-lg-6 mx-auto">
            <div class="text-center mb-4">
                <h1 class="h4 text-gray-900 mb-2">HOD Login</h1>
                <p class="text-muted">Select your project type to continue</p>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <div class="project-card">
                        <i class="fas fa-project-diagram"></i>
                        <h3>Mini Project</h3>
                        <button class="btn btn-primary" onclick="window.location.href='login.php?project_type=mini'">Login</button>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="project-card">
                        <i class="fas fa-graduation-cap"></i>
                        <h3>Major Project</h3>
                        <button class="btn btn-primary" onclick="window.location.href='login.php?project_type=major'">Login</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
