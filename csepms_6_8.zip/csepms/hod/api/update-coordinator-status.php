<?php
require_once '../../config/config.php';

header('Content-Type: application/json');
requireRoleAPI('hod');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$coordinatorId = intval($_POST['coordinator_id'] ?? 0);
$status = sanitizeInput($_POST['status'] ?? '');

if ($coordinatorId <= 0 || !in_array($status, ['approved', 'rejected'])) {
    sendJSON(['success' => false, 'message' => 'Invalid input']);
}

$projectType = $_SESSION['hod_project_type'] ?? $_SESSION['project_type'] ?? null;
if (!in_array($projectType, ['mini', 'major'])) {
    sendJSON(['success' => false, 'message' => 'Invalid project type']);
}

if ($conn) {
    $conn->close();
}
$dbName = getDatabaseName($projectType);
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
if ($conn->connect_error) {
    sendJSON(['success' => false, 'message' => 'Database connection failed']);
}
$conn->set_charset('utf8mb4');

$columnCheck = $conn->query("SHOW COLUMNS FROM coordinators LIKE 'approval_status'");
if (!$columnCheck || $columnCheck->num_rows === 0) {
    sendJSON(['success' => false, 'message' => 'Approval status not available in database schema'], 500);
}

$stmt = $conn->prepare("UPDATE coordinators SET approval_status = ? WHERE id = ?");
if (!$stmt) {
    sendJSON(['success' => false, 'message' => 'Database error']);
}
$stmt->bind_param('si', $status, $coordinatorId);
if (!$stmt->execute()) {
    sendJSON(['success' => false, 'message' => 'Failed to update coordinator status']);
}

sendJSON(['success' => true, 'message' => 'Coordinator status updated']);
