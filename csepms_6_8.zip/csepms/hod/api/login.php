<?php
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$projectType = sanitizeInput($_POST['project_type'] ?? '');
$email = strtolower(sanitizeInput($_POST['email'] ?? ''));
$password = trim($_POST['password'] ?? '');

if (empty($projectType) || !in_array($projectType, ['mini', 'major'])) {
    sendJSON(['success' => false, 'message' => 'Invalid project type']);
}
if (empty($email) || empty($password)) {
    sendJSON(['success' => false, 'message' => 'Email and password are required']);
}

if ($conn) {
    $conn->close();
}
$dbName = getDatabaseName($projectType);
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
if ($conn->connect_error) {
    sendJSON(['success' => false, 'message' => 'Database connection failed']);
}
$conn->set_charset('utf8mb4');

$stmt = $conn->prepare("SELECT * FROM hod WHERE LOWER(email) = ? LIMIT 1");
if (!$stmt) {
    sendJSON(['success' => false, 'message' => 'Database error']);
}
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    sendJSON(['success' => false, 'message' => 'Invalid credentials']);
}

$stmt->bind_result($hodId, $hodName, $hodEmail, $storedPassword, $hodPhone, $hodCreatedAt);
$stmt->fetch();
$storedPassword = trim($storedPassword);

if (password_verify($password, $storedPassword)) {
    if (password_needs_rehash($storedPassword, PASSWORD_DEFAULT)) {
        $newHashedPassword = hashPassword($password);
        $updateStmt = $conn->prepare("UPDATE hod SET password = ? WHERE id = ?");
        if ($updateStmt) {
            $updateStmt->bind_param('si', $newHashedPassword, $hodId);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }
} elseif ($storedPassword === $password) {
    // Legacy plain-text password stored in database. Migrate it to a secure hash.
    $newHashedPassword = hashPassword($password);
    $updateStmt = $conn->prepare("UPDATE hod SET password = ? WHERE id = ?");
    if ($updateStmt) {
        $updateStmt->bind_param('si', $newHashedPassword, $hodId);
        $updateStmt->execute();
        $updateStmt->close();
    }
} else {
    sendJSON(['success' => false, 'message' => 'Invalid credentials']);
}

$_SESSION['user_id'] = $hodId;
$_SESSION['role_id'] = $hodId;
$_SESSION['role'] = 'hod';
$_SESSION['hod_name'] = $hodName;
$_SESSION['hod_email'] = $hodEmail;
$_SESSION['hod_project_type'] = $projectType;
$_SESSION['project_type'] = $projectType;

sendJSON([
    'success' => true,
    'message' => 'Login successful',
    'redirect' => BASE_URL . 'hod/dashboard.php'
]);
