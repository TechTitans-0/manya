<?php
require_once '../config/config.php';
requireRole('hod');

$hodProjectType = $_SESSION['hod_project_type'] ?? $_SESSION['project_type'] ?? null;
if (!$hodProjectType) {
    redirect('index.php');
}

// Ensure the database is connected to the HOD-selected project type
if (!isset($_SESSION['project_type']) || $_SESSION['project_type'] !== $hodProjectType) {
    if ($conn) {
        $conn->close();
    }
    $_SESSION['project_type'] = $hodProjectType;
    $dbName = getDatabaseName($hodProjectType);
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
    if ($conn->connect_error) {
        die('Database connection failed');
    }
    $conn->set_charset('utf8mb4');
}

$projectLabel = ($hodProjectType === 'mini') ? 'Mini Project' : 'Major Project';

$approvalColumnExists = false;
$columnResult = $conn->query("SHOW COLUMNS FROM coordinators LIKE 'approval_status'");
if ($columnResult && $columnResult->num_rows > 0) {
    $approvalColumnExists = true;
}

$coordinatorQuery = "SELECT c.id, c.employee_id, c.designation, c.research_domain_expertise, c.department, ";
$coordinatorQuery .= $approvalColumnExists ? "c.approval_status, " : "'approved' AS approval_status, ";
$coordinatorQuery .= "u.username, u.email, u.phone FROM coordinators c ";
$coordinatorQuery .= "INNER JOIN users u ON c.user_id = u.id ORDER BY c.id DESC";
$result = $conn->query($coordinatorQuery);
$coordinators = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $coordinators[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>HOD Dashboard - <?php echo $projectLabel; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <div class="container-fluid mt-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 text-gray-800">HOD Dashboard - <?php echo $projectLabel; ?></h1>
            <a href="logout.php" class="btn btn-secondary">Logout</a>
        </div>

        <?php if (!$approvalColumnExists): ?>
            <div class="alert alert-warning">
                HOD approval is not fully configured yet. Please run the database migration to add the <strong>approval_status</strong> column to the <strong>coordinators</strong> table.
            </div>
        <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Coordinator Approvals</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th>Coordinator Name</th>
                                <th>Email</th>
                                <th>Employee ID</th>
                                <th>Department</th>
                                <th>Designation</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($coordinators)): ?>
                                <tr><td colspan="7" class="text-center">No coordinators found</td></tr>
                            <?php else: ?>
                                <?php foreach ($coordinators as $coordinator): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($coordinator['username']); ?></td>
                                        <td><?php echo htmlspecialchars($coordinator['email']); ?></td>
                                        <td><?php echo htmlspecialchars($coordinator['employee_id']); ?></td>
                                        <td><?php echo htmlspecialchars($coordinator['department']); ?></td>
                                        <td><?php echo htmlspecialchars($coordinator['designation']); ?></td>
                                        <td>
                                            <?php
                                                $status = htmlspecialchars($coordinator['approval_status'] ?? 'approved');
                                                if ($status === 'approved') {
                                                    echo '<span class="badge badge-success">Approved</span>';
                                                } elseif ($status === 'rejected') {
                                                    echo '<span class="badge badge-danger">Rejected</span>';
                                                } else {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-success mr-1" <?php echo !$approvalColumnExists ? 'disabled' : ''; ?> onclick="updateCoordinatorStatus(<?php echo $coordinator['id']; ?>, 'approved')">Approve</button>
                                            <button class="btn btn-sm btn-danger" <?php echo !$approvalColumnExists ? 'disabled' : ''; ?> onclick="updateCoordinatorStatus(<?php echo $coordinator['id']; ?>, 'rejected')">Reject</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function updateCoordinatorStatus(coordinatorId, status) {
            if (!confirm('Are you sure you want to ' + status + ' this coordinator?')) {
                return;
            }

            $.post('api/update-coordinator-status.php', {
                coordinator_id: coordinatorId,
                status: status
            }, function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message || 'Unable to update status.');
                }
            }, 'json').fail(function() {
                alert('Network error. Please try again.');
            });
        }
    </script>
</body>
</html>
