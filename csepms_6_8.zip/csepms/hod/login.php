<?php
require_once '../config/config.php';


$projectType = sanitizeInput($_GET['project_type'] ?? '');
if (!in_array($projectType, ['mini', 'major'])) {
    redirect('index.php');
}

$projectLabel = ($projectType === 'mini') ? 'Mini Project' : 'Major Project';
$projectTitle = ($projectType === 'mini') ? 'Mini Project HOD Login' : 'Major Project HOD Login';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $projectTitle; ?> - FYPM System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-primary">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-7 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <h1 class="h4 text-gray-900 mb-2"><?php echo $projectTitle; ?></h1>
                            <p class="text-muted">Log in with your HOD email and password</p>
                        </div>
                        <div id="alertBox"></div>
                        <form id="hodLoginForm">
                            <input type="hidden" name="project_type" value="<?php echo htmlspecialchars($projectType); ?>">
                            <div class="form-group">
                                <label class="small mb-1">Email</label>
                                <input type="email" class="form-control form-control-user" name="email" placeholder="Enter email" required>
                            </div>
                            <div class="form-group position-relative">
                                <label class="small mb-1">Password</label>
                                <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Password" required>
                                <span class="position-absolute" style="right: 25px; top: 40px; cursor: pointer;" onclick="togglePassword()">
                                    <i class="fas fa-eye" id="toggleIcon"></i>
                                </span>
                            </div>
                            <button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
                        </form>
                        <hr>
                        <div class="text-center">
                            <a href="index.php" class="small">Back to project selection</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        document.getElementById('hodLoginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const alertBox = document.getElementById('alertBox');
            const formData = new FormData(this);
            fetch('api/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alertBox.innerHTML = `<div class="alert alert-success">${data.message || 'Login successful. Redirecting...'}</div>`;
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 800);
                } else {
                    alertBox.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                }
            })
            .catch(() => {
                alertBox.innerHTML = `<div class="alert alert-danger">An unexpected error occurred.</div>`;
            });
        });
    </script>
</body>
</html>
