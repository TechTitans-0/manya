<?php
require_once '../config/config.php';
require_once '../includes/auth.class.php';

$auth = new Auth($conn);
$auth->logout();

redirect('hod/index.php');
