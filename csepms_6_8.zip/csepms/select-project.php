<?php
require_once 'config/config.php';

// Get project type from URL
$projectType = isset($_GET['type']) ? sanitizeInput($_GET['type']) : null;

// Validate project type
if (!in_array($projectType, ['major', 'mini'])) {
    redirect('index.php');
}

// Set the project type in session
$_SESSION['project_type'] = $projectType;

// Establish database connection for the selected project type
establishDatabaseConnection();

// Check if connection was successful
if (!$conn) {
    die("Failed to connect to database");
}

// Redirect to login
redirect('login.php');
?>
