<?php
// Prevent directory access to the database folder.
header('Location: /csepms/index.php');
exit;
