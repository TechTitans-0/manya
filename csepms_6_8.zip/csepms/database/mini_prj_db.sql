-- ==================== MINI PROJECTS DATABASE ====================
CREATE DATABASE IF NOT EXISTS mini_prj_db;
USE mini_prj_db;

CREATE TABLE academic_years (
    id INT AUTO_INCREMENT PRIMARY KEY,
    year_label VARCHAR(20) NOT NULL UNIQUE,
    status ENUM('ACTIVE','COMPLETED') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE hod (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Users table (common for all roles)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usn_emp_id VARCHAR(50) UNIQUE,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'guide', 'coordinator') NOT NULL,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active TINYINT(1) DEFAULT 1,
    reset_token VARCHAR(255) NULL,
    reset_token_expiry DATETIME NULL
);

-- Students table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    usn VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    year_of_passing INT NOT NULL,
    branch VARCHAR(100) NOT NULL,
    group_id INT NULL,
    is_team_lead TINYINT(1) DEFAULT 0,
    is_authorized TINYINT(1) DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Guides table
CREATE TABLE guides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    domain VARCHAR(100),
    department VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Coordinators table
CREATE TABLE coordinators (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    designation VARCHAR(100) DEFAULT NULL,
    research_domain_expertise VARCHAR(150) DEFAULT NULL,
    years_of_experience INT DEFAULT NULL,
    department VARCHAR(100),
    approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Authorized Students (uploaded by coordinator)
CREATE TABLE authorized_students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usn VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    academic_year_id INT DEFAULT NULL,
    department VARCHAR(100) DEFAULT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Authorized',
    registered_user_id INT DEFAULT NULL,
    registered_at TIMESTAMP NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Authorized Guides (uploaded by coordinator)
CREATE TABLE authorized_guides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    research_domain_expertise VARCHAR(150) NOT NULL,
    years_of_experience INT NOT NULL,
    branch VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Authorized',
    registered_user_id INT DEFAULT NULL,
    registered_at TIMESTAMP NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Groups table
CREATE TABLE pgroups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_name VARCHAR(100) NOT NULL,
    domain VARCHAR(100),
    batch VARCHAR(50),
    guide_id INT NULL,
    coordinator_guide_id INT NULL,
    project_title VARCHAR(255),
    project_description TEXT,
    overall_grade DECIMAL(5,2) DEFAULT 0,
    project_status ENUM('planning', 'in_progress', 'under_review', 'completed') DEFAULT 'planning',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (guide_id) REFERENCES guides(id) ON DELETE SET NULL,
    FOREIGN KEY (coordinator_guide_id) REFERENCES coordinators(id) ON DELETE SET NULL,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Project Configuration
CREATE TABLE project_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(50) UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    description VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default configuration for mini projects (adjusted for lighter scope)
INSERT INTO project_config (config_key, config_value, description) VALUES
('max_team_size', '4', 'Maximum number of students per team'),
('chat_retention_days', '60', 'Number of days to keep chat messages'),
('min_team_size', '3', 'Minimum number of students per team');

-- Project Uploads table
CREATE TABLE project_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    project_title VARCHAR(255),
    uploaded_by INT NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'approved', 'changes_required') DEFAULT 'pending',
    feedback TEXT,
    FOREIGN KEY (group_id) REFERENCES pgroups(id) ON DELETE CASCADE,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Evaluation Sheets (Created by coordinator)
CREATE TABLE evaluation_sheets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_code VARCHAR(50) NOT NULL DEFAULT '',
    title VARCHAR(255) NOT NULL DEFAULT '',
    status ENUM('draft', 'active') DEFAULT 'draft',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES coordinators(id) ON DELETE CASCADE
);

-- Evaluation Criteria
CREATE TABLE evaluation_criteria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    evaluation_sheet_id INT NOT NULL,
    criterion_name VARCHAR(255) NOT NULL,
    max_marks INT NOT NULL,
    display_order INT DEFAULT 0,
    FOREIGN KEY (evaluation_sheet_id) REFERENCES evaluation_sheets(id) ON DELETE CASCADE
);

-- Grades table (Given by guides)
CREATE TABLE grades(
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    evaluation_sheet_id INT NOT NULL,
    guide_id INT NOT NULL,
    total_marks DECIMAL(5,2) NOT NULL,
    academic_year_id INT NOT NULL,
    max_marks DECIMAL(5,2) NOT NULL,
    status ENUM('draft', 'submitted') DEFAULT 'draft',
    graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES pgroups(id) ON DELETE CASCADE,
    FOREIGN KEY (evaluation_sheet_id) REFERENCES evaluation_sheets(id) ON DELETE CASCADE,
    FOREIGN KEY (guide_id) REFERENCES guides(id) ON DELETE CASCADE,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Grade Details (Individual criterion marks)
CREATE TABLE grade_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grade_id INT NOT NULL,
    criterion_id INT NOT NULL,
    marks_obtained DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (grade_id) REFERENCES grades(id) ON DELETE CASCADE,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (criterion_id) REFERENCES evaluation_criteria(id) ON DELETE CASCADE,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Chat Messages
CREATE TABLE chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    sender_role ENUM('student', 'guide', 'coordinator') NOT NULL,
    receiver_id INT NOT NULL,
    academic_year_id INT NOT NULL,
    receiver_role ENUM('student', 'guide', 'coordinator') NOT NULL,
    group_id INT NULL,
    message TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_read TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES pgroups(id) ON DELETE CASCADE,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    academic_year_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    target_type ENUM('all_students', 'all_guides', 'specific_batch', 'specific_team', 'specific_user') NOT NULL,
    target_value VARCHAR(100),
    attachment_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Notification Read Status
CREATE TABLE notification_read_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    notification_id INT NOT NULL,
    user_id INT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    read_at TIMESTAMP NULL,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT,
    FOREIGN KEY (notification_id) REFERENCES notifications(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_notification_user (notification_id, user_id)
);

-- Batches
CREATE TABLE batches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    batch_name VARCHAR(50) UNIQUE NOT NULL,
    year INT NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Global Settings
CREATE TABLE global_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value VARCHAR(255) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Student Grades
CREATE TABLE student_grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    group_id INT NOT NULL,
    evaluation_sheet_id INT NOT NULL,
    guide_id INT NULL,
    coordinator_guide_id INT NULL,
    total_marks DECIMAL(5,2) NOT NULL,
    max_marks DECIMAL(5,2) NOT NULL,
    status ENUM('draft', 'submitted', 'pending', 'approved') DEFAULT 'draft',
    overall_remarks TEXT,
    graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES pgroups(id) ON DELETE CASCADE,
    FOREIGN KEY (evaluation_sheet_id) REFERENCES evaluation_sheets(id) ON DELETE CASCADE,
    FOREIGN KEY (guide_id) REFERENCES guides(id) ON DELETE SET NULL,
    FOREIGN KEY (coordinator_guide_id) REFERENCES coordinators(id) ON DELETE SET NULL,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Student Grade Details
CREATE TABLE student_grade_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_grade_id INT NOT NULL,
    criterion_id INT NOT NULL,
    marks_obtained DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (student_grade_id) REFERENCES student_grades(id) ON DELETE CASCADE,
    FOREIGN KEY (criterion_id) REFERENCES evaluation_criteria(id) ON DELETE CASCADE,
    academic_year_id INT NOT NULL,
    FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT
);

-- Create indexes for better performance
CREATE INDEX idx_students_usn ON students(usn);
CREATE INDEX idx_students_group ON students(group_id);
CREATE INDEX idx_guides_empid ON guides(employee_id);
CREATE INDEX idx_groups_guide ON pgroups(guide_id);
CREATE INDEX idx_uploads_group ON project_uploads(group_id);
CREATE INDEX idx_grades_group ON grades(group_id);
CREATE INDEX idx_chat_sender ON chat_messages(sender_id);
CREATE INDEX idx_chat_receiver ON chat_messages(receiver_id);
CREATE INDEX idx_notifications_target ON notifications(target_type, target_value);
CREATE INDEX idx_students_academic_year ON students(academic_year_id);
CREATE INDEX idx_authorized_students_academic_year ON authorized_students(academic_year_id);
CREATE INDEX idx_groups_academic_year ON pgroups(academic_year_id);
CREATE INDEX idx_uploads_academic_year ON project_uploads(academic_year_id);
CREATE INDEX idx_grades_academic_year ON grades(academic_year_id);
CREATE INDEX idx_grade_details_academic_year ON grade_details(academic_year_id);
CREATE INDEX idx_chat_academic_year ON chat_messages(academic_year_id);
CREATE INDEX idx_notifications_academic_year ON notifications(academic_year_id);
CREATE INDEX idx_notification_read_status_academic_year ON notification_read_status(academic_year_id);
CREATE INDEX idx_batches_academic_year ON batches(academic_year_id);
CREATE INDEX idx_setting_key ON global_settings(setting_key);
CREATE INDEX idx_student_grades_academic_year ON student_grades(academic_year_id);
CREATE INDEX idx_student_grade_details_academic_year ON student_grade_details(academic_year_id);


