-- Migration: add columns to authorized_students for registration validation
ALTER TABLE authorized_students
  ADD COLUMN academic_year VARCHAR(20) NULL,
  ADD COLUMN department VARCHAR(100) NULL,
  ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'Authorized',
  ADD COLUMN registered_user_id INT NULL,
  ADD COLUMN registered_at TIMESTAMP NULL;

-- Optional: create index on LOWER(usn) for faster lookups
CREATE INDEX idx_authorized_usn_lower ON authorized_students (usn);
