<?php
require_once '../config/config.php';
requireRole('student');

// Allow students to view the uploads page even if they are not yet assigned to a group.
// Previously the page redirected to group.php when `group_id` was missing; that
// redirect prevented students from seeing the uploads UI. We keep the page
// accessible and handle missing group state in the UI/JS.
$hasGroup = isset($_SESSION['group_id']) && !empty($_SESSION['group_id']);

$pageTitle = "Project Uploads";

// Check if student is in a completed academic year (read-only mode)
$isReadOnly = isStudentInReadOnlyYear();

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Project Uploads</h1>
        <?php if (!$isReadOnly && !empty($_SESSION['is_team_lead'])): ?>
        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#uploadModal">
            <i class="fas fa-upload mr-1"></i> Upload File
        </button>
        <?php elseif ($isReadOnly): ?>
        <span class="badge badge-warning">Read-Only: Academic year completed</span>
        <?php endif; ?>
    </div>
    
    <?php if (!$hasGroup): ?>
    <div class="alert alert-info">You are not assigned to a group yet. The uploads list will appear when you join a group.</div>
    <?php endif; ?>

    <!-- Uploads Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Uploads</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="uploadsTable" width="100%">
                    <thead>
                        <tr>
                            <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                            <th>Phase</th>
                            <th>Review</th>
                            <?php endif; ?>
                            <th>File Name</th>
                            <th>Uploaded By</th>
                            <th>Upload Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="uploadsTableBody">
                        <tr>
                            <td colspan="<?php echo ($_SESSION['project_type'] === 'mini') ? 5 : 7; ?>" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upload Project File</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="uploadForm">
                <div class="modal-body">
                    <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                    <!-- Display Current Phase and Review (Read-only) -->
                    <div class="alert alert-info">
                        <strong>Current Phase & Review:</strong>
                        <div class="mt-2">
                            <i class="fas fa-layer-group mr-2"></i>Phase: <span id="currentPhaseDisplay" class="font-weight-bold">-</span><br>
                            <i class="fas fa-clipboard-check mr-2"></i>Review: <span id="currentReviewDisplay" class="font-weight-bold">-</span>
                        </div>
                    </div>
                    
                    <!-- Hidden fields to submit phase and review -->
                    <input type="hidden" id="phase" name="phase" required>
                    <input type="hidden" id="reviewType" name="review" required>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="file">File * (PDF, DOC, DOCX, PPT, PPTX - Max 10MB)</label>
                        <input type="file" class="form-control-file" id="file" name="file" 
                               accept=".pdf,.doc,.docx,.ppt,.pptx" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
const isTeamLead = <?php echo !empty($_SESSION['is_team_lead']) ? 'true' : 'false'; ?>;
const isReadOnlyMode = <?php echo $isReadOnly ? 'true' : 'false'; ?>;
const isMiniProject = <?php echo json_encode($_SESSION['project_type'] === 'mini'); ?>;
const currentStudentRoleId = <?php echo intval($_SESSION['role_id']); ?>;
const hasGroup = <?php echo $hasGroup ? 'true' : 'false'; ?>;

$(document).ready(function() {
    loadUploads();
    loadGlobalSettings();
    
    $('#uploadForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        $.ajax({
            url: '../api/upload-file.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                Swal.fire({
                    title: 'Uploading...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    $('#uploadModal').modal('hide');
                    $('#uploadForm')[0].reset();
                    Swal.fire('Success!', response.message, 'success');
                    loadUploads();
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function() {
                Swal.close();
                Swal.fire('Error!', 'Failed to upload file', 'error');
            }
        });
    });
});

function loadGlobalSettings() {
    $.ajax({
        url: '../api/get-global-settings.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const phase = response.phase || 1;
                const review = response.review || 1;
                
                // Set display values
                $('#currentPhaseDisplay').text('Phase ' + phase);
                $('#currentReviewDisplay').text(review === 99 ? 'Final Review' : 'Review ' + review);
                
                // Set hidden field values
                $('#phase').val(phase);
                $('#reviewType').val(review);
            } else {
                $('#currentPhaseDisplay').text('Unable to load');
                $('#currentReviewDisplay').text('Unable to load');
            }
        },
        error: function() {
            $('#currentPhaseDisplay').text('Error loading');
            $('#currentReviewDisplay').text('Error loading');
        }
    });
}

function loadUploads() {
    // Helper to safely destroy any existing DataTable instance
    function destroyUploadsDataTable() {
        if ($.fn.dataTable && $.fn.dataTable.isDataTable('#uploadsTable')) {
            try {
                $('#uploadsTable').DataTable().clear().destroy();
            } catch (e) {
                // fallback to generic destroy
                $('#uploadsTable').DataTable().destroy();
            }
        }
    }

    if (!hasGroup) {
        // Ensure any previous DataTable is removed
        destroyUploadsDataTable();
        const colCount = isMiniProject ? 5 : 7;
        $('#uploadsTableBody').html(`<tr><td class="text-center" colspan="${colCount}">You are not assigned to any group yet.</td></tr>`);
        return;
    }

    $.ajax({
        url: '../api/get-uploads.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '';
                if (response.uploads.length === 0) {
                    // No uploads: ensure any existing DataTable is destroyed and show a normal row
                    destroyUploadsDataTable();
                    const colCount = isMiniProject ? 5 : 7;
                    html = `<tr><td class="text-center" colspan="${colCount}">No uploads found</td></tr>`;
                } else {
                    response.uploads.forEach(upload => {
                        const statusBadge = getStatusBadge(upload.status);
                        if (isMiniProject) {
                            html += `
                                <tr>
                                    <td><a href="../${upload.file_path}" target="_blank">${upload.file_name}</a></td>
                                    <td>${upload.uploaded_by_name}</td>
                                    <td>${new Date(upload.uploaded_at).toLocaleDateString()}</td>
                                    <td>${statusBadge}</td>
                                    <td>
                                        ${!isReadOnlyMode && isTeamLead && upload.status !== 'approved' ? `<button class="btn btn-sm btn-secondary ml-1 reupload-btn" data-id="${upload.id}">Reupload</button>` : ''}
                                        ${!isReadOnlyMode && isTeamLead && upload.status === 'pending' ? `<button class="btn btn-sm btn-danger ml-1 delete-upload-btn" data-id="${upload.id}">Delete</button>` : ''}
                                        ${upload.feedback ? `<button class="btn btn-sm btn-outline-info ml-1 view-feedback" data-feedback="${(upload.feedback||'').replace(/"/g,'&quot;')}">Feedback</button>` : ''}
                                    </td>
                                </tr>
                            `;
                        } else {
                            html += `
                                <tr>
                                    <td>${upload.phase}</td>
                                    <td>${formatReviewLabel(upload.review_type)}</td>
                                    <td><a href="../${upload.file_path}" target="_blank">${upload.file_name}</a></td>
                                    <td>${upload.uploaded_by_name}</td>
                                    <td>${new Date(upload.uploaded_at).toLocaleDateString()}</td>
                                    <td>${statusBadge}</td>
                                    <td>
                                        ${!isReadOnlyMode && isTeamLead && upload.status !== 'approved' ? `<button class="btn btn-sm btn-secondary ml-1 reupload-btn" data-id="${upload.id}">Reupload</button>` : ''}
                                        ${!isReadOnlyMode && isTeamLead && upload.status === 'pending' ? `<button class="btn btn-sm btn-danger ml-1 delete-upload-btn" data-id="${upload.id}">Delete</button>` : ''}
                                        ${upload.feedback ? `<button class="btn btn-sm btn-outline-info ml-1 view-feedback" data-feedback="${(upload.feedback||'').replace(/"/g,'&quot;')}">Feedback</button>` : ''}
                                    </td>
                                </tr>
                            `;
                        }
                    });
                }
                $('#uploadsTableBody').html(html);

                // Initialize DataTable only when actual upload rows exist
                if (response.uploads.length > 0) {
                    // Safely destroy any previous instance before re-initializing
                    destroyUploadsDataTable();
                    $('#uploadsTable').DataTable({
                        order: [[4, 'desc']]
                    });
                }

                // Attach delete handlers for uploads that belong to current student
                $('.delete-upload-btn').on('click', function() {
                    const id = $(this).data('id');
                    Swal.fire({
                        title: 'Delete Upload?',
                        text: 'This will permanently delete the uploaded file.',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Delete'
                    }).then(result => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: '../api/delete-upload.php',
                                type: 'POST',
                                data: { upload_id: id },
                                dataType: 'json',
                                success: function(resp) {
                                    if (resp.success) {
                                        Swal.fire('Deleted', resp.message, 'success');
                                        loadUploads();
                                    } else {
                                        Swal.fire('Error', resp.message || 'Failed to delete', 'error');
                                    }
                                },
                                error: function() {
                                    Swal.fire('Error', 'Failed to delete upload', 'error');
                                }
                            });
                        }
                    });
                    });

                    // Reupload handler (team lead only)
                    $('.reupload-btn').on('click', function() {
                        const id = $(this).data('id');
                        const fileInput = $('<input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx" style="display:none">');
                        fileInput.on('change', function() {
                            const file = this.files[0];
                            if (!file) return;
                            const fd = new FormData();
                            fd.append('file', file);
                            fd.append('upload_id', id);

                            Swal.fire({
                                title: 'Reuploading...',
                                allowOutsideClick: false,
                                didOpen: () => { Swal.showLoading(); }
                            });

                            $.ajax({
                                url: '../api/reupload-file.php',
                                type: 'POST',
                                data: fd,
                                processData: false,
                                contentType: false,
                                dataType: 'json',
                                success: function(resp) {
                                    Swal.close();
                                    if (resp.success) {
                                        Swal.fire('Success', resp.message, 'success');
                                        loadUploads();
                                    } else {
                                        Swal.fire('Error', resp.message || 'Failed to reupload', 'error');
                                    }
                                },
                                error: function() {
                                    Swal.close();
                                    Swal.fire('Error', 'Failed to reupload file', 'error');
                                }
                            });
                        });
                        // trigger file select
                        $(document.body).append(fileInput);
                        fileInput.trigger('click');
                    });

                    // View feedback
                    $('.view-feedback').on('click', function() {
                        const fb = $(this).data('feedback') || '';
                        Swal.fire({
                            title: 'Reviewer Feedback',
                            html: `<pre style="white-space:pre-wrap;text-align:left">${fb}</pre>`,
                            width: '90%'
                        });
                    });
            }
        },
        error: function() {
            $('#uploadsTableBody').html('<tr><td colspan="7" class="text-center text-danger">Failed to load uploads</td></tr>');
        }
    });
}

function getStatusBadge(status) {
    const badges = {
        'pending': '<span class="badge badge-warning">Pending</span>',
        'approved': '<span class="badge badge-success">Approved</span>',
        'changes_required': '<span class="badge badge-danger">Changes Required</span>'
    };
    return badges[status] || status;
}

function formatReviewLabel(review) {
    if (review === null || typeof review === 'undefined') return '-';
    if (review === 99 || review === '99') return 'Final Review';
    return 'Review ' + review;
}
</script>

