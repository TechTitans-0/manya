<?php
require_once '../config/config.php';
requireRole('student');

$pageTitle = "My Group";

// Check if student is in a completed academic year (read-only mode)
$isReadOnly = isStudentInReadOnlyYear();

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">My Group</h1>

    <?php if (!isset($_SESSION['group_id']) || !$_SESSION['group_id']): ?>
    <!-- Create Group Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Create Group</h6>
        </div>
        <div class="card-body">
            <form id="createGroupForm">
                <div class="form-group">
                    <label for="teamLeadName">Team Lead Name *</label>
                    <input type="text" class="form-control" id="teamLeadName" name="team_lead_name" required>
                </div>
                <div class="form-group">
                    <label for="teamLeadUSN">Team Lead USN *</label>
                    <input type="text" class="form-control" id="teamLeadUSN" name="team_lead_usn" required>
                </div>
                <!-- Project fields hidden during group creation, shown after guide assignment -->
                <div id="projectFieldsContainer">
                    <div class="form-group">
                        <label for="projectDomain">Project Domain *</label>
                        <select class="form-control" id="projectDomain" name="project_domain" required>
                            <option value="">Select domain</option>
                            <option value="Networking">Networking</option>
                            <option value="Image Processing">Image Processing</option>
                            <option value="Internet of Things">Internet of Things</option>
                            <option value="AI and ML">AI and ML</option>
                            <option value="Data Science and Analytics (Big Data)">Data Science and Analytics (Big Data)</option>
                            <option value="Block Chain">Block Chain</option>
                            <option value="Web development">Web development</option>
                            <option value="Embedded Systems">Embedded Systems</option>
                            <option value="Cloud Computing">Cloud Computing</option>
                            <option value="Deep Learning">Deep Learning</option>
                            <option value="Any others">Any others</option>
                        </select>
                    </div>
                    <div class="form-group" id="customDomainContainer" style="display:none;">
                        <label for="customDomain">Please specify the domain *</label>
                        <input type="text" class="form-control" id="customDomain" name="custom_domain" placeholder="Enter domain details">
                    </div>
                </div>
                <div class="form-group">
                    <label for="groupSize">Group Size *</label>
                    <select class="form-control" id="groupSize" name="group_size" required>
                        <option value="">Select group size</option>
                        <option value="3">3 Members</option>
                        <option value="4">4 Members</option>
                    </select>
                </div>
                <div id="groupMembersContainer"></div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-users mr-1"></i> Create Group
                </button>
            </form>
        </div>
    </div>
    <!-- Project fields script moved to footer to ensure jQuery is loaded -->
    <?php else: ?>
    <!-- Group Details Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Group Details</h6>
            <?php if ($_SESSION['is_team_lead']): ?>
            <span class="badge badge-success">Team Lead</span>
            <?php endif; ?>
        </div>
        <div class="card-body" id="groupDetailsContainer">
            <div class="text-center">
                <div class="spinner-border" role="status"></div>
                <p class="mt-2">Loading group details...</p>
            </div>
        </div>
    </div>

    <!-- Group Members Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Group Members</h6>
            <div id="memberActionsContainer"></div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="membersTable">
                    <thead>
                        <tr>
                            <th>USN</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody id="membersTableBody">
                        <tr>
                            <td colspan="4" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

<script>
var isReadOnly = <?php echo $isReadOnly ? 'true' : 'false'; ?>;
function editProjectTitle() {
    const currentTitle = $('#projectTitleDisplay').text();
    Swal.fire({
        title: 'Edit Project Title',
        input: 'text',
        inputValue: currentTitle,
        showCancelButton: true,
        confirmButtonText: 'Update',
        cancelButtonText: 'Cancel',
        inputValidator: (value) => {
            if (!value || value.trim().length === 0) {
                return 'Project title cannot be empty!';
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/update-project-title.php',
                type: 'POST',
                data: { project_title: result.value },
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Success!', response.message, 'success').then(() => {
                            loadGroupDetails();
                        });
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to update project title', 'error');
                }
            });
        }
    });
}

$(document).ready(function() {
    <?php if (!isset($_SESSION['group_id']) || !$_SESSION['group_id']): ?>
    
    // Handle group size change
    $('#groupSize').on('change', function() {
        const groupSize = parseInt($(this).val());
        if (groupSize > 0) {
            generateMemberFields(groupSize);
        } else {
            $('#groupMembersContainer').html('');
        }
    });
    
    // Handle domain dropdown change
    $('#projectDomain').on('change', function() {
        if ($(this).val() === 'Any others') {
            $('#customDomainContainer').show();
        } else {
            $('#customDomainContainer').hide();
        }
    });
    
    $('#createGroupForm').on('submit', function(e) {
        e.preventDefault();
        
        // Validate required fields
        const teamLeadName = $('#teamLeadName').val().trim();
        const teamLeadUSN = $('#teamLeadUSN').val().trim();
        const groupSize = $('#groupSize').val();
        const projectDomain = $('#projectDomain').val();
        const customDomain = $('#customDomain').val().trim();
        
        if (!teamLeadName || !teamLeadUSN || !groupSize || !projectDomain) {
            Swal.fire('Error!', 'All fields are required!', 'error');
            return;
        }
        
        // If "Any others" is selected, validate custom domain is provided
        if (projectDomain === 'Any others' && !customDomain) {
            Swal.fire('Error!', 'Please specify the custom domain!', 'error');
            return;
        }
        
        // Validate duplicate USNs
        const usns = [];
        usns.push(teamLeadUSN.toUpperCase());
        
        let hasDuplicates = false;
        $('.member-usn').each(function() {
            const usn = $(this).val().trim().toUpperCase();
            if (usn) {
                if (usns.includes(usn)) {
                    hasDuplicates = true;
                    $(this).addClass('is-invalid');
                } else {
                    usns.push(usn);
                    $(this).removeClass('is-invalid');
                }
            }
        });
        
        if (hasDuplicates) {
            Swal.fire('Error!', 'Duplicate USNs detected! Each member must have a unique USN.', 'error');
            return;
        }
        
        const formData = new FormData(this);
        const members = [];
        
        $('.member-row').each(function() {
            const name = $(this).find('.member-name').val().trim();
            const usn = $(this).find('.member-usn').val().trim();
            if (name && usn) {
                members.push({ name: name, usn: usn });
            }
        });
        
        formData.append('members', JSON.stringify(members));
        
        $.ajax({
            url: '../api/create-group.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    Swal.fire('Success!', response.message, 'success').then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function() {
                Swal.fire('Error!', 'Failed to create group', 'error');
            }
        });
    });
    <?php else: ?>
    // Load group details
    loadGroupDetails();
    <?php endif; ?>
});

function generateMemberFields(groupSize) {
    let html = '<hr><h6 class="mb-3">Group Members</h6>';
    
    // Generate fields for additional members (groupSize - 1, excluding team lead)
    for (let i = 1; i < groupSize; i++) {
        html += `
            <div class="member-row mb-3 p-3 border rounded">
                <h6 class="text-primary">Member ${i}</h6>
                <div class="form-group">
                    <label>Member Name *</label>
                    <input type="text" class="form-control member-name" 
                           name="member_name_${i}" required>
                </div>
                <div class="form-group">
                    <label>Member USN *</label>
                    <input type="text" class="form-control member-usn" 
                           name="member_usn_${i}" required>
                    <div class="invalid-feedback">
                        This USN is already added to the group!
                    </div>
                </div>
            </div>
        `;
    }
    
    $('#groupMembersContainer').html(html);
    
    // Add real-time duplicate validation
    $('.member-usn').on('input', function() {
        validateUSNDuplicates();
    });
    
    $('#teamLeadUSN').on('input', function() {
        validateUSNDuplicates();
    });
}

function validateUSNDuplicates() {
    const usns = [];
    const teamLeadUSN = $('#teamLeadUSN').val().trim().toUpperCase();
    
    if (teamLeadUSN) {
        usns.push(teamLeadUSN);
    }
    
    $('.member-usn').each(function() {
        const $input = $(this);
        const usn = $input.val().trim().toUpperCase();
        
        if (usn) {
            const count = usns.filter(u => u === usn).length;
            const teamLeadMatch = (teamLeadUSN === usn);
            
            if (count > 0 || teamLeadMatch) {
                $input.addClass('is-invalid');
            } else {
                $input.removeClass('is-invalid');
                usns.push(usn);
            }
        } else {
            $input.removeClass('is-invalid');
        }
    });
}

function loadGroupDetails() {
    $.ajax({
        url: '../api/get-group-details.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                const group = response.group;
                const members = response.members;
                const canEditMembers = response.can_edit_members;
                const canEditTitle = response.can_edit_title;
                const canEditDescription = response.can_edit_description;

                // Treat either a regular guide or a coordinator assigned as guide as 'guideAssigned'
                let guideAssigned = !!group.guide_id || !!group.coordinator_guide_id;
                let domainOptions = [
                    'Networking',
                    'Image Processing',
                    'Internet of Things',
                    'AI and ML',
                    'Data Science and Analytics (Big Data)',
                    'Block Chain',
                    'Web development',
                    'Embedded Systems',
                    'Cloud Computing',
                    'Deep Learning',
                    'Any others'
                ];
                let domainDropdown = `<select class="form-control" id="projectDomainDropdown" ${guideAssigned && !isReadOnly ? '' : 'disabled'}>`;
                domainDropdown += `<option value="">Select domain</option>`;
                domainOptions.forEach(opt => {
                    domainDropdown += `<option value="${opt}" ${group.domain === opt ? 'selected' : ''}>${opt}</option>`;
                });
                domainDropdown += `</select>`;
                let customDomainInput = `<input type="text" class="form-control mt-2" id="customDomainInput" placeholder="Enter domain details" value="${group.domain && !domainOptions.includes(group.domain) ? group.domain : ''}" style="display:${group.domain === 'Any others' ? 'block' : 'none'};" ${guideAssigned ? '' : 'disabled'}>`;
                let editTitleDomainBtn = `<button class="btn btn-sm btn-secondary mr-2" id="editTitleDomainBtn" ${guideAssigned && !isReadOnly ? '' : 'disabled'}><i class="fas fa-edit"></i> Edit Title/Domain</button>`;
                let editDescriptionBtn = `<button class="btn btn-sm btn-primary" id="editDescriptionBtn" ${guideAssigned && !isReadOnly ? '' : 'disabled'}><i class="fas fa-edit"></i> Edit Description</button>`;

                let projectFieldsHtml = '';
                if (!guideAssigned) {
                    projectFieldsHtml = `
                        <div class="alert alert-warning mb-2">Guide has to be assigned to fill these details.</div>
                        <div class="form-group">
                            <label>Project Domain</label>
                            <input type="text" class="form-control" value="${group.domain || ''}" disabled>
                        </div>
                        <div class="form-group">
                            <label>Project Title</label>
                            <input type="text" class="form-control" value="${group.project_title || ''}" disabled>
                        </div>
                        <div class="form-group">
                            <label>Project Description</label>
                            <textarea class="form-control" rows="3" disabled>${group.project_description || ''}</textarea>
                        </div>
                    `;
                } else if (!group.project_title || !group.domain || !group.project_description) {
                    // First time entry: show editable fields and OK button
                    projectFieldsHtml = `
                        <div id="projectDetailsForm">
                            <div class="form-group">
                                <label>Project Domain</label>
                                ${domainDropdown}
                                ${customDomainInput}
                            </div>
                            <div class="form-group">
                                <label>Project Title</label>
                                <input type="text" class="form-control" id="projectTitleInput" value="${group.project_title || ''}">
                            </div>
                            <div class="form-group">
                                <label>Project Description</label>
                                <textarea class="form-control" id="projectDescriptionInput" rows="3">${group.project_description || ''}</textarea>
                            </div>
                            <button class="btn btn-success" id="okProjectDetailsBtn">OK</button>
                        </div>
                    `;
                } else {
                    // After first submission: only show edit buttons
                    projectFieldsHtml = `
                        <div class="d-flex">
                            ${editTitleDomainBtn}
                            ${editDescriptionBtn}
                        </div>
                    `;
                }

                let html = `
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Group Name:</strong> ${group.group_name}</p>
                            ${window.isMiniProject ? '' : `<p><strong>Current Phase:</strong> <span class="badge badge-info">Phase ${group.current_phase}</span></p>`}
                            ${window.isMiniProject ? '' : `<p><strong>Current Review:</strong> <span class="badge badge-warning">Review ${group.current_review}</span></p>`}
                        </div>
                        <div class="col-md-6">
                                    <p><strong>Guide:</strong> 
                                        ${group.guide_name ? group.guide_name : (group.coordinator_guide_id && group.coordinator_name ? group.coordinator_name + ' (Coordinator)' : 'Not Assigned')}
                                    </p>
                                    <p><strong>Batch:</strong> ${group.batch ? group.batch + (group.academic_year_label ? ' (' + group.academic_year_label + ')' : (group.academic_year ? ' (' + group.academic_year + ')' : '')) : 'Not Assigned'}</p>
                                </div>
                    </div>
                    <hr>
                    <div>
                        <p><strong>Project Domain:</strong> ${group.domain || ''}</p>
                        <p><strong>Project Title:</strong> ${group.project_title || ''}</p>
                        <p><strong>Project Description:</strong> ${group.project_description || ''}</p>
                    </div>
                    ${projectFieldsHtml}
                `;
                $('#groupDetailsContainer').html(html);

                // Domain dropdown logic
                $('#projectDomainDropdown').on('change', function() {
                    if ($(this).val() === 'Any others') {
                        $('#customDomainInput').show();
                    } else {
                        $('#customDomainInput').hide();
                    }
                });

                // OK button logic for first time entry
                $('#okProjectDetailsBtn').on('click', function() {
                    const domain = $('#projectDomainDropdown').val();
                    const customDomain = $('#customDomainInput').val();
                    const title = $('#projectTitleInput').val();
                    const description = $('#projectDescriptionInput').val();
                    if (!domain || (domain === 'Any others' && !customDomain) || !title || !description) {
                        Swal.fire('Error!', 'All fields are required.', 'error');
                        return;
                    }
                    $.ajax({
                        url: '../api/update-project-details.php',
                        type: 'POST',
                        data: {
                            project_domain: domain,
                            custom_domain: customDomain,
                            project_title: title,
                            project_description: description
                        },
                        success: function(response) {
                            if (response.success) {
                                Swal.fire('Success!', response.message, 'success').then(() => {
                                    loadGroupDetails();
                                });
                            } else {
                                Swal.fire('Error!', response.message, 'error');
                            }
                        },
                        error: function() {
                            Swal.fire('Error!', 'Failed to update project details', 'error');
                        }
                    });
                });

                // Edit Title/Domain button logic
                $('#editTitleDomainBtn').on('click', function() {
                    if (!guideAssigned) return;
                    const currentTitle = $('#projectTitleInput').val() || '';
                    const currentDomain = $('#projectDomainDropdown').val() || '';
                    const currentCustomDomain = $('#customDomainInput').val() || '';
                    Swal.fire({
                        title: 'Edit Project Title/Domain',
                        html: `<input type='text' id='swalProjectTitle' class='swal2-input' placeholder='Project Title' value='${currentTitle}'>` +
                              `<br><select id='swalProjectDomain' class='swal2-select'>` +
                              domainOptions.map(opt => `<option value='${opt}' ${currentDomain === opt ? 'selected' : ''}>${opt}</option>`).join('') +
                              `</select>` +
                              `<br><input type='text' id='swalCustomDomain' class='swal2-input' placeholder='Specify domain' style='display:${currentDomain === 'Any others' ? 'block' : 'none'};' value='${currentCustomDomain}'>`,
                        preConfirm: () => {
                            return {
                                title: $('#swalProjectTitle').val(),
                                domain: $('#swalProjectDomain').val(),
                                customDomain: $('#swalCustomDomain').val()
                            };
                        },
                        didOpen: () => {
                            $('#swalProjectDomain').on('change', function() {
                                if ($(this).val() === 'Any others') {
                                    $('#swalCustomDomain').show();
                                } else {
                                    $('#swalCustomDomain').hide();
                                }
                            });
                        },
                        showCancelButton: true,
                        confirmButtonText: 'Update',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // AJAX to update title/domain
                            $.ajax({
                                url: '../api/update-project-title-domain.php',
                                type: 'POST',
                                data: {
                                    project_title: result.value.title,
                                    project_domain: result.value.domain,
                                    custom_domain: result.value.customDomain
                                },
                                success: function(response) {
                                    if (response.success) {
                                        Swal.fire('Success!', response.message, 'success').then(() => {
                                            loadGroupDetails();
                                        });
                                    } else {
                                        Swal.fire('Error!', response.message, 'error');
                                    }
                                },
                                error: function() {
                                    Swal.fire('Error!', 'Failed to update project title/domain', 'error');
                                }
                            });
                        }
                    });
                });

                // Edit Description button logic
                $('#editDescriptionBtn').on('click', function() {
                    if (!guideAssigned) return;
                    Swal.fire({
                        title: 'Edit Project Description',
                        input: 'textarea',
                        inputValue: $('#projectDescriptionInput').val(),
                        showCancelButton: true,
                        confirmButtonText: 'Update',
                        cancelButtonText: 'Cancel',
                        inputValidator: (value) => {
                            if (!value || value.trim().length === 0) {
                                return 'Project description cannot be empty!';
                            }
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: '../api/update-project-description.php',
                                type: 'POST',
                                data: { project_description: result.value },
                                success: function(response) {
                                    if (response.success) {
                                        Swal.fire('Success!', response.message, 'success').then(() => {
                                            loadGroupDetails();
                                        });
                                    } else {
                                        Swal.fire('Error!', response.message, 'error');
                                    }
                                },
                                error: function() {
                                    Swal.fire('Error!', 'Failed to update project description', 'error');
                                }
                            });
                        }
                    });
                });
                function editProjectTitle() {
                    const currentTitle = $('#projectTitleDisplay').text();
                    Swal.fire({
                        title: 'Edit Project Title',
                        input: 'text',
                        inputValue: currentTitle,
                        showCancelButton: true,
                        confirmButtonText: 'Update',
                        cancelButtonText: 'Cancel',
                        inputValidator: (value) => {
                            if (!value || value.trim().length === 0) {
                                return 'Project title cannot be empty!';
                            }
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: '../api/update-project-title.php',
                                type: 'POST',
                                data: { project_title: result.value },
                                success: function(response) {
                                    if (response.success) {
                                        Swal.fire('Success!', response.message, 'success').then(() => {
                                            loadGroupDetails();
                                        });
                                    } else {
                                        Swal.fire('Error!', response.message, 'error');
                                    }
                                },
                                error: function() {
                                    Swal.fire('Error!', 'Failed to update project title', 'error');
                                }
                            });
                        }
                    });
                }
                
                // Set member actions
                let memberActions = '';
                if (canEditMembers && !isReadOnly) {
                    memberActions = `
                        <button class="btn btn-sm btn-success" onclick="showAddMemberModal()">
                            <i class="fas fa-user-plus"></i> Add Member
                        </button>
                    `;
                }
                $('#memberActionsContainer').html(memberActions);
                
                // Load members with remove buttons if editable
                let membersHtml = '';
                members.forEach(member => {
                    const displayName = member.full_name || member.username;
                    const removeButton = canEditMembers && !member.is_team_lead ? 
                        `<button class="btn btn-sm btn-danger" onclick="removeMember(${member.id}, '${displayName}')">
                            <i class="fas fa-user-minus"></i> Remove
                         </button>` : '';
                    
                    membersHtml += `
                        <tr>
                            <td>${member.usn}</td>
                            <td>${displayName}</td>
                            <td>${member.email}</td>
                            <td>${member.is_team_lead ? '<span class="badge badge-success">Team Lead</span>' : 'Member'} ${removeButton}</td>
                        </tr>
                    `;
                });
                $('#membersTableBody').html(membersHtml);
            } else {
                // Session is stale - student has no group, reload to show Create Group form
                location.reload();
            }
        },
        error: function() {
            $('#groupDetailsContainer').html('<p class="text-danger">Failed to load group details</p>');
        }
    });
}

function editProjectDescription() {
    const currentDescription = $('#projectDescription').text();
    
    Swal.fire({
        title: 'Edit Project Description',
        input: 'textarea',
        inputValue: currentDescription,
        inputAttributes: {
            rows: 6
        },
        showCancelButton: true,
        confirmButtonText: 'Update',
        cancelButtonText: 'Cancel',
        inputValidator: (value) => {
            if (!value || value.trim().length === 0) {
                return 'Project description cannot be empty!';
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/update-project-description.php',
                type: 'POST',
                data: { project_description: result.value },
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Success!', response.message, 'success').then(() => {
                            loadGroupDetails();
                        });
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to update project description', 'error');
                }
            });
        }
    });
}

function showAddMemberModal() {
    Swal.fire({
        title: 'Add Group Member',
        html: `
            <div class="form-group text-left">
                <label for="memberName">Member Name *</label>
                <input type="text" id="memberName" class="form-control" placeholder="Enter member name">
            </div>
            <div class="form-group text-left">
                <label for="memberUSN">Member USN *</label>
                <input type="text" id="memberUSN" class="form-control" placeholder="Enter member USN">
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Add Member',
        cancelButtonText: 'Cancel',
        preConfirm: () => {
            const name = $('#memberName').val().trim();
            const usn = $('#memberUSN').val().trim();
            
            if (!name || !usn) {
                Swal.showValidationMessage('Both name and USN are required');
                return false;
            }
            
            return { name: name, usn: usn };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/add-group-member.php',
                type: 'POST',
                data: {
                    member_name: result.value.name,
                    member_usn: result.value.usn
                },
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Success!', response.message, 'success').then(() => {
                            loadGroupDetails();
                        });
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to add member', 'error');
                }
            });
        }
    });
}

function removeMember(memberId, memberName) {
    Swal.fire({
        title: 'Remove Member',
        text: `Are you sure you want to remove ${memberName} from the group?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, remove',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/remove-group-member.php',
                type: 'POST',
                data: { member_id: memberId },
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Success!', response.message, 'success').then(() => {
                            loadGroupDetails();
                        });
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to remove member', 'error');
                }
            });
        }
    });
}
</script>

