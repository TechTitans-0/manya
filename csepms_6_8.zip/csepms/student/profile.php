<?php
require_once '../config/config.php';
requireRole('student');

$currentPage = 'profile';
$pageTitle = 'My Profile';

$query = "SELECT u.username as full_name, u.usn_emp_id as usn, u.email, u.phone, s.branch, s.year_of_passing
          FROM students s
          INNER JOIN users u ON s.user_id = u.id
          WHERE s.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">My Profile</h1>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- Profile Details Card -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
            </div>
            <div class="card-body">
                <div id="alertBox"></div>
                
                <form id="profileForm">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Full Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="full_name" 
                                   value="<?php echo htmlspecialchars($student['full_name']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">USN</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" 
                                   value="<?php echo htmlspecialchars($student['usn']); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" name="email" 
                                   value="<?php echo htmlspecialchars($student['email']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Phone</label>
                        <div class="col-sm-9">
                            <input type="tel" class="form-control" name="phone" 
                                   value="<?php echo htmlspecialchars($student['phone']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Branch</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="branch" 
                                   value="<?php echo htmlspecialchars($student['branch']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Year of Passing</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" name="year_of_passing" 
                                   value="<?php echo htmlspecialchars($student['year_of_passing']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <div class="col-sm-9 offset-sm-3">
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- Change Password Card -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
            </div>
            <div class="card-body">
                <div id="passwordAlertBox"></div>
                
                <form id="passwordForm">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" class="form-control" name="current_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" class="form-control" name="new_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" class="form-control" name="confirm_password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-warning btn-block">Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Delay execution until jQuery is available to avoid "$ is not defined" errors
(function waitForjQueryAndInit() {
    function init($) {
        // Update profile
        $('#profileForm').submit(function(e) {
            e.preventDefault();

            $.ajax({
                url: '<?php echo BASE_URL; ?>api/update-profile.php',
                method: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#alertBox').html('<div class="alert alert-success">' + response.message + '</div>');
                        // Update topbar username/email if returned, then reload to ensure UI reflects changes
                        if (response.username || response.email) {
                            setTimeout(function() { location.reload(); }, 700);
                        }
                    } else {
                        $('#alertBox').html('<div class="alert alert-danger">' + response.message + '</div>');
                    }
                },
                error: function(xhr) {
                    console.error('Update profile error:', xhr.responseText);
                    var msg = 'Error updating profile. Please try again.';
                    try {
                        var j = JSON.parse(xhr.responseText);
                        if (j.message) msg = j.message;
                    } catch(e) {}
                    $('#alertBox').html('<div class="alert alert-danger">' + msg + '</div>');
                }
            });
        });

        // Change password
        $('#passwordForm').submit(function(e) {
            e.preventDefault();

            const newPass = $('[name="new_password"]').val();
            const confirmPass = $('[name="confirm_password"]').val();

            if (newPass !== confirmPass) {
                $('#passwordAlertBox').html('<div class="alert alert-danger">Passwords do not match!</div>');
                return;
            }

            if (newPass.length < 6) {
                $('#passwordAlertBox').html('<div class="alert alert-danger">New password must be at least 6 characters!</div>');
                return;
            }

            $.ajax({
                url: '<?php echo BASE_URL; ?>api/change-password.php',
                method: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#passwordAlertBox').html('<div class="alert alert-success">' + response.message + '</div>');
                        $('#passwordForm')[0].reset();
                    } else {
                        $('#passwordAlertBox').html('<div class="alert alert-danger">' + response.message + '</div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    $('#passwordAlertBox').html('<div class="alert alert-danger">Error changing password. Please try again.</div>');
                }
            });
        });
    }

    function check() {
        if (window.jQuery) {
            init(window.jQuery);
        } else {
            setTimeout(check, 50);
        }
    }

    check();
})();
</script>

<?php include '../includes/footer.php'; ?>
