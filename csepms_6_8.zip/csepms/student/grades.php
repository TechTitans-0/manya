<?php
require_once '../config/config.php';
requireRole('student');

// Allow students to view the grades page even if they are not assigned to a group.
// Previously the page redirected to group.php when `group_id` was missing; that
// redirect prevented students from viewing the grades/Uploads UI. We keep the page
// accessible and handle missing group state in the UI/JS.
$hasGroup = isset($_SESSION['group_id']) && !empty($_SESSION['group_id']);

$pageTitle = "My Grades";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">My Grades</h1>
    </div>

    <!-- Grades Container -->
    <div id="gradesContainer">
        <div class="text-center py-5">
            <div class="spinner-border" role="status"></div>
            <p class="mt-2">Loading grades...</p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Project type flag for Mini/Major project handling
const isMiniProject = <?php echo json_encode($_SESSION['project_type'] === 'mini'); ?>;

$(document).ready(function() {
    const hasGroup = <?php echo $hasGroup ? 'true' : 'false'; ?>;
    // make group id global so dynamically rendered buttons can access it
    window.currentGroupId = <?php echo isset($_SESSION['group_id']) ? intval($_SESSION['group_id']) : 'null'; ?>;

    if (!hasGroup) {
        $('#gradesContainer').html(`
            <div class="alert alert-info">
                <i class="fas fa-info-circle mr-2"></i>
                You are not assigned to a group yet. Grades will appear here when your coordinator adds them.
            </div>
        `);
    } else {
        loadGrades();
        // Auto-refresh every 60 seconds
        setInterval(function() {
            loadGrades();
        }, 60000);
    }
    
});

function loadGrades() {
    $.ajax({
        url: '../api/get-grades.php',
        type: 'GET',
        dataType: 'json',
        cache: false,
        success: function(response) {
            console.log('Grades API Response:', response);
            if (response.success) {
                        let html = '';

                        if (response.grades.length === 0) {
                            html = `
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle mr-2"></i>
                                    No grades available yet. Grades will appear here once your coordinator authorizes them.
                                </div>
                            `;
                        } else {
                            console.log('Loaded ' + response.grades.length + ' grades');
                            if (isMiniProject) {
                                html = renderMiniGradesTable(response.grades);
                            } else {
                                // Keep existing major project logic with phase/review grouping
                                const phases = {};
                                response.grades.forEach(grade => {
                                    const p = grade.phase || 0;
                                    if (!phases[p]) phases[p] = { phase: p, reviews: [] };
                                    phases[p].reviews.push(grade);
                                });

                                // render phase cards
                                Object.keys(phases).sort().forEach(pkey => {
                                    const phaseObj = phases[pkey];
                                    html += createPhaseCard(phaseObj);
                                });
                            }
                        }

                        $('#gradesContainer').html(html);



                        // Attach phase download handlers
                        // Attach per-review evaluation sheet handlers for students (group-level sheets)
                        // Note: using delegated handler instead (at bottom of file)
            } else {
                console.error('Grades API Error:', response.message);
                $('#gradesContainer').html(`
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        ${response.message || 'Unable to load grades'}
                    </div>
                `);
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', {xhr, status, error});
            $('#gradesContainer').html(`
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Failed to load grades. Please refresh the page or contact support.
                </div>
            `);
        }
    });
}

function renderMiniGradesTable(grades) {
    let rows = '';

    grades.forEach(grade => {
        rows += `
            <tr>
                <td>${grade.guide_name}</td>
                <td>${new Date(grade.graded_at).toLocaleDateString()}</td>
                <td class="text-center">${grade.total_marks}</td>
                <td class="text-center">${grade.max_marks}</td>
                <td class="text-center">
                    <button class="btn btn-sm btn-success" onclick="downloadEvaluationSheetPDF({ group_id: currentGroupId })"><i class="fas fa-file-alt"></i> Download</button>
                </td>
            </tr>
        `;
    });

    return `
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">My Grades</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="miniGradesTable">
                        <thead class="thead-light">
                            <tr>
                                <th>Guide</th>
                                <th>Graded On</th>
                                <th class="text-center">Total Marks</th>
                                <th class="text-center">Max Marks</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${rows}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}

function createPhaseCard(phaseObj) {
    let reviewsHtml = '';
    phaseObj.reviews.forEach(review => {
        // Build criteria table for this review
        let criteriaTbl = '';
        if (Array.isArray(review.criteria) && review.criteria.length > 0) {
            criteriaTbl += '<div class="table-responsive"><table class="table table-sm table-bordered mb-2"><thead><tr><th>Criteria</th><th class="text-center">Obtained</th><th class="text-center">Max</th></tr></thead><tbody>';
            review.criteria.forEach(c => {
                const obtained = (typeof c.marks_obtained !== 'undefined') ? parseFloat(c.marks_obtained).toFixed(2) : '0.00';
                const max = (typeof c.max_marks !== 'undefined') ? parseFloat(c.max_marks).toFixed(2) : '';
                criteriaTbl += `<tr><td>${c.criterion_name}</td><td class="text-center">${obtained}</td><td class="text-center">${max}</td></tr>`;
            });
            criteriaTbl += `<tr class="font-weight-bold bg-light"><td>Total</td><td class="text-center">${parseFloat(review.total_marks).toFixed(2)}</td><td class="text-center">${parseFloat(review.max_marks).toFixed(2)}</td></tr>`;
            criteriaTbl += '</tbody></table></div>';
        } else {
            criteriaTbl = '<div class="text-muted">No detailed criteria available.</div>';
        }

        reviewsHtml += `
            <div class="card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <strong>Review ${review.review}</strong>
                            <div class="small text-muted">${review.title} — Graded by ${review.guide_name} on ${new Date(review.graded_at).toLocaleDateString()}</div>
                        </div>
                       
                    </div>
                    ${criteriaTbl}
                    ${review.overall_remarks && review.overall_remarks.trim() !== '' ? `
                    <div class="alert alert-info mt-3 mb-0">
                        <h6 class="font-weight-bold mb-2">Overall Remarks:</h6>
                        <p class="mb-0" style="white-space: pre-wrap;">${review.overall_remarks}</p>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
    });

    return `
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Phase ${phaseObj.phase}</h6>
                <div>
                    <span class="small text-muted mr-3">${phaseObj.reviews.length} review(s)</span>
                    ${phaseObj.reviews.map(r => `<button class="btn btn-sm btn-outline-primary mr-1 eval-sheet-btn" data-phase="${phaseObj.phase}" data-review="${r.review}"><i class="fas fa-file-alt"></i> R${r.review}</button>`).join('')}
                </div>
            </div>
            <div class="card-body">
                ${reviewsHtml}
            </div>
        </div>
    `;
}

function getGradeBadgeClass(percentage) {
    if (percentage >= 90) return 'success';
    if (percentage >= 75) return 'primary';
    if (percentage >= 60) return 'info';
    if (percentage >= 50) return 'warning';
    return 'danger';
}

function downloadGradePDF(gradeId) {
    $.ajax({
        url: '../api/download-grade-pdf.php',
        type: 'GET',
        data: { grade_id: gradeId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Open HTML in new window for printing to PDF
                const printWindow = window.open('', '', 'height=600,width=800');
                printWindow.document.write(response.html);
                printWindow.document.close();
                
                // Auto-trigger print dialog
                setTimeout(function() {
                    printWindow.print();
                }, 250);
            } else {
                Swal.fire('Error', response.message || 'Failed to generate PDF', 'error');
            }
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
            Swal.fire('Error', 'Failed to generate PDF', 'error');
        }
    });
}
</script>
<?php include '../includes/evaluation_sheet_js.php'; ?>
<script>
// Delegated handler to ensure dynamically rendered eval-sheet-btns work
$(document).on('click', '.eval-sheet-btn', function() {
    const phase = $(this).data('phase');
    const review = $(this).data('review');
    if (!currentGroupId) {
        Swal.fire('Error', 'You are not assigned to any group.', 'error');
        return;
    }
    console.log('Eval sheet button clicked', { group: currentGroupId, phase, review });
    downloadEvaluationSheetPDF({ group_id: currentGroupId, phase: phase, review: review });
});
</script>

