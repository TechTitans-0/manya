<?php
require_once '../config/config.php';
requireRole('student');

$pageTitle = "Chat";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Messages</h1>

    <div class="row">
        <!-- Users List -->
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Conversations</h6>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush" id="usersList">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3" id="chatHeader">
                    <h6 class="m-0 font-weight-bold text-primary">Select a conversation</h6>
                </div>
                <div class="card-body" style="height: 500px; overflow-y: auto;" id="chatMessages">
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-comments fa-3x mb-3"></i>
                        <p>Select a user to start chatting</p>
                    </div>
                </div>
                <div class="card-footer" id="chatFooter" style="display: none;">
                    <form id="messageForm">
                        <div class="input-group">
                            <input type="text" class="form-control" id="messageInput" 
                                   placeholder="Type a message..." required>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<style>
.chat-item-unread {
    background-color: #f0f8ff !important;
    border-left: 4px solid #007bff !important;
}
.chat-item-unread .chat-name {
    font-weight: bold !important;
}
.unread-badge {
    background-color: #28a745;
    color: white;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 11px;
    font-weight: bold;
}
.last-message {
    color: #6c757d;
    font-size: 0.875rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 200px;
}
.message-time {
    font-size: 0.75rem;
    color: #999;
}
</style>

<script>
let currentChatUser = null;
let chatRefreshInterval = null;
let userListRefreshInterval = null;

$(document).ready(function() {
    loadChatUsers();
    updateSidebarBadge();

    $('#messageForm').on('submit', function(e) {
        e.preventDefault();
        sendMessage();
    });
    
    // Refresh chat list every 5 seconds
    userListRefreshInterval = setInterval(function() {
        loadChatUsers();
        updateSidebarBadge();
    }, 5000);
    
    // Clear refresh intervals when navigating away
    $(window).on('beforeunload', function() {
        if (chatRefreshInterval) clearInterval(chatRefreshInterval);
        if (userListRefreshInterval) clearInterval(userListRefreshInterval);
    });
});

function updateSidebarBadge() {
    $.getJSON('../api/get-chat-users.php', function(response) {
        if (response && response.success) {
            const users = response.users || [];
            let totalUnread = 0;
            users.forEach(u => {
                totalUnread += parseInt(u.unread_count || 0);
            });
            
            const badge = $('#sidebar-unread-chat-badge');
            if (totalUnread > 0) {
                badge.html(`<span class="badge badge-danger badge-counter">${totalUnread > 99 ? '99+' : totalUnread}</span>`).show();
            } else {
                badge.hide();
            }
        }
    });
}

function loadChatUsers() {
    $.getJSON('../api/get-chat-users.php', function(response) {
        if (!response || !response.success) {
            $('#usersList').html('<p class="text-center text-muted p-3">No conversations</p>');
            console.error('Failed to load chat users:', response);
            return;
        }

        const users = response.users || [];
        if (users.length === 0) {
            $('#usersList').html('<p class="text-center text-muted p-3">No conversations</p>');
            return;
        }

        let html = '';
        users.forEach(u => {
            const displayName = u.name || u.username || u.email || 'User';
            const unreadCount = parseInt(u.unread_count || 0);
            const lastMessage = u.last_message || 'No messages yet';
            const lastMessagePreview = lastMessage.length > 30 ? lastMessage.substring(0, 30) + '...' : lastMessage;
            const messageTime = u.last_message_time ? formatMessageTime(u.last_message_time) : '';
            
            const isUnread = unreadCount > 0;
            const unreadClass = isUnread ? 'chat-item-unread' : '';
            const activeClass = (currentChatUser && currentChatUser.id == u.id) ? 'active' : '';
            
            html += `
                <a href="#" class="list-group-item list-group-item-action user-item ${unreadClass} ${activeClass}" 
                   data-user-id="${u.id}" data-user-role="${u.role}">
                    <div class="d-flex w-100 justify-content-between align-items-start">
                        <div class="flex-grow-1" style="min-width: 0;">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="mb-0 chat-name">${displayName}</h6>
                                ${messageTime ? `<small class="message-time">${messageTime}</small>` : ''}
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="last-message">${lastMessagePreview}</small>
                                ${isUnread ? `<span class="unread-badge ml-2">${unreadCount}</span>` : ''}
                            </div>
                        </div>
                    </div>
                </a>
            `;
        });

        $('#usersList').html(html);

        $('.user-item').on('click', function(e) {
            e.preventDefault();
            const userId = $(this).data('user-id');
            const userRole = $(this).data('user-role');
            const userName = $(this).find('.chat-name').text().trim();
            openChat(userId, userName, userRole);
        });
    }).fail(function(xhr, status, error) {
        const respText = xhr && xhr.responseText ? xhr.responseText : (error || 'Unknown error');
        $('#usersList').html(`<p class="text-center text-danger p-3">Unable to load conversations: ${$('<div>').text(respText).html().substring(0,200)}</p>`);
        console.error('AJAX error loading chat users:', status, error, respText);
    });
}

function formatMessageTime(timeString) {
    const date = new Date(timeString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    return date.toLocaleDateString();
}

function openChat(userId, userName, userRole) {
    currentChatUser = {id: userId, name: userName, role: userRole};

    $('.user-item').removeClass('active');
    $(`.user-item[data-user-id="${userId}"]`).addClass('active');

    $('#chatHeader').html(`<h6 class="m-0 font-weight-bold text-primary">${userName}</h6>`);
    $('#chatMessages').html('<div class="text-center py-3"><i class="fas fa-spinner fa-spin"></i> Loading conversation...</div>');
    $('#chatFooter').show();

    // Load conversation history
    loadMessages();

    // Set up auto-refresh
    if (chatRefreshInterval) clearInterval(chatRefreshInterval);
    chatRefreshInterval = setInterval(loadMessages, 3000);
}

function loadMessages() {
    if (!currentChatUser) return;

    $.getJSON('../api/get-messages.php', { user_id: currentChatUser.id }, function(response) {
        if (!response || !response.success) {
            $('#chatMessages').html('<p class="text-center text-muted p-3">Unable to load messages. Please try again.</p>');
            console.error('Failed to load messages:', response);
            return;
        }

        let html = '';
        (response.messages || []).forEach(msg => {
            const isOwn = msg.sender_id == <?php echo $_SESSION['user_id']; ?>;
            html += createMessageBubble(msg, isOwn);
        });

        if (html === '') html = '<p class="text-center text-muted">No messages yet. Start the conversation!</p>';

        const chatBox = $('#chatMessages');
        const shouldScroll = chatBox[0].scrollHeight - chatBox.scrollTop() <= chatBox.outerHeight() + 50;
        chatBox.html(html);
        if (shouldScroll) chatBox.scrollTop(chatBox[0].scrollHeight);
        
        // Refresh user list and sidebar badge after messages are loaded (marks as read)
        loadChatUsers();
        updateSidebarBadge();
    }).fail(function(xhr, status, error) {
        $('#chatMessages').html('<p class="text-center text-danger p-3"><i class="fas fa-exclamation-triangle"></i> Error loading messages. Please refresh the page.</p>');
        console.error('AJAX error loading messages:', status, error, xhr.responseText);
    });
}

function sendMessage() {
    const message = $('#messageInput').val().trim();
    if (!message || !currentChatUser) return;

    // Clear input immediately
    $('#messageInput').val('');

    $.post('../api/send-message.php', {
        receiver_id: currentChatUser.id,
        receiver_role: currentChatUser.role,
        message: message,
        group_id: <?php echo isset($_SESSION['group_id']) ? $_SESSION['group_id'] : 'null'; ?>
    }, function(response) {
        console.log('Send message response:', response);
        if (response && response.success) {
            console.log('Message sent successfully, ID:', response.id);
            // Reload messages to show the sent message
            loadMessages();
            // Refresh user list to update last message preview
            loadChatUsers();
        } else {
            console.error('Failed to send message:', response);
            Swal.fire('Error', (response && response.message) || 'Unable to send message', 'error');
            $('#messageInput').val(message);
        }
    }, 'json').fail(function(xhr, status, error) {
        console.error('AJAX error sending message:', status, error);
        console.error('Response text:', xhr.responseText);
        Swal.fire('Error', 'Unable to send message', 'error');
        $('#messageInput').val(message);
    });
}

function createMessageBubble(msg, isOwn) {
    const alignment = isOwn ? 'text-right' : 'text-left';
    const bgClass = isOwn ? 'bg-primary text-white' : 'bg-light';
    const dateTime = formatFullDateTime(msg.sent_at);
    const senderName =  msg.sender_name || '';

    return `
        <div class="${alignment} mb-3">
            <div class="d-inline-block ${bgClass} rounded px-3 py-2" style="max-width: 70%;">
                ${!isOwn ? `<small class="badge badge-secondary mb-1">${senderName}</small><br>` : ''}
                <p class="mb-0">${msg.message}</p>
                <small class="text-${isOwn ? 'white-50' : 'muted'}">${dateTime}</small>
            </div>
        </div>
    `;
}

function formatFullDateTime(timeString) {
    const date = new Date(timeString);
    const now = new Date();
    
    // Reset time to midnight for date comparison
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const messageDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Format time as HH:MM AM/PM
    const timeStr = date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
    
    // Determine date label
    if (messageDate.getTime() === today.getTime()) {
        return `Today, ${timeStr}`;
    } else if (messageDate.getTime() === yesterday.getTime()) {
        return `Yesterday, ${timeStr}`;
    } else {
        // Format as "22 Jan 2026, 11:10 AM"
        const day = date.getDate();
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                           'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        return `${day} ${month} ${year}, ${timeStr}`;
    }
}

</script>

