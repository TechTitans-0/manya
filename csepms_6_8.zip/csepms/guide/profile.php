<?php
require_once '../config/config.php';
requireRole('guide');

$pageTitle = "My Profile";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

// Get guide details
$query = "SELECT u.username as full_name, u.usn_emp_id as employee_id, u.email, u.phone, g.domain, g.department 
          FROM users u 
          INNER JOIN guides g ON u.id = g.user_id 
          WHERE u.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$guide = $stmt->get_result()->fetch_assoc();
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">My Profile</h1>

    <div class="row">
        <div class="col-lg-12">
            <!-- Profile Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
                </div>
                <div class="card-body">
                    <form id="profileForm">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Employee ID</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($guide['employee_id']); ?>" readonly>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Full Name</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="full_name" id="full_name" 
                                       value="<?php echo htmlspecialchars($guide['full_name']); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Email</label>
                            <div class="col-sm-9">
                                <input type="email" class="form-control" name="email" id="email" 
                                       value="<?php echo htmlspecialchars($guide['email']); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Phone</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="phone" id="phone" 
                                       value="<?php echo htmlspecialchars($guide['phone']); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Domain/Expertise</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="domain" id="domain" 
                                       value="<?php echo htmlspecialchars($guide['domain'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Department</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="department" id="department" 
                                       value="<?php echo htmlspecialchars($guide['department']); ?>">
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Change Password Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
                </div>
                <div class="card-body">
                    <form id="passwordForm">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" class="form-control" name="new_password" id="new_password" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Update Profile
$('#profileForm').on('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    $.ajax({
        url: '../api/update-profile.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                Swal.fire('Success!', response.message, 'success');
                setTimeout(function(){ location.reload(); }, 700);
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to update profile', 'error');
        }
    });
});

// Change Password
$('#passwordForm').on('submit', function(e) {
    e.preventDefault();
    
    const newPass = $('#new_password').val();
    const confirmPass = $('input[name="confirm_password"]').val();
    
    if (newPass !== confirmPass) {
        Swal.fire('Error!', 'Passwords do not match', 'error');
        return;
    }
    
    const formData = new FormData(this);
    
    $.ajax({
        url: '../api/change-password.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                Swal.fire('Success!', response.message, 'success');
                $('#passwordForm')[0].reset();
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to change password', 'error');
        }
    });
});
</script>
