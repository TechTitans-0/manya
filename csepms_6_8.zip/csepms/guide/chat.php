<?php
require_once '../config/config.php';
requireRole('guide');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Chat";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<style>
.chat-item-unread {
    background-color: #f0f8ff !important;
    border-left: 4px solid #007bff !important;
}
.chat-item-unread .chat-name {
    font-weight: bold !important;
}
.unread-badge {
    background-color: #28a745;
    color: white;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 11px;
    font-weight: bold;
}
.last-message {
    color: #6c757d;
    font-size: 0.875rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 200px;
}
.message-time {
    font-size: 0.75rem;
    color: #999;
}
</style>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Messages</h1>

    <div class="row">
        <!-- Users List -->
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Conversations</h6>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush" id="usersList">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3" id="chatHeader">
                    <h6 class="m-0 font-weight-bold text-primary">Select a conversation</h6>
                </div>
                <div class="card-body" style="height: 500px; overflow-y: auto;" id="chatMessages">
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-comments fa-3x mb-3"></i>
                        <p>Select a user to start chatting</p>
                    </div>
                </div>
                <div class="card-footer" id="chatFooter" style="display: none;">
                    <form id="messageForm">
                        <div class="input-group">
                            <input type="text" class="form-control" id="messageInput" 
                                   placeholder="Type a message..." required>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
let currentChatUser = null;
let chatRefreshInterval = null;
let userListRefreshInterval = null;

$(document).ready(function() {
    loadChatUsers();
    updateSidebarBadge();
    
    $('#messageForm').on('submit', function(e) {
        e.preventDefault();
        sendMessage();
    });
    
    // Refresh chat list every 5 seconds
    userListRefreshInterval = setInterval(function() {
        loadChatUsers();
        updateSidebarBadge();
    }, 5000);
    
    // Clear refresh intervals when navigating away
    $(window).on('beforeunload', function() {
        if (chatRefreshInterval) clearInterval(chatRefreshInterval);
        if (userListRefreshInterval) clearInterval(userListRefreshInterval);
    });
});

function updateSidebarBadge() {
    $.getJSON('../api/get-chat-users.php', function(response) {
        if (response && response.success) {
            const users = response.users || [];
            let totalUnread = 0;
            users.forEach(u => {
                totalUnread += parseInt(u.unread_count || 0);
            });
            
            const badge = $('#sidebar-unread-chat-badge');
            if (totalUnread > 0) {
                badge.html(`<span class="badge badge-danger badge-counter">${totalUnread > 99 ? '99+' : totalUnread}</span>`).show();
            } else {
                badge.hide();
            }
        }
    });
}

function formatMessageTime(timeString) {
    if (!timeString) return '';
    const date = new Date(timeString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    return date.toLocaleDateString();
}

function loadChatUsers() {
    $.ajax({
        url: '../api/get-chat-users.php',
        type: 'GET',
        success: function(response) {
            if (response.success && response.users && response.users.length > 0) {
                // Deduplicate: filter out duplicate entries by role+id
                const seen = {};
                const uniqueUsers = response.users.filter(item => {
                    const key = `${item.role || 'unknown'}-${item.id || item.group_id}`;
                    if (seen[key]) return false; // skip duplicate
                    seen[key] = true;
                    return true;
                });
                renderChatUsers(uniqueUsers);
            } else if (response.success) {
                loadFallbackGroups();
            } else {
                loadFallbackGroups();
            }
        },
        error: function() {
            loadFallbackGroups();
        }
    });
}

function renderChatUsers(users) {
    let html = '';
    users.forEach(item => {
        const unreadCount = parseInt(item.unread_count || 0);
        const lastMessage = item.last_message || 'No messages yet';
        const lastMessagePreview = lastMessage.length > 30 ? lastMessage.substring(0, 30) + '...' : lastMessage;
        const messageTime = formatMessageTime(item.last_message_time);
        const isUnread = unreadCount > 0;
        const unreadClass = isUnread ? 'chat-item-unread' : '';
                    
        if (item.role === 'group') {
            const activeClass = (currentGroupChat && currentGroupChat.group_id == item.id) ? 'active' : '';
            const groupName = item.group_name || item.name || 'Group';
            const batch = item.batch || '';
            const coordinatorName = item.coordinator_name || '';
            const displayTitle = batch ? `${groupName} - ${batch}` : groupName;
            const subtitle = coordinatorName ? `Coordinator: ${coordinatorName}` : '';
            html += `
                <a href="#" class="list-group-item list-group-item-action group-chat-item ${unreadClass} ${activeClass}" 
                   data-group-id="${item.id}" data-chat-type="${item.chat_type}" data-group-name="${groupName}" data-batch="${batch}" data-coordinator="${coordinatorName}">
                    <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                        <h6 class="mb-0 chat-name">${displayTitle}</h6>
                        <small class="badge badge-info">Group</small>
                    </div>
                    ${subtitle ? `<div class="text-muted small mb-1">${subtitle}</div>` : ''}
                    <div class="d-flex w-100 justify-content-between align-items-center">
                        <small class="last-message text-truncate" style="max-width: 70%;">${lastMessagePreview}</small>
                        <div class="d-flex align-items-center">
                            ${messageTime ? `<small class="message-time mr-2">${messageTime}</small>` : ''}
                            ${isUnread ? `<span class="unread-badge">${unreadCount}</span>` : ''}
                        </div>
                    </div>
                </a>
            `;
        } else {
            // Coordinator
            const displayName = item.name || item.username || item.full_name || 'Unknown User';
            const userName = item.name || item.username || 'User';
            const activeClass = (currentChatUser && currentChatUser.id == item.id) ? 'active' : '';
            html += `
                <a href="#" class="list-group-item list-group-item-action user-item ${unreadClass} ${activeClass}" 
                   data-user-id="${item.id}" data-user-name="${userName}" data-user-role="${item.role}">
                    <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                        <h6 class="mb-0 chat-name">${displayName}</h6>
                        <small class="badge badge-danger">coordinator</small>
                    </div>
                    <div class="d-flex w-100 justify-content-between align-items-center">
                        <small class="last-message text-truncate" style="max-width: 70%;">${lastMessagePreview}</small>
                        <div class="d-flex align-items-center">
                            ${messageTime ? `<small class="message-time mr-2">${messageTime}</small>` : ''}
                            ${isUnread ? `<span class="unread-badge">${unreadCount}</span>` : ''}
                        </div>
                    </div>
                </a>
            `;
        }
    });
    $('#usersList').html(html || '<p class="text-center text-muted p-3">No conversations</p>');

    // group click
    $('.group-chat-item').on('click', function(e) {
        e.preventDefault();
        const groupId = $(this).data('group-id');
        const groupName = $(this).data('group-name');
        const batch = $(this).data('batch');
        const coordinator = $(this).data('coordinator');
        openGroupChat(groupId, groupName, batch, coordinator);
    });

    // individual click
    $('.user-item').on('click', function(e) {
        e.preventDefault();
        const userId = $(this).data('user-id');
        const userName = $(this).data('user-name');
        const userRole = $(this).data('user-role');
        openChat(userId, userName, userRole);
    });
}

function loadFallbackGroups() {
    $.getJSON('../api/get-my-groups.php', function(resp) {
        if (!resp.success || !Array.isArray(resp.groups) || resp.groups.length === 0) {
            $('#usersList').html('<p class="text-center text-muted p-3">No conversations</p>');
            return;
        }

        let html = '';
        resp.groups.forEach(item => {
            const groupName = item.group_name || item.project_title || 'Group';
            const batch = item.batch || 'N/A';
            const coordinatorName = item.coordinator_name || 'Not assigned';
            const displayTitle = groupName;
            const subtitle = `Coordinator: ${coordinatorName} | Batch: ${batch}`;

            html += `
                <a href="#" class="list-group-item list-group-item-action group-chat-item" 
                   data-group-id="${item.id}" data-chat-type="project_group" data-group-name="${groupName}" data-batch="${batch}" data-coordinator="${coordinatorName}">
                    <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                        <h6 class="mb-0 chat-name">${displayTitle}</h6>
                        <small class="badge badge-info">Group</small>
                    </div>
                    <div class="text-muted small mb-1" style="font-size:0.8rem;">${subtitle}</div>
                    <div class="d-flex w-100 justify-content-between align-items-center">
                        <small class="last-message text-truncate" style="max-width: 70%;">No messages yet</small>
                        <div class="d-flex align-items-center"><small class="message-time">—</small></div>
                    </div>
                </a>
            `;
        });

        $('#usersList').html(html);
        $('.group-chat-item').on('click', function(e) {
            e.preventDefault();
            const groupId = $(this).data('group-id');
            const groupName = $(this).data('group-name');
            const batch = $(this).data('batch');
            const coordinator = $(this).data('coordinator');
            openGroupChat(groupId, groupName, batch, coordinator);
        });
    }).fail(function() {
        $('#usersList').html('<p class="text-center text-muted p-3">Unable to load conversations</p>');
    });
}

let currentGroupChat = null;

function openGroupChat(groupId, groupName, batch = '', coordinator = '') {
    currentGroupChat = { group_id: groupId, type: 'project_group' };
    currentChatUser = null;

    $('.user-item, .group-chat-item').removeClass('active');
    $(`.group-chat-item[data-group-id="${groupId}"]`).addClass('active');

    let headerTitle = `${groupName}`;
    if (batch) headerTitle += ` - ${batch}`;
    if (coordinator) headerTitle += ` (Coordinator: ${coordinator})`;

    $('#chatHeader').html(`<h6 class="m-0 font-weight-bold text-success"><i class="fas fa-users"></i> ${headerTitle}</h6>`);
    $('#chatMessages').html(`
        <div class="text-center py-3">
            <p class="text-muted mb-1">Coordinator: ${coordinator || 'N/A'} | Batch: ${batch || 'N/A'}</p>
            <div class="spinner-border spinner-border-sm"></div>
            <div class="mt-2">Loading conversation...</div>
        </div>
    `);
    $('#chatFooter').show();

    // Load conversation history
    loadGroupMessages();

    if (chatRefreshInterval) clearInterval(chatRefreshInterval);
    chatRefreshInterval = setInterval(loadGroupMessages, 3000);
}

function loadGroupMessages() {
    if (!currentGroupChat) return;

    $.ajax({
        url: '../api/get-group-messages.php',
        type: 'GET',
        data: { chat_type: currentGroupChat.type, group_id: currentGroupChat.group_id },
        dataType: 'json',
        success: function(response) {
            if (!response || !response.success) return;
            
            let html = '';
            if (response.messages && response.messages.length > 0) {
                response.messages.forEach(msg => {
                    const isOwn = msg.sender_id == <?php echo $_SESSION['user_id']; ?>;
                    html += createMessageBubble(msg, isOwn);
                });
            } else {
                html = '<p class="text-center text-muted">No messages yet. Start the conversation!</p>';
            }

            const chatBox = $('#chatMessages');
            const shouldScroll = chatBox[0].scrollHeight - chatBox.scrollTop() <= chatBox.outerHeight() + 50;
            chatBox.html(html);
            if (shouldScroll) chatBox.scrollTop(chatBox[0].scrollHeight);
            
            // Refresh user list and sidebar badge after messages are loaded (marks as read)
            loadChatUsers();
            updateSidebarBadge();
        },
        error: function(xhr) {
            console.error('Load group messages error:', xhr.responseText);
        }
    });
}

function openChat(userId, userName, userRole) {
    currentChatUser = {id: userId, name: userName, role: userRole};
    currentGroupChat = null;
    
    $('.user-item, .group-chat-item').removeClass('active');
    $(`.user-item[data-user-id="${userId}"]`).addClass('active');
    
    $('#chatHeader').html(`<h6 class="m-0 font-weight-bold text-primary">${userName}</h6>`);
    $('#chatMessages').html('<div class="text-center py-3"><i class="fas fa-spinner fa-spin"></i> Loading conversation...</div>');
    $('#chatFooter').show();
    
    // Load conversation history
    loadMessages();
    
    // Set up auto-refresh
    if (chatRefreshInterval) {
        clearInterval(chatRefreshInterval);
    }
    chatRefreshInterval = setInterval(loadMessages, 3000);
}

function loadMessages() {
    if (!currentChatUser) return;
    
    $.ajax({
        url: '../api/get-messages.php',
        type: 'GET',
        data: {user_id: currentChatUser.id},
        dataType: 'json',
        success: function(response) {
            if (response && response.success) {
                let html = '';
                if (response.messages && response.messages.length > 0) {
                    response.messages.forEach(msg => {
                        const isOwn = msg.sender_id == <?php echo $_SESSION['user_id']; ?>;
                        html += createMessageBubble(msg, isOwn);
                    });
                } else {
                    html = '<p class="text-center text-muted">No messages yet. Start the conversation!</p>';
                }
                
                const chatBox = $('#chatMessages');
                const shouldScroll = chatBox[0].scrollHeight - chatBox.scrollTop() <= chatBox.outerHeight() + 50;
                chatBox.html(html);
                if (shouldScroll) chatBox.scrollTop(chatBox[0].scrollHeight);
                
                // Refresh user list and sidebar badge after messages are loaded (marks as read)
                loadChatUsers();
                updateSidebarBadge();
            }
        },
        error: function(xhr) {
            console.error('Load messages error:', xhr.responseText);
        }
    });
}

function sendMessage() {
    const message = $('#messageInput').val().trim();
    if (!message) return;
    
    if (currentGroupChat) {
        $.ajax({
            url: '../api/send-group-message.php',
            type: 'POST',
            data: { 
                chat_type: currentGroupChat.type, 
                group_id: currentGroupChat.group_id, 
                message: message 
            },
            dataType: 'json',
            success: function(resp) {
                // Only show error if backend explicitly returns success: false
                if (resp && resp.success === false) {
                    const errorMsg = resp.message || 'Failed to send message';
                    console.error('Send failed:', resp);
                    Swal.fire('Error', errorMsg, 'error');
                } else {
                    // Treat all other cases as success
                    $('#messageInput').val('');
                    loadGroupMessages();
                    loadChatUsers();
                }
            },
            error: function(xhr, status, error) {
                // Only show error for real network/server failures (not backend success)
                let shouldShowError = true;
                try {
                    const parsedResponse = JSON.parse(xhr.responseText);
                    if (parsedResponse && parsedResponse.success === true) {
                        // Backend says success, jQuery misinterpreted - don't show error
                        console.log('Message sent successfully despite error callback');
                        $('#messageInput').val('');
                        loadGroupMessages();
                        loadChatUsers();
                        shouldShowError = false;
                    }
                } catch (e) {
                    // Could not parse as JSON, treat as real error
                }
                if (shouldShowError) {
                    console.error('AJAX Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    Swal.fire('Error', 'Failed to send message. Please try again.', 'error');
                }
            }
        });
    } else if (currentChatUser) {
        // Clear input immediately to prevent double-sending
        const messageToSend = message;
        $('#messageInput').val('');
        
        $.ajax({
            url: '../api/send-message.php',
            type: 'POST',
            data: {
                receiver_id: currentChatUser.id,
                receiver_role: currentChatUser.role,
                message: messageToSend
            },
            dataType: 'json',
            success: function(response) {
                // Check if response is valid and has success property
                if (response && response.success === true) {
                    // Message sent successfully, reload to show it
                    loadMessages();
                    loadChatUsers(); // Refresh user list to update last message
                } else {
                    // Only show error if explicitly failed
                    if (response && response.success === false) {
                        // Restore message on failure
                        $('#messageInput').val(messageToSend);
                        const errorMsg = response.message || 'Failed to send message';
                        console.error('Send failed:', response);
                        Swal.fire('Error', errorMsg, 'error');
                    } else {
                        // Response unclear, but assume success if no explicit failure
                        console.warn('Unclear response, assuming success:', response);
                        loadMessages();
                    }
                }
            },
            error: function(xhr, status, error) {
                // Only show error for real network/server failures
                // Check if response indicates success despite jQuery treating it as error
                let shouldShowError = true;
                try {
                    const parsedResponse = JSON.parse(xhr.responseText);
                    if (parsedResponse && parsedResponse.success === true) {
                        // Backend says success, jQuery misinterpreted - don't show error
                        console.log('Message sent successfully despite error callback');
                        loadMessages();
                        shouldShowError = false;
                    }
                } catch (e) {
                    // Could not parse as JSON, treat as real error
                }
                
                if (shouldShowError) {
                    // Restore message on error
                    $('#messageInput').val(messageToSend);
                    console.error('AJAX Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    Swal.fire('Error', 'Failed to send message. Please try again.', 'error');
                }
            }
        });
    }
}

function createMessageBubble(msg, isOwn) {
    const alignment = isOwn ? 'text-right' : 'text-left';
    const bgClass = isOwn ? 'bg-primary text-white' : 'bg-light';
    const dateTime = formatFullDateTime(msg.sent_at);
    const senderName = msg.sender_name || '';
    
    return `
        <div class="${alignment} mb-3">
            <div class="d-inline-block ${bgClass} rounded px-3 py-2" style="max-width: 70%;">
                ${!isOwn ? `<small class="badge badge-secondary mb-1">${senderName}</small><br>` : ''}
                <p class="mb-0">${msg.message}</p>
                <small class="text-${isOwn ? 'white-50' : 'muted'}">${dateTime}</small>
            </div>
        </div>
    `;
}

function formatFullDateTime(timeString) {
    const date = new Date(timeString);
    const now = new Date();
    
    // Reset time to midnight for date comparison
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const messageDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Format time as HH:MM AM/PM
    const timeStr = date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
    
    // Determine date label
    if (messageDate.getTime() === today.getTime()) {
        return `Today, ${timeStr}`;
    } else if (messageDate.getTime() === yesterday.getTime()) {
        return `Yesterday, ${timeStr}`;
    } else {
        // Format as "22 Jan 2026, 11:10 AM"
        const day = date.getDate();
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                           'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        return `${day} ${month} ${year}, ${timeStr}`;
    }
}

function getRoleBadgeClass(role) {
    const classes = {
        'student': 'info',
        'guide': 'success',
        'coordinator': 'danger'
    };
    return classes[role] || 'secondary';
}
</script>

