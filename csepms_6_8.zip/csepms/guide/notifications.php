<?php
require_once '../config/config.php';
requireRole('guide');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$currentPage = 'notifications';
$pageTitle = 'Notifications';

// Get notifications for the guide (only circulars from coordinator)
$query = "SELECT n.*, nrs.is_read, nrs.read_at, u.role as sender_role
          FROM notifications n
          INNER JOIN notification_read_status nrs ON n.id = nrs.notification_id
          INNER JOIN users u ON n.sender_id = u.id
          WHERE nrs.user_id = ? AND n.title LIKE 'Circular:%' AND u.role = 'coordinator'
          ORDER BY n.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Notifications</h1>
    <?php if (count($notifications) > 0): ?>
        <button class="btn btn-primary btn-sm" onclick="markAllAsRead()">
            <i class="fas fa-check-double"></i> Mark All as Read
        </button>
    <?php endif; ?>
</div>

<!-- Notifications List -->
<div class="row">
    <div class="col-lg-12">
        <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $notif): ?>
                <div class="card shadow mb-3 <?php echo $notif['is_read'] ? 'border-left-secondary' : 'border-left-primary'; ?>">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-auto">
                                <div class="icon-circle <?php echo $notif['is_read'] ? 'bg-secondary' : 'bg-primary'; ?>">
                                    <i class="fas fa-bell text-white"></i>
                                </div>
                            </div>
                            <div class="col">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="mb-1 font-weight-bold">
                                        <?php echo htmlspecialchars($notif['title']); ?>
                                        <?php if (!$notif['is_read']): ?>
                                            <span class="badge badge-primary ml-2">New</span>
                                        <?php endif; ?>
                                    </h5>
                                    <small class="text-muted">
                                        <?php echo date('d M Y, h:i A', strtotime($notif['created_at'])); ?>
                                    </small>
                                </div>
                                
                                <p class="mb-2"><?php echo nl2br(htmlspecialchars($notif['message'])); ?></p>
                                
                                <?php if (!empty($notif['attachment_path'])): ?>
                                    <a href="<?php echo BASE_URL . $notif['attachment_path']; ?>" 
                                       class="btn btn-sm btn-outline-primary" target="_blank">
                                        <i class="fas fa-paperclip"></i> View Attachment
                                    </a>
                                <?php endif; ?>
                                
                                <?php if (!$notif['is_read']): ?>
                                    <button class="btn btn-sm btn-outline-secondary ml-2" 
                                            onclick="markAsRead(<?php echo $notif['id']; ?>)">
                                        <i class="fas fa-check"></i> Mark as Read
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card shadow mb-4">
                <div class="card-body text-center py-5">
                    <i class="fas fa-bell-slash fa-3x text-gray-300 mb-3"></i>
                    <h5 class="text-gray-600">No notifications yet</h5>
                    <p class="text-gray-500">You'll see notifications from coordinator and system here.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.icon-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>

<script>
function markAsRead(notificationId) {
    $.ajax({
        url: '<?php echo BASE_URL; ?>api/mark-notification-read.php',
        method: 'POST',
        data: { notification_id: notificationId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                location.reload();
            } else {
                Swal.fire('Error!', response.message || 'Failed to mark notification as read', 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to mark notification as read', 'error');
        }
    });
}

function markAllAsRead() {
    $.ajax({
        url: '<?php echo BASE_URL; ?>api/mark-all-notifications-read.php',
        method: 'POST',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                Swal.fire('Success!', 'All notifications marked as read', 'success').then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Error!', response.message || 'Failed to mark all notifications as read', 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to mark all notifications as read', 'error');
        }
    });
}
</script>

<?php include '../includes/footer.php'; ?>
