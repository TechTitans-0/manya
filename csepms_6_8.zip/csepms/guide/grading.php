<?php
require_once '../config/config.php';
requireRole('guide');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Grading";
$projectType = getCurrentProjectType();
$isMiniProject = ($projectType === 'mini');

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Grade Students</h1>

    <!-- Global Drafts -->
    <div id="globalDraftsSection" class="card shadow mb-4" style="display:none;">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Saved Drafts</h6>
        </div>
        <div class="card-body" id="globalDraftsContainer">
            <!-- Filled by JS -->
        </div>
    </div>

    <!-- Select Group -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo $isMiniProject ? 'Select Group' : 'Select Group & Evaluation Sheet'; ?></h6>
        </div>
        <div class="card-body">
            <form id="selectForm">
                <div class="row">
                    <div class="<?php echo $isMiniProject ? 'col-md-12' : 'col-md-6'; ?>">
                        <div class="form-group">
                            <label for="groupSelect">Group *</label>
                            <select class="form-control" id="groupSelect" required>
                                <option value="">Loading...</option>
                            </select>
                        </div>
                    </div>
                    <?php if (!$isMiniProject): ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="evaluationSheetSelect">Evaluation Sheet *</label>
                            <select class="form-control" id="evaluationSheetSelect" required>
                                <option value="">Select Evaluation Sheet</option>
                            </select>
                        </div>
                    </div>
                    <?php else: ?>
                    <input type="hidden" id="evaluationSheetSelect">
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Grading Form -->
    <div id="gradingFormContainer" style="display: none;">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Student Evaluation</h6>
            </div>
            <div class="card-body">
                <form id="gradingForm">
                    <input type="hidden" id="selectedGroup" name="group_id">
                    <input type="hidden" id="evaluationSheetId" name="evaluation_sheet_id">

                    <div id="studentsContainer"></div>

                    <div class="form-group mt-4">
                        <label for="overallRemarks">Overall Remarks <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="overallRemarks" name="overall_remarks" rows="4" 
                                  placeholder="Provide overall remarks for this evaluation (mandatory for submission)..."></textarea>
                        <small class="form-text text-muted">These remarks will be included in the grade report.</small>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <div>
                            <button type="button" class="btn btn-secondary" onclick="saveAllGrades('draft')">
                                Save as Draft
                            </button>
                            <button type="button" class="btn btn-success" onclick="saveAllGrades('submitted')">
                                Submit All Grades
                            </button>
                        </div>
                        <div id="draftControls" style="display:none">
                            <span class="text-muted mr-2">Draft exists</span>
                            <button type="button" class="btn btn-sm btn-primary" id="submitDraftsBtn">Submit Drafts</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Check if this is a mini project
const isMiniProject = <?php echo json_encode($isMiniProject); ?>;

let evaluationCriteria = [];


function getUrlParam(name) {
    const url = new URL(window.location.href);
    return url.searchParams.get(name);
}

$(document).ready(function() {
    loadMyGroups();
    loadEvaluationSheets();
    loadAllDrafts();

    // Auto-select group and evaluation sheet from query params
    const preGroupId = getUrlParam('group_id');
    const preSheetId = getUrlParam('sheet_id');

    // Wait for dropdowns to be populated, then set and trigger
    if (preGroupId && preSheetId) {
        const trySetDropdowns = setInterval(function() {
            const groupOptionsReady = $('#groupSelect option').length > 1;
            const sheetOptionsReady = isMiniProject || $('#evaluationSheetSelect option').length > 1;
            
            if (groupOptionsReady && sheetOptionsReady) {
                $('#groupSelect').val(preGroupId);
                if (!isMiniProject) {
                    $('#evaluationSheetSelect').val(preSheetId);
                }
                $('#groupSelect, #evaluationSheetSelect').trigger('change');
                clearInterval(trySetDropdowns);
            }
        }, 100);
    }

    // Auto-load students when selections are made
    if (isMiniProject) {
        // For mini projects, only group selection matters
        $('#groupSelect').on('change', function() {
            const groupId = $(this).val();
            if (groupId) {
                // Get the evaluation sheet ID for this mini project group
                loadMiniProjectEvaluationSheet(groupId);
            } else {
                $('#gradingFormContainer').hide();
            }
        });
    } else {
        // For major projects, both selections matter
        $('#groupSelect, #evaluationSheetSelect').on('change', function() {
            const groupId = $('#groupSelect').val();
            const evaluationSheetId = $('#evaluationSheetSelect').val();
            if (groupId && evaluationSheetId) {
                loadGroupStudents();
            } else {
                $('#gradingFormContainer').hide();
            }
        });
    }
});

function loadMiniProjectEvaluationSheet(groupId) {
    // For mini projects, fetch the single evaluation sheet created by coordinator
    $.ajax({
        url: '../api/get-mini-project-evaluation-sheet.php',
        type: 'GET',
        data: {group_id: groupId},
        dataType: 'json',
        success: function(response) {
            if (response.success && response.sheet) {
                // Auto-populate the sheet ID
                $('#evaluationSheetSelect').val(response.sheet.id);
                // Load students for this group and sheet
                loadGroupStudents();
            } else {
                Swal.fire('Error', 'No evaluation sheet found for this mini project', 'error');
                $('#gradingFormContainer').hide();
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to load evaluation sheet', 'error');
            $('#gradingFormContainer').hide();
        }
    });
}

function loadMyGroups() {
    // Get groups assigned to this guide
    $.ajax({
        url: '../api/get-my-groups.php',
        type: 'GET',
        success: function(response) {
            if (response.success && response.groups) {
                let html = '<option value="">Select Group</option>';
                response.groups.forEach(group => {
                    html += `<option value="${group.id}">${group.group_name}</option>`;
                });
                $('#groupSelect').html(html);
            }
        }
    });
}

function loadAllDrafts() {
    $.ajax({
        url: '../api/get-draft-grades.php',
        type: 'GET',
        success: function(response) {
            let parsed = response;
            try { if (typeof response === 'string') parsed = JSON.parse(response); } catch(e) { parsed = {drafts: []}; }
            const drafts = (parsed && parsed.drafts) ? parsed.drafts : [];

            // Group drafts by group + evaluation sheet
            const grouped = {};
            drafts.forEach(d => {
                const key = d.group_id + '_' + d.evaluation_sheet_id;
                if (!grouped[key]) {
                    grouped[key] = {
                        group_id: d.group_id,
                        group_name: d.group_name,
                        evaluation_sheet_id: d.evaluation_sheet_id,
                        sheet_title: d.sheet_title,
                        phase: d.phase,
                        review: d.review,
                        students: []
                    };
                }
                grouped[key].students.push(d);
            });

            let html = '';
            if (Object.keys(grouped).length === 0) {
                html = '<div class="text-muted">No drafts saved yet.</div>';
            } else {
                Object.keys(grouped).forEach(k => {
                    const g = grouped[k];
                    html += `<div class="d-flex justify-content-between align-items-center"><h6 class="mt-2 mb-0">${g.sheet_title} — ${g.group_name} <small class="text-muted">(Phase ${g.phase}, Review ${g.review})</small></h6>`;
                    html += `<div><button class="btn btn-sm btn-outline-primary mr-2 open-draft-btn" data-group-id="${g.group_id}" data-sheet-id="${g.evaluation_sheet_id}">Open / Assign Grades</button><button class="btn btn-sm btn-success submit-draft-group-btn" data-group-id="${g.group_id}" data-sheet-id="${g.evaluation_sheet_id}">Submit Drafts</button></div></div>`;
                    html += '<div class="table-responsive"><table class="table table-sm table-bordered"><thead><tr><th>Student</th><th>USN</th>';

                    // Build dynamic criteria headers using first student's criteria
                    const first = g.students[0];
                    const criteria = first.criteria || [];
                    criteria.forEach(c => {
                        html += `<th>${c.criterion_name || 'Criterion'}<br><small>Max: ${c.max_marks || ''}</small></th>`;
                    });
                    html += '<th>Total</th><th>Status</th></tr></thead><tbody>';

                    g.students.forEach(s => {
                        html += `<tr><td>${s.student_name}</td><td>${s.usn}</td>`;
                        // ensure criteria align
                        (s.criteria || []).forEach(c => {
                            html += `<td>${parseFloat(c.marks_obtained).toFixed(2)}</td>`;
                        });
                        html += `<td>${parseFloat(s.total_marks).toFixed(2)}</td><td>${s.status}</td></tr>`;
                    });

                    html += '</tbody></table></div>';
                });
            }

            $('#globalDraftsContainer').html(html);
            $('#globalDraftsSection').show();

            // Attach handlers for open & submit buttons
            $('.open-draft-btn').off('click').on('click', function() {
                const gid = $(this).data('group-id');
                const sid = $(this).data('sheet-id');
                // set selects and load group students
                $('#groupSelect').val(gid);
                $('#evaluationSheetSelect').val(sid);
                // trigger change to load students
                $('#groupSelect, #evaluationSheetSelect').trigger('change');
                // Scroll to grading form
                $('html, body').animate({ scrollTop: $('#gradingFormContainer').offset().top - 100 }, 400);
            });

            $('.submit-draft-group-btn').off('click').on('click', function() {
                const gid = $(this).data('group-id');
                const sid = $(this).data('sheet-id');
                if (!confirm('Submit all drafts for this group and evaluation sheet? This will change the status from draft to submitted.')) return;
                
                Swal.fire({
                    title: 'Submitting...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });
                
                $.ajax({
                    url: '../api/submit-draft-grades.php',
                    type: 'POST',
                    data: { group_id: gid, evaluation_sheet_id: sid },
                    dataType: 'json',
                    success: function(resp) {
                        Swal.close();
                        if (resp && resp.success) {
                            Swal.fire('Success', resp.message, 'success').then(() => {
                                // Reload drafts to remove submitted ones
                                loadAllDrafts();
                                // if currently viewing same group+sheet, reload preload and hide drafts
                                const currentG = $('#groupSelect').val();
                                const currentS = $('#evaluationSheetSelect').val();
                                if (parseInt(currentG) === parseInt(gid) && parseInt(currentS) === parseInt(sid)) {
                                    preloadSavedGrades(currentG, currentS);
                                    $('#draftControls').hide();
                                    $('#draftsContainer').html('');
                                }
                            });
                        } else {
                            Swal.fire('Error', (resp && resp.message) || 'Failed to submit drafts', 'error');
                        }
                    },
                    error: function(xhr) {
                        Swal.close();
                        console.error('Submit error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to submit drafts', 'error');
                    }
                });
            });
        },
        error: function() {
            // Never hide the drafts section, just show empty
            $('#globalDraftsContainer').html('<div class="text-muted">No drafts saved yet.</div>');
            $('#globalDraftsSection').show();
        }
    });
}

function loadEvaluationSheets() {
    // For mini projects, skip loading evaluation sheets dropdown
    if (isMiniProject) {
        return;
    }
    
    $.ajax({
        url: '../api/get-active-evaluation-sheets.php',
        type: 'GET',
        success: function(response) {
            if (response.success && response.sheets) {
                let html = '<option value="">Select Evaluation Sheet</option>';
                response.sheets.forEach(sheet => {
                    html += `<option value="${sheet.id}">${sheet.title} (Phase ${sheet.phase}, Review ${sheet.review})</option>`;
                });
                $('#evaluationSheetSelect').html(html);
            }
        }
    });
}

function loadGroupStudents() {
    const groupId = $('#groupSelect').val();
    const evaluationSheetId = $('#evaluationSheetSelect').val();
    
    if (!groupId || !evaluationSheetId) {
        Swal.fire('Error', 'Please select both group and evaluation sheet', 'error');
        return;
    }
    
    // Load evaluation sheet criteria
    $.ajax({
        url: '../api/get-evaluation-sheet-criteria.php',
        type: 'GET',
        data: {id: evaluationSheetId},
        success: function(response) {
            if (response.success) {
                evaluationCriteria = response.criteria;
                $('#selectedGroup').val(groupId);
                $('#evaluationSheetId').val(evaluationSheetId);
                
                // Load group members
                $.ajax({
                    url: '../api/get-group-details.php',
                    type: 'GET',
                    data: {group_id: groupId},
                    success: function(memberResponse) {
                        if (memberResponse.success) {
                            renderStudentGradingForms(memberResponse.members);
                            // After rendering inputs, try to preload any saved grades for this group+sheet
                            preloadSavedGrades(groupId, evaluationSheetId);
                            $('#gradingFormContainer').show();
                        } else {
                            Swal.fire('Error', 'Failed to load group members', 'error');
                        }
                    },
                    error: function() {
                        Swal.fire('Error', 'Failed to load group members', 'error');
                    }
                });
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to load evaluation sheet', 'error');
        }
    });
}

function renderStudentGradingForms(members) {
    let html = '<div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Student</th><th>USN</th>';

    // Add criteria headers
    evaluationCriteria.forEach(criterion => {
        html += `<th>${criterion.name}<br><small>Max: ${criterion.max_marks}</small></th>`;
    });

    html += '<th>Total</th></tr></thead><tbody>';

    // Add student rows
    members.forEach(member => {
        const displayName = member.full_name || member.username;
        html += `<tr data-student-id="${member.id}">
            <td>${displayName}</td>
            <td>${member.usn}</td>`;

        // Add input fields for each criterion
        evaluationCriteria.forEach(criterion => {
            html += `<td>
                <input type="number" class="form-control marks-input"
                       data-student-id="${member.id}"
                       data-criterion-id="${criterion.id}"
                       data-max="${criterion.max_marks}"
                       min="0" max="${criterion.max_marks}" step="0.5"
                       placeholder="0">
            </td>`;
        });

        html += `<td><span class="student-total" data-student-id="${member.id}">0.00</span></td></tr>`;
    });

    html += '</tbody></table></div>';
    html += '<div id="draftsContainer" class="mt-3"></div>';
    $('#studentsContainer').html(html);

    // Add input event listeners
    $('.marks-input').on('input', function() {
        calculateStudentTotal($(this).data('student-id'));
    });
}

function preloadSavedGrades(groupId, evaluationSheetId) {

    $.ajax({
        url: '../api/get-group-grades.php',
        type: 'GET',
        data: { group_id: groupId, evaluation_sheet_id: evaluationSheetId },
        success: function(response) {
            if (!response.success || !response.grades) return;

            // Map grades by student id
            response.grades.forEach(function(grade) {
                if (parseInt(grade.evaluation_sheet_id) !== parseInt(evaluationSheetId)) return;

                const studentId = grade.student_id;
                // Fill criteria inputs
                if (Array.isArray(grade.criteria)) {
                    grade.criteria.forEach(function(c) {
                        const critId = c.criterion_id || c.criterion_id === 0 ? c.criterion_id : (c.criterion_id || c.id || c.criterion_id);
                        // Find input matching student and criterion
                        const input = $(`.marks-input[data-student-id="${studentId}"][data-criterion-id="${critId}"]`);
                        if (input.length) {
                            input.val(parseFloat(c.marks_obtained).toFixed(2));
                        }
                    });
                }

                // Update displayed total
                $(`.student-total[data-student-id="${studentId}"]`).text(parseFloat(grade.total_marks).toFixed(2));
            });

            // Recalculate totals in case some inputs were filled
            $('tr[data-student-id]').each(function() {
                calculateStudentTotal($(this).data('student-id'));
            });

            // Auto-fill overall remarks from the first grade (if available)
            let firstGradeWithRemarks = response.grades.find(g => g.overall_remarks && g.overall_remarks.trim() !== '');
            if (firstGradeWithRemarks) {
                $('#overallRemarks').val(firstGradeWithRemarks.overall_remarks);
            } else {
                $('#overallRemarks').val('');
            }

            // Display overall remarks if available
            let remarksHtml = '';
            if (response.overall_remarks) {
                remarksHtml = `<div class="alert alert-info"><strong>Overall Remarks:</strong> ${response.overall_remarks}</div>`;
            }

            // Only show/hide draftControls, do not render a second drafts table
            const drafts = (response.grades || []).filter(g => g.status && g.status === 'draft');
            if (drafts.length > 0) {
                $('#draftControls').show();
                $('#draftsContainer').html(remarksHtml);
                $('#submitDraftsBtn').off('click').on('click', function() {
                    if (!confirm('Submit all drafts for this evaluation sheet? This will change the status from draft to submitted.')) return;
                    Swal.fire({
                        title: 'Submitting...',
                        allowOutsideClick: false,
                        didOpen: () => { Swal.showLoading(); }
                    });
                    $.ajax({
                        url: '../api/submit-draft-grades.php',
                        type: 'POST',
                        data: { group_id: groupId, evaluation_sheet_id: evaluationSheetId },
                        dataType: 'json',
                        success: function(resp) {
                            Swal.close();
                            if (resp && resp.success) {
                                Swal.fire('Success', resp.message, 'success').then(() => {
                                    // Hide draft controls and clear drafts container
                                    $('#draftControls').hide();
                                    $('#draftsContainer').html('');
                                    // Reload all drafts list to remove this group
                                    loadAllDrafts();
                                    // Reload preloaded grades to show submitted status
                                    preloadSavedGrades(groupId, evaluationSheetId);
                                });
                            } else {
                                Swal.fire('Error', (resp && resp.message) || 'Failed to submit drafts', 'error');
                            }
                        },
                        error: function(xhr) {
                            Swal.close();
                            console.error('Submit error:', xhr.responseText);
                            Swal.fire('Error', 'Failed to submit drafts', 'error');
                        }
                    });
                });
            } else {
                $('#draftControls').hide();
                $('#draftsContainer').html(remarksHtml);
            }
        },
        error: function() {
            console.warn('Failed to preload saved grades');
        }
    });
}

function calculateStudentTotal(studentId) {
    let total = 0;
    $(`.marks-input[data-student-id="${studentId}"]`).each(function() {
        const value = parseFloat($(this).val()) || 0;
        const max = parseFloat($(this).data('max'));

        if (value > max) {
            $(this).addClass('is-invalid');
        } else {
            $(this).removeClass('is-invalid');
            total += value;
        }
    });

    $(`.student-total[data-student-id="${studentId}"]`).text(total.toFixed(2));
}

function saveAllGrades(status) {
    const groupId = $('#selectedGroup').val();
    const evaluationSheetId = $('#evaluationSheetId').val();
    const students = [];
    const totalStudents = $('tr[data-student-id]').length;

    // Collect data for each student
    $('tr[data-student-id]').each(function() {
        const studentId = $(this).data('student-id');
        const studentData = {
            student_id: studentId,
            criteria: []
        };

        let allFilled = true;
        $(this).find('.marks-input').each(function() {
            const marks = parseFloat($(this).val());
            if (isNaN(marks) || marks < 0) {
                allFilled = false;
                return false;
            }

            studentData.criteria.push({
                criterion_id: $(this).data('criterion-id'),
                obtained_marks: marks
            });
        });

        if (allFilled) {
            students.push(studentData);
        }
    });

    if (students.length === 0) {
        Swal.fire('Error', 'Please fill marks for at least one student', 'error');
        return;
    }

    // If submitting but not all students graded, save as draft instead
    let submitStatus = status;
    if (status === 'submitted' && students.length < totalStudents) {
        submitStatus = 'draft';
        Swal.fire('Notice', 'Not all students graded — saving as draft instead.', 'info');
    }

    // Get overall remarks
    const overallRemarks = $('#overallRemarks').val().trim();
    
    // Validate remarks for submission (mandatory when status is submitted)
    if (submitStatus === 'submitted' && !overallRemarks) {
        Swal.fire('Error', 'Overall remarks are mandatory when submitting grades', 'error');
        $('#overallRemarks').focus();
        return;
    }

    const formData = {
        group_id: groupId,
        evaluation_sheet_id: evaluationSheetId,
        status: submitStatus,
        overall_remarks: overallRemarks,
        students: JSON.stringify(students)
    };

    $.ajax({
        url: '../api/save-student-grades.php',
        type: 'POST',
        data: formData,
        success: function(response) {
            try {
                if (typeof response === 'string') {
                    response = JSON.parse(response);
                }
                
                if (response.success) {
                    Swal.fire('Success', response.message, 'success').then(() => {
                        // Refresh global drafts list so changes reflect everywhere
                        loadAllDrafts();

                        // If we are still viewing the same group & sheet, reload saved grades
                        const currentG = $('#groupSelect').val();
                        const currentS = $('#evaluationSheetSelect').val();
                        if (parseInt(currentG) === parseInt(groupId) && parseInt(currentS) === parseInt(evaluationSheetId)) {
                            preloadSavedGrades(currentG, currentS);
                        }

                        // Reset form and hide container
                        $('#selectForm')[0].reset();
                        $('#gradingFormContainer').hide();
                        $('#draftControls').hide();
                        $('#draftsContainer').html('');
                        loadMyGroups();
                        loadEvaluationSheets();
                    });
                } else {
                    Swal.fire('Error', response.message, 'error');
                }
            } catch (e) {
                console.error('JSON Parse Error:', e);
                console.error('Response:', response);
                Swal.fire('Error', 'Invalid response from server', 'error');
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', xhr.status, xhr.statusText);
            console.error('Response:', xhr.responseText);
            
            // Try to parse error response
            try {
                const errorResponse = JSON.parse(xhr.responseText);
                Swal.fire('Error', errorResponse.message || 'Failed to save grades', 'error');
            } catch (e) {
                // If response is not JSON, show generic error
                Swal.fire('Error', 'Failed to save grades. Please check your connection and try again.', 'error');
            }
        }
    });
}
</script>

