<?php
require_once '../config/config.php';
requireRole('guide');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Pending Reviews";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Pending Reviews</h1>

    <!-- Pending Reviews Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Files Awaiting Review</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="reviewsTable" width="100%">
                    <thead>
                        <tr>
                            <th>Project Title</th>
                            <th>Batch</th>
                            <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                            <th>Phase</th>
                            <th>Review</th>
                            <?php endif; ?>
                            <th>File Name</th>
                            <th>Uploaded By</th>
                            <th>Upload Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="reviewsTableBody">
                        <tr>
                            <td colspan="<?php echo ($_SESSION['project_type'] === 'mini') ? 7 : 9; ?>" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Review Modal -->
<div class="modal fade" id="reviewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Review Submission</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="reviewForm">
                <input type="hidden" id="uploadId" name="upload_id">
                <div class="modal-body">
                    <div class="alert alert-info" id="uploadInfo"></div>
                    
                    <div class="form-group">
                        <label for="feedback">Feedback *</label>
                        <textarea class="form-control" id="feedback" name="feedback" rows="4" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-warning" onclick="submitReview('changes_required')">
                        Request Changes
                    </button>
                    <button type="button" class="btn btn-success" onclick="submitReview('approved')">
                        Approve
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
const isMiniProject = <?php echo json_encode($_SESSION['project_type'] === 'mini'); ?>;
let reviewsCache = [];

$(document).ready(function() {
    loadPendingReviews();
});

function loadPendingReviews() {
    $.ajax({
        url: '../api/get-pending-reviews.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                reviewsCache = response.reviews || [];
                let html = '';

                if (reviewsCache.length === 0) {
                    const cols = isMiniProject ? 7 : 9;
                    html = `<tr><td colspan="${cols}" class="text-center">No uploads</td></tr>`;
                } else {
                    reviewsCache.forEach(review => {
                        const statusBadge = getStatusBadge(review.status);
                        html += `
                            <tr data-upload-id="${review.id}">
                                <td>${review.project_title || review.group_name}</td>
                                <td>${review.batch}</td>
                                ${!isMiniProject ? `<td>Phase ${review.phase}</td><td>Review ${review.review_type}</td>` : ''}
                                <td><a href="#" onclick="viewFile('${review.file_path}'); return false;">${review.file_name}</a></td>
                                <td>${review.uploaded_by_name}</td>
                                <td>${new Date(review.uploaded_at).toLocaleDateString()}</td>
                                <td>
                                    ${statusBadge}
                                    ${review.status !== 'approved' ? `
                                    <div class="btn-group ml-2">
                                        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-toggle="dropdown">Set</button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="#" onclick="changeStatus(${review.id}, 'pending'); return false;">Pending</a>
                                            <a class="dropdown-item" href="#" onclick="changeStatus(${review.id}, 'approved'); return false;">Reviewed</a>
                                        </div>
                                    </div>
                                    ` : ''}
                                </td>
                                <td>
                                    ${review.status !== 'approved' ? `<a href="reviews.php?upload_id=${review.id}" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> Review</a>` : `<span class='text-muted'>&mdash;</span>`}
                                </td>
                            </tr>
                        `;
                    });
                }

                $('#reviewsTableBody').html(html);

                // If navigated with upload_id param, open the review modal for that upload
                try {
                    const params = new URLSearchParams(window.location.search);
                    if (params.has('upload_id')) {
                        const targetId = params.get('upload_id');
                        const found = reviewsCache.find(r => String(r.id) === String(targetId));
                        if (found) {
                            openReviewModal(found.id);
                        }
                    }
                } catch (e) {
                    // ignore if URLSearchParams not supported
                }

                if ($.fn.DataTable.isDataTable('#reviewsTable')) {
                    $('#reviewsTable').DataTable().destroy();
                }
                $('#reviewsTable').DataTable({
                    order: [[6, 'desc']]
                });
            }
        },
        error: function() {
            const cols = isMiniProject ? 7 : 9;
            $('#reviewsTableBody').html(`<tr><td colspan="${cols}" class="text-center text-danger">No uploads</td></tr>`);
        }
    });
}

function viewFile(filePath) {
    // `file_path` already contains the relative path (uploads/project_files/...), avoid duplicating
    if (filePath.indexOf('uploads/') === 0) {
        window.open('../' + filePath, '_blank');
    } else {
        window.open('../' + filePath, '_blank');
    }
}

function openReviewModal(uploadId) {
    const found = reviewsCache.find(r => Number(r.id) === Number(uploadId));
    if (!found) return;
    $('#uploadId').val(found.id);
    let infoHtml = `<strong>Project:</strong> ${found.project_title || found.group_name}`;
    if (!isMiniProject) {
        infoHtml += `<br><strong>Phase:</strong> ${found.phase}<br><strong>Review:</strong> ${found.review_type}`;
    }
    $('#uploadInfo').html(infoHtml);
    $('#feedback').val(found.feedback || '');
    $('#reviewModal').modal('show');
}

function submitReview(status) {
    const uploadId = $('#uploadId').val();
    const feedback = $('#feedback').val().trim();
    
    if (!feedback) {
        Swal.fire('Error', 'Please provide feedback', 'error');
        return;
    }
    
    $.ajax({
        url: '../api/approve-upload.php',
        type: 'POST',
        data: {
            upload_id: uploadId,
            status: status,
            feedback: feedback
        },
        success: function(response) {
            if (response.success) {
                $('#reviewModal').modal('hide');
                // Remove upload_id from URL so modal does not reopen on refresh
                if (window.history.replaceState) {
                    const url = new URL(window.location);
                    url.searchParams.delete('upload_id');
                    window.history.replaceState({}, document.title, url.pathname + url.search);
                }
                Swal.fire('Success', response.message, 'success');
                // reload list so the updated status and feedback are visible
                loadPendingReviews();
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to submit review', 'error');
        }
    });
}

function changeStatus(uploadId, status) {
    $.post('../api/approve-upload.php', { upload_id: uploadId, status: status }, function(resp) {
        if (resp && resp.success) {
            Swal.fire('Success', resp.message, 'success');
            loadPendingReviews();
        } else {
            Swal.fire('Error', (resp && resp.message) || 'Failed to update status', 'error');
        }
    }, 'json').fail(function() {
        Swal.fire('Error', 'Failed to update status', 'error');
    });
}

function getStatusBadge(status) {
    const cls = status === 'approved' ? 'success' : (status === 'changes_required' ? 'warning' : 'secondary');
    const label = status === 'approved' ? 'Approved' : (status === 'changes_required' ? 'Changes Required' : 'Pending');
    return `<span class="badge badge-${cls}">${label}</span>`;
}
</script>

