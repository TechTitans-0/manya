<?php
require_once '../config/config.php';
requireRole('guide');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$currentPage = 'dashboard';
$pageTitle = 'Guide Dashboard';

// Get guide details
$guideQuery = "SELECT g.*, u.username, u.email, u.phone
               FROM guides g
               INNER JOIN users u ON g.user_id = u.id
               WHERE g.id = ?";
$stmt = $conn->prepare($guideQuery);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$guide = $stmt->get_result()->fetch_assoc();

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
    if ($selectedAcademicYearId) $_SESSION['academic_year_id'] = $selectedAcademicYearId;
}

// Get assigned groups for selected academic year
$groupsQuery = "SELECT COUNT(*) as count FROM pgroups WHERE guide_id = ? AND academic_year_id = ?";
$stmt = $conn->prepare($groupsQuery);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$groupsCount = $stmt->get_result()->fetch_assoc()['count'];

// Get pending reviews for selected academic year
$pendingQuery = "SELECT COUNT(*) as count FROM project_uploads pu
                 INNER JOIN pgroups g ON pu.group_id = g.id
                 WHERE g.guide_id = ? AND g.academic_year_id = ? AND pu.status = 'pending'";
$stmt = $conn->prepare($pendingQuery);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$pendingCount = $stmt->get_result()->fetch_assoc()['count'];

// Get completed gradings for selected academic year
$gradedQuery = "SELECT COUNT(*) as count FROM student_grades WHERE guide_id = ? AND status = 'submitted' AND academic_year_id = ?";
$stmt = $conn->prepare($gradedQuery);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$gradedCount = $stmt->get_result()->fetch_assoc()['count'];

// Get current phase and review from global settings
$cfgRes = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$current_phase = 1;  // default values
$current_review = 1;
while ($crow = $cfgRes->fetch_assoc()) {
    if ($crow['setting_key'] === 'current_phase') $current_phase = intval($crow['setting_value']);
    if ($crow['setting_key'] === 'current_review') $current_review = intval($crow['setting_value']);
}

// Get recent uploads for selected academic year
$uploadsQuery = "SELECT pu.*, g.group_name, g.batch, g.project_title 
                 FROM project_uploads pu
                 INNER JOIN pgroups g ON pu.group_id = g.id
                 WHERE g.guide_id = ? AND g.academic_year_id = ?
                 ORDER BY pu.upload_date DESC 
                 LIMIT 10";
$stmt = $conn->prepare($uploadsQuery);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$recentUploads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Guide Dashboard</h1>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Assigned Groups Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Assigned Groups</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $groupsCount; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Pending Reviews Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Pending Reviews</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $pendingCount; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($_SESSION['project_type'] !== 'mini'): ?>
    <!-- Current Phase & Review Card (replaces Completed Gradings) -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Current Phase</div>
                        <div class="h5 mb-1 font-weight-bold text-gray-800">Phase <?php echo $current_phase; ?></div>
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1 mt-2">Current Review</div>
                        <div class="h6 mb-0 font-weight-bold text-gray-800">Review <?php echo $current_review; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-tasks fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Domain Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Domain</div>
                        <div class="h6 mb-0 font-weight-bold text-gray-800">
                            <?php echo htmlspecialchars($guide['domain'] ?? 'Not specified'); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-bookmark fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Uploads -->
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Recent Uploads - Pending Review</h6>
                <a href="reviews.php" class="btn btn-primary btn-sm">View All</a>
            </div>
            <div class="card-body">
                <?php if (count($recentUploads) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable">
                            <thead>
                                <tr>
                                    <th>Project Title</th>
                                    <th>Batch</th>
                                    <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                                    <th>Phase</th>
                                    <th>Review</th>
                                    <?php endif; ?>
                                    <th>Filename</th>
                                    <th>Upload Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUploads as $upload): ?>
                                    <tr>
                                                <td><?php echo htmlspecialchars($upload['project_title'] ?? $upload['group_name']); ?></td>
                                        <td><?php echo htmlspecialchars($upload['batch']); ?></td>
                                        <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                                        <td>Phase <?php echo $upload['phase']; ?></td>
                                        <td>Review <?php echo $upload['review']; ?></td>
                                        <?php endif; ?>
                                        <td><?php echo htmlspecialchars($upload['filename']); ?></td>
                                        <td><?php echo date('d M Y, h:i A', strtotime($upload['upload_date'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php 
                                                echo $upload['status'] == 'approved' ? 'success' : 
                                                     ($upload['status'] == 'changes_required' ? 'warning' : 'secondary'); 
                                            ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $upload['status'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if (($upload['status'] ?? '') !== 'approved'): ?>
                                                <a href="reviews.php?upload_id=<?php echo $upload['id']; ?>" 
                                                   class="btn btn-info btn-sm">
                                                    <i class="fas fa-eye"></i> Review
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">&mdash;</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-inbox fa-3x text-gray-300 mb-3"></i>
                        <p class="text-gray-600">No uploads to review.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#dataTable').DataTable({
        "pageLength": 10,
        "ordering": true,
        "searching": true
    });
});
</script>

<?php include '../includes/footer.php'; ?>
