<?php
require_once '../config/config.php';
requireRole('guide');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$currentPage = 'groups';
$pageTitle = 'My Groups';

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
    if ($selectedAcademicYearId) $_SESSION['academic_year_id'] = $selectedAcademicYearId;
}

// Get global phase and review settings
$globalSettings = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$current_phase = 1;
$current_review = 1;
while ($row = $globalSettings->fetch_assoc()) {
    if ($row['setting_key'] === 'current_phase') $current_phase = intval($row['setting_value']);
    if ($row['setting_key'] === 'current_review') $current_review = intval($row['setting_value']);
}

// Get all groups assigned to this guide in the selected academic year
$groupsQuery = "SELECT g.*, b.batch_name, ay.year_label,
                COUNT(DISTINCT s.id) as member_count,
                (SELECT COUNT(*) FROM project_uploads pu WHERE pu.group_id = g.id AND pu.status = 'pending') as pending_reviews,
                (SELECT CONCAT(u.username, '|', u.phone) FROM students st 
                 INNER JOIN users u ON st.user_id = u.id 
                 WHERE st.group_id = g.id AND st.is_team_lead = 1 LIMIT 1) as team_lead_info
                FROM pgroups g
                LEFT JOIN batches b ON g.batch = b.batch_name
                LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
                LEFT JOIN students s ON s.group_id = g.id
                WHERE g.guide_id = ? AND g.academic_year_id = ?
                GROUP BY g.id
                ORDER BY g.batch DESC, g.group_name ASC";
$stmt = $conn->prepare($groupsQuery);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$groups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Add global phase/review and parse team lead info for each group
foreach ($groups as &$group) {
    $group['current_phase'] = $current_phase;
    $group['current_review'] = $current_review;
    
    // Parse team lead info
    if (!empty($group['team_lead_info'])) {
        $parts = explode('|', $group['team_lead_info']);
        $group['team_lead_name'] = $parts[0] ?? '';
        $group['team_lead_phone'] = $parts[1] ?? '';
    }
}

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">My Groups</h1>
        <div>
            <button class="btn btn-success btn-sm" id="downloadAllSheetsBtn"><i class="fas fa-file-archive"></i> Download All Sheets</button>
        </div>
    </div>

    <?php if (count($groups) > 0): ?>
        <div class="row">
            <?php foreach ($groups as $group): ?>
                <div class="col-lg-6 mb-4">
                    <div class="card shadow h-100">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary"><?php echo htmlspecialchars($group['group_name']); ?></h6>
                            <span class="badge badge-info"><?php echo htmlspecialchars($group['batch']); if (!empty($group['year_label'])) echo '(' . htmlspecialchars(formatAcademicYear($group['year_label'])) . ')'; ?></span>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p class="mb-2">
                                        <strong><i class="fas fa-users text-success"></i> Members:</strong><br>
                                        <?php echo $group['member_count']; ?> students
                                    </p>
                                    <?php if (!empty($group['team_lead_name'])): ?>
                                    <p class="mb-2">
                                        <strong><i class="fas fa-user-tie text-primary"></i> Team Lead:</strong><br>
                                        <?php echo htmlspecialchars($group['team_lead_name']); ?>
                                        <?php if (!empty($group['team_lead_phone'])): ?>
                                        <br><a href="tel:<?php echo htmlspecialchars($group['team_lead_phone']); ?>" class="text-success">
                                            <i class="fas fa-phone"></i> <?php echo htmlspecialchars($group['team_lead_phone']); ?>
                                        </a>
                                        <?php endif; ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <?php if ($group['pending_reviews'] > 0): ?>
                                    <p class="mb-2">
                                        <strong><i class="fas fa-exclamation-circle text-danger"></i> Pending:</strong><br>
                                        <span class="badge badge-warning"><?php echo $group['pending_reviews']; ?> reviews</span>
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if (!empty($group['project_title'])): ?>
                                <div class="mb-3">
                                    <strong><i class="fas fa-book text-primary"></i> Project Title:</strong>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($group['project_title']); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($group['project_description'])): ?>
                                <div class="mb-3">
                                    <strong><i class="fas fa-align-left text-primary"></i> Description:</strong>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($group['project_description']); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if ($group['pending_reviews'] > 0): ?>
                                <div class="alert alert-warning mb-3">
                                    <i class="fas fa-exclamation-triangle"></i> 
                                    <?php echo $group['pending_reviews']; ?> pending review(s)
                                </div>
                            <?php endif; ?>

                            <div class="btn-group btn-block" role="group">
                                <button class="btn btn-primary btn-sm" onclick="viewGroupDetails(<?php echo $group['id']; ?>)">
                                    <i class="fas fa-eye"></i> View Details
                                </button>
                                <button class="btn btn-info btn-sm" onclick="viewGroupGrades(<?php echo $group['id']; ?>)">
                                    <i class="fas fa-chart-bar"></i> View Grades
                                </button>
                                <?php if ($_SESSION['project_type'] === 'mini'): ?>
                                <button class="btn btn-success btn-sm" onclick="downloadGroupEvaluationSheet(<?php echo $group['id']; ?>)">
                                    <i class="fas fa-download"></i> Download
                                </button>
                                <?php else: ?>
                                <button class="btn btn-success btn-sm" onclick="downloadEvaluationSheetPDF({ group_id: <?php echo $group['id']; ?>, phase: <?php echo $group['current_phase']; ?>, review: 1 })">
                                    <i class="fas fa-file-alt"></i> Review 1
                                </button>
                                <button class="btn btn-success btn-sm" onclick="downloadEvaluationSheetPDF({ group_id: <?php echo $group['id']; ?>, phase: <?php echo $group['current_phase']; ?>, review: 2 })">
                                    <i class="fas fa-file-alt"></i> Review 2
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card shadow">
            <div class="card-body text-center py-5">
                <i class="fas fa-users fa-3x text-gray-300 mb-3"></i>
                <h5 class="text-gray-600">No Groups Assigned</h5>
                <p class="text-muted">You don't have any groups assigned yet.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Group Details Modal -->
<div class="modal fade" id="groupDetailsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Group Details</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="groupDetailsContent">
                <div class="text-center py-4">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php include '../includes/evaluation_sheet_js.php'; ?>

<script>
// Project type flag for Mini/Major project handling
const isMiniProject = <?php echo json_encode($_SESSION['project_type'] === 'mini'); ?>;

function viewGroupDetails(groupId) {
    $('#groupDetailsModal').modal('show');
    
    // Details only (grades moved to separate View Grades)
    let html = `
        <div id="detailsContent"></div>
    `;
    
    $('#groupDetailsContent').html(html);
    
    // Load group details
    $.ajax({
        url: '../api/get-group-details.php',
        type: 'GET',
        data: { group_id: groupId },
        success: function(response) {
            if (response.success) {
                const group = response.group;
                const members = response.members;
                
                let detailsHtml = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Group Information</h6>
                            <table class="table table-sm">
                                <tr>
                                    <td><strong>Group Name:</strong></td>
                                    <td>${group.group_name}</td>
                                </tr>
                                <tr>
                                    <td><strong>Batch:</strong></td>
                                    <td>${group.batch}</td>
                                </tr>
                                ${!isMiniProject ? `<tr>
                                    <td><strong>Current Phase:</strong></td>
                                    <td>Phase ${group.current_phase || '1'}</td>
                                </tr>` : ''}
                                ${!isMiniProject ? `<tr>
                                    <td><strong>Current Review:</strong></td>
                                    <td>Review ${group.current_review || '1'}</td>
                                </tr>` : ''}
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Project Information</h6>
                            <table class="table table-sm">
                                <tr>
                                    <td><strong>Title:</strong></td>
                                    <td>${group.project_title || 'Not set'}</td>
                                </tr>
                                <tr>
                                    <td colspan="2"><strong>Description:</strong><br>
                                    <span class="text-muted">${group.project_description || 'Not set'}</span></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h6 class="font-weight-bold">Group Members</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>USN</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                members.forEach(member => {
                    detailsHtml += `
                        <tr>
                            <td>${member.full_name || member.username}</td>
                            <td>${member.usn}</td>
                            <td>${member.email}</td>
                            <td>${member.phone || 'N/A'}</td>
                            <td>${member.is_team_lead == 1 ? '<span class="badge badge-primary">Team Lead</span>' : 'Member'}</td>
                        </tr>
                    `;
                });
                
                detailsHtml += `
                            </tbody>
                        </table>
                    </div>
                `;
                
                $('#detailsContent').html(detailsHtml);
            } else {
                $('#detailsContent').html('<div class="alert alert-danger">Failed to load group details</div>');
            }
        },
        error: function() {
            $('#detailsContent').html('<div class="alert alert-danger">Error loading group details</div>');
        }
    });
}

function viewGroupGrades(groupId) {
    // Open modal showing only grades
    $('#groupDetailsModal').modal('show');
    
    let html = `
        <div id="gradesContent">
            <div class="text-center py-4">
                <div class="spinner-border" role="status"></div>
                <p class="mt-2">Loading grades...</p>
            </div>
        </div>
    `;
    
    $('#groupDetailsContent').html(html);
    
    // Load group grades
    $.ajax({
        url: '../api/get-group-grades.php',
        type: 'GET',
        data: { group_id: groupId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const grades = response.grades;

                if (grades.length === 0) {
                    $('#groupDetailsContent').html(`
                        <div class="text-center py-4">
                            <i class="fas fa-info-circle fa-2x"></i>
                            <p class="mt-2">No grades available yet.</p>
                            <a class="btn btn-success" href="grading.php?group_id=${groupId}">Assign Grades</a>
                        </div>
                    `);
                    return;
                }
                
                // Group grades by evaluation sheet or mini-project grouped data
                let gradesHtml = '';
                let sheetGroups = {};
                for (let i = 0; i < grades.length; i++) {
                    const grade = grades[i];
                    const phaseKey = (typeof grade.phase !== 'undefined' && grade.phase !== null) ? grade.phase : 'mini';
                    const reviewKey = (typeof grade.review !== 'undefined' && grade.review !== null) ? grade.review : 'mini';
                    const sheetTitle = grade.sheet_title || 'Evaluation Sheet';
                    const sheetKey = `${phaseKey}-${reviewKey}-${sheetTitle}`;
                    if (!sheetGroups[sheetKey]) {
                        sheetGroups[sheetKey] = [];
                    }
                    sheetGroups[sheetKey].push({grade, idx: i});
                }

                Object.keys(sheetGroups).forEach(sheetKey => {
                    const groupGrades = sheetGroups[sheetKey];
                    const firstGrade = groupGrades[0].grade;
                    const sheetLabel = isMiniProject
                        ? `${firstGrade.sheet_title || 'Mini Project Evaluation'}`
                        : `Phase ${firstGrade.phase || 1} - Review ${firstGrade.review || 1} - ${firstGrade.sheet_title || 'Evaluation Sheet'}`;

                    // Edit button for the whole phase/review
                    gradesHtml += `
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <h6 class="font-weight-bold mb-0">${sheetLabel}</h6>
                            <button class="btn btn-sm btn-primary edit-grade-btn" data-sheetkey="${sheetKey}">Edit</button>
                        </div>
                        <div class="mb-2"><strong>Overall Remarks:</strong> ${firstGrade.overall_remarks ? firstGrade.overall_remarks : '<span class="text-muted">-</span>'}</div>
                        <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead>
                                <tr class="bg-light">
                                    <th>Student Name</th>
                                    <th>USN</th>
                                    <th>Criteria</th>
                                    <th>Total Marks</th>
                                    <th>Status</th>
                                    <th>Graded On</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    groupGrades.forEach(({grade}) => {
                        let statusBadge;
                        if (grade.status === 'submitted' || grade.status === 'approved') {
                            statusBadge = '<span class="badge badge-success">Submitted</span>';
                        } else {
                            statusBadge = '<span class="badge badge-warning">Draft</span>';
                        }
                        gradesHtml += `
                            <tr>
                                <td>${grade.student_name}</td>
                                <td>${grade.usn}</td>
                                <td>
                                    ${(grade.criteria && grade.criteria.length > 0) ?
                                        `<ul class='mb-0 pl-3'>` + grade.criteria.map(c => `<li>${c.criterion_name}: <strong>${parseFloat(c.marks_obtained).toFixed(2)}</strong>/${parseFloat(c.max_marks).toFixed(2)}</li>`).join('') + `</ul>`
                                        : '<span class="text-muted">-</span>'}
                                </td>
                                <td>${grade.total_marks.toFixed(2)}</td>
                                <td>${statusBadge}</td>
                                <td>${grade.graded_at ? new Date(grade.graded_at).toLocaleDateString() : '-'}</td>
                            </tr>
                        `;
                    });
                    gradesHtml += '</tbody></table></div>';
                });

                $('#groupDetailsContent').html(gradesHtml);

                // Attach handler to Edit buttons for each phase/review
                $('#groupDetailsContent').find('.edit-grade-btn').each(function() {
                    const sheetKey = $(this).data('sheetkey');
                    const groupGrades = sheetGroups[sheetKey];
                    if (!groupGrades || !groupGrades[0] || !groupGrades[0].grade) {
                        console.error('No grade data found for sheetKey', sheetKey);
                        return;
                    }

                    const selectedGroupId = groupId; // use outer function parameter

                    $(this).on('click', function() {
                        openPhaseReviewEditModal(groupGrades, selectedGroupId);
                    });
                });
            } else {
                $('#groupDetailsContent').html('<div class="alert alert-danger">Error: ' + (response.message || 'Failed to load grades') + '</div>');
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', xhr.status, xhr.statusText, error);
            console.error('Response:', xhr.responseText);
            
            let errorMsg = 'Error loading grades';
            try {
                const errorResponse = JSON.parse(xhr.responseText);
                errorMsg = errorResponse.message || errorMsg;
            } catch(e) {
                errorMsg = xhr.responseText || errorMsg;
            }
            
            $('#groupDetailsContent').html('<div class="alert alert-danger"><strong>Error:</strong> ' + errorMsg + '</div>');
        }
    });
}

// Modal to edit all students for a phase/review
function openPhaseReviewEditModal(groupGrades, groupId) {
    const firstGradeData = (groupGrades && groupGrades[0] && groupGrades[0].grade) ? groupGrades[0].grade : null;
    const initialRemarks = firstGradeData ? (firstGradeData.overall_remarks || '') : '';
    const gradeTitle = firstGradeData ?
        (isMiniProject ?
            `Edit Grades - ${firstGradeData.sheet_title || 'Mini Project Evaluation'}` :
            `Edit Grades - Phase ${firstGradeData.phase || 1} / Review ${firstGradeData.review || 1} / ${firstGradeData.sheet_title || 'Evaluation Sheet'}`
        ) : 'Edit Grades';

    let html = `
        <div class="modal-header">
            <h5 class="modal-title">${gradeTitle}</h5>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="phaseReviewGradeForm">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered">
                        <thead>
                            <tr><th>Student</th><th>USN</th><th>Criteria</th><th class="text-center">Current Total</th></tr>
                        </thead>
                        <tbody>
    `;
    groupGrades.forEach(({grade}, idx) => {
        const totalMarks = (typeof grade.total_marks !== 'undefined' && grade.total_marks !== null) ? parseFloat(grade.total_marks).toFixed(2) : '0.00';
        const maxMarks = (typeof grade.max_marks !== 'undefined' && grade.max_marks !== null) ? parseFloat(grade.max_marks).toFixed(2) : '0.00';
        html += `<tr><td>${grade.student_name}</td><td>${grade.usn}</td><td>`;
        (grade.criteria || []).forEach(function(c) {
            const val = (typeof c.marks_obtained !== 'undefined') ? parseFloat(c.marks_obtained).toFixed(2) : '';
            const max = (typeof c.max_marks !== 'undefined') ? parseFloat(c.max_marks).toFixed(2) : '';
            html += `<div class="mb-2">${c.criterion_name} <small class='text-muted'>(Max: ${max})</small>: <input type="number" step="0.5" min="0" max="${max}" class="form-control d-inline-block w-auto criterion-input" data-student-idx="${idx}" data-criterion-id="${c.criterion_id}" value="${val}"></div>`;
        });
        html += `</td><td class="text-center">${totalMarks}/${maxMarks}</td></tr>`;
    });
    html += `</tbody></table></div>`;
    html += `<div class="form-group mt-3">
                <label for="phaseOverallRemarks">Overall Remarks <span class="text-danger">*</span></label>
                <textarea class="form-control" id="phaseOverallRemarks" rows="4" placeholder="Enter overall remarks for this evaluation...">${initialRemarks}</textarea>
                <small class="form-text text-muted">These remarks will be included when the grade is saved.</small>
            </div>`;
    html += `<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success" id="submitPhaseReviewGradeBtn">Save & Submit</button>
    </div>`;

    let modal = $('#gradeDetailModal');
    if (!modal.length) {
        $('body').append(`
            <div class="modal fade" id="gradeDetailModal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content" id="gradeDetailContent"></div>
                </div>
            </div>
        `);
        modal = $('#gradeDetailModal');
    }
    $('#gradeDetailContent').html(html);
    modal.modal('show');
    // Remove aria-hidden from modal and all ancestors to avoid accessibility/focus issues
    modal.parents().addBack().removeAttr('aria-hidden');

    // Attach submit handler
    $('#submitPhaseReviewGradeBtn').on('click', function() {
        // collect criteria for all students
        const students = [];
        groupGrades.forEach(({grade}, idx) => {
            const criteria = [];
            $(`#gradeDetailContent .criterion-input[data-student-idx='${idx}']`).each(function() {
                const critId = $(this).data('criterion-id');
                const marks = parseFloat($(this).val()) || 0;
                criteria.push({ criterion_id: critId, obtained_marks: marks });
            });
            if (criteria.length > 0) {
                students.push({ student_id: grade.student_id, criteria });
            }
        });
        const overallRemarks = $('#phaseOverallRemarks').val().trim();
        if (!overallRemarks) {
            Swal.fire('Error', 'Overall remarks are required when submitting grades.', 'error');
            $('#phaseOverallRemarks').focus();
            return;
        }

        const payload = {
            group_id: String(groupId), // ensure always string, not undefined
            evaluation_sheet_id: String(groupGrades[0].grade.evaluation_sheet_id),
            status: 'submitted',
            students: JSON.stringify(students),
            overall_remarks: overallRemarks
        };
        // Debug: log payload before sending
        console.log('Submitting grades payload:', payload);
        $.ajax({
            url: '../api/save-student-grades.php',
            type: 'POST',
            data: payload,
            dataType: 'json',
            success: function(resp) {
                if (resp.success) {
                    Swal.fire('Success', resp.message, 'success').then(() => {
                        modal.modal('hide');
                        viewGroupGrades(groupId);
                    });
                } else {
                    Swal.fire('Error', resp.message || 'Failed to submit grade', 'error');
                }
            },
            error: function(xhr) {
                console.error('Submit error:', xhr.responseText);
                Swal.fire('Error', 'Failed to submit grade', 'error');
            }
        });
    });
}
</script>

<script>
// Download all evaluation sheets for all groups assigned to this guide
$('#downloadAllSheetsBtn').on('click', function() {
    Swal.fire({title: 'Preparing downloads...', allowOutsideClick: false, didOpen: () => Swal.showLoading()});
    $.getJSON('../api/get-my-groups.php', function(resp) {
        Swal.close();
        if (!resp.success || !resp.groups) {
            Swal.fire('Error', 'Failed to load groups', 'error');
            return;
        }
        
        if (isMiniProject) {
            // For Mini Projects: download once per group (no R1/R2 distinction)
            resp.groups.forEach(g => {
                downloadEvaluationSheetPDF({ group_id: g.id });
            });
        } else {
            // For Major Projects: download R1 & R2 for each group
            resp.groups.forEach(g => {
                downloadEvaluationSheetPDF({ group_id: g.id, phase: g.current_phase || 1, review: 1 });
                downloadEvaluationSheetPDF({ group_id: g.id, phase: g.current_phase || 1, review: 2 });
            });
        }
    }).fail(function() { Swal.close(); Swal.fire('Error', 'Failed to load groups', 'error'); });
});

function downloadGroupEvaluationSheet(groupId) {
    Swal.fire({title: 'Preparing sheet...', allowOutsideClick: false, didOpen: () => Swal.showLoading()});
    $.getJSON('../api/get-group-grades.php', { group_id: groupId }, function(resp) {
        Swal.close();
        if (!resp.success) {
            Swal.fire('Error', resp.message || 'Unable to load grade details', 'error');
            return;
        }

        if (!resp.grades || resp.grades.length === 0) {
            downloadEvaluationSheetPDF({ group_id: groupId });
            return;
        }

        const firstGrade = resp.grades[0];
        const sheetId = firstGrade.evaluation_sheet_id || null;
        if (sheetId) {
            downloadEvaluationSheetPDF({ group_id: groupId, evaluation_sheet_id: sheetId });
        } else {
            downloadEvaluationSheetPDF({ group_id: groupId });
        }
    }).fail(function(xhr, status, error) {
        Swal.close();
        console.error('Download group sheet error:', status, error, xhr.responseText);
        Swal.fire('Error', 'Failed to load grades for this group', 'error');
    });
}

</script>
