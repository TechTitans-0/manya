<?php
require_once 'config/config.php';

if (isLoggedIn()) {
    $role = $_SESSION['role'];
    redirect($role . '/dashboard.php');
}

// Check if project type is selected
if (!isset($_SESSION['project_type'])) {
    redirect('index.php');
}

$projectType = $_SESSION['project_type'];
$projectTitle = ($projectType === 'mini') ? 'Mini Project Management' : 'Final Year Project Management';
$projectLabel = ($projectType === 'mini') ? 'Mini Project' : 'Major Project';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Register - <?php echo $projectTitle; ?></title>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .form-group.position-relative {
            position: relative;
        }
        .form-group.position-relative input[type="password"] {
            padding-right: 2.5rem !important;
        }
        .form-group.position-relative .position-absolute {
            top: 50%;
            transform: translateY(-50%);
            right: 18px;
            z-index: 2;
            cursor: pointer;
        }
        .password-requirements {
            margin-top: 5px;
            padding: 8px;
            background-color: #f8f9fc;
            border-radius: 4px;
            border: 1px solid #e3e6f0;
        }
        .requirement {
            margin-bottom: 2px;
        }
        .requirement i {
            margin-right: 5px;
            width: 12px;
        }
        .project-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
        .project-badge.major {
            background-color: #667eea;
            color: white;
        }
        .project-badge.mini {
            background-color: #764ba2;
            color: white;
        }
        .btn-change-project {
            font-size: 12px;
            padding: 5px 10px;
            margin-left: 10px;
        }
    </style>
</head>
   
<body class="bg-gradient-primary">
    <div class="container">
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <div>
                                    <span class="project-badge <?php echo $projectType; ?>">
                                        <?php echo $projectLabel; ?>
                                    </span>
                                    <a href="logout-project.php" class="btn btn-sm btn-outline-primary btn-change-project">
                                        Change
                                    </a>
                                </div>
                                <h1 class="h4 text-gray-900 mb-4">Create an Account</h1>
                            </div>
                            
                            <div id="alertBox"></div>
                            
                            <!-- Role Selection -->
                            <div class="form-group">
                                <label>Select User Type</label>
                                <select class="form-control" id="userType">
                                    <option value="">-- Select User Type --</option>
                                    <option value="student">Student</option>
                                    <option value="guide">Guide</option>
                                    <option value="coordinator">Coordinator</option>
                                </select>
                            </div>
                            
                            <!-- Student Registration Form -->
                            <form class="user" id="studentForm" style="display: none;">
                                <input type="hidden" name="role" value="student">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="username" placeholder="Full Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="usn" placeholder="USN" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" 
                                                   name="email" placeholder="Email Address" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="tel" class="form-control form-control-user" 
                                                   name="phone" placeholder="Phone Number" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="number" class="form-control form-control-user" 
                                                   name="year_of_passing" placeholder="Year of Passing" 
                                                   min="2024" max="2030" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="branch" placeholder="Branch" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group position-relative">
                                            <input type="password" class="form-control form-control-user" 
                                                   name="password" id="student_password" placeholder="Password" required>
                                            <span class="position-absolute" onclick="togglePassword('student_password', this)">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                        <div id="student_password_requirements" class="password-requirements" style="display: none;">
                                            <small class="text-muted">
                                                <div id="student_length" class="requirement"><i class="fas fa-times text-danger"></i> At least 8 characters</div>
                                                <div id="student_uppercase" class="requirement"><i class="fas fa-times text-danger"></i> One uppercase letter</div>
                                                <div id="student_lowercase" class="requirement"><i class="fas fa-times text-danger"></i> One lowercase letter</div>
                                                <div id="student_number" class="requirement"><i class="fas fa-times text-danger"></i> One number</div>
                                                <div id="student_special" class="requirement"><i class="fas fa-times text-danger"></i> One special character</div>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group position-relative">
                                            <input type="password" class="form-control form-control-user" 
                                                   name="confirm_password" id="student_confirm_password" placeholder="Confirm Password" required>
                                            <span class="position-absolute" onclick="togglePassword('student_confirm_password', this)">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    Register as Student
                                </button>
                            </form>
                            
                            <!-- Guide Registration Form -->
                            <form class="user" id="guideForm" style="display: none;">
                                <input type="hidden" name="role" value="guide">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="username" placeholder="Full Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="employee_id" placeholder="Employee ID" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" 
                                                   name="email" placeholder="Email Address" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="tel" class="form-control form-control-user" 
                                                   name="phone" placeholder="Phone Number" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="domain" placeholder="Domain" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="department" placeholder="Department" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group position-relative">
                                            <input type="password" class="form-control form-control-user" 
                                                   name="password" id="guide_password" placeholder="Password" required>
                                            <span class="position-absolute" onclick="togglePassword('guide_password', this)">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                        <div id="guide_password_requirements" class="password-requirements" style="display: none;">
                                            <small class="text-muted">
                                                <div id="guide_length" class="requirement"><i class="fas fa-times text-danger"></i> At least 8 characters</div>
                                                <div id="guide_uppercase" class="requirement"><i class="fas fa-times text-danger"></i> One uppercase letter</div>
                                                <div id="guide_lowercase" class="requirement"><i class="fas fa-times text-danger"></i> One lowercase letter</div>
                                                <div id="guide_number" class="requirement"><i class="fas fa-times text-danger"></i> One number</div>
                                                <div id="guide_special" class="requirement"><i class="fas fa-times text-danger"></i> One special character</div>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group position-relative">
                                            <input type="password" class="form-control form-control-user" 
                                                   name="confirm_password" id="guide_confirm_password" placeholder="Confirm Password" required>
                                            <span class="position-absolute" onclick="togglePassword('guide_confirm_password', this)">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    Register as Guide
                                </button>
                            </form>
                            
                            <!-- Coordinator Registration Form -->
                            <form class="user" id="coordinatorForm" style="display: none;">
                                <input type="hidden" name="role" value="coordinator">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="username" placeholder="Full Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="employee_id" placeholder="Employee ID" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" 
                                                   name="email" placeholder="Email Address" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="tel" class="form-control form-control-user" 
                                                   name="phone" placeholder="Phone Number" required>
                                        </div>
                                    </div>
                                </div>
                                <!-- professional details for coordinator -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="designation" placeholder="Designation" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" 
                                                   name="research_domain_expertise" placeholder="Research Domain Expertise" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="number" class="form-control form-control-user" 
                                           name="years_of_experience" placeholder="Years of Experience" min="0" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" 
                                           name="department" placeholder="Department" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group position-relative">
                                            <input type="password" class="form-control form-control-user" 
                                                   name="password" id="coordinator_password" placeholder="Password" required>
                                            <span class="position-absolute" onclick="togglePassword('coordinator_password', this)">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                        <div id="coordinator_password_requirements" class="password-requirements" style="display: none;">
                                            <small class="text-muted">
                                                <div id="coordinator_length" class="requirement"><i class="fas fa-times text-danger"></i> At least 8 characters</div>
                                                <div id="coordinator_uppercase" class="requirement"><i class="fas fa-times text-danger"></i> One uppercase letter</div>
                                                <div id="coordinator_lowercase" class="requirement"><i class="fas fa-times text-danger"></i> One lowercase letter</div>
                                                <div id="coordinator_number" class="requirement"><i class="fas fa-times text-danger"></i> One number</div>
                                                <div id="coordinator_special" class="requirement"><i class="fas fa-times text-danger"></i> One special character</div>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group position-relative">
                                            <input type="password" class="form-control form-control-user" 
                                                   name="confirm_password" id="coordinator_confirm_password" placeholder="Confirm Password" required>
                                            <span class="position-absolute" onclick="togglePassword('coordinator_confirm_password', this)">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    Register as Coordinator
                                </button>
                            </form>
                            
                            <hr>
                            <div class="text-center">
                                <a class="small" href="login.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Show appropriate form based on user type
        document.getElementById('userType').addEventListener('change', function() {
            document.getElementById('studentForm').style.display = 'none';
            document.getElementById('guideForm').style.display = 'none';
            document.getElementById('coordinatorForm').style.display = 'none';
            
            if (this.value === 'student') {
                document.getElementById('studentForm').style.display = 'block';
            } else if (this.value === 'guide') {
                document.getElementById('guideForm').style.display = 'block';
            } else if (this.value === 'coordinator') {
                document.getElementById('coordinatorForm').style.display = 'block';
            }
        });
        
        // Handle form submissions
        function handleRegistration(formId) {
            document.getElementById(formId).addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const password = formData.get('password');
                const confirmPassword = formData.get('confirm_password');
                
                if (password !== confirmPassword) {
                    document.getElementById('alertBox').innerHTML = 
                        '<div class="alert alert-danger">Passwords do not match!</div>';
                    return;
                }
                
                fetch('api/register.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    return response.text();
                })
                .then(text => {
                    try {
                        const data = JSON.parse(text);
                        if (data.success) {
                            document.getElementById('alertBox').innerHTML = 
                                `<div class="alert alert-success">${data.message}</div>`;
                            setTimeout(() => {
                                window.location.href = 'login.php';
                            }, 2000);
                        } else {
                            document.getElementById('alertBox').innerHTML = 
                                `<div class="alert alert-danger">${data.message}</div>`;
                        }
                    } catch (e) {
                        console.error('Response text:', text);
                        document.getElementById('alertBox').innerHTML = 
                            '<div class="alert alert-danger">Invalid response from server. Check console for details.</div>';
                    }
                })
                .catch(error => {
                    document.getElementById('alertBox').innerHTML = 
                        '<div class="alert alert-danger">An error occurred. Please try again.</div>';
                    console.error('Error:', error);
                });
            });
        }
        
        handleRegistration('studentForm');
        handleRegistration('guideForm');
        handleRegistration('coordinatorForm');
        
        // Password validation and requirements display
        function setupPasswordValidation(formPrefix) {
            const passwordInput = document.getElementById(formPrefix + '_password');
            const requirementsDiv = document.getElementById(formPrefix + '_password_requirements');
            
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                if (password.length > 0) {
                    requirementsDiv.style.display = 'block';
                    updatePasswordRequirements(formPrefix, password);
                } else {
                    requirementsDiv.style.display = 'none';
                }
            });
            
            passwordInput.addEventListener('focus', function() {
                if (this.value.length > 0) {
                    requirementsDiv.style.display = 'block';
                }
            });
            
            passwordInput.addEventListener('blur', function() {
                // Keep requirements visible if password has content
                if (this.value.length === 0) {
                    requirementsDiv.style.display = 'none';
                }
            });
        }
        
        function updatePasswordRequirements(prefix, password) {
            // Length check
            const lengthReq = document.getElementById(prefix + '_length');
            if (password.length >= 8) {
                lengthReq.innerHTML = '<i class="fas fa-check text-success"></i> At least 8 characters';
            } else {
                lengthReq.innerHTML = '<i class="fas fa-times text-danger"></i> At least 8 characters';
            }
            
            // Uppercase check
            const upperReq = document.getElementById(prefix + '_uppercase');
            if (/[A-Z]/.test(password)) {
                upperReq.innerHTML = '<i class="fas fa-check text-success"></i> One uppercase letter';
            } else {
                upperReq.innerHTML = '<i class="fas fa-times text-danger"></i> One uppercase letter';
            }
            
            // Lowercase check
            const lowerReq = document.getElementById(prefix + '_lowercase');
            if (/[a-z]/.test(password)) {
                lowerReq.innerHTML = '<i class="fas fa-check text-success"></i> One lowercase letter';
            } else {
                lowerReq.innerHTML = '<i class="fas fa-times text-danger"></i> One lowercase letter';
            }
            
            // Number check
            const numberReq = document.getElementById(prefix + '_number');
            if (/[0-9]/.test(password)) {
                numberReq.innerHTML = '<i class="fas fa-check text-success"></i> One number';
            } else {
                numberReq.innerHTML = '<i class="fas fa-times text-danger"></i> One number';
            }
            
            // Special character check
            const specialReq = document.getElementById(prefix + '_special');
            if (/[!@#$%^&*()_+\-=\[\]{};\':"\\|,.<>\/?]/.test(password)) {
                specialReq.innerHTML = '<i class="fas fa-check text-success"></i> One special character';
            } else {
                specialReq.innerHTML = '<i class="fas fa-times text-danger"></i> One special character';
            }
        }
        
        // Setup password validation for all forms
        setupPasswordValidation('student');
        setupPasswordValidation('guide');
        setupPasswordValidation('coordinator');
        
        // Toggle password visibility for any field
        function togglePassword(inputId, el) {
            const passwordInput = document.getElementById(inputId);
            const icon = el.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
    
    </script>
</body>
</html>
