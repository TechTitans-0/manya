<?php
// Prevent directory access to the config folder.
header('Location: /csepms/index.php');
exit;
