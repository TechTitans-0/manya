<?php
require_once '../config/config.php';
requireRole('coordinator');

$pageTitle = "Profile";

// Get coordinator details (including professional fields)
$coordQuery = "SELECT u.username as full_name, u.usn_emp_id as employee_id, u.email, u.phone, c.department,
               c.designation, c.research_domain_expertise, c.years_of_experience
               FROM coordinators c
               INNER JOIN users u ON c.user_id = u.id
               WHERE c.id = ?";
$stmt = $conn->prepare($coordQuery);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$coordinator = $stmt->get_result()->fetch_assoc();

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">My Profile</h1>

    <div class="row">
        <div class="col-lg-8">
            <!-- Profile Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
                </div>
                <div class="card-body">
                    <form id="profileForm">
                        <div class="form-group">
                            <label for="username">Full Name *</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo htmlspecialchars($coordinator['full_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($coordinator['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" 
                                   value="<?php echo htmlspecialchars($coordinator['phone'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="employee_id">Employee ID</label>
                            <input type="text" class="form-control" id="employee_id" 
                                   value="<?php echo htmlspecialchars($coordinator['employee_id']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="designation">Designation</label>
                            <input type="text" class="form-control" id="designation" name="designation"
                                   value="<?php echo htmlspecialchars($coordinator['designation'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="research_domain_expertise">Research Domain Expertise</label>
                            <input type="text" class="form-control" id="research_domain_expertise" name="research_domain_expertise"
                                   value="<?php echo htmlspecialchars($coordinator['research_domain_expertise'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="years_of_experience">Years of Experience</label>
                            <input type="number" class="form-control" id="years_of_experience" name="years_of_experience" min="0"
                                   value="<?php echo htmlspecialchars($coordinator['years_of_experience'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="department">Department</label>
                            <input type="text" class="form-control" id="department" name="department" 
                                   value="<?php echo htmlspecialchars($coordinator['department'] ?? ''); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save mr-2"></i> Update Profile
                        </button>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
                </div>
                <div class="card-body">
                    <form id="passwordForm">
                        <div class="form-group">
                            <label for="current_password">Current Password *</label>
                            <input type="password" class="form-control" id="current_password" 
                                   name="current_password" required>
                        </div>
                        <div class="form-group">
                            <label for="new_password">New Password *</label>
                            <input type="password" class="form-control" id="new_password" 
                                   name="new_password" minlength="6" required>
                            <small class="form-text text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password *</label>
                            <input type="password" class="form-control" id="confirm_password" 
                                   name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-key mr-2"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

<?php include '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    // Update Profile
    $('#profileForm').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: '../api/update-profile.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire('Success!', response.message, 'success');
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function() {
                Swal.fire('Error!', 'Failed to update profile', 'error');
            }
        });
    });
    
    // Change Password
    $('#passwordForm').on('submit', function(e) {
        e.preventDefault();
        
        const newPassword = $('#new_password').val();
        const confirmPassword = $('#confirm_password').val();
        
        if (newPassword !== confirmPassword) {
            Swal.fire('Error!', 'New passwords do not match', 'error');
            return;
        }
        
        $.ajax({
            url: '../api/change-password.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire('Success!', response.message, 'success');
                    $('#passwordForm')[0].reset();
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function() {
                Swal.fire('Error!', 'Failed to change password', 'error');
            }
        });
    });
});
</script> 
