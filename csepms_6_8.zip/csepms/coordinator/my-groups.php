<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$currentPage = 'my-groups';
$pageTitle = 'My Groups';

// Get selected academic year status for read-only mode
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? $_SESSION['academic_year_id'] : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
}

$academicYearStatus = 'ACTIVE';
if ($selectedAcademicYearId) {
    $yearStatusStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
    $yearStatusStmt->bind_param("i", $selectedAcademicYearId);
    $yearStatusStmt->execute();
    $yearStatusResult = $yearStatusStmt->get_result()->fetch_assoc();
    if ($yearStatusResult) {
        $academicYearStatus = $yearStatusResult['status'];
    }
    $yearStatusStmt->close();
}

// Get global phase and review settings
$globalSettings = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$current_phase = 1;
$current_review = 1;
while ($row = $globalSettings->fetch_assoc()) {
    if ($row['setting_key'] === 'current_phase') $current_phase = intval($row['setting_value']);
    if ($row['setting_key'] === 'current_review') $current_review = intval($row['setting_value']);
}


$selectedAcademicYear = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;

// Get only groups where this coordinator is assigned as coordinator_guide for the selected academic year
$groupsQuery = "SELECT g.*, b.batch_name, ay.year_label,
                COUNT(DISTINCT s.id) as member_count,
                (SELECT COUNT(*) FROM project_uploads pu WHERE pu.group_id = g.id AND pu.status = 'pending') as pending_reviews,
                (SELECT CONCAT(u.username, '|', u.phone) FROM students st 
                 INNER JOIN users u ON st.user_id = u.id 
                 WHERE st.group_id = g.id AND st.is_team_lead = 1 LIMIT 1) as team_lead_info
                FROM pgroups g
                LEFT JOIN batches b ON g.batch = b.batch_name
                LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
                LEFT JOIN students s ON s.group_id = g.id
                WHERE g.coordinator_guide_id = ? AND g.academic_year_id = ?
                GROUP BY g.id
                ORDER BY g.batch DESC, g.group_name ASC";
$stmt = $conn->prepare($groupsQuery);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYear);
$stmt->execute();
$groups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

foreach ($groups as &$group) {
    $group['current_phase'] = $current_phase;
    $group['current_review'] = $current_review;
    if (!empty($group['team_lead_info'])) {
        $parts = explode('|', $group['team_lead_info']);
        $group['team_lead_name'] = $parts[0] ?? '';
        $group['team_lead_phone'] = $parts[1] ?? '';
    }
}

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<style>
    /* Add vertical spacing between main cards */
    .my-groups-main-card + .my-groups-main-card {
        margin-top: 2rem !important;
    }
</style>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">My Groups</h1>
    </div>

    <?php if (count($groups) > 0): ?>
        <div class="row">
            <?php foreach ($groups as $group): ?>
                <div class="col-lg-6 mb-4">
                    <div class="card shadow h-100">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary"><?php echo htmlspecialchars($group['group_name']); ?></h6>
                            <span class="badge badge-info"><?php echo htmlspecialchars($group['batch']); if (!empty($group['year_label'])) echo '(' . htmlspecialchars(formatAcademicYear($group['year_label'])) . ')'; ?></span>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p class="mb-2">
                                        <strong><i class="fas fa-users text-success"></i> Members:</strong><br>
                                        <?php echo $group['member_count']; ?> students
                                    </p>
                                    <p class="mb-2">
                                        <strong><i class="fas fa-project-diagram text-info"></i> Phase:</strong><br>
                                        Phase <?php echo $group['current_phase']; ?>
                                    </p>
                                    <p class="mb-2">
                                        <strong><i class="fas fa-clipboard-check text-warning"></i> Review:</strong><br>
                                        Review <?php echo $group['current_review']; ?>
                                    </p>
                                    <?php if (!empty($group['team_lead_name'])): ?>
                                    <p class="mb-2">
                                        <strong><i class="fas fa-user-tie text-primary"></i> Team Lead:</strong><br>
                                        <?php echo htmlspecialchars($group['team_lead_name']); ?>
                                        <?php if (!empty($group['team_lead_phone'])): ?>
                                        <br><a href="tel:<?php echo htmlspecialchars($group['team_lead_phone']); ?>" class="text-success">
                                            <i class="fas fa-phone"></i> <?php echo htmlspecialchars($group['team_lead_phone']); ?>
                                        </a>
                                        <?php endif; ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <?php if ($group['pending_reviews'] > 0): ?>
                                    <p class="mb-2">
                                        <strong><i class="fas fa-exclamation-circle text-danger"></i> Pending:</strong><br>
                                        <span class="badge badge-warning"><?php echo $group['pending_reviews']; ?> reviews</span>
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <?php if (!empty($group['project_title'])): ?>
                                <div class="mb-3">
                                    <strong><i class="fas fa-book text-primary"></i> Project Title:</strong>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($group['project_title']); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($group['project_description'])): ?>
                                <div class="mb-3">
                                    <strong><i class="fas fa-align-left text-primary"></i> Description:</strong>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($group['project_description']); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if ($group['pending_reviews'] > 0): ?>
                                <div class="alert alert-warning mb-3">
                                    <i class="fas fa-exclamation-triangle"></i> 
                                    <?php echo $group['pending_reviews']; ?> pending review(s)
                                </div>
                            <?php endif; ?>

                            <div class="btn-group btn-block" role="group">
                                <button class="btn btn-primary btn-sm" onclick="viewGroupDetails(<?php echo $group['id']; ?>, true)">
                                    <i class="fas fa-eye"></i> View Details
                                </button>
                                <button class="btn btn-info btn-sm" onclick="viewGroupGrades(<?php echo $group['id']; ?>)">
                                    <i class="fas fa-chart-bar"></i> View Grades
                                </button>
                                <?php if ($_SESSION['project_type'] === 'mini'): ?>
                                <button class="btn btn-success btn-sm" onclick="downloadEvaluationSheetPDF({ group_id: <?php echo $group['id']; ?> })">
                                    <i class="fas fa-download"></i> Download
                                </button>
                                <?php else: ?>
                                <button class="btn btn-success btn-sm" onclick="downloadEvaluationSheetPDF({ group_id: <?php echo $group['id']; ?>, phase: <?php echo $group['current_phase']; ?>, review: 1 })">
                                    <i class="fas fa-file-alt"></i> Download R1
                                </button>
                                <button class="btn btn-success btn-sm" onclick="downloadEvaluationSheetPDF({ group_id: <?php echo $group['id']; ?>, phase: <?php echo $group['current_phase']; ?>, review: 2 })">
                                    <i class="fas fa-file-alt"></i> Download R2
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card shadow my-groups-main-card">
            <div class="card-body text-center py-5">
                <i class="fas fa-users fa-3x text-gray-300 mb-3"></i>
                <h5 class="text-gray-600">No Groups Assigned</h5>
                <p class="text-muted">You are not assigned to any groups as a coordinator-guide. Please assign yourself to a batch in the Groups section.</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Coordinator Review Uploads Table (show once below all group cards) -->
    <div class="card shadow mb-4 my-groups-main-card">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Review Uploads for Your Groups</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="coordReviewsTable" width="100%">
                    <thead>
                        <tr>
                            <th>Project Title</th>
                            <th>Batch</th>
                            <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                            <th>Phase</th>
                            <th>Review</th>
                            <?php endif; ?>
                            <th>File Name</th>
                            <th>Uploaded By</th>
                            <th>Upload Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="coordReviewsTableBody">
                        <tr>
                            <td colspan="<?php echo ($_SESSION['project_type'] === 'mini') ? 7 : 9; ?>" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Coordinator Grading Panel -->
    <div class="card shadow mb-4 my-groups-main-card">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Grade Students</h6>
        </div>
        <div class="card-body">
            <!-- Select Group -->
            <div class="card mb-3 border-light">
                <div class="card-header bg-light py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo ($_SESSION['project_type'] === 'mini') ? 'Select Group' : 'Select Group & Evaluation Sheet'; ?></h6>
                </div>
                <div class="card-body">
                    <form id="coordSelectForm">
                        <div class="row">
                            <div class="<?php echo ($_SESSION['project_type'] === 'mini') ? 'col-md-12' : 'col-md-6'; ?>">
                                <div class="form-group">
                                    <label for="coordGroupSelect">Group *</label>
                                    <select class="form-control" id="coordGroupSelect" required>
                                        <option value="">Loading...</option>
                                    </select>
                                </div>
                            </div>
                            <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="coordEvaluationSheetSelect">Evaluation Sheet *</label>
                                    <select class="form-control" id="coordEvaluationSheetSelect" required>
                                        <option value="">Select Evaluation Sheet</option>
                                    </select>
                                </div>
                            </div>
                            <?php else: ?>
                            <input type="hidden" id="coordEvaluationSheetSelect">
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Grading Form -->
            <div id="coordGradingFormContainer" style="display: none;">
                <div class="card border-light">
                    <div class="card-header bg-light py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Student Evaluation</h6>
                    </div>
                    <div class="card-body">
                        <form id="coordGradingForm">
                            <input type="hidden" id="coordSelectedGroup" name="group_id">
                            <input type="hidden" id="coordEvaluationSheetId" name="evaluation_sheet_id">

                            <div id="coordStudentsContainer"></div>

                            <div class="form-group mt-4">
                                <label for="coordOverallRemarks">Overall Remarks <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="coordOverallRemarks" name="overall_remarks" rows="4" 
                                          placeholder="Provide overall remarks for this evaluation (mandatory for submission)..."></textarea>
                                <small class="form-text text-muted">These remarks will be included in the grade report.</small>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <div>
                                    <button type="button" class="btn btn-secondary" onclick="coordSaveAllGrades('draft')">
                                        Save as Draft
                                    </button>
                                    <button type="button" class="btn btn-success" onclick="coordSaveAllGrades('submitted')">
                                        Submit All Grades
                                    </button>
                                </div>
                                <div id="coordDraftControls" style="display:none">
                                    <span class="text-muted mr-2">Draft exists</span>
                                    <button type="button" class="btn btn-sm btn-primary" id="coordSubmitDraftsBtn">Submit Drafts</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Add Grade Modal (content loaded by JS) -->
<div class="modal fade" id="addGradeModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" id="addGradeModalContent">
            <!-- Content loaded dynamically -->
        </div>
    </div>
</div>

<!-- Group Uploads Modal (content loaded by JS) -->
<div class="modal fade" id="groupUploadsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" id="groupUploadsModalContent">
            <!-- Content loaded dynamically -->
        </div>
    </div>
</div>

<!-- Group Details Modal (reused by viewGroupDetails / viewGroupGrades) -->
<div class="modal fade" id="groupDetailsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Group Details</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="groupDetailsContent">
                <div class="text-center py-4">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php include '../includes/evaluation_sheet_js.php'; ?>
<?php include '../includes/group-details-scripts.php'; ?>

<script>
let coordReviewsCache = [];
let coordEvaluationCriteria = [];
const academicYearStatus = '<?php echo $academicYearStatus; ?>';
const isMiniProject = <?php echo json_encode($_SESSION['project_type'] === 'mini'); ?>;

$(document).ready(function() {
    loadCoordinatorReviews();
    loadCoordinatorGroups();
    if (!isMiniProject) {
        loadCoordinatorEvaluationSheets();
    }

    // Auto-load students when selections are made
    if (isMiniProject) {
        // For mini projects, only group selection matters
        $('#coordGroupSelect').on('change', function() {
            const groupId = $(this).val();
            if (groupId) {
                // Get the evaluation sheet ID for this mini project group
                coordLoadMiniProjectEvaluationSheet(groupId);
            } else {
                $('#coordGradingFormContainer').hide();
            }
        });
    } else {
        // For major projects, both selections matter
        $('#coordGroupSelect, #coordEvaluationSheetSelect').on('change', function() {
            const groupId = $('#coordGroupSelect').val();
            const evaluationSheetId = $('#coordEvaluationSheetSelect').val();
            if (groupId && evaluationSheetId) {
                coordLoadGroupStudents();
            } else {
                $('#coordGradingFormContainer').hide();
            }
        });
    }
});

function loadCoordinatorGroups() {
    $.ajax({
        url: '../api/get-coordinator-groups.php',
        type: 'GET',
        success: function(response) {
            if (response.success && response.groups) {
                let html = '<option value="">Select Group</option>';
                response.groups.forEach(group => {
                    html += `<option value="${group.id}">${group.group_name}</option>`;
                });
                $('#coordGroupSelect').html(html);
            }
        }
    });
}

function loadCoordinatorEvaluationSheets() {
    $.ajax({
        url: '../api/get-active-evaluation-sheets.php',
        type: 'GET',
        success: function(response) {
            if (response.success && response.sheets) {
                let html = '<option value="">Select Evaluation Sheet</option>';
                response.sheets.forEach(sheet => {
                    html += `<option value="${sheet.id}">${sheet.title} (Phase ${sheet.phase}, Review ${sheet.review})</option>`;
                });
                $('#coordEvaluationSheetSelect').html(html);
            }
        }
    });
}

function coordLoadMiniProjectEvaluationSheet(groupId) {
    // For mini projects, fetch the single evaluation sheet created by coordinator
    $.ajax({
        url: '../api/get-mini-project-evaluation-sheet.php',
        type: 'GET',
        data: {group_id: groupId},
        dataType: 'json',
        success: function(response) {
            if (response.success && response.sheet) {
                // Auto-populate the sheet ID
                $('#coordEvaluationSheetSelect').val(response.sheet.id);
                // Load students for this group and sheet
                coordLoadGroupStudents();
            } else {
                Swal.fire('Error', 'No evaluation sheet found for this mini project', 'error');
                $('#coordGradingFormContainer').hide();
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to load evaluation sheet', 'error');
            $('#coordGradingFormContainer').hide();
        }
    });
}

function coordLoadGroupStudents() {
    const groupId = $('#coordGroupSelect').val();
    const evaluationSheetId = $('#coordEvaluationSheetSelect').val();
    
    if (!groupId || !evaluationSheetId) {
        Swal.fire('Error', 'Please select both group and evaluation sheet', 'error');
        return;
    }
    
    // Load evaluation sheet criteria
    $.ajax({
        url: '../api/get-evaluation-sheet-criteria.php',
        type: 'GET',
        data: {id: evaluationSheetId},
        success: function(response) {
            if (response.success) {
                coordEvaluationCriteria = response.criteria;
                $('#coordSelectedGroup').val(groupId);
                $('#coordEvaluationSheetId').val(evaluationSheetId);
                
                // Load group members
                $.ajax({
                    url: '../api/get-group-details.php',
                    type: 'GET',
                    data: {group_id: groupId},
                    success: function(memberResponse) {
                        if (memberResponse.success) {
                            coordRenderStudentGradingForms(memberResponse.members);
                            // After rendering inputs, try to preload any saved grades for this group+sheet
                            coordPreloadSavedGrades(groupId, evaluationSheetId);
                            $('#coordGradingFormContainer').show();
                        } else {
                            Swal.fire('Error', 'Failed to load group members', 'error');
                        }
                    },
                    error: function() {
                        Swal.fire('Error', 'Failed to load group members', 'error');
                    }
                });
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to load evaluation sheet', 'error');
        }
    });
}

function coordRenderStudentGradingForms(members) {
    let html = '<div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Student</th><th>USN</th>';

    // Add criteria headers
    coordEvaluationCriteria.forEach(criterion => {
        html += `<th>${criterion.name}<br><small>Max: ${criterion.max_marks}</small></th>`;
    });

    html += '<th>Total</th></tr></thead><tbody>';

    // Add student rows
    members.forEach(member => {
        const displayName = member.full_name || member.username;
        html += `<tr data-student-id="${member.id}">
            <td>${displayName}</td>
            <td>${member.usn}</td>`;

        // Add input fields for each criterion
        coordEvaluationCriteria.forEach(criterion => {
            html += `<td>
                <input type="number" class="form-control coord-marks-input"
                       data-student-id="${member.id}"
                       data-criterion-id="${criterion.id}"
                       data-max="${criterion.max_marks}"
                       min="0" max="${criterion.max_marks}" step="0.5"
                       placeholder="0">
            </td>`;
        });

        html += `<td><span class="coord-student-total" data-student-id="${member.id}">0.00</span></td></tr>`;
    });

    html += '</tbody></table></div>';
    $('#coordStudentsContainer').html(html);

    // Add input event listeners
    $('.coord-marks-input').on('input', function() {
        coordCalculateStudentTotal($(this).data('student-id'));
    });
}

function coordPreloadSavedGrades(groupId, evaluationSheetId) {
    $.ajax({
        url: '../api/get-group-grades.php',
        type: 'GET',
        data: { group_id: groupId, evaluation_sheet_id: evaluationSheetId },
        success: function(response) {
            if (!response.success || !response.grades) return;

            // Map grades by student id
            response.grades.forEach(function(grade) {
                if (parseInt(grade.evaluation_sheet_id) !== parseInt(evaluationSheetId)) return;

                const studentId = grade.student_id;
                // Fill criteria inputs
                if (Array.isArray(grade.criteria)) {
                    grade.criteria.forEach(function(c) {
                        const critId = c.criterion_id || c.criterion_id === 0 ? c.criterion_id : (c.criterion_id || c.id || c.criterion_id);
                        // Find input matching student and criterion
                        const input = $(`.coord-marks-input[data-student-id="${studentId}"][data-criterion-id="${critId}"]`);
                        if (input.length) {
                            input.val(parseFloat(c.marks_obtained).toFixed(2));
                        }
                    });
                }

                // Update displayed total
                $(`.coord-student-total[data-student-id="${studentId}"]`).text(parseFloat(grade.total_marks).toFixed(2));
            });

            // Recalculate totals in case some inputs were filled
            $('tr[data-student-id]').each(function() {
                coordCalculateStudentTotal($(this).data('student-id'));
            });

            // Auto-fill overall remarks from the first grade (if available)
            let firstGradeWithRemarks = response.grades.find(g => g.overall_remarks && g.overall_remarks.trim() !== '');
            if (firstGradeWithRemarks) {
                $('#coordOverallRemarks').val(firstGradeWithRemarks.overall_remarks);
            } else {
                $('#coordOverallRemarks').val('');
            }

            // Only show/hide draftControls
            const drafts = (response.grades || []).filter(g => g.status && g.status === 'draft');
            if (drafts.length > 0) {
                $('#coordDraftControls').show();
                $('#coordSubmitDraftsBtn').off('click').on('click', function() {
                    if (!confirm('Submit all drafts for this evaluation sheet? This will change the status from draft to submitted.')) return;
                    Swal.fire({
                        title: 'Submitting...',
                        allowOutsideClick: false,
                        didOpen: () => { Swal.showLoading(); }
                    });
                    $.ajax({
                        url: '../api/submit-draft-grades.php',
                        type: 'POST',
                        data: { group_id: groupId, evaluation_sheet_id: evaluationSheetId },
                        dataType: 'json',
                        success: function(resp) {
                            Swal.close();
                            if (resp && resp.success) {
                                Swal.fire('Success', resp.message, 'success').then(() => {
                                    // Hide draft controls
                                    $('#coordDraftControls').hide();
                                    // Reload preloaded grades to show submitted status
                                    coordPreloadSavedGrades(groupId, evaluationSheetId);
                                });
                            } else {
                                Swal.fire('Error', (resp && resp.message) || 'Failed to submit drafts', 'error');
                            }
                        },
                        error: function(xhr) {
                            Swal.close();
                            console.error('Submit error:', xhr.responseText);
                            Swal.fire('Error', 'Failed to submit drafts', 'error');
                        }
                    });
                });
            } else {
                $('#coordDraftControls').hide();
            }
        },
        error: function() {
            console.warn('Failed to preload saved grades');
        }
    });
}

function coordCalculateStudentTotal(studentId) {
    let total = 0;
    $(`.coord-marks-input[data-student-id="${studentId}"]`).each(function() {
        const value = parseFloat($(this).val()) || 0;
        const max = parseFloat($(this).data('max'));

        if (value > max) {
            $(this).addClass('is-invalid');
        } else {
            $(this).removeClass('is-invalid');
            total += value;
        }
    });

    $(`.coord-student-total[data-student-id="${studentId}"]`).text(total.toFixed(2));
}

function coordSaveAllGrades(status) {
    const groupId = $('#coordSelectedGroup').val();
    const evaluationSheetId = $('#coordEvaluationSheetId').val();
    const students = [];
    const totalStudents = $('tr[data-student-id]').length;

    // Collect data for each student
    $('tr[data-student-id]').each(function() {
        const studentId = $(this).data('student-id');
        const studentData = {
            student_id: studentId,
            criteria: []
        };

        let allFilled = true;
        $(this).find('.coord-marks-input').each(function() {
            const marks = parseFloat($(this).val());
            if (isNaN(marks) || marks < 0) {
                allFilled = false;
                return false;
            }

            studentData.criteria.push({
                criterion_id: $(this).data('criterion-id'),
                obtained_marks: marks
            });
        });

        if (allFilled) {
            students.push(studentData);
        }
    });

    if (students.length === 0) {
        Swal.fire('Error', 'Please fill marks for at least one student', 'error');
        return;
    }

    // If submitting but not all students graded, save as draft instead
    let submitStatus = status;
    if (status === 'submitted' && students.length < totalStudents) {
        submitStatus = 'draft';
        Swal.fire('Notice', 'Not all students graded — saving as draft instead.', 'info');
    }

    // Get overall remarks
    const overallRemarks = $('#coordOverallRemarks').val().trim();
    
    // Validate remarks for submission (mandatory when status is submitted)
    if (submitStatus === 'submitted' && !overallRemarks) {
        Swal.fire('Error', 'Overall remarks are mandatory when submitting grades', 'error');
        $('#coordOverallRemarks').focus();
        return;
    }

    const formData = {
        group_id: groupId,
        evaluation_sheet_id: evaluationSheetId,
        status: submitStatus,
        overall_remarks: overallRemarks,
        students: JSON.stringify(students)
    };

    $.ajax({
        url: '../api/save-student-grades.php',
        type: 'POST',
        data: formData,
        success: function(response) {
            try {
                if (typeof response === 'string') {
                    response = JSON.parse(response);
                }
                
                if (response.success) {
                    Swal.fire('Success', response.message, 'success').then(() => {
                        // Reset form
                        $('#coordSelectForm')[0].reset();
                        $('#coordGradingFormContainer').hide();
                        $('#coordDraftControls').hide();
                        loadCoordinatorGroups();
                        loadCoordinatorEvaluationSheets();
                    });
                } else {
                    Swal.fire('Error', response.message, 'error');
                }
            } catch (e) {
                console.error('JSON Parse Error:', e);
                console.error('Response:', response);
                Swal.fire('Error', 'Invalid response from server', 'error');
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', xhr.status, xhr.statusText);
            console.error('Response:', xhr.responseText);
            
            // Try to parse error response
            try {
                const errorResponse = JSON.parse(xhr.responseText);
                Swal.fire('Error', errorResponse.message || 'Failed to save grades', 'error');
            } catch (e) {
                // If response is not JSON, show generic error
                Swal.fire('Error', 'Failed to save grades. Please check your connection and try again.', 'error');
            }
        }
    });
}


function loadCoordinatorReviews() {
    $.ajax({
        url: '../api/get-pending-reviews-coordinator.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                coordReviewsCache = response.reviews || [];
                let html = '';

                if (coordReviewsCache.length === 0) {
                    html = '<tr><td colspan="9" class="text-center">No uploads</td></tr>';
                } else {
                    coordReviewsCache.forEach(review => {
                        const statusBadge = getStatusBadge(review.status);
                        html += `
                            <tr data-upload-id="${review.id}">
                                <td>${review.project_title || review.group_name}</td>
                                <td>${review.batch}${review.academic_year ? `(${review.academic_year})` : ''}</td>
                                <td>Phase ${review.phase}</td>
                                <td>Review ${review.review_type}</td>
                                <td><a href="#" onclick="coordViewFile('${review.file_path}'); return false;">${review.file_name}</a></td>
                                <td>${review.uploaded_by_name}</td>
                                <td>${new Date(review.uploaded_at).toLocaleDateString()}</td>
                                <td>
                                    ${statusBadge}
                                </td>
                                <td>
                                    ${review.status !== 'approved' ? `<button class="btn btn-info btn-sm" onclick="coordOpenReviewModal(${review.id})"><i class="fas fa-eye"></i> Review</button>` : `<span class='text-muted'>&mdash;</span>`}
                                </td>
                            </tr>
                        `;
                    });
                }

                $('#coordReviewsTableBody').html(html);

                if ($.fn.DataTable.isDataTable('#coordReviewsTable')) {
                    $('#coordReviewsTable').DataTable().destroy();
                }
                $('#coordReviewsTable').DataTable({ order: [[6, 'desc']] });
            }
        },
        error: function(xhr) {
            let message = 'Failed to load reviews';
            if (xhr && xhr.status === 404) {
                message = 'No uploads to review yet.';
            } else if (xhr && xhr.responseText && xhr.responseText.includes('no groups')) {
                message = 'No groups assigned. Uploads will appear here once you are assigned to a group.';
            } else if (<?php echo json_encode(count($groups) === 0); ?>) {
                message = 'No groups assigned. Uploads will appear here once you are assigned to a group.';
            }
            $('#coordReviewsTableBody').html('<tr><td colspan="9" class="text-center text-muted">' + message + '</td></tr>');
        }
    });
}

function coordViewFile(filePath) {
    if (filePath.indexOf('uploads/') === 0) {
        window.open('../' + filePath, '_blank');
    } else {
        window.open('../' + filePath, '_blank');
    }
}

function coordOpenReviewModal(uploadId) {
    const found = coordReviewsCache.find(r => Number(r.id) === Number(uploadId));
    if (!found) return;
    $('#coordUploadId').val(found.id);
    $('#coordUploadInfo').html(`<strong>Project:</strong> ${found.project_title || found.group_name}<br><strong>Phase:</strong> ${found.phase}<br><strong>Review:</strong> ${found.review_type}`);
    $('#coordFeedback').val(found.feedback || '');
    $('#coordReviewModal').modal('show');
}

function coordSubmitReview(status) {
    const uploadId = $('#coordUploadId').val();
    const feedback = $('#coordFeedback').val().trim();
    if (!feedback) {
        Swal.fire('Error', 'Please provide feedback', 'error');
        return;
    }

    $.ajax({
        url: '../api/approve-upload.php',
        type: 'POST',
        data: { upload_id: uploadId, status: status, feedback: feedback },
        success: function(response) {
            if (response.success) {
                $('#coordReviewModal').modal('hide');
                Swal.fire('Success', response.message, 'success');
                loadCoordinatorReviews();
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to submit review', 'error');
        }
    });
}

function getStatusBadge(status) {
    const cls = status === 'approved' ? 'success' : (status === 'changes_required' ? 'warning' : 'secondary');
    const label = status === 'approved' ? 'Approved' : (status === 'changes_required' ? 'Changes Required' : 'Pending');
    return `<span class="badge badge-${cls}">${label}</span>`;
}
</script>
