<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Manage Students";
$isMiniProject = (getCurrentProjectType() === 'mini');

// Get selected academic year status for read-only mode
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? $_SESSION['academic_year_id'] : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
}

$academicYearStatus = 'ACTIVE';
if ($selectedAcademicYearId) {
    $yearStatusStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
    $yearStatusStmt->bind_param("i", $selectedAcademicYearId);
    $yearStatusStmt->execute();
    $yearStatusResult = $yearStatusStmt->get_result()->fetch_assoc();
    if ($yearStatusResult) {
        $academicYearStatus = $yearStatusResult['status'];
    }
    $yearStatusStmt->close();
}

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Students</h1>
        <div>
            <button class="btn btn-success mr-2" onclick="generateReport()">
                <i class="fas fa-download mr-2"></i> Generate Report
            </button>
            <button class="btn btn-info mr-2" onclick="downloadRegisteredStudents()">
                <i class="fas fa-users mr-2"></i> Download Registered Students
            </button>
            <?php if ($academicYearStatus !== 'COMPLETED'): ?>
            <button class="btn btn-primary" data-toggle="modal" data-target="#uploadModal">
                <i class="fas fa-file-excel mr-2"></i> Upload Student List
            </button>
            <?php else: ?>
            <span class="badge badge-warning"><i class="fas fa-lock"></i> Upload disabled for COMPLETED year</span>
            <?php endif; ?>
        </div>
    </div>
    

    <!-- Students Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Students</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="studentsTable" width="100%">
                    <thead>
                        <tr>
                            <th>USN</th>
                            <th>Name</th>
                            <th>Batch Number</th>
                            <th>Project Title</th>
                            <th>Guide Name</th>
                            <?php if (!$isMiniProject): ?>
                            <th>Review 1 Marks</th>
                            <th>Review 2 Marks</th>
                            <?php else: ?>
                            <th>Final Marks</th>
                            <?php endif; ?>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="studentsTableBody">
                        <tr>
                            <td colspan="<?php echo $isMiniProject ? '7' : '8'; ?>" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upload Student List</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="uploadForm">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <strong>File Format:</strong> CSV file (.csv)<br>
                        <strong>Required Columns (any order, any names):</strong><br>
                        • USN / Student ID / Roll Number<br>
                        • Name / Student Name<br>
                        • Email / Email Address<br>
                        • Phone Number<br><br>
                        <strong>Example:</strong> 4GW23CS001, John Doe, john@example.com, 1234567890<br>
                        <small class="text-muted">Column names can be anything - the system will auto-detect them!</small>
                    </div>
                    <div class="form-group">
                        <label for="file">Select CSV File *</label>
                        <input type="file" class="form-control-file" id="file" name="file" 
                               accept=".csv" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
let currentPhase = 1; // Default to phase 1
// current logged-in coordinator id (used for guide name logic)
let currentCoordinatorId = <?php echo isset($_SESSION['role_id']) ? (int)$_SESSION['role_id'] : 'null'; ?>;

$(document).ready(function() {
    console.log('Students page loaded, calling loadStudents()...');
    
    // Get current phase first
    getCurrentPhase().then(() => {
        // Add a small delay to ensure everything is loaded
        setTimeout(function() {
            loadStudents();
        }, 100);
    });
    
    $('#uploadForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        console.log('Starting upload...');
        
        $.ajax({
            url: '../api/upload-student-list.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            processData: false,
            contentType: false,
            timeout: 30000,
            beforeSend: function() {
                console.log('Sending request...');
                Swal.fire({
                    title: 'Uploading...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });
            },
            success: function(response) {
                console.log('Response:', response);
                console.log('Response type:', typeof response);
                Swal.close();
                
                // Check if response is HTML (means session expired/redirected to login)
                if (typeof response === 'string' && response.includes('<!DOCTYPE')) {
                    Swal.fire('Session Expired', 'Please login again', 'warning').then(() => {
                        window.location.href = '../login.php';
                    });
                    return;
                }
                
                if (response.success) {
                    $('#uploadModal').modal('hide');
                    $('#uploadForm')[0].reset();
                    Swal.fire('Success!', response.message, 'success');
                    loadStudents();
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.error('Upload error:', error);
                console.error('Status:', status);
                console.error('Response:', xhr.responseText);
                console.error('XHR status:', xhr.status);
                Swal.close();
                
                // Check if response is HTML (login page)
                if (xhr.responseText && xhr.responseText.includes('<!DOCTYPE')) {
                    Swal.fire('Session Expired', 'Please login again', 'warning').then(() => {
                        window.location.href = '../login.php';
                    });
                } else {
                    Swal.fire('Error!', 'Failed to upload file: ' + (xhr.responseText || error), 'error');
                }
            }
        });
    });
});

function getCurrentPhase() {
    return $.ajax({
        url: '../api/get-config.php',
        type: 'GET',
        dataType: 'json'
    }).then(function(response) {
        if (response.success && response.current_phase) {
            currentPhase = response.current_phase;
            console.log('Current phase set to:', currentPhase);
        } else {
            console.log('Using default phase 1');
        }
    }).catch(function() {
        console.log('Failed to get current phase, using default phase 1');
    });
}

function loadStudents() {
    console.log('Loading students data from API...');
    
    $('#studentsTableBody').html('<tr><td colspan="<?php echo $isMiniProject ? '7' : '8'; ?>" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading data...</td></tr>');
    
    $.ajax({
        url: '../api/get-students.php',
        type: 'GET',
        data: { current_phase: currentPhase },
        dataType: 'json',
        cache: false,
        timeout: 10000,
        success: function(response) {
            console.log('Raw API response:', response);
            
            if (response.success) {
                let html = '';
                
                // Process all students from response
                if (response.students && response.students.length > 0) {
                    console.log('Processing', response.students.length, 'students');
                    
                    response.students.forEach(student => {
                        console.log('Student data:', {
                            usn: student.usn,
                            phase1_review1_obtained: student.phase1_review1_obtained,
                            phase1_review1_total: student.phase1_review1_total,
                            phase1_review2_obtained: student.phase1_review2_obtained,
                            phase1_review2_total: student.phase1_review2_total
                        });
                        
                        // Status badge
                        let statusBadge;
                        if (student.group_id && student.group_id != '0') {
                            statusBadge = '<span class="badge badge-success">In Group</span>';
                        } else {
                            statusBadge = '<span class="badge badge-warning">Unassigned</span>';
                        }
                        
                        // Batch number
                        let batchNum = '<span class="text-muted">-</span>';
                        if (student.batch) {
                            batchNum = student.batch + (student.academic_year ? `(${student.academic_year})` : '');
                        }
                        
                        // Project title
                        const projectTitle = student.project_title || '<span class="text-muted">Not assigned</span>';
                        
                        // Guide name
                        let guideName = '<span class="text-muted">No guide</span>';
                        if (student.guide_name) {
                            guideName = student.guide_name;
                        } else if (student.coordinator_guide_id && student.coordinator_name) {
                            if (currentCoordinatorId && student.coordinator_guide_id == currentCoordinatorId) {
                                guideName = student.coordinator_name; // same color as guide
                            } else {
                                guideName = `${student.coordinator_name} (Coordinator)`; // plain text
                            }
                        }
                        
                        // Review marks for current phase
                        let review1Marks = '<span class="text-muted">Not graded</span>';
                        let review2Marks = '<span class="text-muted">Not graded</span>';
                        let finalMarks = '<span class="text-muted">Not graded</span>';
                        
                        if (currentPhase == 1) {
                            // Show Phase 1 reviews - check if marks > 0
                            if (student.phase1_review1_obtained && parseFloat(student.phase1_review1_obtained) > 0) {
                                review1Marks = `<div><strong>${student.phase1_review1_obtained}/${student.phase1_review1_total}</strong></div>
                                 `;                            }
                            
                            if (student.phase1_review2_obtained && parseFloat(student.phase1_review2_obtained) > 0) {
                                review2Marks = `<div><strong>${student.phase1_review2_obtained}/${student.phase1_review2_total}</strong></div>
                                 `;                            }
                        } else if (currentPhase == 2) {
                            // Show Phase 2 reviews - check if marks > 0
                            if (student.phase2_review1_obtained && parseFloat(student.phase2_review1_obtained) > 0) {
                                review1Marks = `<div><strong>${student.phase2_review1_obtained}/${student.phase2_review1_total}</strong></div>
                                 `;                            }
                            
                            if (student.phase2_review2_obtained && parseFloat(student.phase2_review2_obtained) > 0) {
                                review2Marks = `<div><strong>${student.phase2_review2_obtained}/${student.phase2_review2_total}</strong></div>
                                 `;                            }
                        }
                        
                        // Calculate final marks for mini project (sum of both reviews)
                        if (<?php echo json_encode($isMiniProject); ?>) {
                            let totalObtained = 0;
                            let totalMax = 0;
                            
                            if (currentPhase == 1) {
                                if (student.phase1_review1_obtained && parseFloat(student.phase1_review1_obtained) > 0) {
                                    totalObtained += parseFloat(student.phase1_review1_obtained);
                                    totalMax += parseFloat(student.phase1_review1_total || 0);
                                }
                                if (student.phase1_review2_obtained && parseFloat(student.phase1_review2_obtained) > 0) {
                                    totalObtained += parseFloat(student.phase1_review2_obtained);
                                    totalMax += parseFloat(student.phase1_review2_total || 0);
                                }
                            } else if (currentPhase == 2) {
                                if (student.phase2_review1_obtained && parseFloat(student.phase2_review1_obtained) > 0) {
                                    totalObtained += parseFloat(student.phase2_review1_obtained);
                                    totalMax += parseFloat(student.phase2_review1_total || 0);
                                }
                                if (student.phase2_review2_obtained && parseFloat(student.phase2_review2_obtained) > 0) {
                                    totalObtained += parseFloat(student.phase2_review2_obtained);
                                    totalMax += parseFloat(student.phase2_review2_total || 0);
                                }
                            }
                            
                            if (totalMax > 0) {
                                finalMarks = `<div><strong>${totalObtained}/${totalMax}</strong></div>`;
                            }
                        }
                        
                        // Highlight unassigned students
                        const rowClass = (student.group_id && student.group_id != '0') ? '' : 'table-warning';
                        
                        html += `
                            <tr class="${rowClass}">
                                <td><strong>${student.usn}</strong></td>
                                <td>${student.name}</td>
                                <td class="text-center">${batchNum}</td>
                                <td>${projectTitle}</td>
                                <td>${guideName}</td>
                                <?php if (!$isMiniProject): ?>
                                <td class="text-center">${review1Marks}</td>
                                <td class="text-center">${review2Marks}</td>
                                <?php else: ?>
                                <td class="text-center">${finalMarks}</td>
                                <?php endif; ?>
                                <td class="text-center">${statusBadge}</td>
                            </tr>
                        `;
                    });
                } else {
                    html = '<tr><td colspan="<?php echo $isMiniProject ? '7' : '8'; ?>" class="text-center">No students found. Upload student list to get started.</td></tr>';
                }
                
                console.log('Setting HTML with', html.length, 'characters');
                $('#studentsTableBody').html(html);
                
                if ($.fn.DataTable.isDataTable('#studentsTable')) {
                    $('#studentsTable').DataTable().destroy();
                }
                $('#studentsTable').DataTable({
                    "order": [[0, "asc"]],
                    "pageLength": 25
                });
                
                console.log('Students table updated successfully');
            } else {
                console.error('Error from API:', response.message);
                $('#studentsTableBody').html('<tr><td colspan="<?php echo $isMiniProject ? '7' : '8'; ?>" class="text-center text-danger"><i class="fas fa-exclamation-circle"></i> Error: ' + (response.message || 'Unknown error') + '</td></tr>');
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX error:', error);
            console.error('Status:', status);
            console.error('Response:', xhr.responseText);
            console.error('XHR Status:', xhr.status);
            
            let errorMsg = 'Failed to load students data';
            
            if (status === 'timeout') {
                errorMsg = 'Request timeout - server took too long to respond';
            } else if (xhr.responseText) {
                try {
                    const errorResponse = JSON.parse(xhr.responseText);
                    errorMsg = errorResponse.message || errorMsg;
                } catch(e) {
                    if (xhr.responseText.includes('<!DOCTYPE') || xhr.responseText.includes('<html')) {
                        errorMsg = 'Server error - check PHP error logs';
                    } else {
                        errorMsg += '<br><small>' + xhr.responseText.substring(0, 200) + '</small>';
                    }
                }
            }
            
            $('#studentsTableBody').html('<tr><td colspan="8" class="text-center text-danger"><i class="fas fa-exclamation-circle"></i> ' + errorMsg + '<br><button class="btn btn-sm btn-primary mt-2" onclick="loadStudents()">Retry</button></td></tr>');
        }
    });
}

function generateReport() {
    Swal.fire({
        title: 'Generating Report...',
        text: 'Please wait while we generate the CSV file',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    window.location.href = '../api/generate-student-report.php';
    
    setTimeout(() => {
        Swal.close();
    }, 2000);
}

function downloadRegisteredStudents() {
    Swal.fire({
        title: 'Downloading...',
        text: 'Please wait while we prepare the registered students list',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    window.location.href = '../api/download-registered-students.php';
    
    setTimeout(() => {
        Swal.close();
    }, 2000);
}


</script>
