<?php
require_once '../config/config.php';
requireRole('coordinator');

$pageTitle = "Evaluation Sheets";
$projectType = getCurrentProjectType();
$isMiniProject = ($projectType === 'mini');

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Evaluation Sheets</h1>
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <div class="form-group mb-0 flex-fill">
                <label for="subjectCode" class="mb-2">Enter Subject Code</label>
                <input type="text" class="form-control" id="subjectCode" placeholder="e.g., CS101, MATH202" required>
            </div>
            <button class="btn btn-primary" data-toggle="modal" data-target="#createSheetModal">
                <i class="fas fa-plus mr-2"></i> Create New Sheet
            </button>
        </div>
    </div>

    <!-- Evaluation Sheets Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Evaluation Sheets</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="sheetsTable" width="100%">
                    <thead>
                        <tr>
                            <?php if (!$isMiniProject): ?>
                            <th>Phase</th>
                            <th>Review Type</th>
                            <?php endif; ?>
                            <th>Max Marks</th>
                            <th>Criteria Count</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="sheetsTableBody">
                        <tr>
                            <td colspan="8" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Create Sheet Modal -->
<div class="modal fade" id="createSheetModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create Evaluation Sheet</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="createSheetForm">
                <div class="modal-body">
                    <div class="row">
                        <!-- Sheet title removed: only phase and review are required -->
                        <?php if (!$isMiniProject): ?>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="phase">Phase *</label>
                                <select class="form-control" id="phase" name="phase" required>
                                    <option value="">Select</option>
                                    <option value="1">Phase 1</option>
                                    <option value="2">Phase 2</option>
                        
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="reviewType">Review *</label>
                                <select class="form-control" id="reviewType" name="review_type" required>
                                    <option value="">Select</option>
                                    <option value="1">Review 1</option>
                                    <option value="2">Review 2</option>
                                    
                                    
                                </select>
                            </div>
                        </div>
                        <?php else: ?>
                        <!-- Mini Project: Hidden fields with fixed values -->
                        <input type="hidden" id="phase" name="phase" value="1">
                        <input type="hidden" id="reviewType" name="review_type" value="1">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> Mini projects use a single evaluation sheet without phases or reviews.
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <hr>
                    <h6>Evaluation Criteria</h6>
                    <div id="criteriaContainer">
                        <div class="criteria-item mb-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" class="form-control" placeholder="Criterion Name" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" class="form-control" placeholder="Max Marks" min="1" step="0.5" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-block" onclick="removeCriterion(this)">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-sm btn-secondary mt-2" onclick="addCriterion()">
                        <i class="fas fa-plus"></i> Add Criterion
                    </button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Sheet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Sheet Modal -->
<div class="modal fade" id="editSheetModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Evaluation Sheet</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="editSheetForm">
                <input type="hidden" id="editSheetId" name="sheet_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- Title removed for edit -->
                        </div>
                        <?php if (!$isMiniProject): ?>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="editPhase">Phase *</label>
                                <select class="form-control" id="editPhase" name="phase" required>
                                    <option value="">Select</option>
                                    <option value="1">Phase 1</option>
                                    <option value="2">Phase 2</option>
                                    <option value="3">Phase 3</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="editReviewType">Review *</label>
                                <select class="form-control" id="editReviewType" name="review_type" required>
                                    <option value="">Select</option>
                                    <option value="1">Review 1</option>
                                    <option value="2">Review 2</option>
                                    <option value="3">Review 3</option>
                                    <option value="4">Final Review</option>
                                </select>
                            </div>
                        </div>
                        <?php else: ?>
                        <!-- Mini Project: Hidden fields with fixed values -->
                        <input type="hidden" id="editPhase" name="phase" value="1">
                        <input type="hidden" id="editReviewType" name="review_type" value="1">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> Mini projects use a single evaluation sheet without phases or reviews.
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <hr>
                    <h6>Evaluation Criteria</h6>
                    <div id="editCriteriaContainer">
                        <!-- Criteria will be loaded here -->
                    </div>
                    <button type="button" class="btn btn-sm btn-secondary mt-2" onclick="addEditCriterion()">
                        <i class="fas fa-plus"></i> Add Criterion
                    </button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Sheet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Check if this is a mini project
const isMiniProject = <?php echo json_encode($isMiniProject); ?>;

$(document).ready(function() {
    // Restore subject code from localStorage on page load
    const savedSubjectCode = localStorage.getItem(`evaluationSheetSubjectCode_${isMiniProject ? 'mini' : 'major'}`);
    if (savedSubjectCode) {
        $('#subjectCode').val(savedSubjectCode);
    }
    
    // Save subject code to localStorage when changed
    $('#subjectCode').on('change', function() {
        const subjectCode = $(this).val().trim();
        if (subjectCode) {
            localStorage.setItem(`evaluationSheetSubjectCode_${isMiniProject ? 'mini' : 'major'}`, subjectCode);
        }
    });
    
    loadSheets();
    
    $('#createSheetForm').on('submit', function(e) {
        e.preventDefault();
        createSheet();
    });
    
    $('#editSheetForm').on('submit', function(e) {
        e.preventDefault();
        updateSheet();
    });
});

function loadSheets() {
    $.ajax({
        url: '../api/get-evaluation-sheets.php',
        type: 'GET',
        dataType: 'json',
        cache: false,
        success: function(response) {
            if (response.success) {
                let html = '';
                
                if (response.sheets.length === 0) {
                    const colspan = isMiniProject ? '6' : '8';
                    html = `<tr><td colspan="${colspan}" class="text-center">No evaluation sheets found</td></tr>`;
                } else {
                    response.sheets.forEach(sheet => {
                        const statusBadge = sheet.status === 'active' ? 
                            '<span class="badge badge-success">Active</span>' : 
                            '<span class="badge badge-secondary">Draft</span>';
                        
                        const toggleBtn = sheet.status === 'active' ?
                            `<button class="btn btn-sm btn-warning" onclick="toggleStatus(${sheet.id}, 'draft')">
                                <i class="fas fa-ban"></i> Deactivate
                            </button>` :
                            `<button class="btn btn-sm btn-success" onclick="toggleStatus(${sheet.id}, 'active')">
                                <i class="fas fa-check"></i> Activate
                            </button>`;
                        
                        let html_row = `<tr>`;
                        if (!isMiniProject) {
                            html_row += `<td>Phase ${sheet.phase}</td>`;
                            html_row += `<td>Review ${sheet.review}</td>`;
                        }
                        html_row += `<td>${sheet.total_marks}</td>
                                <td>${sheet.criteria_count}</td>
                                <td>${statusBadge}</td>
                                <td>${new Date(sheet.created_at).toLocaleDateString()}</td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick="editSheet(${sheet.id})">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    ${toggleBtn}
                                    <button class="btn btn-sm btn-danger" onclick="deleteSheet(${sheet.id})">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </td>
                            </tr>`;
                        html += html_row;
                    });
                }
                
                $('#sheetsTableBody').html(html);
                
                if ($.fn.DataTable.isDataTable('#sheetsTable')) {
                    $('#sheetsTable').DataTable().destroy();
                }
                $('#sheetsTable').DataTable({
                    "order": [[6, "desc"]]
                });
            }
        },
        error: function() {
            $('#sheetsTableBody').html('<tr><td colspan="8" class="text-center text-danger">Failed to load evaluation sheets</td></tr>');
        }
    });
}

function toggleStatus(sheetId, newStatus) {
    const statusText = newStatus === 'active' ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to ${statusText} this evaluation sheet?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, proceed'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/update-evaluation-status.php',
                type: 'POST',
                data: {
                    sheet_id: sheetId,
                    status: newStatus
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Success!', response.message, 'success');
                        loadSheets();
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to update status', 'error');
                }
            });
        }
    });
}

function editSheet(sheetId) {
    // Load sheet details
    $.ajax({
        url: '../api/get-evaluation-sheet-by-id.php',
        type: 'GET',
        data: { sheet_id: sheetId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const sheet = response.sheet;
                
                // Populate form
                $('#editSheetId').val(sheet.id);
                $('#editPhase').val(sheet.phase);
                $('#editReviewType').val(sheet.review);
                
                // Load criteria
                $('#editCriteriaContainer').empty();
                sheet.criteria.forEach(criterion => {
                    addEditCriterion(criterion.name, criterion.max_marks);
                });
                
                // If no criteria, add one empty row
                if (sheet.criteria.length === 0) {
                    addEditCriterion();
                }
                
                $('#editSheetModal').modal('show');
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to load evaluation sheet', 'error');
        }
    });
}

function addEditCriterion(name = '', marks = '') {
    const criteriaHtml = `
        <div class="criteria-item mb-2">
            <div class="row">
                <div class="col-md-8">
                    <input type="text" class="form-control" placeholder="Criterion Name" value="${name}" required>
                </div>
                <div class="col-md-3">
                    <input type="number" class="form-control" placeholder="Max Marks" min="1" step="0.5" value="${marks}" required>
                </div>
                <div class="col-md-1">
                    <button type="button" class="btn btn-danger btn-block" onclick="removeEditCriterion(this)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
    $('#editCriteriaContainer').append(criteriaHtml);
}

function removeEditCriterion(btn) {
    if ($('#editCriteriaContainer .criteria-item').length > 1) {
        $(btn).closest('.criteria-item').remove();
    } else {
        Swal.fire('Warning', 'At least one criterion is required', 'warning');
    }
}

function deleteSheet(sheetId, title) {
    Swal.fire({
        title: 'Delete Evaluation Sheet?',
        text: 'Are you sure you want to delete this evaluation sheet? This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/delete-evaluation-sheet.php',
                type: 'POST',
                data: { sheet_id: sheetId },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Deleted!', response.message, 'success');
                        loadSheets();
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to delete sheet', 'error');
                }
            });
        }
    });
}

function addCriterion() {
    const html = `
        <div class="criteria-item mb-2">
            <div class="row">
                <div class="col-md-8">
                    <input type="text" class="form-control" placeholder="Criterion Name" required>
                </div>
                <div class="col-md-3">
                    <input type="number" class="form-control" placeholder="Max Marks" min="1" step="0.5" required>
                </div>
                <div class="col-md-1">
                    <button type="button" class="btn btn-danger btn-block" onclick="removeCriterion(this)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
    $('#criteriaContainer').append(html);
}

function removeCriterion(btn) {
    if ($('.criteria-item').length > 1) {
        $(btn).closest('.criteria-item').remove();
    } else {
        Swal.fire('Error', 'At least one criterion is required', 'error');
    }
}

function createSheet() {
    const subjectCode = $('#subjectCode').val().trim();
    
    if (!subjectCode) {
        Swal.fire('Error', 'Please enter a subject code', 'error');
        return;
    }
    
    const criteria = [];
    let totalMarks = 0;
    let isValid = true;
    
    $('.criteria-item').each(function() {
        const name = $(this).find('input[type="text"]').val().trim();
        const marks = parseFloat($(this).find('input[type="number"]').val());
        
        if (!name || !marks || marks <= 0) {
            isValid = false;
            return false;
        }
        
        criteria.push({name: name, marks: marks});
        totalMarks += marks;
    });
    
    if (!isValid) {
        Swal.fire('Error', 'Please fill all criteria fields correctly', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('phase', $('#phase').val());
    formData.append('review_type', $('#reviewType').val());
    formData.append('subject_code', subjectCode);
    formData.append('max_marks', totalMarks);
    formData.append('criteria', JSON.stringify(criteria));
    
    $.ajax({
        url: '../api/create-evaluation-sheet.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                $('#createSheetModal').modal('hide');
                $('#createSheetForm')[0].reset();
                $('#criteriaContainer').html(`
                    <div class="criteria-item mb-2">
                        <div class="row">
                            <div class="col-md-8">
                                <input type="text" class="form-control" placeholder="Criterion Name" required>
                            </div>
                            <div class="col-md-3">
                                <input type="number" class="form-control" placeholder="Max Marks" min="1" step="0.5" required>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="btn btn-danger btn-block" onclick="removeCriterion(this)">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `);
                Swal.fire('Success!', response.message, 'success').then(() => {
                    // If API returned the created sheet, prepend it to the table for instant feedback
                    if (response.sheet) {
                        // reload full list to keep ordering and DataTable state consistent
                        loadSheets();
                    } else {
                        loadSheets();
                    }
                });
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        }
    });
}

function updateSheet() {
    const criteria = [];
    let totalMarks = 0;
    let isValid = true;
    
    $('#editCriteriaContainer .criteria-item').each(function() {
        const name = $(this).find('input[type="text"]').val().trim();
        const marks = parseFloat($(this).find('input[type="number"]').val());
        
        if (!name || !marks || marks <= 0) {
            isValid = false;
            return false;
        }
        
        criteria.push({name: name, marks: marks});
        totalMarks += marks;
    });
    
    if (!isValid) {
        Swal.fire('Error', 'Please fill all criteria fields correctly', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('sheet_id', $('#editSheetId').val());
    formData.append('phase', $('#editPhase').val());
    formData.append('review_type', $('#editReviewType').val());
    formData.append('criteria', JSON.stringify(criteria));
    
    $.ajax({
        url: '../api/update-evaluation-sheet.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response.success) {
                $('#editSheetModal').modal('hide');
                Swal.fire('Success!', response.message, 'success');
                loadSheets();
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to update evaluation sheet', 'error');
        }
    });
}
</script>
