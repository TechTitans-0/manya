<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Reports";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>
<style>
.file-item {
    margin-bottom: 8px; /* space between file names */
}
</style>


<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Reports</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Upload Tracking</h6>
            <div>
                <button class="btn btn-sm btn-primary" id="downloadAllReportsBtn">Download All Uploads (ZIP)</button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>Batches With Uploads</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered" id="uploadedTable">
                            <thead>
                                <tr>
                                    <th>Batch</th>
                                    <th>Project Title</th>
                                    <th>Team Lead</th>
                                    <th>Team Lead Phone</th>
                                    <th>Files</th>
                                </tr>
                            </thead>
                            <tbody id="uploadedBody"></tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6>Batches Missing Uploads</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered" id="notUploadedTable">
                            <thead>
                                <tr>
                                    <th>Batch</th>
                                    <th>Project Title</th>
                                    <th>Team Lead</th>
                                    <th>Team Lead Phone</th>
                                    <th>Files</th>
                                </tr>
                            </thead>
                            <tbody id="notUploadedBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    loadUploadsReport();

    // Check if server supports ZipArchive before enabling bulk-download
    $('#downloadAllReportsBtn').prop('disabled', true).attr('title', 'Checking server support...');
    $.ajax({
        url: '../api/check-zip.php',
        dataType: 'json',
        success: function(r) {
            if (r && r.zip) {
                $('#downloadAllReportsBtn').prop('disabled', false).attr('title', 'Download all approved uploads as ZIP');
                $('#downloadAllReportsBtn').on('click', function() {
                    window.location.href = '../api/bulk-download-uploads.php';
                });
            } else {
                $('#downloadAllReportsBtn').prop('disabled', true).attr('title', 'ZIP support unavailable on server');
            }
        },
        error: function() {
            $('#downloadAllReportsBtn').prop('disabled', true).attr('title', 'Failed to check ZIP support');
        }
    });

    // Show friendly message if user clicks the disabled button
    $('#downloadAllReportsBtn').on('click', function(e) {
        if ($(this).prop('disabled')) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Bulk download unavailable',
                html: 'Server does not have PHP Zip support enabled. To enable bulk download, enable the <strong>php_zip</strong> (ZipArchive) extension in your PHP configuration and restart Apache. <br><br>On XAMPP edit <code>php.ini</code> and uncomment <code>extension=zip</code> then restart Apache.',
                confirmButtonText: 'OK'
            });
        }
    });
});

function loadUploadsReport() {
    $.ajax({
        url: '../api/get-uploads-report.php',
        type: 'GET',
        dataType: 'json',
        success: function(resp) {
            if (!resp || !resp.success) return;

            // Uploaded
            const uploaded = resp.uploaded || [];
            let upHtml = '';
            if (uploaded.length === 0) {
                upHtml = '<tr><td colspan="5" class="text-center">No uploads yet</td></tr>';
            } else {
                uploaded.forEach(r => {
                    let filesHtml = '';
                    if (Array.isArray(r.filenames) && Array.isArray(r.upload_ids)) {
                        for (let i = 0; i < r.filenames.length; i++) {
                            const fname = r.filenames[i];
                            const uid = r.upload_ids[i];
                        filesHtml += `
    <div class="file-item">
        <a href="../api/download-upload.php?upload_id=${uid}" target="_blank">${fname}</a>
    </div>
`;

                        }
                    } else {
                        filesHtml = '-';
                    }
                    upHtml += `<tr>
                        <td>${r.batch ? r.batch + (r.academic_year ? `(${r.academic_year})` : '') : ''}</td>
                        <td>${r.project_title || r.group_name || ''}</td>
                        <td>${r.team_lead_name || ''}</td>
                        <td>${r.team_lead_phone || ''}</td>
                        <td>${filesHtml}</td>
                    </tr>`;
                });
            }
            $('#uploadedBody').html(upHtml);

            // Not uploaded
            const notUploaded = resp.not_uploaded || [];
            let notHtml = '';
            if (notUploaded.length === 0) {
                notHtml = '<tr><td colspan="5" class="text-center">All students have uploaded</td></tr>';
            } else {
                notUploaded.forEach(r => {
                    const files = r.files || '-';
                    notHtml += `<tr>
                        <td>${r.batch ? r.batch + (r.academic_year ? `(${r.academic_year})` : '') : ''}</td>
                        <td>${r.project_title || r.group_name || ''}</td>
                        <td>${r.team_lead_name || ''}</td>
                        <td>${r.team_lead_phone || ''}</td>
                        <td>${files}</td>
                    </tr>`;
                });
            }
            $('#notUploadedBody').html(notHtml);
        },
        error: function() {
            $('#uploadedBody').html('<tr><td colspan="5" class="text-center text-danger">Failed to load</td></tr>');
            $('#notUploadedBody').html('<tr><td colspan="5" class="text-center text-danger">Failed to load</td></tr>');
        }
    });
}

function downloadStudentReport(studentId) {
    // Open coordinator download endpoint which returns HTML for the student; open in new tab
    window.open('../api/coordinator-download-student-report.php?student_id=' + studentId, '_blank');
}

function downloadUpload(uploadId) {
    window.location.href = '../api/download-upload.php?upload_id=' + uploadId;
}
</script>
