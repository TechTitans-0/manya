<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$currentPage = 'dashboard';
$pageTitle = 'Coordinator Dashboard';

// Get coordinator details
$coordQuery = "SELECT c.*, u.username, u.email, u.phone
               FROM coordinators c
               INNER JOIN users u ON c.user_id = u.id
               WHERE c.id = ?";
$stmt = $conn->prepare($coordQuery);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$coordinator = $stmt->get_result()->fetch_assoc();

// Get selected academic year for coordinator (from session, default to ACTIVE)
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? $_SESSION['academic_year_id'] : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
    if ($selectedAcademicYearId) $_SESSION['academic_year_id'] = $selectedAcademicYearId;
}

// Get selected academic year status for read-only mode
$academicYearStatus = 'ACTIVE';
if ($selectedAcademicYearId) {
    $yearStatusStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
    $yearStatusStmt->bind_param("i", $selectedAcademicYearId);
    $yearStatusStmt->execute();
    $yearStatusResult = $yearStatusStmt->get_result()->fetch_assoc();
    if ($yearStatusResult) {
        $academicYearStatus = $yearStatusResult['status'];
    }
    $yearStatusStmt->close();
}

// Get statistics - filter by selected academic year
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM authorized_students WHERE academic_year_id = ?");
$stmt->bind_param("i", $selectedAcademicYearId);
$stmt->execute();
$totalStudents = $stmt->get_result()->fetch_assoc()['count'];

$totalGuides = $conn->query("SELECT COUNT(*) as count FROM guides")->fetch_assoc()['count'];

$stmt = $conn->prepare("SELECT COUNT(DISTINCT batch) as count FROM pgroups WHERE batch IS NOT NULL AND academic_year_id = ?");
$stmt->bind_param("i", $selectedAcademicYearId);
$stmt->execute();
$totalBatches = $stmt->get_result()->fetch_assoc()['count'];

// Get recent groups with coordinator name if assigned as guide - filter by academic year
$groupsQuery = "SELECT g.*, 
                (SELECT COUNT(*) FROM students WHERE group_id = g.id AND academic_year_id = ?) as member_count,
                gu.username as guide_name,
                c.username as coordinator_name,
                ay.year_label as academic_year
                FROM pgroups g
                LEFT JOIN guides gd ON g.guide_id = gd.id
                LEFT JOIN users gu ON gd.user_id = gu.id
                LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
                LEFT JOIN users c ON cd.user_id = c.id
                LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
                WHERE g.academic_year_id = ?
                ORDER BY g.created_at DESC
                LIMIT 10";
$stmt = $conn->prepare($groupsQuery);
$stmt->bind_param("ii", $selectedAcademicYearId, $selectedAcademicYearId);
$stmt->execute();
$recentGroups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get batch-wise statistics - filter by academic year
$batchStatsQuery = "SELECT 
                    g.batch,
                    COUNT(DISTINCT g.id) as total_teams,
                    COUNT(DISTINCT s.id) as total_students,
                    AVG(g.overall_grade) as avg_grade
                    FROM pgroups g
                    LEFT JOIN students s ON s.group_id = g.id AND s.academic_year_id = ?
                    WHERE g.batch IS NOT NULL AND g.academic_year_id = ?
                    GROUP BY g.batch
                    ORDER BY g.batch DESC";
$stmt = $conn->prepare($batchStatsQuery);
$stmt->bind_param("ii", $selectedAcademicYearId, $selectedAcademicYearId);
$stmt->execute();
$batchStats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>


<!-- Page Heading (Close Academic Year button moved to topbar dropdown) -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Coordinator Dashboard</h1>
    <?php if ($academicYearStatus === 'COMPLETED'): ?>
    <span class="badge badge-warning ml-3"><i class="fas fa-lock"></i> Year is COMPLETED - Read-Only Mode</span>
    <?php endif; ?>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Total Students Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Students</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalStudents; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-graduate fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Total Guides Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Guides</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalGuides; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chalkboard-teacher fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Total Groups Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Total Batches</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalBatches; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (getCurrentProjectType() !== 'mini'): ?>
    <!-- Current Phase Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Current Phase</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800" id="currentPhaseCard">-</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-layer-group fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Current Review Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-dark shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-dark text-uppercase mb-1">Current Review</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800" id="currentReviewCard">-</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Recent Groups -->
    <div class="col-lg-12 mb-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Recent Groups</h6>
                 <a href="groups.php" class="btn btn-primary btn-sm">Groups</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="groupsTable">
                        <thead>
                            <tr>
                                <th>Group Name</th>
                                <th>Batch</th>
                                <th>Members</th>
                                <th>Guide</th>
                                <th>Project Title</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentGroups as $group): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($group['group_name']); ?></td>
                                    <td><?php echo htmlspecialchars($group['batch'] ?? 'Not assigned'); if (!empty($group['academic_year'])) echo "(" . htmlspecialchars($group['academic_year']) . ")"; ?></td>
                                    <td><?php echo $group['member_count']; ?></td>
                                    <td>
                                        <?php
                                        if (!empty($group['guide_name'])) {
                                            echo htmlspecialchars($group['guide_name']);
                                        } else if (!empty($group['coordinator_guide_id']) && !empty($group['coordinator_name'])) {
                                            echo htmlspecialchars($group['coordinator_name']) . ' (Coordinator)';
                                        } else {
                                            echo 'Not assigned';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($group['project_title'] ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Quick Actions</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <a href="students.php" class="btn btn-primary btn-block">
                            <i class="fas fa-users"></i> Manage Students
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="staff.php" class="btn btn-success btn-block">
                            <i class="fas fa-chalkboard-teacher"></i> Manage Guides
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="evaluation-sheets.php" class="btn btn-info btn-block">
                            <i class="fas fa-file-alt"></i> Evaluation Sheets
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="circulars.php" class="btn btn-warning btn-block">
                            <i class="fas fa-bullhorn"></i> Send Circular
                        </a>
                    </div>
                    <?php if (getCurrentProjectType() !== 'mini'): ?>
                    <div class="col-md-3 mb-3">
                        <button class="btn btn-secondary btn-block" id="btnSetPhase" data-toggle="modal" data-target="#setPhaseOnlyModal">
                            <i class="fas fa-sliders-h"></i> Set Phase
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button class="btn btn-secondary btn-block" id="btnSetReview" data-toggle="modal" data-target="#setReviewOnlyModal">
                            <i class="fas fa-check-double"></i> Set Review
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Group Modal -->
<div class="modal fade" id="editGroupModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Manage Group: <span id="modalGroupName"></span></h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editGroupId">
                
                <!-- Tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#assignGuideTab">Assign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#batchDomainTab">Batch & Domain</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#studentsTab">Students</a>
                    </li>
                </ul>
                
                <div class="tab-content mt-3">
                    <!-- Assign Guide Tab -->
                    <div id="assignGuideTab" class="tab-pane active">
                        <form id="assignGuideForm">
                            <div class="form-group">
                                <label for="guideSelect">Select Guide *</label>
                                <select class="form-control" id="guideSelect" required>
                                    <option value="">Loading...</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Assign Guide
                            </button>
                        </form>
                    </div>
                    
                    <!-- Batch & Domain Tab -->
                    <div id="batchDomainTab" class="tab-pane">
                        <form id="batchDomainForm">
                            <div class="form-group">
                                <label for="batchSelect">Batch *</label>
                                <select class="form-control" id="batchSelect" required>
                                    <option value="">Loading...</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="domainInput">Domain/Area of Specialization</label>
                                <input type="text" class="form-control" id="domainInput" 
                                       placeholder="e.g., AI/ML, Web Development, Mobile Apps">
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Details
                            </button>
                        </form>
                    </div>
                    
                    <!-- Students Tab -->
                    <div id="studentsTab" class="tab-pane">
                        <div id="studentsTableContainer">
                            <div class="text-center py-4">
                                <i class="fas fa-spinner fa-spin fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let currentGroupId = null;


// Ensure DOM is ready before binding
$(document).ready(function() {
});

$(document).on('click', '.btn-manage-group', function() {
    const groupId = $(this).data('group-id');
    const groupName = $(this).data('group-name');
    const batch = $(this).data('batch');
    const guideId = $(this).data('guide-id');
    const domain = $(this).data('domain');
    
    editGroup(groupId, groupName, batch, guideId, domain);
});

function editGroup(groupId, groupName, batch, guideId, domain) {
    currentGroupId = groupId;
    $('#editGroupId').val(groupId);
    $('#modalGroupName').text(groupName);
    $('#batchSelect').val(batch);
    $('#domainInput').val(domain);
    
    // Load guides
    loadGuides(guideId);
    
    // Load batches
    loadBatches(batch);
    
    // Show modal
    $('#editGroupModal').modal('show');
}

function loadGuides(selectedGuideId) {
    $.ajax({
        url: '../api/get-guides.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let options = '<option value="">-- Select Guide --</option>';
                response.guides.forEach(guide => {
                    const selected = guide.id == selectedGuideId ? 'selected' : '';
                    const displayName = guide.name || guide.username || '';
                    options += `<option value="${guide.id}" ${selected}>${displayName} (${guide.employee_id || ''}) - ${guide.department || ''}</option>`;
                });
                $('#guideSelect').html(options);
            }
        }
    });
}

function loadBatches(selectedBatch) {
    $.ajax({
        url: '../api/get-batches.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let options = '<option value="">-- Select Batch --</option>';
                response.batches.forEach(batch => {
                    const selected = batch.batch_name == selectedBatch ? 'selected' : '';
                    options += `<option value="${batch.batch_name}" ${selected}>${batch.batch_name} (${batch.year})</option>`;
                });
                $('#batchSelect').html(options);
            }
        }
    });
}

// Assign Guide
$('#assignGuideForm').on('submit', function(e) {
    e.preventDefault();
    
    const guideId = $('#guideSelect').val();
    if (!guideId) {
        Swal.fire('Error!', 'Please select a guide', 'error');
        return;
    }
    
    $.ajax({
        url: '../api/assign-guide.php',
        method: 'POST',
        data: {
            group_id: currentGroupId,
            guide_id: guideId
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                Swal.fire('Success!', 'Guide assigned successfully', 'success').then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to assign guide', 'error');
        }
    });
});

// (removed duplicate/garbled handler)

// Load students when tab is clicked
$('a[href="#studentsTab"]').on('shown.bs.tab', function() {
    loadGroupStudents();
});

function loadGroupStudents() {
    $.ajax({
        url: '../api/get-group-details.php',
        method: 'GET',
        data: { group_id: currentGroupId },
        dataType: 'json',
        success: function(response) {
            if (response.success && response.members) {
                let html = `
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>USN</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                response.members.forEach(student => {
                    html += `
                        <tr>
                            <td>${student.full_name || student.username}</td>
                            <td>${student.usn}</td>
                            <td>${student.email}</td>
                            <td>${student.phone || 'N/A'}</td>
                            <td>${student.is_team_lead == 1 ? '<span class="badge badge-primary">Team Lead</span>' : 'Member'}</td>
                            <td>
                                <button class="btn btn-sm btn-info" onclick="editStudent(${student.id}, '${student.full_name || student.username}', '${student.usn}', '${student.email}', '${student.phone || ''}')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                `;
                
                $('#studentsTableContainer').html(html);
            } else {
                $('#studentsTableContainer').html('<div class="alert alert-warning">No students found in this group</div>');
            }
        },
        error: function() {
            $('#studentsTableContainer').html('<div class="alert alert-danger">Failed to load students</div>');
        }
    });
}

function editStudent(studentId, name, usn, email, phone) {
    Swal.fire({
        title: 'Edit Student Information',
        html: `
            <div class="form-group text-left">
                <label>Full Name</label>
                <input id="swal-name" class="swal2-input" value="${name}" style="width: 90%;">
            </div>
            <div class="form-group text-left">
                <label>Email</label>
                <input id="swal-email" class="swal2-input" type="email" value="${email}" style="width: 90%;">
            </div>
            <div class="form-group text-left">
                <label>Phone</label>
                <input id="swal-phone" class="swal2-input" value="${phone}" style="width: 90%;">
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Update',
        preConfirm: () => {
            const name = $('#swal-name').val();
            const email = $('#swal-email').val();
            const phone = $('#swal-phone').val();
            
            if (!name || !email) {
                Swal.showValidationMessage('Name and email are required');
                return false;
            }
            
            return { name, email, phone };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../api/update-student-info.php',
                method: 'POST',
                data: {
                    student_id: studentId,
                    full_name: result.value.name,
                    email: result.value.email,
                    phone: result.value.phone
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire('Success!', 'Student information updated', 'success');
                        loadGroupStudents();
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Failed to update student information', 'error');
                }
            });
        }
    });
}
</script>

<!-- View Group Details Modal -->
<div class="modal fade" id="viewGroupDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Group Details: <span id="viewGroupName"></span></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="groupDetailsContent">
                    <div class="text-center py-4">
                        <i class="fas fa-spinner fa-spin fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function viewGroupDetails(groupId, groupName) {
    $('#viewGroupName').text(groupName);
    $('#viewGroupDetailsModal').modal('show');
    
    $.ajax({
        url: '../api/get-group-details.php',
        method: 'GET',
        data: { group_id: groupId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let html = `
                    <div class="mb-4">
                        <h6 class="text-primary">Group Information</h6>
                        <table class="table table-sm table-bordered">
                            <tr><th width="30%">Group Name:</th><td>${response.group.group_name}</td></tr>
                            <tr><th>Project Title:</th><td>${response.group.project_title || 'Not set'}</td></tr>
                            <tr><th>Batch:</th><td>${response.group.batch || 'Not assigned'}</td></tr>
                            <tr><th>Domain:</th><td>${response.group.domain || 'Not specified'}</td></tr>
                            <tr><th>Guide:</th><td>${response.group.guide_name || 'Not assigned'}</td></tr>
                            <tr><th>Phase:</th><td>Phase ${response.group.current_phase}</td></tr>
                            <tr><th>Status:</th><td><span class="badge badge-info">${response.group.project_status}</span></td></tr>
                            <tr><th>Overall Grade:</th><td>${response.group.overall_grade || 'Not graded'}</td></tr>
                        </table>
                    </div>
                    <div>
                        <h6 class="text-primary">Team Members (${response.members.length})</h6>
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>USN</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                response.members.forEach(member => {
                    html += `
                        <tr>
                            <td>${member.full_name || member.username}</td>
                            <td>${member.usn}</td>
                            <td>${member.email}</td>
                            <td>${member.phone || 'N/A'}</td>
                            <td>${member.is_team_lead == 1 ? '<span class="badge badge-primary">Team Lead</span>' : 'Member'}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                `;
                
                $('#groupDetailsContent').html(html);
            } else {
                $('#groupDetailsContent').html('<div class="alert alert-danger">Failed to load group details</div>');
            }
        },
        error: function() {
            $('#groupDetailsContent').html('<div class="alert alert-danger">Error loading group details</div>');
        }
    });
}
</script>

<?php include '../includes/footer.php'; ?>

<?php if (getCurrentProjectType() !== 'mini'): ?>
<!-- Set Phase Modal -->
<div class="modal fade" id="setPhaseOnlyModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Set Global Phase</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="setPhaseOnlyForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="phaseOnlyInput">Select Phase</label>
                        <select class="form-control" id="phaseOnlyInput" name="phase" required>
                            <option value="">-- Select Phase --</option>
                            <option value="1">Phase 1</option>
                            <option value="2">Phase 2</option>
                        </select>
                        <small class="form-text text-muted">This will be applied globally to all dashboards</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Set Phase</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Set Review Modal -->
<div class="modal fade" id="setReviewOnlyModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Set Global Review</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="setReviewOnlyForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="reviewOnlyInput">Review Number</label>
                        <input type="number" min="1" max="2" class="form-control" id="reviewOnlyInput" name="review" required placeholder="Enter review ">
                        <small class="form-text text-muted">This will be applied globally to all dashboards</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Set Review</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Load global phase and review settings
function loadCurrentPhaseReview() {
    $.ajax({
        url: '../api/get-global-settings.php',
        method: 'GET',
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                window.currentPhaseConfig = res.phase || 1;
                window.currentReviewConfig = res.review || 1;
                $('#currentPhaseCard').text('Phase ' + window.currentPhaseConfig);
                $('#currentReviewCard').text('Review ' + window.currentReviewConfig);
            }
        },
        error: function() {
            $('#currentPhaseCard').text('-');
            $('#currentReviewCard').text('-');
        }
    });
}
<?php if (getCurrentProjectType() !== 'mini'): ?>
loadCurrentPhaseReview();
<?php endif; ?>

<?php if (getCurrentProjectType() !== 'mini'): ?>
$('#setPhaseOnlyForm').on('submit', function(e) {
    e.preventDefault();
    const phase = parseInt($('#phaseOnlyInput').val(),10);
    if (!phase || (phase !== 1 && phase !== 2)) { 
        Swal.fire('Error','Please select a valid phase (1 or 2)','error'); 
        return; 
    }
    Swal.fire({title:'Setting global phase...', allowOutsideClick:false, didOpen:()=>Swal.showLoading()});
    $.post('../api/set-global-phase.php', {phase: phase}, function(r){
        Swal.close();
        if (r.success) {
            Swal.fire('Success', r.message, 'success').then(()=> {
                $('#setPhaseOnlyModal').modal('hide');
                loadCurrentPhaseReview();
            });
        } else {
            Swal.fire('Error', r.message||'Failed to set phase', 'error');
        }
    }, 'json').fail(()=>{
        Swal.close();
        Swal.fire('Error','Request failed','error');
    });
});

$('#setReviewOnlyForm').on('submit', function(e) {
    e.preventDefault();
    const review = parseInt($('#reviewOnlyInput').val(),10);
    if (!review || review < 1 || review > 10) { 
        Swal.fire('Error','Please enter a valid review number (1-10)','error'); 
        return; 
    }
    Swal.fire({title:'Setting global review...', allowOutsideClick:false, didOpen:()=>Swal.showLoading()});
    $.post('../api/set-global-review.php', {review: review}, function(r){
        Swal.close();
        if (r.success) {
            Swal.fire('Success', r.message, 'success').then(()=> {
                $('#setReviewOnlyModal').modal('hide');
                loadCurrentPhaseReview();
            });
        } else {
            Swal.fire('Error', r.message||'Failed to set review', 'error');
        }
    }, 'json').fail(()=>{
        Swal.close();
        Swal.fire('Error','Request failed','error');
    });
});
<?php endif; ?>
</script>
