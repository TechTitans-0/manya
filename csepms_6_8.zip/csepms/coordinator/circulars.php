<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Send Circular";

// Get selected academic year status for read-only mode
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? $_SESSION['academic_year_id'] : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
}

$academicYearStatus = 'ACTIVE';
if ($selectedAcademicYearId) {
    $yearStatusStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
    $yearStatusStmt->bind_param("i", $selectedAcademicYearId);
    $yearStatusStmt->execute();
    $yearStatusResult = $yearStatusStmt->get_result()->fetch_assoc();
    if ($yearStatusResult) {
        $academicYearStatus = $yearStatusResult['status'];
    }
    $yearStatusStmt->close();
}

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Send Circular</h1>

    <div class="row">
        <div class="col-lg-6">
            <!-- Send Circular Form -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">New Circular</h6>
                </div>
                <div class="card-body">
                    <form id="circularForm" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="targetRole">Send To *</label>
                            <select class="form-control" id="targetRole" name="target_role" required>
                                <option value="all">All Users (Students, Guides & Coordinators)</option>
                                <option value="student">Students Only</option>
                                <option value="guide">Guides Only</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="title">Circular Title</label>
                            <input type="text" class="form-control" id="title" name="title">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="6"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="attachment">Attachment (Optional)</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="attachment" name="attachment" accept=".pdf,.ppt,.pptx,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png,.zip">
                                <label class="custom-file-label" for="attachment">Choose file</label>
                            </div>
                            <small class="form-text text-muted">Max 100MB. Supported: PDF, PPT, DOC, XLS, Images, ZIP</small>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-paper-plane mr-2"></i> Send Circular
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6">
            <!-- Circular History -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Circular History</h6>
                </div>
                <div class="card-body" style="max-height: 600px; overflow-y: auto;">
                    <div id="circularHistory">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm"></div>
                            <p class="text-muted mt-2">Loading history...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
const currentUserId = <?php echo isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0; ?>;
const academicYearStatus = '<?php echo $academicYearStatus; ?>';
$(document).ready(function() {
    loadCircularHistory();
    
    // Update file input label
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').html(fileName || 'Choose file');
    });
    
    $('#circularForm').on('submit', function(e) {
        e.preventDefault();
        
        let formData = new FormData(this);
        
        Swal.fire({
            title: 'Sending...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        
        $.ajax({
            url: '../api/send-circular.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                Swal.close();
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Circular Sent!',
                        text: response.message,
                        confirmButtonColor: '#4e73df'
                    }).then(() => {
                        $('#circularForm')[0].reset();
                        $('.custom-file-label').html('Choose file');
                        loadCircularHistory();
                    });
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function(xhr) {
                Swal.close();
                Swal.fire('Error!', xhr.responseText || 'Failed to send circular', 'error');
            }
        });
    });
});

function loadCircularHistory() {
    $.ajax({
        url: '../api/get-circular-history.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '';
                if (response.circulars.length === 0) {
                    html = '<p class="text-center text-muted">No circulars sent yet</p>';
                } else {
                    response.circulars.forEach(circular => {
                        const date = new Date(circular.created_at).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                        
                        // Render target badges. API returns `target_label` and `target_types` (array)
                        let targetBadge = '';
                        if (circular.target_label === 'All') {
                            targetBadge = '<span class="badge badge-primary">All</span>';
                        } else if (Array.isArray(circular.target_types) && circular.target_types.length > 0) {
                            const map = {
                                'all_students': '<span class="badge badge-info">Students</span>',
                                'all_guides': '<span class="badge badge-success">Guides</span>',
                                'all_coordinators': '<span class="badge badge-secondary">Coordinators</span>'
                            };
                            targetBadge = circular.target_types.map(t => map[t] || '<span class="badge badge-primary">'+t+'</span>').join(' ');
                        } else {
                            targetBadge = '<span class="badge badge-primary">All Users</span>';
                        }
                        
                        const attachment = circular.attachment_path ?
                            `<br><a href="../${circular.attachment_path}" target="_blank" class="btn btn-sm btn-outline-primary mt-2">
                                <i class="fas fa-paperclip"></i> View Attachment
                            </a>` : '';
                        
                        // Sender name (if available)
                        const senderName = circular.sender_name ? `<div><small class="text-muted">Sent by: ${circular.sender_name}</small></div>` : '';

                        // Show delete button only if current user is the sender AND academic year is not COMPLETED
                        const showDelete = (circular.sender_id && parseInt(circular.sender_id) === parseInt(currentUserId)) && (academicYearStatus !== 'COMPLETED');
                        const deleteBtn = showDelete ? `<button class="btn btn-sm btn-danger mt-2 delete-circular-btn" data-id="${circular.id}">Delete</button>` : '';

                        html += `
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h6 class="card-title mb-1">${circular.title}</h6>
                                        ${targetBadge}
                                    </div>
                                    ${senderName}
                                    <small class="text-muted">${date}</small>
                                    <p class="card-text mt-2">${circular.message}</p>
                                    ${attachment}
                                    ${deleteBtn}
                                </div>
                            </div>
                        `;
                    });
                }
                $('#circularHistory').html(html);
                // Add delete button handler
                $('.delete-circular-btn').on('click', function() {
                    const circularId = $(this).data('id');
                    if (confirm('Are you sure you want to delete this circular?')) {
                        $.ajax({
                            url: '../api/delete-circular.php',
                            type: 'POST',
                            data: { id: circularId },
                            success: function(resp) {
                                if (resp && resp.success) {
                                    loadCircularHistory();
                                } else {
                                    alert('Failed to delete circular');
                                }
                            },
                            error: function() {
                                alert('Failed to delete circular');
                            }
                        });
                    }
                });
            }
        },
        error: function() {
            $('#circularHistory').html('<p class="text-center text-danger">Failed to load history</p>');
        }
    });
}
</script>

