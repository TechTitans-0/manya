<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Chat";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Messages</h1>

    <div class="row">
        <!-- Recent Chats Section -->
        <div class="col-md-3">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Recent Chats</h6>
                    <button class="btn btn-sm btn-outline-primary" id="refreshRecentChats" title="Refresh">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                <div class="card-body p-0" style="max-height: 500px; overflow-y: auto;" id="recentChatsList">
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p class="mb-0 mt-2">Loading...</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Selection Area -->
        <div class="col-md-3">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Select Recipient</h6>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="recipientType">Message To:</label>
                        <select class="form-control" id="recipientType">
                            <option value="">-- Select Type --</option>
                            <option value="batch">Batch (All Students)</option>
                            <option value="guide">Individual Guide</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="batchDropdownGroup" style="display: none;">
                        <label for="batchSelect">Select Batch:</label>
                        <select class="form-control" id="batchSelect">
                            <option value="">-- Select Batch --</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="guideDropdownGroup" style="display: none;">
                        <label for="guideSelect">Select Guide:</label>
                        <select class="form-control" id="guideSelect">
                            <option value="">-- Select Guide --</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3" id="chatHeader">
                    <h6 class="m-0 font-weight-bold text-primary">Select a recipient to start messaging</h6>
                </div>
                <div class="card-body" style="height: 500px; overflow-y: auto;" id="chatMessages">
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-comments fa-3x mb-3"></i>
                        <p>Select a batch or guide from the dropdown to start messaging</p>
                    </div>
                </div>
                <div class="card-footer" id="chatFooter" style="display: none;">
                    <form id="messageForm">
                        <div class="input-group">
                            <textarea class="form-control" id="messageInput" rows="2"
                                   placeholder="Type your message..." required></textarea>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-paper-plane"></i> Send
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<style>
/* Recent Chats Styling */
#recentChatsList .list-group-item {
    border-left: none;
    border-right: none;
    border-top: none;
    padding: 0.75rem 1rem;
    cursor: pointer;
    transition: all 0.2s ease;
}

#recentChatsList .list-group-item:first-child {
    border-top: none;
}

#recentChatsList .list-group-item:hover {
    background-color: #f8f9fc !important;
    transform: translateX(5px);
}

#recentChatsList .list-group-item.bg-light {
    background-color: #e3f2fd !important;
    border-left: 3px solid #4e73df;
}

#recentChatsList .badge-primary {
    background-color: #4e73df;
    font-size: 0.7rem;
    min-width: 20px;
}

#recentChatsList .text-truncate {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

#refreshRecentChats {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

#refreshRecentChats:hover {
    background-color: #4e73df;
    color: white;
}
</style>

<script>
let currentBatch = null;
let currentGuide = null;
let chatType = null; // 'batch' or 'guide'

$(document).ready(function() {
    loadBatches();
    loadGuides();
    loadRecentChats();
    
    // Auto-refresh recent chats every 30 seconds
    setInterval(loadRecentChats, 30000);
    
    // Refresh button click handler
    $('#refreshRecentChats').on('click', function() {
        $(this).find('i').addClass('fa-spin');
        loadRecentChats();
        setTimeout(() => {
            $(this).find('i').removeClass('fa-spin');
        }, 1000);
    });
    
    // Handle recipient type change
    $('#recipientType').on('change', function() {
        const type = $(this).val();
        
        // Hide both dropdowns
        $('#batchDropdownGroup').hide();
        $('#guideDropdownGroup').hide();
        $('#batchSelect').val('');
        $('#guideSelect').val('');
        
        // Reset chat area
        resetChatArea();
        
        // Show appropriate dropdown
        if (type === 'batch') {
            $('#batchDropdownGroup').show();
        } else if (type === 'guide') {
            $('#guideDropdownGroup').show();
        }
    });
    
    // Handle batch selection
    $('#batchSelect').on('change', function() {
        const batchName = $(this).val();
        if (batchName) {
            openBatchChat(batchName);
        } else {
            resetChatArea();
        }
    });
    
    // Handle guide selection
    $('#guideSelect').on('change', function() {
        const guideId = $(this).val();
        const guideName = $(this).find('option:selected').text();
        if (guideId) {
            openGuideChat(guideId, guideName);
        } else {
            resetChatArea();
        }
    });
    
    $('#messageForm').on('submit', function(e) {
        e.preventDefault();
        if (chatType === 'batch') {
            sendBatchMessage();
        } else if (chatType === 'guide') {
            sendGuideMessage();
        }
    });
});

function loadBatches() {
    $.ajax({
        url: '../api/get-batches.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let options = '<option value="">-- Select Batch --</option>';
                response.batches.forEach(batch => {
                    options += `<option value="${batch.batch}">${batch.batch} (${batch.student_count} students, ${batch.group_count} groups)</option>`;
                });
                $('#batchSelect').html(options);
            }
        },
        error: function() {
            $('#batchSelect').html('<option value="">Failed to load batches</option>');
        }
    });
}

function loadGuides() {
    $.ajax({
        url: '../api/get-guides.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let options = '<option value="">-- Select Guide --</option>';
                response.guides.forEach(guide => {
                    if (guide.is_registered == 1 && guide.user_id) {
                        options += `<option value="${guide.user_id}">${guide.name}</option>`;
                    }
                });
                $('#guideSelect').html(options);
            }
        },
        error: function() {
            $('#guideSelect').html('<option value="">Failed to load guides</option>');
        }
    });
}

function loadRecentChats() {
    $.ajax({
        url: '../api/get-coordinator-recent-chats.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayRecentChats(response.chats);
            } else {
                $('#recentChatsList').html('<div class="text-center text-danger p-3">Error loading chats</div>');
            }
        },
        error: function() {
            $('#recentChatsList').html('<div class="text-center text-danger p-3">Failed to load chats</div>');
        }
    });
}

function displayRecentChats(chats) {
    if (!chats || chats.length === 0) {
        $('#recentChatsList').html(`
            <div class="text-center text-muted py-4">
                <i class="fas fa-inbox fa-2x mb-2"></i>
                <p class="mb-0">No recent chats</p>
            </div>
        `);
        return;
    }
    
    let html = '<div class="list-group list-group-flush">';
    
    chats.forEach(chat => {
        const isUnread = chat.unread_count > 0;
        const bgClass = isUnread ? 'bg-light' : '';
        const fontWeight = isUnread ? 'font-weight-bold' : '';
        const timeStr = formatChatTime(chat.last_message_time);
        const previewText = truncateText(chat.last_message, 40);
        const isSent = chat.sender_id == <?php echo $_SESSION['user_id']; ?>;
        const messagePrefix = isSent ? 'You: ' : '';
        
        let chatIdentifier = '';
        let recipientName = chat.recipient_name;
        let subtitle = '';
        
        if (chat.chat_type === 'guide') {
            chatIdentifier = `data-guide-id="${chat.guide_user_id}"`;
            recipientName = chat.full_name || chat.recipient_name;
            subtitle ='';
        } else if (chat.chat_type === 'batch') {
            chatIdentifier = `data-batch="${chat.batch}"`;
            recipientName = chat.batch;
            subtitle = `<small class="text-muted d-block">${chat.student_count} students</small>`;
        }
        
        html += `
            <a href="javascript:void(0)" 
               class="list-group-item list-group-item-action recent-chat-item ${bgClass}" 
               data-chat-type="${chat.chat_type}"
               ${chatIdentifier}>
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1" style="min-width: 0;">
                        <div class="d-flex justify-content-between align-items-center">
                            <strong class="${fontWeight}" style="font-size: 0.9rem;">${escapeHtml(recipientName)}</strong>
                            ${isUnread ? `<span class="badge badge-primary badge-pill ml-2">${chat.unread_count}</span>` : ''}
                        </div>
                        ${subtitle}
                        <p class="mb-1 text-muted text-truncate" style="font-size: 0.85rem;">
                            ${messagePrefix}${escapeHtml(previewText)}
                        </p>
                        <small class="text-muted">${timeStr}</small>
                    </div>
                </div>
            </a>
        `;
    });
    
    html += '</div>';
    $('#recentChatsList').html(html);
    
    // Add click handlers
    $('.recent-chat-item').on('click', function() {
        const chatType = $(this).data('chat-type');
        
        if (chatType === 'guide') {
            const guideId = $(this).data('guide-id');
            const guideName = $(this).find('strong').text().trim();
            
            // Set the dropdown values
            $('#recipientType').val('guide').trigger('change');
            $('#guideSelect').val(guideId).trigger('change');
            
            // Mark as read
            markChatAsRead('guide', guideId);
            
        } else if (chatType === 'batch') {
            const batch = $(this).data('batch');
            
            // Set the dropdown values
            $('#recipientType').val('batch').trigger('change');
            $('#batchSelect').val(batch).trigger('change');
            
            // Mark as read
            markChatAsRead('batch', null, batch);
        }
        
        // Refresh recent chats after a short delay
        setTimeout(loadRecentChats, 1000);
    });
}

function markChatAsRead(chatType, guideUserId = null, batch = null) {
    const data = { chat_type: chatType };
    
    if (chatType === 'guide' && guideUserId) {
        data.guide_user_id = guideUserId;
    } else if (chatType === 'batch' && batch) {
        data.batch = batch;
    }
    
    $.ajax({
        url: '../api/mark-chat-as-read.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(data),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                console.log('Messages marked as read:', response.marked_count);
            }
        },
        error: function(xhr) {
            console.error('Failed to mark as read:', xhr.responseText);
        }
    });
}

function formatChatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return diffMins + 'm ago';
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return diffHours + 'h ago';
    
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return diffDays + 'd ago';
    
    return date.toLocaleDateString();
}

function truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}


function resetChatArea() {
    currentBatch = null;
    currentGuide = null;
    chatType = null;
    $('#chatHeader').html('<h6 class="m-0 font-weight-bold text-primary">Select a recipient to start messaging</h6>');
    $('#chatMessages').html(`
        <div class="text-center text-muted py-5">
            <i class="fas fa-comments fa-3x mb-3"></i>
            <p>Select a batch or guide from the dropdown to start messaging</p>
        </div>
    `);
    $('#chatFooter').hide();
    $('#messageInput').val('');
}

function openBatchChat(batchName) {
    currentBatch = batchName;
    currentGuide = null;
    chatType = 'batch';
    
    $('#chatHeader').html(`
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-users"></i> Batch: ${batchName}
        </h6>
    `);
    $('#messageInput').attr('placeholder', 'Type a message to all students in ' + batchName + '...');
    $('#chatMessages').html('<p class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin"></i> Loading messages...</p>');
    $('#chatFooter').show();
    
    // Load batch messages
    loadBatchMessages(batchName);
}

function openGuideChat(guideId, guideName) {
    currentGuide = guideId;
    currentBatch = null;
    chatType = 'guide';
    
    $('#chatHeader').html(`
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-chalkboard-teacher"></i> Guide: ${guideName}
        </h6>
    `);
    $('#messageInput').attr('placeholder', 'Type a message to ' + guideName + '...');
    $('#chatMessages').html('<p class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin"></i> Loading messages...</p>');
    $('#chatFooter').show();
    
    // Load guide messages
    loadGuideMessages(guideId);
}

function sendBatchMessage() {
    const message = $('#messageInput').val().trim();
    if (!message || !currentBatch) return;
    
    Swal.fire({
        title: 'Sending...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });
    
    $.ajax({
        url: '../api/send-batch-message.php',
        type: 'POST',
        data: {
            batch: currentBatch,
            message: message
        },
        dataType: 'json',
        success: function(response) {
            Swal.close();
            if (response.success) {
                $('#messageInput').val('');
                // Append sent message immediately
                if (response.sent_message) {
                    appendMessage({
                        message: response.sent_message,
                        sent_at: response.timestamp || new Date().toISOString(),
                        sender_id: <?php echo $_SESSION['user_id']; ?>,
                        sender_name: '<?php echo $_SESSION['username']; ?>'
                    });
                }
                // Refresh recent chats
                loadRecentChats();
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            console.error('Batch message error:', xhr.responseText);
            const errorMsg = xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText || 'Failed to send message';
            Swal.fire('Error', errorMsg, 'error');
        }
    });
}

function sendGuideMessage() {
    const message = $('#messageInput').val().trim();
    if (!message || !currentGuide) return;
    
    Swal.fire({
        title: 'Sending...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });
    
    $.ajax({
        url: '../api/send-guide-message.php',
        type: 'POST',
        data: {
            guide_id: currentGuide,
            message: message
        },
        dataType: 'json',
        success: function(response) {
            Swal.close();
            if (response.success) {
                $('#messageInput').val('');
                // Append sent message immediately
                if (response.sent_message) {
                    appendMessage({
                        message: response.sent_message,
                        sent_at: response.timestamp || new Date().toISOString(),
                        sender_id: <?php echo $_SESSION['user_id']; ?>,
                        sender_name: '<?php echo $_SESSION['username']; ?>'
                    });
                }
                // Refresh recent chats
                loadRecentChats();
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            console.error('Guide message error:', xhr.responseText);
            const errorMsg = xhr.responseJSON ? xhr.responseJSON.message : xhr.responseText || 'Failed to send message';
            Swal.fire('Error', errorMsg, 'error');
        }
    });
}

// Load batch messages
function loadBatchMessages(batch) {
    $.ajax({
        url: '../api/get-batch-messages.php',
        type: 'GET',
        data: { batch: batch },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayMessages(response.messages);
            } else {
                $('#chatMessages').html('<p class="text-center text-danger">Error loading messages</p>');
            }
        },
        error: function() {
            $('#chatMessages').html('<p class="text-center text-danger">Failed to load messages</p>');
        }
    });
}

// Load guide messages
function loadGuideMessages(guideId) {
    $.ajax({
        url: '../api/get-guide-messages.php',
        type: 'GET',
        data: { guide_user_id: guideId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayMessages(response.messages);
            } else {
                $('#chatMessages').html('<p class="text-center text-danger">Error loading messages</p>');
            }
        },
        error: function() {
            $('#chatMessages').html('<p class="text-center text-danger">Failed to load messages</p>');
        }
    });
}

// Display messages in chat area
function displayMessages(messages) {
    const currentUserId = <?php echo $_SESSION['user_id']; ?>;
    
    // Clear any existing content
    $('#chatMessages').empty();
    
    if (messages.length === 0) {
        $('#chatMessages').html('<p class="text-center text-muted py-5">No messages yet. Start the conversation!</p>');
        return;
    }
    
    let html = '';
    messages.forEach(msg => {
        const isSent = msg.sender_id == currentUserId;
        const alignment = isSent ? 'text-right' : 'text-left';
        const bgColor = isSent ? 'bg-primary text-white' : 'bg-light';
        const timeStr = formatMessageTime(msg.sent_at);
        
        html += `
            <div class="mb-3 ${alignment}">
                <div class="d-inline-block ${bgColor} rounded px-3 py-2" style="max-width: 70%;">
                    <div><strong>${isSent ? 'You' : msg.sender_name}</strong></div>
                    <div>${escapeHtml(msg.message)}</div>
                    <small class="text-muted" style="font-size: 0.75rem;">${timeStr}</small>
                </div>
            </div>
        `;
    });
    
    $('#chatMessages').html(html);
    scrollChatToBottom();
}

// Append a single message
function appendMessage(msg) {
    // Clear placeholder text if it exists
    const chatContent = $('#chatMessages').html();
    if (chatContent.includes('No messages yet') || chatContent.includes('Loading messages') || chatContent.includes('Start the conversation')) {
        $('#chatMessages').empty();
    }
    
    const currentUserId = <?php echo $_SESSION['user_id']; ?>;
    const isSent = msg.sender_id == currentUserId;
    const alignment = isSent ? 'text-right' : 'text-left';
    const bgColor = isSent ? 'bg-primary text-white' : 'bg-light';
    const timeStr = formatMessageTime(msg.sent_at);
    
    const html = `
        <div class="mb-3 ${alignment}">
            <div class="d-inline-block ${bgColor} rounded px-3 py-2" style="max-width: 70%;">
                <div><strong>${isSent ? 'You' : msg.sender_name}</strong></div>
                <div>${escapeHtml(msg.message)}</div>
                <small class="text-muted" style="font-size: 0.75rem;">${timeStr}</small>
            </div>
        </div>
    `;
    
    $('#chatMessages').append(html);
    scrollChatToBottom();
}

// Format message timestamp
function formatMessageTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return diffMins + ' min ago';
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return diffHours + ' hour' + (diffHours > 1 ? 's' : '') + ' ago';
    
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

// Scroll chat to bottom
function scrollChatToBottom() {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}
</script>


    