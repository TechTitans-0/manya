<?php
require_once '../config/config.php';
requireRole('coordinator');

$pageTitle = "Manage Guides";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Guides</h1>
        <button class="btn btn-primary" data-toggle="modal" data-target="#uploadModal">
            <i class="fas fa-file-excel mr-2"></i> Upload Guide List
        </button>
    </div>

    <!-- Guides Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Guides</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="guidesTable" width="100%">
                    <thead>
                        <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Designation</th>
                                    <th>Research Domain</th>
                                    <th>Years Exp</th>
                                        <th>Branch</th>
                                    <th>Assigned Groups</th>
                                    <th>Batches Assigned</th>
                        </tr>
                    </thead>
                    <tbody id="guidesTableBody">
                        <tr>
                            <td colspan="8" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Edit Guide Modal -->
<div class="modal fade" id="editGuideModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Guide Information</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="editGuideForm">
                <input type="hidden" id="editGuideId" name="guide_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="editGuideName">Name *</label>
                        <input type="text" class="form-control" id="editGuideName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="editGuideEmail">Email *</label>
                        <input type="email" class="form-control" id="editGuideEmail" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="editGuideDepartment">Department</label>
                        <input type="text" class="form-control" id="editGuideDepartment" name="department">
                    </div>
                    <div class="form-group">
                        <label for="editGuideDomain">Domain/Specialization</label>
                        <input type="text" class="form-control" id="editGuideDomain" name="domain" 
                               placeholder="e.g., AI/ML, Web Development, IoT">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upload Guide List</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="uploadForm">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <strong>File Format:</strong> CSV file (.csv)<br>
                        <strong>Required Columns (any order, any names):</strong><br>
                        • Employee ID<br>
                        • Name<br>
                        • Designation<br>
                        • Research Domain Expertise<br>
                        • Years of Experience<br>
                        • Branch / Department<br>
                        • Phone Number<br>
                        • Email<br><br>
                        <strong>Example:</strong> EMP001, Dr. Jane Smith, Professor, AI/ML, 10, Computer Science, 9876543210, jane@example.com<br>
                        <small class="text-muted">Column names can be anything - the system will auto-detect them!</small>
                    </div>
                    <div class="form-group">
                        <label for="file">Select CSV File *</label>
                        <input type="file" class="form-control-file" id="file" name="file" 
                               accept=".csv" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    loadGuides();
    
    $('#uploadForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        console.log('Starting staff upload...');
        
        $.ajax({
            url: '../api/upload-guide-list.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            processData: false,
            contentType: false,
            timeout: 30000,
            beforeSend: function() {
                console.log('Sending staff upload request...');
                Swal.fire({
                    title: 'Uploading...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });
            },
            success: function(response) {
                console.log('Staff upload response:', response);
                console.log('Response type:', typeof response);
                Swal.close();
                
                // Check if response is HTML (means session expired/redirected to login)
                if (typeof response === 'string' && response.includes('<!DOCTYPE')) {
                    Swal.fire('Session Expired', 'Please login again', 'warning').then(() => {
                        window.location.href = '../login.php';
                    });
                    return;
                }
                
                if (response.success) {
                    $('#uploadModal').modal('hide');
                    $('#uploadForm')[0].reset();
                    Swal.fire('Success!', response.message, 'success');
                    loadGuides();
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.error('Staff upload error:', error);
                console.error('Status:', status);
                console.error('Response:', xhr.responseText);
                console.error('XHR status:', xhr.status);
                Swal.close();
                
                // Check if response is HTML (login page)
                if (xhr.responseText && xhr.responseText.includes('<!DOCTYPE')) {
                    Swal.fire('Session Expired', 'Please login again', 'warning').then(() => {
                        window.location.href = '../login.php';
                    });
                } else {
                    Swal.fire('Error!', 'Failed to upload file: ' + (xhr.responseText || error), 'error');
                }
            }
        });
    });
});

function loadGuides() {
    $.ajax({
        url: '../api/get-guides.php',
        type: 'GET',
        success: function(response) {
            // Destroy existing DataTable before rebuilding
            if ($.fn.DataTable.isDataTable('#guidesTable')) {
                $('#guidesTable').DataTable().destroy();
            }
            
            if (response.success) {
                let html = '';
                
                if (!response.guides || response.guides.length === 0) {
                    html = '<tr><td colspan="8" class="text-center">Upload the guide list to view guides</td></tr>';
                } else {
                    response.guides.forEach(guide => {
                        // Ensure all fields have default values to prevent undefined
                        const name = escapeHtml(guide.name || '');
                        const email = escapeHtml(guide.email || '');
                        const designation = escapeHtml(guide.designation || '');
                        const research_domain = escapeHtml(guide.research_domain_expertise || '');
                        const years_exp = escapeHtml(guide.years_of_experience ? String(guide.years_of_experience) : '');
                        const branch = escapeHtml(guide.branch || '');
                        const group_count = guide.group_count || 0;
                        const batches = guide.batches ? guide.batches.split(', ').map(b => `<span class="badge badge-primary mr-1">${escapeHtml(b)}</span>`).join('') : '<span class="text-muted">None</span>';
                        
                        const isCoordinator = (guide.auth_id === null && guide.guide_id === null);
                        const coordinatorBadge = isCoordinator ? ' <span class="badge badge-secondary ml-2">Coordinator</span>' : '';

                        if (guide.is_registered == 1 && guide.id) {
                            html += `
                                <tr>
                                    <td>${name}${coordinatorBadge}</td>
                                    <td>${email}</td>
                                    <td>${designation}</td>
                                    <td>${research_domain}</td>
                                    <td>${years_exp}</td>
                                    <td>${branch}</td>
                                    <td><span class="badge badge-info">${group_count}</span></td>
                                    <td>${batches}</td>
                                </tr>
                            `;
                        } else {
                            // Show authorized-but-unregistered guides so uploads appear immediately
                            html += `
                                <tr class="text-muted">
                                    <td>${name}${coordinatorBadge} <span class="badge badge-warning ml-2">Authorized</span></td>
                                    <td>${email}</td>
                                    <td>${designation}</td>
                                    <td>${research_domain}</td>
                                    <td>${years_exp}</td>
                                    <td>${branch}</td>
                                    <td><span class="badge badge-secondary">${group_count}</span></td>
                                    <td>${batches}</td>
                                </tr>
                            `;
                        }
                    });
                }
                
                $('#guidesTableBody').html(html);
                
                // Initialize DataTable after content is set
                $('#guidesTable').DataTable();
            }
        },
        error: function() {
            if ($.fn.DataTable.isDataTable('#guidesTable')) {
                $('#guidesTable').DataTable().destroy();
            }
            $('#guidesTableBody').html('<tr><td colspan="8" class="text-center text-danger">Failed to load guides</td></tr>');
        }
    });
}

function escapeHtml(text) {
    // Always convert input to string to avoid .replace errors
    text = (text === undefined || text === null) ? '' : String(text);
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"]'/g, m => map[m]);
}

function openEditGuideModal(id, name, email, department, domain) {
    $('#editGuideId').val(id);
    $('#editGuideName').val(name);
    $('#editGuideEmail').val(email);
    $('#editGuideDepartment').val(department);
    $('#editGuideDomain').val(domain);
    $('#editGuideModal').modal('show');
}

$('#editGuideForm').on('submit', function(e) {
    e.preventDefault();
    
    $.ajax({
        url: '../api/update-guide-info.php',
        type: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#editGuideModal').modal('hide');
                Swal.fire('Success!', response.message, 'success');
                loadGuides();
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Failed to update guide information', 'error');
        }
    });
});
</script>

