<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Manage Groups";

// Get selected academic year status for read-only mode
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? $_SESSION['academic_year_id'] : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
}

$academicYearStatus = 'ACTIVE';
if ($selectedAcademicYearId) {
    $yearStatusStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
    $yearStatusStmt->bind_param("i", $selectedAcademicYearId);
    $yearStatusStmt->execute();
    $yearStatusResult = $yearStatusStmt->get_result()->fetch_assoc();
    if ($yearStatusResult) {
        $academicYearStatus = $yearStatusResult['status'];
    }
    $yearStatusStmt->close();
}

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Groups</h1>
        <div>
            <?php if ($academicYearStatus !== 'COMPLETED'): ?>
            <button class="btn btn-success mr-2" onclick="openCreateGroupModal()">
                <i class="fas fa-plus mr-2"></i> Create Group/Batch
            </button>
            <button class="btn btn-primary mr-2" onclick="openAssignStudentsModal()">
                <i class="fas fa-user-plus mr-2"></i> Assign to Group/Batch
            </button>
            <button class="btn btn-warning" id="approveAllBtn">
                <i class="fas fa-check-double mr-2"></i> Approve All Grades
            </button>
            <?php else: ?>
            <span class="badge badge-warning"><i class="fas fa-lock"></i> Modifications disabled for COMPLETED year</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Groups Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Groups</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="groupsTable" width="100%">
                    <thead>
                        <tr>
                            <th>Team Lead Name</th>
                            <th>Project Title</th>
                            <th>Batch</th>
                            <th>Guide Assigned</th>
                            <th>Members</th>
                            <?php if ($_SESSION['project_type'] !== 'mini'): ?>
                            <th>Phase</th>
                            <?php endif; ?>
                            <th>Grade</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="groupsTableBody">
                        <tr>
                            <td colspan="8" class="text-center">Groups formed by students will be displayed here</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Assign Guide Modal -->
<div class="modal fade" id="assignGuideModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Assign Guide</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="assignGuideForm">
                <input type="hidden" id="groupId" name="group_id">
                <div class="modal-body">
                    <div class="alert alert-info" id="groupInfo"></div>
                    <div class="form-group">
                        <label for="guideSelect">Select Guide *</label>
                        <select class="form-control" id="guideSelect" name="guide_id" required>
                            <option value="">Loading...</option>
                        </select>
                        <small class="form-text text-muted">Guide information: Name - Domain (Current Groups)</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!--  Batch numbers are now auto-generated -->

<!-- View Group Details Modal -->
<div class="modal fade" id="viewGroupModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Group Details: <span id="viewModalGroupName"></span></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="viewGroupContent">
                    <div class="text-center py-4">
                        <i class="fas fa-spinner fa-spin fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create Group/Batch Modal -->
<div class="modal fade" id="createGroupModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create New Group</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="createGroupForm">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <strong>Create a new group:</strong> Select unassigned students below and provide group details. Batch will be auto-assigned.
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Team Lead Name *</label>
                                <input type="text" class="form-control" name="team_lead_name" required
                                       placeholder="Enter team lead name">
                                </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Project Title</label>
                        <input type="text" class="form-control" name="project_title" 
                               placeholder="Optional">
                    </div>
                    
                    <hr>
                    <h6>Select Students (Max 4) *</h6>
                    <div id="unassignedStudentsCreate" style="max-height: 300px; overflow-y: auto;">
                        <div class="text-center py-3">
                            <i class="fas fa-spinner fa-spin"></i> Loading unassigned students...
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Create Group</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Assign Students to Existing Group Modal -->
<div class="modal fade" id="assignStudentsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Assign Students to Existing Group</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="assignStudentsForm">
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <strong>Note:</strong> You can only assign students to batches with 3 or fewer members (max group size is 4).
                    </div>
                    
                    <h6>Step 1: Select Students *</h6>
                    <div id="unassignedStudentsAssign" style="max-height: 200px; overflow-y: auto; margin-bottom: 20px;">
                        <div class="text-center py-3">
                            <i class="fas fa-spinner fa-spin"></i> Loading unassigned students...
                        </div>
                    </div>
                    
                    <hr>
                    <h6>Step 2: Select Target Batch *</h6>
                    <div class="form-group">
                        <label>Select Batch (≤3 members)</label>
                        <select class="form-control" id="targetBatchSelect" name="target_batch" required>
                            <option value="">-- Select a batch --</option>
                        </select>
                        <small class="text-muted">Only batches with 3 or fewer members are shown (max group size is 4)</small>
                    </div>
                    
                    <div id="targetBatchInfo" class="alert alert-info" style="display: none;">
                        <!-- Batch info will be displayed here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Assign Students</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php include '../includes/evaluation_sheet_js.php'; ?>

<script>
// Project type flag for Mini/Major project handling
const isMiniProject = <?php echo json_encode($_SESSION['project_type'] === 'mini'); ?>;

// logged-in coordinator ID for display logic
let currentCoordinatorId = <?php echo isset($_SESSION['role_id']) ? (int)$_SESSION['role_id'] : 'null'; ?>;

$(document).ready(function() {
    loadGroups();
    loadGuidesForAssignment();
});

function loadGroups() {
    $.ajax({
        url: '../api/get-all-groups.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '';
                
                if (response.groups.length === 0) {
                    html = '<tr><td colspan="8" class="text-center">No groups found</td></tr>';
                } else {
                    response.groups.forEach(group => {
                        // Escape team lead name for onclick handlers
                        const escapedName = (group.team_lead_name || group.group_name).replace(/'/g, "\\'");
                        
                        // Batch is auto-generated when group is created
                        let batchDisplay = '<span class="badge badge-warning">Pending</span>';
                        if (group.batch) {
                            batchDisplay = `<span class="badge badge-success">${group.batch}${group.academic_year ? `(${group.academic_year})` : ''}</span>`;
                        }
                        
                        let guideDisplay = '<span class="text-muted">Not Assigned</span>';
                        let hasAssignedGuide = false;
                        if (group.guide_name) {
                            guideDisplay = `<span class="text-success"><i class="fas fa-check-circle"></i> ${group.guide_name}</span>`;
                            hasAssignedGuide = true;
                        } else if (group.coordinator_guide_id && group.coordinator_name) {
                            if (currentCoordinatorId && group.coordinator_guide_id == currentCoordinatorId) {
                                // logged-in coordinator is the guide, show simple name with same style as guide
                                guideDisplay = `<span class="text-success"><i class="fas fa-check-circle"></i> ${group.coordinator_name}</span>`;
                            } else {
                                guideDisplay = `<span class="text-success"><i class="fas fa-check-circle"></i> ${group.coordinator_name}</span>`;
                            }
                            hasAssignedGuide = true;
                        }
                        
                        // show 'Assign' when no guide/coordinator is assigned, otherwise show 'Reassign'
                        const guideButton = hasAssignedGuide
                            ? `<button class="btn btn-sm btn-warning" onclick="openAssignModal(${group.id}, '${escapedName}')">
                                    <i class="fas fa-sync"></i> Reassign
                                </button>`
                            : `<button class="btn btn-sm btn-primary" onclick="openAssignModal(${group.id}, '${escapedName}')">
                                    <i class="fas fa-user-plus"></i> Assign
                                </button>`;
                        
                        html += `
                            <tr>
                                <td>${group.team_lead_name || group.group_name}</td>
                                <td>${group.project_title || 'Not set'}</td>
                                <td>${batchDisplay}</td>
                                <td>${guideDisplay}</td>
                                <td><span class="badge badge-secondary">${group.member_count}</span></td>
                                ${!isMiniProject ? `<td><span class="badge badge-info">Phase ${group.current_phase}</span></td>` : ''}
                                <td>
                                    ${renderGradeActions(group)}
                                </td>
                                <td>
                                    ${guideButton}
                                    <button class="btn btn-sm btn-info" 
                                            onclick="viewGroupDetails(${group.id}, '${escapedName}')">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                </td>
                            </tr>
                        `;
                    });
                }
                
                $('#groupsTableBody').html(html);

                if ($.fn.DataTable.isDataTable('#groupsTable')) {
                    $('#groupsTable').DataTable().destroy();
                }
                $('#groupsTable').DataTable();
            }
        }
    });
}

function renderGradeActions(group) {
    const status = group.grade_status || 'none';
    
    // For Mini Projects, show single Download button instead of R1 and R2
    if (isMiniProject) {
        const downloadBtn = `<button class="btn btn-sm btn-success" onclick="downloadEvaluationSheetPDF({ group_id: ${group.id} })"><i class="fas fa-download"></i> Download</button>`;
        
        if (status === 'submitted') {
            return `${downloadBtn}`;
        }
        if (status === 'approved') {
            return `${downloadBtn} <span class="badge badge-success">Approved</span>`;
        }
        return `${downloadBtn} <span class="badge badge-secondary">No Grades</span>`;
    }
    
    // For Major Projects, show R1 and R2 buttons
    const downloadR1 = `<button class="btn btn-sm btn-success mr-1" onclick="downloadEvaluationSheetPDF({ group_id: ${group.id}, phase: ${group.current_phase || 1}, review: 1 })"><i class=\"fas fa-file-alt\"></i> R1</button>`;
    const downloadR2 = `<button class="btn btn-sm btn-success" onclick="downloadEvaluationSheetPDF({ group_id: ${group.id}, phase: ${group.current_phase || 1}, review: 2 })"><i class=\"fas fa-file-alt\"></i> R2</button>`;

    if (status === 'submitted') {
        // Grades submitted by guide, waiting for coordinator approval
        return `${downloadR1} ${downloadR2}`;
    }
    if (status === 'approved') {
        // Grades already approved and visible to students
        return `${downloadR1} ${downloadR2} <span class="badge badge-success">Approved</span>`;
    }
    // No grades available but allow download of blank/structure sheet
    return `${downloadR1} ${downloadR2} <span class="badge badge-secondary">No Grades</span>`;
}
// Approve All Grades for all groups (batches)
$(document).on('click', '#approveAllBtn', function() {
    Swal.fire({
        title: 'Approve all grades?',
        text: 'This will approve grades for all batches in all groups. Already approved batches will be skipped.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Approve All'
    }).then(result => {
        if (!result.isConfirmed) return;

        // Get all group IDs from the table (assume each row has group.id as data attribute or from loaded data)
        // We'll use the loaded response.groups from loadGroups
        $.ajax({
            url: '../api/get-all-groups.php',
            type: 'GET',
            success: function(response) {
                if (!response.success || !response.groups) {
                    Swal.fire('Error', 'Could not load groups', 'error');
                    return;
                }
                let groupIds = response.groups.map(g => g.id);
                approveAllGroups(groupIds);
            },
            error: function() {
                Swal.fire('Error', 'Failed to load groups', 'error');
            }
        });
    });
});

function approveAllGroups(groupIds) {
    if (!groupIds || groupIds.length === 0) {
        Swal.fire('Info', 'No groups found to approve.', 'info');
        return;
    }
    let approvedCount = 0;
    let failedCount = 0;
    let total = groupIds.length;
    let completed = 0;
    let errors = [];
    Swal.fire({
        title: 'Processing...',
        html: 'Approving grades for all groups...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });
    groupIds.forEach(groupId => {
        $.ajax({
            url: '../api/approve-all-grades.php',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ group_id: groupId }),
            success: function(res) {
                // Count this group as approved if any grades were approved
                if (res.success && res.approved_count && res.approved_count > 0) {
                    approvedCount += 1;
                } else if (!res.success) {
                    failedCount++;
                    errors.push('Group ' + groupId + ': ' + (res.message || 'Unexpected error'));
                }
            },
            error: function(xhr) {
                failedCount++;
                errors.push('Group ' + groupId + ': ' + (xhr.responseJSON?.error || 'Request failed'));
            },
            complete: function() {
                completed++;
                if (completed === total) {
                    Swal.close();
                    let msg = `${approvedCount} batch(es) approved.`;
                    if (failedCount > 0) msg += ` ${failedCount} group(s) failed.`;
                    if (errors.length > 0) msg += '<br>' + errors.join('<br>');
                    Swal.fire('Approve All Complete', msg, failedCount > 0 ? 'warning' : 'success');
                    loadGroups();
                }
            }
        });
    });
}

function viewGrades(groupId) {
    $.getJSON('../api/get-group-grades-coordinator.php', { group_id: groupId }, function(res) {
        if (!res.success) {
            Swal.fire('Error', res.message || 'Failed to load grades', 'error');
            return;
        }
        if (!res.grades || res.grades.length === 0) {
            Swal.fire('Info', 'No submitted grades available for this group. Approved grades are not shown here.', 'info');
            return;
        }

        const grades = res.grades;
        if (grades.length === 0) {
            Swal.fire('Info', 'No grades available for this group', 'info');
            return;
        }

        // Group by phase and review
        const grouped = {};
        grades.forEach(g => {
            const key = `Phase ${g.phase} - Review ${g.review}`;
            if (!grouped[key]) {
                grouped[key] = [];
            }
            grouped[key].push(g);
        });

        // Build cards for each phase/review
        let html = '<div style="max-height: 500px; overflow-y: auto;">';
        Object.keys(grouped).sort().forEach(key => {
                html += `<div class="card mb-3">
                        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                            <h6 class="mb-0">${key}</h6>
                            <div>
                                <button class="btn btn-sm btn-light mr-1" onclick="previewEvaluationSheet(${groupId}, ${grouped[key][0].grade.phase}, ${grouped[key][0].grade.review})">Preview Sheet</button>
                                <button class="btn btn-sm btn-light" onclick="downloadEvaluationSheetPDF({ group_id: ${groupId}, phase: ${grouped[key][0].grade.phase}, review: ${grouped[key][0].grade.review} })">Download Sheet</button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-sm table-bordered mb-0">
                                <thead>
                                    <tr>
                                        <th>USN</th>
                                        <th>Name</th>
                                        <th>Total Marks</th>
                                        <th>Max Marks</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>`;
            grouped[key].forEach(g => {
                let badge = g.status === 'approved'
                    ? '<span class="badge badge-success">Approved</span>'
                    : '<span class="badge badge-warning">Submitted</span>';
                html += `<tr>
                            <td>${g.usn}</td>
                            <td>${g.student_name}</td>
                            <td>${g.total_marks}</td>
                            <td>${g.max_marks}</td>
                            <td>${badge}</td>
                         </tr>`;
            });
            html += `       </tbody>
                            </table>
                        </div>
                    </div>`;
        });
        html += '</div>';

        Swal.fire({
            title: 'Group Grades',
            html: html,
            width: '80%',
            showCloseButton: true
        });
    });
}

function authorizeGrades(groupId) {
    Swal.fire({
        title: 'Authorize grades?',
        text: 'This will make grades visible to students.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Authorize'
    }).then(result => {
        if (!result.isConfirmed) return;
        $.post('../api/authorize-grades.php', { group_id: groupId }, function(res) {
            if (res.success) {
                Swal.fire('Authorized', res.message, 'success');
                loadGroups();
            } else {
                Swal.fire('Error', res.message || 'Failed to authorize', 'error');
            }
        }, 'json').fail(() => {
            Swal.fire('Error', 'Request failed', 'error');
        });
    });
}
function previewEvaluationSheet(groupId, phase, review) {
    $.ajax({
        url: '../api/download-evaluation-sheet.php',
        method: 'GET',
        data: { group_id: groupId, phase: phase, review: review },
        dataType: 'json',
        success: function(resp) {
            if (resp.success) {
                const w = window.open('', '', 'height=900,width=800');
                w.document.write(resp.html);
                w.document.close();
            } else {
                Swal.fire('Error', resp.message || 'Failed to load sheet', 'error');
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to load sheet', 'error');
        }
    });
}
function loadGuidesForAssignment() {
    $.ajax({
        url: '../api/get-guides.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '<option value="">Select Guide</option>';
                response.guides.forEach(guide => {
                    const domain = guide.domain || guide.department || 'General';
                    html += `<option value="${guide.id}">${guide.name} - ${domain} (${guide.group_count} groups assigned)</option>`;
                });

                // Add coordinator as guide option
                // Get coordinator info from session or AJAX
                // Get all registered coordinators and add to dropdown
                $.ajax({
                    url: '../api/get-all-coordinators.php',
                    type: 'GET',
                    success: function(coordResp) {
                        if (coordResp.success && coordResp.coordinators) {
                            coordResp.coordinators.forEach(coord => {
                                const domain = coord.department || 'General';
                                const desig = coord.designation ? `, ${coord.designation}` : '';
                                html += `<option value="coordinator_${coord.id}">${coord.username} (Coordinator${desig}) - ${domain}</option>`;
                            });
                        }
                        $('#guideSelect').html(html);
                    },
                    error: function() {
                        $('#guideSelect').html(html);
                    }
                });
            }
        }
    });
}

function viewGroupDetails(groupId, groupName) {
    $('#viewModalGroupName').text(groupName);
    $('#viewGroupModal').modal('show');
    
    $.ajax({
        url: '../api/get-group-details.php',
        method: 'GET',
        data: { group_id: groupId },
        dataType: 'json',
        success: function(response) {
            if (response.success) { 
                
                let html = `
                    <div class="mb-4">
                        <h6 class="text-primary">Group Information</h6>
                        <table class="table table-sm table-bordered">
                            <tr><th width="30%">Team Lead Name:</th><td>${response.group.team_lead_name || response.group.group_name}</td></tr>
                            <tr><th>Project Title:</th><td>${response.group.project_title || 'Not set'}</td></tr>
                            <tr><th>Batch:</th><td>${response.group.batch || 'Not assigned'}</td></tr>
                            <tr><th>Domain:</th><td>${response.group.domain || 'Not specified'}</td></tr>
                            <tr><th>Guide:</th><td>${response.group.guide_name ? response.group.guide_name : (response.group.coordinator_guide_id && response.group.coordinator_name ? response.group.coordinator_name : 'Not assigned')}</td></tr>
                            ${!isMiniProject ? `<tr><th>Phase:</th><td>Phase ${response.group.current_phase}</td></tr>` : ''}
                        </table>
                    </div>
                    <div>
                        <h6 class="text-primary">Team Members (${response.members.length})</h6>
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>USN</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                response.members.forEach(member => {
                    html += `
                        <tr>
                            <td>${member.name || member.username}</td>
                            <td>${member.usn}</td>
                            <td>${member.email}</td>
                            <td>${member.phone || 'N/A'}</td>
                            <td>${member.is_team_lead == 1 ? '<span class="badge badge-primary">Team Lead</span>' : 'Member'}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                `;
                
                $('#viewGroupContent').html(html);
            } else {
                $('#viewGroupContent').html('<div class="alert alert-danger">Failed to load group details</div>');
            }
        },
        error: function() {
            $('#viewGroupContent').html('<div class="alert alert-danger">Error loading group details</div>');
        }
    });

}
function openAssignModal(groupId, groupName) {
    $('#groupId').val(groupId);
    $('#groupInfo').html(`<strong>Group:</strong> ${groupName}`);

    // Get current assignment for this group
    $.ajax({
        url: '../api/get-group-details.php',
        type: 'GET',
        data: { group_id: groupId },
        success: function(response) {
            if (response.success) {
                let currentGuide = response.group.guide_id ? response.group.guide_id : null;
                let currentCoordinator = response.group.coordinator_guide_id ? response.group.coordinator_guide_id : null;
                loadGuidesForAssignment(currentGuide, currentCoordinator);
            } else {
                loadGuidesForAssignment();
            }
        },
        error: function() {
            loadGuidesForAssignment();
        }
    });
    $('#assignGuideModal').modal('show');
}

function loadGuidesForAssignment(currentGuideId, currentCoordinatorId) {
    $.ajax({
        url: '../api/get-guides.php',
        type: 'GET',
        success: function(response) {
            let html = '<option value="">Select Guide</option>';
            if (response.success && response.guides.length > 0) {
                response.guides.forEach(guide => {
                    // Display format: Name - Domain (X groups assigned)
                    const domain = guide.domain || guide.branch || 'General';
                    const groupCount = guide.group_count || 0;
                    
                    // Distinguish guides vs coordinators by is_authorized flag
                    // Guides have is_authorized = 1, Coordinators have is_authorized = 0
                    let displayText = `${guide.name} - ${domain} (${groupCount} groups)`;
                    let optionValue = guide.id;
                    
                    if (guide.is_authorized === 0) {
                        // This is a coordinator
                        optionValue = `coordinator_${guide.id}`;
                        displayText = `${guide.name} - ${domain} (${groupCount} groups)`;
                    }
                    
                    const selected = (
                        (currentGuideId && guide.id == currentGuideId && guide.is_authorized === 1) ||
                        (currentCoordinatorId && guide.id == currentCoordinatorId && guide.is_authorized === 0)
                    ) ? 'selected' : '';
                    
                    html += `<option value="${optionValue}" ${selected}>${displayText}</option>`;
                });
            }
            $('#guideSelect').html(html);
        },
        error: function() {
            $('#guideSelect').html('<option value="">Error loading guides</option>');
        }
    });
}

$('#assignGuideForm').on('submit', function(e) {
    e.preventDefault();
    
    $.ajax({
        url: '../api/assign-guide.php',
        type: 'POST',
        data: $(this).serialize(),
        success: function(response) {
            if (response.success) {
                $('#assignGuideModal').modal('hide');
                Swal.fire('Success!', response.message, 'success');
                loadGroups();
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        }
    });
});

// Create Group Modal Functions
function openCreateGroupModal() {
    $('#createGroupModal').modal('show');
    loadUnassignedStudentsForCreate();
}

function loadUnassignedStudentsForCreate() {
    $.ajax({
        url: '../api/get-unassigned-students.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '';
                if (response.students.length === 0) {
                    html = '<div class="alert alert-info">No unassigned students found.</div>';
                } else {
                    response.students.forEach(student => {
                        html += `
                            <div class="custom-control custom-checkbox mb-2">
                                <input type="checkbox" class="custom-control-input student-checkbox" 
                                       id="student_${student.id}" name="students[]" value="${student.id}"
                                       data-usn="${student.usn}" data-name="${student.name}">
                                <label class="custom-control-label" for="student_${student.id}">
                                    <strong>${student.usn}</strong> - ${student.name}
                                </label>
                            </div>
                        `;
                    });
                }
                $('#unassignedStudentsCreate').html(html);
                
                // Limit selection to 4
                $('.student-checkbox').on('change', function() {
                    if ($('.student-checkbox:checked').length > 4) {
                        this.checked = false;
                        Swal.fire('Limit Reached', 'You can only select up to 4 students per group', 'warning');
                    }
                });
            }
        }
    });
}

$('#createGroupForm').on('submit', function(e) {
    e.preventDefault();
    
    const selectedStudents = $('.student-checkbox:checked').length;
    if (selectedStudents === 0) {
        Swal.fire('Error', 'Please select at least one student', 'error');
        return;
    }
    
    const formData = $(this).serialize();
    
    $.ajax({
        url: '../api/create-group.php',
        type: 'POST',
        data: formData,
        success: function(response) {
            if (response.success) {
                $('#createGroupModal').modal('hide');
                $('#createGroupForm')[0].reset();
                const message = response.batch ? 
                    `Group created successfully with batch: ${response.batch}` : 
                    'Group created successfully';
                Swal.fire('Success!', message, 'success');
                loadGroups();
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        }
    });
});

// Assign Students to Existing Group Functions
function openAssignStudentsModal() {
    $('#assignStudentsModal').modal('show');
    loadUnassignedStudentsForAssign();
    loadAvailableBatches();
}

function loadUnassignedStudentsForAssign() {
    $.ajax({
        url: '../api/get-unassigned-students.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '';
                if (response.students.length === 0) {
                    html = '<div class="alert alert-info">No unassigned students found.</div>';
                } else {
                    response.students.forEach(student => {
                        html += `
                            <div class="custom-control custom-checkbox mb-2">
                                <input type="checkbox" class="custom-control-input assign-student-checkbox" 
                                       id="assign_student_${student.id}" name="student_ids[]" value="${student.id}">
                                <label class="custom-control-label" for="assign_student_${student.id}">
                                    <strong>${student.usn}</strong> - ${student.name}
                                </label>
                            </div>
                        `;
                    });
                }
                $('#unassignedStudentsAssign').html(html);
            }
        }
    });
}

function loadAvailableBatches() {
    $.ajax({
        url: '../api/get-available-batches.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let options = '<option value="">-- Select a batch --</option>';
                response.batches.forEach(batch => {
                    const spotsLeft = 4 - batch.member_count;
                    const displayName = batch.team_lead_name || batch.group_name;
                    options += `<option value="${batch.batch}" data-group-id="${batch.group_id}" data-members="${batch.member_count}">
                        ${batch.batch} - ${displayName} (${batch.member_count}/4 members, ${spotsLeft} spots left)
                    </option>`;
                });
                $('#targetBatchSelect').html(options);
            }
        }
    });
}

$('#targetBatchSelect').on('change', function() {
    const selected = $(this).find(':selected');
    const members = selected.data('members');
    const batch = selected.val();
    
    if (batch) {
        const spotsLeft = 4 - members;
        $('#targetBatchInfo').html(`
            <strong>Selected Batch:</strong> ${batch}<br>
            <strong>Current Members:</strong> ${members}/4<br>
            <strong>Available Spots:</strong> ${spotsLeft}
        `).show();
        
        // Update max selection based on spots left
        $('.assign-student-checkbox').off('change').on('change', function() {
            const selectedCount = $('.assign-student-checkbox:checked').length;
            if (selectedCount > spotsLeft) {
                this.checked = false;
                Swal.fire('Limit Reached', `This batch only has ${spotsLeft} spot(s) available`, 'warning');
            }
        });
    } else {
        $('#targetBatchInfo').hide();
    }
});

$('#assignStudentsForm').on('submit', function(e) {
    e.preventDefault();
    
    const selectedStudents = $('.assign-student-checkbox:checked').length;
    if (selectedStudents === 0) {
        Swal.fire('Error', 'Please select at least one student', 'error');
        return;
    }
    
    const targetBatch = $('#targetBatchSelect').val();
    if (!targetBatch) {
        Swal.fire('Error', 'Please select a target batch', 'error');
        return;
    }
    
    const formData = $(this).serialize();
    
    $.ajax({
        url: '../api/assign-students-to-batch.php',
        type: 'POST',
        data: formData,
        success: function(response) {
            if (response.success) {
                $('#assignStudentsModal').modal('hide');
                $('#assignStudentsForm')[0].reset();
                Swal.fire('Success!', response.message, 'success');
                loadGroups();
            } else {
                Swal.fire('Error!', response.message, 'error');
            }
        }
    });
});
</script>
