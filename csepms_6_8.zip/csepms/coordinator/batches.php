<?php
require_once '../config/config.php';
requireRole('coordinator');
ensureValidActiveYear(); // Auto-switch to ACTIVE year if deleted

$pageTitle = "Manage Batches";
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Batches</h1>
        <button class="btn btn-primary" data-toggle="modal" data-target="#createBatchModal">
            <i class="fas fa-plus mr-2"></i> Create New Batch
        </button>
    </div>

    <!-- Batches Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Batches</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="batchesTable" width="100%">
                    <thead>
                        <tr>
                            <th>Batch Name</th>
                            <th>Start Year</th>
                            <th>End Year</th>
                            <th>Students</th>
                            <th>Groups</th>
                            <th>Created Date</th>
                        </tr>
                    </thead>
                    <tbody id="batchesTableBody">
                        <tr>
                            <td colspan="6" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Create Batch Modal -->
<div class="modal fade" id="createBatchModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create New Batch</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form id="createBatchForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="batchName">Batch Name *</label>
                        <input type="text" class="form-control" id="batchName" name="batch_name" 
                               placeholder="e.g., 2020-2024" required>
                    </div>
                    <div class="form-group">
                        <label for="startYear">Start Year *</label>
                        <input type="number" class="form-control" id="startYear" name="start_year" 
                               min="2000" max="2100" required>
                    </div>
                    <div class="form-group">
                        <label for="endYear">End Year *</label>
                        <input type="number" class="form-control" id="endYear" name="end_year" 
                               min="2000" max="2100" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Batch</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    loadBatches();
    
    $('#createBatchForm').on('submit', function(e) {
        e.preventDefault();
        
        const startYear = parseInt($('#startYear').val());
        const endYear = parseInt($('#endYear').val());
        
        if (endYear <= startYear) {
            Swal.fire('Error', 'End year must be greater than start year', 'error');
            return;
        }
        
        $.ajax({
            url: '../api/create-batch.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#createBatchModal').modal('hide');
                    $('#createBatchForm')[0].reset();
                    Swal.fire('Success!', response.message, 'success');
                    loadBatches();
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            }
        });
    });
});

function loadBatches() {
    $.ajax({
        url: '../api/get-batches.php',
        type: 'GET',
        success: function(response) {
            if (response.success) {
                let html = '';
                
                if (response.batches.length === 0) {
                    html = '<tr><td colspan="6" class="text-center">No batches found</td></tr>';
                } else {
                    response.batches.forEach(batch => {
                        html += `
                            <tr>
                                <td>${batch.batch_name}${batch.academic_year ? ' (' + batch.academic_year + ')' : ''}</td>
                                <td>${batch.start_year}</td>
                                <td>${batch.end_year}</td>
                                <td>${batch.student_count}</td>
                                <td>${batch.group_count}</td>
                                <td>${new Date(batch.created_at).toLocaleDateString()}</td>
                            </tr>
                        `;
                    });
                }
                
                $('#batchesTableBody').html(html);
                
                if ($.fn.DataTable.isDataTable('#batchesTable')) {
                    $('#batchesTable').DataTable().destroy();
                }
                $('#batchesTable').DataTable();
            }
        }
    });
}
</script>

