<?php
// set-current-academic-year.php
require_once '../includes/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['academic_year'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing academic_year']);
    exit;
}

$year = $data['academic_year'];

// Update or insert the current academic year in global_settings
global $conn;
$stmt = $conn->prepare("INSERT INTO global_settings (setting_key, setting_value) VALUES ('current_academic_year', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
$stmt->bind_param('ss', $year, $year);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'current_academic_year' => $year]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>
