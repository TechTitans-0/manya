<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Get circular history sent by coordinator - filter by academic_year_id
$senderId = $_SESSION['user_id'];

// Fetch all notifications for this academic year that target students, guides or coordinators.
// This lets coordinators see circulars sent by other coordinators as well as those sent by themselves.
$query = "SELECT n.id, n.sender_id, u.username AS sender_name, n.title, n.message, n.attachment_path, n.target_type, n.target_value, n.created_at
                    FROM notifications n
                    LEFT JOIN users u ON u.id = n.sender_id
                    WHERE n.academic_year_id = ?
                        AND n.target_type IN ('all_students','all_guides','all_coordinators')
                    ORDER BY n.created_at DESC
                    LIMIT 1000";

$stmt = $conn->prepare($query);
$stmt->bind_param('i', $selectedAcademicYearId);
$stmt->execute();
$res = $stmt->get_result();
if (!$res) {
        sendJSON(['success' => false, 'message' => $conn->error]);
        exit;
}
$rows = $res->fetch_all(MYSQLI_ASSOC);

// Group notifications that belong to the same circular (same title, message, attachment, created_at)
$groups = [];
foreach ($rows as $r) {
    $key = md5(($r['title'] ?? '') . '||' . ($r['message'] ?? '') . '||' . ($r['attachment_path'] ?? '') . '||' . ($r['created_at'] ?? ''));
    if (!isset($groups[$key])) {
        $groups[$key] = [
            'ids' => [],
            'title' => $r['title'],
            'message' => $r['message'],
            'attachment_path' => $r['attachment_path'],
            'created_at' => $r['created_at'],
            'target_types' => [],
            'sender_id' => $r['sender_id'] ?? null,
            'sender_name' => $r['sender_name'] ?? null
        ];
    }
    $groups[$key]['ids'][] = $r['id'];
    $groups[$key]['target_types'][] = $r['target_type'];
}

$circulars = [];
foreach ($groups as $g) {
    $types = array_unique($g['target_types']);
    $label = '';
    $labels = [];
    if (in_array('all_students', $types)) $labels[] = 'Students';
    if (in_array('all_guides', $types)) $labels[] = 'Guides';
    if (in_array('all_coordinators', $types)) $labels[] = 'Coordinators';

    // If Students + Guides are present treat as 'All' (covers older entries that may lack coordinator record).
    if (in_array('Students', $labels) && in_array('Guides', $labels)) {
        $label = 'All';
    } else if (count($labels) === 3) {
        $label = 'All';
    } else {
        $label = implode(', ', $labels);
    }

    $circulars[] = [
        'id' => $g['ids'][0],
        'ids' => $g['ids'],
        'title' => $g['title'],
        'message' => $g['message'],
        'attachment_path' => $g['attachment_path'],
        'created_at' => $g['created_at'],
        'target_label' => $label,
        'target_types' => $types,
        'sender_id' => $g['sender_id'],
        'sender_name' => $g['sender_name']
    ];
}

sendJSON(['success' => true, 'circulars' => $circulars]);
?>
