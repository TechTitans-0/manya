<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$isMiniProject = (getCurrentProjectType() === 'mini');

$sheet_id = intval($_POST['sheet_id'] ?? 0);
$phase = intval($_POST['phase'] ?? 0);
$review_type = intval($_POST['review_type'] ?? 0);
$criteria = json_decode($_POST['criteria'] ?? '[]', true);

// For mini projects, force phase=1 and review=1
if ($isMiniProject) {
    $phase = 1;
    $review_type = 1;
}

if (!$phase || !$review_type) {
    sendJSON(['success' => false, 'message' => 'Phase and review are required']);
}

if (empty($criteria)) {
    sendJSON(['success' => false, 'message' => 'At least one criterion is required']);
}

try {
    $conn->begin_transaction();
    
    // Update evaluation sheet (title is intentionally left empty)
    $stmt = $conn->prepare("UPDATE evaluation_sheets SET phase = ?, review = ? WHERE id = ?");
    $stmt->bind_param("iii", $phase, $review_type, $sheet_id);
    $stmt->execute();
    $stmt->close();
    
    // Delete existing criteria
    $stmt = $conn->prepare("DELETE FROM evaluation_criteria WHERE evaluation_sheet_id = ?");
    $stmt->bind_param("i", $sheet_id);
    $stmt->execute();
    $stmt->close();
    
    // Insert updated criteria
    $stmt = $conn->prepare("INSERT INTO evaluation_criteria (evaluation_sheet_id, criterion_name, max_marks, display_order) VALUES (?, ?, ?, ?)");
    
    $display_order = 1;
    foreach ($criteria as $criterion) {
        $criterion_name = trim($criterion['name']);
        $max_marks = intval($criterion['marks']);
        
        if (empty($criterion_name) || $max_marks <= 0) {
            throw new Exception('Invalid criterion data');
        }
        
        $stmt->bind_param("isii", $sheet_id, $criterion_name, $max_marks, $display_order);
        $stmt->execute();
        $display_order++;
    }
    $stmt->close();
    
    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Evaluation sheet updated successfully']);
    
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
