<?php
require_once '../config/config.php';
requireRoleAPI('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Fetch active academic year - required for all inserts
$activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
if (!$activeYear) {
    sendJSON(['success' => false, 'message' => 'No active academic year configured'], 400);
}
$academicYearId = intval($activeYear['id']);

// Only team lead may upload
if (!isset($_SESSION['group_id']) || !$_SESSION['group_id']) {
    sendJSON(['success' => false, 'message' => 'You are not part of any group']);
}

if (empty($_SESSION['is_team_lead'])) {
    sendJSON(['success' => false, 'message' => 'Only the team lead can upload files'], 403);
}

$phase = intval($_POST['phase'] ?? 0);
$review = intval($_POST['review'] ?? 0);

// For Mini Projects: Use default phase/review values; For Major Projects: Validate them
if ($_SESSION['project_type'] === 'mini') {
    // For mini projects, set default values (phase and review not applicable)
    $phase = 0;
    $review = 0;
} else {
    // For major projects: Accept review 0 (Review 0) and final review code 99; phase must be >=1
    if ($phase < 1 || $review < 0) {
        sendJSON(['success' => false, 'message' => 'Invalid phase or review']);
    }
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    sendJSON(['success' => false, 'message' => 'No file uploaded or upload error']);
}

$file = $_FILES['file'];
$allowedTypes = ['application/pdf', 'application/msword', 
                 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                 'application/vnd.ms-powerpoint',
                 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mimeType, $allowedTypes)) {
    sendJSON(['success' => false, 'message' => 'Invalid file type. Only PDF, DOC, DOCX, PPT, PPTX allowed']);
}

if ($file['size'] > MAX_FILE_SIZE) {
    sendJSON(['success' => false, 'message' => 'File too large. Maximum size is 10MB']);
}

try {
    $conn->begin_transaction();

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    if ($_SESSION['project_type'] === 'mini') {
        $filename = 'group_' . $_SESSION['group_id'] . '_' . time() . '.' . $extension;
    } else {
        $filename = 'group_' . $_SESSION['group_id'] . '_phase' . $phase . '_review' . $review . '_' . time() . '.' . $extension;
    }
    $uploadPath = UPLOAD_PATH . 'project_files/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        throw new Exception('Failed to move uploaded file');
    }

    // Fetch batch and project_title from pgroups table
    $batch = null;
    $project_title = null;
    $group_id = $_SESSION['group_id'];
    $groupQuery = $conn->prepare("SELECT batch, project_title FROM pgroups WHERE id = ?");
    $groupQuery->bind_param("i", $group_id);
    $groupQuery->execute();
    $groupQuery->bind_result($batch, $project_title);
    if (!$groupQuery->fetch()) {
        throw new Exception('Group not found');
    }
    $groupQuery->close();

    // Save to database with project_title
    $filePath = 'uploads/project_files/' . $filename;

    if ($_SESSION['project_type'] === 'mini') {
        $query = "INSERT INTO project_uploads (group_id, filename, file_path, file_type, project_title, uploaded_by, academic_year_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("isssssi", $group_id, $file['name'], $filePath, $mimeType, $project_title, $_SESSION['role_id'], $academicYearId);
    } else {
        $query = "INSERT INTO project_uploads (group_id, phase, review, filename, file_path, file_type, project_title, uploaded_by, academic_year_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iiissssii", $group_id, $phase, $review, $file['name'], $filePath, $mimeType, $project_title, $_SESSION['role_id'], $academicYearId);
    }

    if (!$stmt->execute()) {
        unlink($uploadPath);
        throw new Exception('Failed to save file record');
    }

    $conn->commit();

    sendJSON([
        'success' => true,
        'message' => 'File uploaded successfully',
        'file_id' => $conn->insert_id
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    if (isset($uploadPath) && file_exists($uploadPath)) {
        unlink($uploadPath);
    }
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
