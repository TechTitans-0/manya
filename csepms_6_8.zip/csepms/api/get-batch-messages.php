<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if (!isset($_GET['batch'])) {
    sendJSON(['success' => false, 'message' => 'Batch parameter required']);
}

$batch = trim($_GET['batch']);
$coordinator_id = $_SESSION['user_id'];

try {
    // Get all students in this batch
    $stmt = $conn->prepare("
        SELECT DISTINCT s.user_id 
        FROM students s 
        INNER JOIN pgroups g ON s.group_id = g.id 
        WHERE g.batch = ?
    ");
    $stmt->bind_param("s", $batch);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $student_ids = [];
    while ($row = $result->fetch_assoc()) {
        $student_ids[] = $row['user_id'];
    }
    $stmt->close();
    
    if (empty($student_ids)) {
        sendJSON(['success' => true, 'messages' => []]);
    }
    
    // Get all messages between coordinator and these students (group to avoid duplicates)
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
        $query = "SELECT 
                                cm.id,
                                cm.sender_id,
                                cm.receiver_id,
                                cm.message,
                                cm.sent_at,
                                u.username as sender_name
                            FROM chat_messages cm
              INNER JOIN users u ON cm.sender_id = u.id
              WHERE (cm.sender_id = ? AND cm.receiver_id IN ($placeholders))
                 OR (cm.sender_id IN ($placeholders) AND cm.receiver_id = ?)
              GROUP BY cm.message, cm.sent_at, cm.sender_id
              ORDER BY cm.sent_at ASC";
    
    $stmt = $conn->prepare($query);
    
    // Bind parameters
    $params = array_merge([$coordinator_id], $student_ids, $student_ids, [$coordinator_id]);
    $types = str_repeat('i', count($params));
    $stmt->bind_param($types, ...$params);
    
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    sendJSON(['success' => true, 'messages' => $messages]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
