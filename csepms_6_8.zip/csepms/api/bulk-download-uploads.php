<?php
// Suppress all output and errors to prevent ZIP corruption
ob_clean();
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once '../config/config.php';
requireRole('coordinator');

$tmpZip = tempnam(sys_get_temp_dir(), 'uploads_') . '.zip';
$zip = new ZipArchive();
if ($zip->open($tmpZip, ZipArchive::CREATE) !== TRUE) {
    http_response_code(500);
    error_log('Could not create ZIP file: ' . $tmpZip);
    exit;
}

// Query all approved uploads along with their group info (batch, project title, academic year)
$sql = "SELECT pu.id, pu.filename, pu.file_path, g.project_title, g.batch, ay.year_label as academic_year
        FROM project_uploads pu
        JOIN pgroups g ON pu.group_id = g.id
        LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
        WHERE pu.status = 'approved'";
$res = $conn->query($sql);
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $file = '../' . $row['file_path'];
        if (file_exists($file)) {
            // Organize in ZIP: Batch/ProjectTitle/filename
            $safeBatch = preg_replace('/[^a-zA-Z0-9_-]/', '_', $row['batch']);
            $safeProject = preg_replace('/[^a-zA-Z0-9_-]/', '_', $row['project_title']);
            $safeYear = preg_replace('/[^a-zA-Z0-9_-]/', '_', $row['academic_year']);

            $zipPath = $safeBatch
                     . ($safeYear ? "($safeYear)" : '')
                     . '-' . $safeProject . '/' . basename($row['filename']);
            $zip->addFile($file, $zipPath);
        }
    }
}
$zip->close();

// Set headers for download (after ZIP is ready)
if (file_exists($tmpZip)) {
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="approved_uploads_' . date('Ymd_His') . '.zip"');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Content-Length: ' . filesize($tmpZip));
    flush();
    readfile($tmpZip);
    @unlink($tmpZip);
    exit;
} else {
    http_response_code(500);
    error_log('ZIP file missing after creation: ' . $tmpZip);
    exit;
}
