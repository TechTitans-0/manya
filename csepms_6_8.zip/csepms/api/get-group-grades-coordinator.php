<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$groupId = intval($_GET['group_id'] ?? 0);
$evaluationSheetId = isset($_GET['evaluation_sheet_id']) ? intval($_GET['evaluation_sheet_id']) : 0;

if (!$groupId) {
    sendJSON(['success' => false, 'message' => 'Group ID is required']);
}

// Get all grades for this group with student details (no guide restriction)

$query = "SELECT sg.*, 
          s.usn, u.username, s.name,
          es.phase, es.review, es.title as sheet_title,
          sgd.criterion_id, sgd.marks_obtained,
          ec.criterion_name, ec.max_marks
          FROM student_grades sg
          INNER JOIN students s ON sg.student_id = s.id
          INNER JOIN users u ON s.user_id = u.id
          INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
          LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
          LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
          WHERE sg.group_id = ? AND sg.status IN ('submitted', 'approved')";

if ($evaluationSheetId) {
    $query .= " AND sg.evaluation_sheet_id = ?";
}

$query .= " ORDER BY es.phase DESC, es.review DESC, s.usn ASC, ec.id ASC";

$stmt = $conn->prepare($query);
if (!$stmt) {
    sendJSON(['success' => false, 'message' => 'Database prepare error: ' . $conn->error]);
}

if ($evaluationSheetId) {
    $stmt->bind_param("ii", $groupId, $evaluationSheetId);
} else {
    $stmt->bind_param("i", $groupId);
}

if (!$stmt->execute()) {
    sendJSON(['success' => false, 'message' => 'Database execute error: ' . $stmt->error]);
}

$result = $stmt->get_result();
$grades = [];
$currentGradeId = null;
$currentGrade = null;

while ($row = $result->fetch_assoc()) {
    $gradeId = $row['id'];
    if ($currentGradeId !== $gradeId) {
        if ($currentGrade !== null) {
            $grades[] = $currentGrade;
        }
        $currentGradeId = $gradeId;
        $currentGrade = [
            'id' => $row['id'],
            'evaluation_sheet_id' => intval($row['evaluation_sheet_id']),
            'student_id' => $row['student_id'],
            'usn' => $row['usn'],
            'student_name' => $row['name'] ?: $row['username'],
            'phase' => $row['phase'],
            'review' => $row['review'],
            'sheet_title' => $row['sheet_title'],
            'total_marks' => floatval($row['total_marks']),
            'max_marks' => floatval($row['max_marks']),
            'percentage' => $row['max_marks'] > 0 ? round((floatval($row['total_marks']) / floatval($row['max_marks'])) * 100, 2) : 0,
            'status' => $row['status'],
            'graded_at' => $row['graded_at'],
            'criteria' => []
        ];
    }
    if ($row['criterion_id']) {
        $currentGrade['criteria'][] = [
            'criterion_id' => intval($row['criterion_id']),
            'criterion_name' => $row['criterion_name'],
            'max_marks' => floatval($row['max_marks']),
            'marks_obtained' => floatval($row['marks_obtained'])
        ];
    }
}

if ($currentGrade !== null) {
    $grades[] = $currentGrade;
}

sendJSON(['success' => true, 'grades' => $grades]);
?>
