<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

$userId = $_SESSION['user_id'];

$update = "UPDATE chat_messages SET is_read = 1 WHERE receiver_id = ? AND is_read = 0";
$stmt = $conn->prepare($update);
$stmt->bind_param('i', $userId);
$stmt->execute();

sendJSON(['success' => true, 'updated' => $stmt->affected_rows]);
?>
