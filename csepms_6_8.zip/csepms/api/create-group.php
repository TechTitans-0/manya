<?php
require_once '../config/config.php';
requireLogin();
// Prevent students from mutating data when their academic year is completed
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Fetch active academic year - required for all inserts
$activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
if (!$activeYear) {
    sendJSON(['success' => false, 'message' => 'No active academic year configured'], 400);
}
$academicYearId = intval($activeYear['id']);

// Coordinator flow: create group with selected student IDs. Student flow: team-lead based creation.
$members = $_POST['students'] ?? null; // coordinator: array of student ids

if (hasRole('coordinator')) {
    $teamLeadName = sanitizeInput($_POST['team_lead_name'] ?? '');
    $batch = sanitizeInput($_POST['batch'] ?? '');
    $projectTitle = sanitizeInput($_POST['project_title'] ?? '');
    // students should be an array of ids
    if (empty($members) || !is_array($members)) {
        sendJSON(['success' => false, 'message' => 'Please select at least one student']);
    }
    // normalize to integers
    $studentIds = array_map('intval', $members);
    if (count($studentIds) < 1) {
        sendJSON(['success' => false, 'message' => 'Please select at least one student']);
    }
    if (count($studentIds) > 4) {
        sendJSON(['success' => false, 'message' => 'Maximum 4 students allowed per group']);
    }
    
    if (empty($teamLeadName)) {
        sendJSON(['success' => false, 'message' => 'Team Lead Name is required']);
    }
} else {
    // Student-created group (existing behavior)
    $teamLeadName = sanitizeInput($_POST['team_lead_name'] ?? '');
    $teamLeadUSN = strtoupper(sanitizeInput($_POST['team_lead_usn'] ?? ''));

    $projectTitle = sanitizeInput($_POST['project_title'] ?? '');
    $projectDomain = sanitizeInput($_POST['project_domain'] ?? '');
    $customDomain = sanitizeInput($_POST['custom_domain'] ?? '');
    $projectDescription = sanitizeInput($_POST['project_description'] ?? '');
    $groupSize = intval($_POST['group_size'] ?? 0);
    $members = json_decode($_POST['members'] ?? '[]', true);

    // Require team lead name, USN, group size, members, and domain for initial group creation
    if (empty($teamLeadName) || empty($teamLeadUSN) || $groupSize < 1 || empty($projectDomain)) {
        sendJSON(['success' => false, 'message' => 'All fields are required']);
    }
    
    // If "Any others" domain is selected, require custom domain input
    if ($projectDomain === 'Any others' && empty($customDomain)) {
        sendJSON(['success' => false, 'message' => 'Please specify the custom domain']);
    }
    
    // Student-specific validations:
    // Check if current student is already in a group (treat 0 and NULL as "no group")
    $checkQuery = "SELECT group_id FROM students WHERE id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("i", $_SESSION['role_id']);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    if ($result && !empty($result['group_id'])) {
        sendJSON(['success' => false, 'message' => 'You are already part of a group']);
    }

    // Validate that team lead USN matches current user
    $studentQuery = "SELECT usn FROM students WHERE id = ?";
    $stmt = $conn->prepare($studentQuery);
    $stmt->bind_param("i", $_SESSION['role_id']);
    $stmt->execute();
    $studentData = $stmt->get_result()->fetch_assoc();
    if (strtoupper($studentData['usn']) !== $teamLeadUSN) {
        sendJSON(['success' => false, 'message' => 'Team Lead USN must match your registered USN']);
    }

    // Check for duplicate USNs in members and validate their existence
    $allUSNs = [$teamLeadUSN];
    if (is_array($members)) {
        foreach ($members as $member) {
            $usn = strtoupper(trim($member['usn'] ?? ''));
            if (in_array($usn, $allUSNs)) {
                sendJSON(['success' => false, 'message' => 'Duplicate USN found: ' . $usn]);
            }
            $allUSNs[] = $usn;
        }
    }

    // Validate that all member USNs exist and are not in groups
    foreach ($members as $member) {
        $usn = strtoupper(trim($member['usn'] ?? ''));
        if ($usn) {
            $checkMemberQuery = "SELECT id, group_id FROM students WHERE UPPER(usn) = ?";
            $stmt = $conn->prepare($checkMemberQuery);
            $stmt->bind_param("s", $usn);
            $stmt->execute();
            $memberResult = $stmt->get_result()->fetch_assoc();
            if (!$memberResult) {
                sendJSON(['success' => false, 'message' => 'Student with USN ' . $usn . ' not found in the system']);
            }
            if ($memberResult['group_id']) {
                sendJSON(['success' => false, 'message' => 'Student with USN ' . $usn . ' is already in a group']);
            }
        }
    }
}

try {
    $conn->begin_transaction();
    
    /**
     * Generate next batch number with row locking to prevent race conditions
     * Uses SELECT FOR UPDATE to ensure concurrent safety
     * @return string The next batch number (e.g., B1, B2, B3...)
     */
    function generateNextBatchNumber($conn, $academicYearId) {
        // Find the highest batch number for the given academic year with row-level locking
        $batchQuery = "SELECT batch FROM pgroups
                       WHERE academic_year_id = ? AND batch REGEXP '^B[0-9]+$'
                       ORDER BY CAST(SUBSTRING(batch, 2) AS UNSIGNED) DESC
                       LIMIT 1
                       FOR UPDATE";

        $stmt = $conn->prepare($batchQuery);
        if (!$stmt) {
            error_log("Batch generation failed: " . $conn->error);
            throw new Exception("Failed to prepare batch query: " . $conn->error);
        }

        $stmt->bind_param('i', $academicYearId);
        $stmt->execute();
        $result = $stmt->get_result();

        $nextNumber = 1;
        if ($result && $result->num_rows > 0) {
            $lastBatch = $result->fetch_assoc()['batch'];
            // Extract number from batch name (e.g., B5 -> 5)
            $number = intval(substr($lastBatch, 1));
            $nextNumber = $number + 1;
        }

        $batchNumber = 'B' . $nextNumber;
        error_log("Generated batch number for AY $academicYearId: " . $batchNumber);
        return $batchNumber;
    }
    
    // Generate batch number for both coordinator AND student flows
    // Generate next batch number scoped to the selected academic year
    $autoBatch = generateNextBatchNumber($conn, $academicYearId);
    // Attach academic year label to batch where possible (returned to client)
    $ayRes = $conn->prepare("SELECT year_label FROM academic_years WHERE id = ? LIMIT 1");
    $ayRes->bind_param('i', $academicYearId);
    $ayRes->execute();
    $ayData = $ayRes->get_result()->fetch_assoc();
    $ayLabel = $ayData ? formatAcademicYear($ayData['year_label']) : null;
    error_log("Auto-batch assigned: " . $autoBatch);
    
    
    
    if (hasRole('coordinator')) {
        // Coordinator flow: create group with selected student IDs
        
        $insertGroup = "INSERT INTO pgroups (group_name, batch, project_title, academic_year_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertGroup);
        $stmt->bind_param("sssi", $teamLeadName, $autoBatch, $projectTitle, $academicYearId);
        if (!$stmt->execute()) {
            throw new Exception('Failed to create group');
        }
        $groupId = $conn->insert_id;

        // Assign selected students to this group; first student becomes team lead
        $first = true;
        $updateStudent = $conn->prepare("UPDATE students SET group_id = ?, is_team_lead = ? WHERE id = ? AND (group_id IS NULL OR group_id = 0)");
        foreach ($studentIds as $sid) {
            // verify student exists and not already in a group
            $chk = $conn->prepare("SELECT id, group_id FROM students WHERE id = ?");
            $chk->bind_param('i', $sid);
            $chk->execute();
            $cres = $chk->get_result()->fetch_assoc();
            if (!$cres) {
                throw new Exception('Student id ' . $sid . ' not found');
            }
            if ($cres['group_id']) {
                throw new Exception('Student id ' . $sid . ' is already in a group');
            }
            $isLead = $first ? 1 : 0;
            $updateStudent->bind_param('iii', $groupId, $isLead, $sid);
            $updateStudent->execute();
            $first = false;
        }
    } else {
        // Student flow: create group with auto-generated batch
        // Create group with team lead name as group name
        $groupName = $teamLeadName . "'s Group";
        error_log("Student creating group: $groupName with batch: $autoBatch");
        
        // Handle domain: if "Any others" is selected, use custom domain
        $finalDomain = ($projectDomain === 'Any others' && $customDomain) ? $customDomain : $projectDomain;
        
        $insertGroup = "INSERT INTO pgroups (group_name, batch, domain, academic_year_id) 
                        VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertGroup);
        if (!$stmt) {
            error_log("Failed to prepare insert: " . $conn->error);
            throw new Exception("Failed to prepare group insert: " . $conn->error);
        }
        
        $stmt->bind_param("sssi", $groupName, $autoBatch, $finalDomain, $academicYearId);
        
        if (!$stmt->execute()) {
            error_log("Failed to execute insert: " . $stmt->error);
            throw new Exception('Failed to create group: ' . $stmt->error);
        }
        
        $groupId = $conn->insert_id;
        error_log("Group created with ID: $groupId and batch: $autoBatch");
        
        // Update team lead name in students table
        $updateLeadName = "UPDATE students SET name = ? WHERE id = ?";
        $stmt = $conn->prepare($updateLeadName);
        $stmt->bind_param("si", $teamLeadName, $_SESSION['role_id']);
        $stmt->execute();
        
        // Add team lead to group
        $updateStudent = "UPDATE students SET group_id = ?, is_team_lead = 1 WHERE id = ?";
        $stmt = $conn->prepare($updateStudent);
        $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
        $stmt->execute();
        
        // Add other members by USN and update their names
        if (!empty($members) && is_array($members)) {
            // Treat both NULL and 0 as "no group" (same as validation above)
            $updateMembers = "UPDATE students SET group_id = ?, name = ? WHERE UPPER(usn) = ? AND (group_id IS NULL OR group_id = 0)";
            $stmt = $conn->prepare($updateMembers);
            
            foreach ($members as $member) {
                $usn = strtoupper(trim($member['usn'] ?? ''));
                $name = trim($member['name'] ?? '');
                if ($usn && $name) {
                    $stmt->bind_param("iss", $groupId, $name, $usn);
                    $stmt->execute();
                }
            }
        }
    }
    
    $conn->commit();
    
    // Update session
    $_SESSION['group_id'] = $groupId;
    $_SESSION['is_team_lead'] = 1;
    
    // Return success with batch number and academic year label for both flows
    $response = [
        'success' => true,
        'message' => "Group created successfully with batch: $autoBatch",
        'group_id' => $groupId,
        'batch' => $autoBatch,
        'academic_year_label' => $ayLabel
    ];
    
    sendJSON($response);
    
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
