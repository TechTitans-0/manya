<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$batchName = sanitizeInput($_POST['batch_name'] ?? '');
$startYear = intval($_POST['start_year'] ?? 0);
$endYear = intval($_POST['end_year'] ?? 0);

if (empty($batchName) || !$startYear || !$endYear) {
    sendJSON(['success' => false, 'message' => 'All fields are required']);
}

if ($endYear <= $startYear) {
    sendJSON(['success' => false, 'message' => 'End year must be greater than start year']);
}

try {
    // Check if batch already exists
    $checkQuery = "SELECT id FROM batches WHERE batch_name = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $batchName);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        throw new Exception('Batch already exists');
    }
    
    // Create batch
    $insertQuery = "INSERT INTO batches (batch_name, start_year, end_year)
                    VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("sii", $batchName, $startYear, $endYear);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to create batch');
    }
    
    sendJSON(['success' => true, 'message' => 'Batch created successfully', 'batch_id' => $conn->insert_id]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
