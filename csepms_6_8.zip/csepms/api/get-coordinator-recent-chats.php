<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$coordinator_id = $_SESSION['user_id'];

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

try {
    // Get recent chats with both guides and batches
    $recentChats = [];
    
    // 1. Get recent chats with individual guides (filter by academic year)
    $stmt = $conn->prepare("
        SELECT 
            cm.receiver_id as user_id,
            cm.receiver_id as guide_user_id,
            'guide' as chat_type,
            u.username as recipient_name,
            ag.name as full_name,
            ag.research_domain_expertise as domain,
            cm.message as last_message,
            cm.sent_at as last_message_time,
            cm.sender_id,
            COUNT(CASE WHEN cm.is_read = 0 AND cm.receiver_id = ? THEN 1 END) as unread_count
        FROM chat_messages cm
        INNER JOIN users u ON cm.receiver_id = u.id
        LEFT JOIN guides g ON u.id = g.user_id
        LEFT JOIN authorized_guides ag ON g.employee_id = ag.employee_id
        WHERE (cm.sender_id = ? AND u.role = 'guide')
           AND cm.academic_year_id = ?
           AND cm.deleted_at IS NULL
        GROUP BY cm.receiver_id
        
        UNION
        
        SELECT 
            cm.sender_id as user_id,
            cm.sender_id as guide_user_id,
            'guide' as chat_type,
            u.username as recipient_name,
            ag.name as full_name,
            ag.research_domain_expertise as domain,
            cm.message as last_message,
            cm.sent_at as last_message_time,
            cm.sender_id,
            COUNT(CASE WHEN cm.is_read = 0 AND cm.receiver_id = ? THEN 1 END) as unread_count
        FROM chat_messages cm
        INNER JOIN users u ON cm.sender_id = u.id
        LEFT JOIN guides g ON u.id = g.user_id
        LEFT JOIN authorized_guides ag ON g.employee_id = ag.employee_id
        WHERE (cm.receiver_id = ? AND u.role = 'guide')
           AND cm.academic_year_id = ?
           AND cm.deleted_at IS NULL
        GROUP BY cm.sender_id
    ");
    
    // bind params for both sections of the UNION (six ? placeholders)
    $stmt->bind_param("iiiiii", $coordinator_id, $coordinator_id, $selectedAcademicYearId, $coordinator_id, $coordinator_id, $selectedAcademicYearId);
    $stmt->execute();
    $guideChats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Process guide chats
    $processedGuides = [];
    foreach ($guideChats as $chat) {
        $guideId = $chat['user_id'];
        
        if (!isset($processedGuides[$guideId])) {
            $processedGuides[$guideId] = $chat;
            $processedGuides[$guideId]['unread_count'] = 0;
        }
        
        // Get the actual unread count
        $stmt = $conn->prepare("
            SELECT COUNT(*) as unread 
            FROM chat_messages 
            WHERE sender_id = ? 
              AND receiver_id = ? 
              AND is_read = 0 
              AND academic_year_id = ?
              AND deleted_at IS NULL
        ");
        $stmt->bind_param("iii", $guideId, $coordinator_id, $selectedAcademicYearId);
        $stmt->execute();
        $unreadResult = $stmt->get_result()->fetch_assoc();
        $processedGuides[$guideId]['unread_count'] = intval($unreadResult['unread']);
        $stmt->close();
        
        // Get the most recent message
        $stmt = $conn->prepare("
            SELECT message, sent_at, sender_id
            FROM chat_messages
            WHERE (sender_id = ? AND receiver_id = ?)
               OR (sender_id = ? AND receiver_id = ?)
            AND academic_year_id = ?
            AND deleted_at IS NULL
            ORDER BY sent_at DESC
            LIMIT 1
        ");
        $stmt->bind_param("iiiii", $coordinator_id, $guideId, $guideId, $coordinator_id, $selectedAcademicYearId);
        $stmt->execute();
        $lastMsg = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($lastMsg) {
            $processedGuides[$guideId]['last_message'] = $lastMsg['message'];
            $processedGuides[$guideId]['last_message_time'] = $lastMsg['sent_at'];
            $processedGuides[$guideId]['sender_id'] = $lastMsg['sender_id'];
        }
    }
    
    $recentChats = array_merge($recentChats, array_values($processedGuides));
    
    // 2. Get recent chats with batches (group messages to students) - filtered by academic year
    $stmt = $conn->prepare("
        SELECT DISTINCT g.batch
        FROM chat_messages cm
        INNER JOIN students s ON (cm.sender_id = s.user_id OR cm.receiver_id = s.user_id)
        INNER JOIN pgroups g ON s.group_id = g.id
        WHERE (cm.sender_id = ? OR cm.receiver_id = ?)
          AND cm.academic_year_id = ?
          AND cm.deleted_at IS NULL
          AND g.batch IS NOT NULL
          AND g.academic_year_id = ?
        ORDER BY cm.sent_at DESC
    ");
    
    $stmt->bind_param("iiii", $coordinator_id, $coordinator_id, $selectedAcademicYearId, $selectedAcademicYearId);
    $stmt->execute();
    $batches = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Process batch chats
    foreach ($batches as $batchRow) {
        $batch = $batchRow['batch'];
        
        // Get students in this batch for the selected academic year
        $stmt = $conn->prepare("
            SELECT DISTINCT s.user_id 
            FROM students s 
            INNER JOIN pgroups g ON s.group_id = g.id 
            WHERE g.batch = ? AND g.academic_year_id = ?
        ");
        $stmt->bind_param("si", $batch, $selectedAcademicYearId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $student_ids = [];
        while ($row = $result->fetch_assoc()) {
            $student_ids[] = $row['user_id'];
        }
        $stmt->close();
        
        if (empty($student_ids)) continue;
        
        // Get last message - filtered by academic year
        $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
        $query = "
            SELECT message, sent_at, sender_id
            FROM chat_messages
            WHERE ((sender_id = ? AND receiver_id IN ($placeholders))
               OR (sender_id IN ($placeholders) AND receiver_id = ?))
              AND academic_year_id = ?
              AND deleted_at IS NULL
            ORDER BY sent_at DESC
            LIMIT 1
        ";
        
        $stmt = $conn->prepare($query);
        $types = str_repeat('i', count($student_ids) * 2 + 3);
        $params = array_merge([$coordinator_id], $student_ids, $student_ids, [$coordinator_id, $selectedAcademicYearId]);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $lastMsg = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$lastMsg) continue;
        
        // Get unread count from students in this batch - filtered by academic year
        $query = "
            SELECT COUNT(*) as unread 
            FROM chat_messages 
            WHERE sender_id IN ($placeholders) 
              AND receiver_id = ? 
              AND is_read = 0 
              AND academic_year_id = ?
              AND deleted_at IS NULL
        ";
        
        $stmt = $conn->prepare($query);
        $types = str_repeat('i', count($student_ids) + 2);
        $params = array_merge($student_ids, [$coordinator_id, $selectedAcademicYearId]);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $unreadResult = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        // Get student count for the selected academic year
        $stmt = $conn->prepare("
            SELECT COUNT(*) as student_count 
            FROM students s 
            INNER JOIN pgroups g ON s.group_id = g.id 
            WHERE g.batch = ? AND g.academic_year_id = ?
        ");
        $stmt->bind_param("si", $batch, $selectedAcademicYearId);
        $stmt->execute();
        $countResult = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        $recentChats[] = [
            'batch' => $batch,
            'chat_type' => 'batch',
            'recipient_name' => 'Batch: ' . $batch,
            'full_name' => $batch . ' (' . $countResult['student_count'] . ' students)',
            'last_message' => $lastMsg['message'],
            'last_message_time' => $lastMsg['sent_at'],
            'sender_id' => $lastMsg['sender_id'],
            'unread_count' => intval($unreadResult['unread']),
            'student_count' => intval($countResult['student_count'])
        ];
    }
    
    // Sort by last message time (most recent first)
    usort($recentChats, function($a, $b) {
        return strtotime($b['last_message_time']) - strtotime($a['last_message_time']);
    });
    
    // Sort unread chats to the top
    usort($recentChats, function($a, $b) {
        if ($a['unread_count'] > 0 && $b['unread_count'] == 0) return -1;
        if ($a['unread_count'] == 0 && $b['unread_count'] > 0) return 1;
        return 0;
    });
    
    sendJSON([
        'success' => true, 
        'chats' => $recentChats
    ]);
    
} catch (Exception $e) {
    sendJSON([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
