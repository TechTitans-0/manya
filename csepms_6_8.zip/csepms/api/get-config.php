<?php
require_once __DIR__ . '/../config/config.php';
requireRole('coordinator');
header('Content-Type: application/json; charset=utf-8');

$res = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$config = [];
while ($row = $res->fetch_assoc()) {
    $config[$row['setting_key']] = $row['setting_value'];
}

echo json_encode([
    'success' => true,
    'current_phase' => isset($config['current_phase']) ? intval($config['current_phase']) : 1,
    'current_review' => isset($config['current_review']) ? intval($config['current_review']) : 1
]);
exit;
?>
