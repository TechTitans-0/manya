<?php
require_once '../config/config.php';

// Prevent sending messages for completed academic years
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'coordinator') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

if (!isset($_POST['batch']) || !isset($_POST['message'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

$batch = trim($_POST['batch']);
$message = trim($_POST['message']);
$sender_id = $_SESSION['user_id'];

// Determine academic year for the message
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ay = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    if ($ay) $academicYearId = intval($ay['id']);
}
if (!$academicYearId) {
    echo json_encode(['success' => false, 'message' => 'No academic year configured']);
    exit;
}

if (empty($batch) || empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Batch and message are required']);
    exit;
}

try {
    // Get all student user_ids in this batch
    $stmt = $conn->prepare("
        SELECT DISTINCT s.user_id 
        FROM students s 
        INNER JOIN pgroups g ON s.group_id = g.id 
        WHERE g.batch = ?
    ");
    $stmt->bind_param("s", $batch);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row['user_id'];
    }
    $stmt->close();
    
    if (empty($students)) {
        echo json_encode(['success' => false, 'message' => 'No students found in this batch']);
        exit;
    }
    
    // Create notification for the batch
    $notification_title = "Message from Coordinator";
    $notification_message = "New message for Batch $batch: " . substr($message, 0, 100) . (strlen($message) > 100 ? '...' : '');
    
        $stmt = $conn->prepare("
            INSERT INTO notifications (title, message, target_type, target_value, sender_id, academic_year_id, created_at) 
            VALUES (?, ?, 'specific_batch', ?, ?, ?, NOW())
        ");
        $stmt->bind_param("sssii", $notification_title, $notification_message, $batch, $sender_id, $academicYearId);
        $stmt->execute();
        $notification_id = $stmt->insert_id;
        $stmt->close();
    
    // Create notification read status for each student
        $stmt = $conn->prepare("
            INSERT INTO notification_read_status (notification_id, user_id, academic_year_id, is_read, read_at) 
            VALUES (?, ?, ?, 0, NULL)
        ");
    
    foreach ($students as $student_id) {
            $stmt->bind_param("iii", $notification_id, $student_id, $academicYearId);
        $stmt->execute();
    }
    $stmt->close();
    
        // Store message in chat_messages table for each student (direct messages)
        $stmt = $conn->prepare("INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())");
        foreach ($students as $student_id) {
            $recvRole = 'student';
            $senderRole = 'coordinator';
            $stmt->bind_param("isissi", $sender_id, $senderRole, $student_id, $recvRole, $message, $academicYearId);
            $stmt->execute();
        }
        $stmt->close();
    
    echo json_encode([
        'success' => true, 
        'message' => "Message sent to " . count($students) . " student(s) in $batch",
        'sent_message' => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    error_log('Batch message error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>