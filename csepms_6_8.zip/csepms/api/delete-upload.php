<?php
require_once '../config/config.php';
requireRoleAPI('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$uploadId = intval($_POST['upload_id'] ?? 0);
if (!$uploadId) {
    sendJSON(['success' => false, 'message' => 'Upload ID required']);
}

// Fetch upload record
$stmt = $conn->prepare("SELECT * FROM project_uploads WHERE id = ?");
$stmt->bind_param("i", $uploadId);
$stmt->execute();
$upload = $stmt->get_result()->fetch_assoc();

if (!$upload) {
    sendJSON(['success' => false, 'message' => 'Upload not found']);
}

// Only the student who uploaded can delete their file (or coordinator/guide could be allowed in future)
if ($upload['uploaded_by'] != $_SESSION['role_id']) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

try {
    $conn->begin_transaction();

    // Delete DB record
    $del = $conn->prepare("DELETE FROM project_uploads WHERE id = ?");
    $del->bind_param("i", $uploadId);
    if (!$del->execute()) {
        throw new Exception('Failed to delete upload record');
    }

    // Delete physical file if exists
    if (!empty($upload['file_path'])) {
        $fileFull = __DIR__ . '/../' . $upload['file_path'];
        if (file_exists($fileFull)) {
            @unlink($fileFull);
        }
    }

    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Upload deleted']);
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>
