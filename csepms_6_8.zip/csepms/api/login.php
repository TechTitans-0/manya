<?php
require_once '../config/config.php';
require_once '../includes/auth.class.php';

header('Content-Type: application/json');

// Check if project type is selected
if (!isset($_SESSION['project_type'])) {
    sendJSON(['success' => false, 'message' => 'Please select a project type first'], 400);
}

// Ensure database connection is correct for the project type
global $conn;
if ($conn) {
    $conn->close();
}
$dbName = getDatabaseName($_SESSION['project_type']);
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
if ($conn->connect_error) {
    sendJSON(['success' => false, 'message' => 'Database connection failed']);
} else {
    $conn->set_charset("utf8mb4");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}


// Always lowercase identifier for employee_id/usn to make case insensitive
$role = sanitizeInput($_POST['role'] ?? '');
$projectType = sanitizeInput($_POST['project_type'] ?? '');
$identifier = sanitizeInput($_POST['identifier'] ?? '');
if ($role === 'coordinator' || $role === 'guide' || $role === 'student') {
    $identifier = strtolower($identifier);
}
$password = $_POST['password'] ?? '';

if (empty($identifier) || empty($password) || empty($role)) {
    sendJSON(['success' => false, 'message' => 'All fields are required']);
}

// Update session project type if provided
if (!empty($projectType) && in_array($projectType, ['major', 'mini'])) {
    $_SESSION['project_type'] = $projectType;
    
    // Reconnect to the correct database
    global $conn;
    if ($conn) {
        $conn->close();
    }
    $dbName = getDatabaseName($projectType);
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
    if ($conn->connect_error) {
        sendJSON(['success' => false, 'message' => 'Database connection failed']);
    } else {
        $conn->set_charset("utf8mb4");
    }
}


// Only allow login in the selected project type's database
$auth = new Auth($conn);
$result = $auth->login($identifier, $password, $role);

if ($result['success']) {
    $result['redirect'] = BASE_URL . $result['role'] . '/dashboard.php';
}

sendJSON($result);
?>
