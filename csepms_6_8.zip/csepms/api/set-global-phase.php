<?php
require_once '../config/config.php';
requireLogin();
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$phase = intval($_POST['phase'] ?? 0);

// Validate phase (1 or 2)
if ($phase !== 1 && $phase !== 2) {
    sendJSON(['success' => false, 'message' => 'Invalid phase. Must be 1 or 2']);
}

try {
    $conn->begin_transaction();
    
    // Update global phase setting
    $updateQuery = "UPDATE global_settings 
                    SET setting_value = ?, updated_by = ?, updated_at = NOW() 
                    WHERE setting_key = 'current_phase'";
    
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("si", $phase, $_SESSION['user_id']);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update global phase');
    }
    
    // Check if the setting was updated or needs to be inserted
    if ($stmt->affected_rows === 0) {
        // Try to insert if it doesn't exist
        $insertQuery = "INSERT INTO global_settings (setting_key, setting_value, updated_by) 
                        VALUES ('current_phase', ?, ?)
                        ON DUPLICATE KEY UPDATE 
                        setting_value = ?, updated_by = ?, updated_at = NOW()";
        
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("sisi", $phase, $_SESSION['user_id'], $phase, $_SESSION['user_id']);
        $stmt->execute();
    }
    
    $conn->commit();
    
    sendJSON([
        'success' => true, 
        'message' => "Global phase updated to Phase $phase successfully",
        'phase' => $phase
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    error_log("Set global phase error: " . $e->getMessage());
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
