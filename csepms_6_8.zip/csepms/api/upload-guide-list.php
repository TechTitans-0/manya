<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    sendJSON(['success' => false, 'message' => 'No file uploaded or upload error']);
}

$file = $_FILES['file'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

if (!in_array($ext, ['csv'])) {
    sendJSON(['success' => false, 'message' => 'Only CSV files are allowed']);
}

try {
    $data = [];
    
    // Parse CSV file
    $handle = fopen($file['tmp_name'], 'r');
    if (!$handle) {
        throw new Exception('Failed to read file');
    }
    
    $headers = fgetcsv($handle); // Get header row
    if (!$headers) {
        fclose($handle);
        throw new Exception('Failed to read header row');
    }

    // Expected columns (any order): Employee ID, Name, Designation, Research Domain Expertise, Years of Experience, Branch, Phone Number, Email
    $columnMap = [];
    for ($i = 0; $i < count($headers); $i++) {
        // Normalize header: trim, lowercase, remove extra spaces and special characters
        $header = strtolower(trim($headers[$i]));
        $header = preg_replace('/[^a-z0-9\s]/', '', $header); // Remove special characters
        $header = preg_replace('/\s+/', ' ', $header); // Normalize spaces to single spaces
        
        if (strpos($header, 'employee') !== false || strpos($header, 'emp id') !== false) $columnMap['employee_id'] = $i;
        elseif (strpos($header, 'name') !== false) $columnMap['name'] = $i;
        elseif (strpos($header, 'design') !== false) $columnMap['designation'] = $i;
        elseif (strpos($header, 'research') !== false || strpos($header, 'domain') !== false) $columnMap['research_domain_expertise'] = $i;
        elseif (strpos($header, 'year') !== false || strpos($header, 'experience') !== false) $columnMap['years_of_experience'] = $i;
        elseif (strpos($header, 'branch') !== false || strpos($header, 'department') !== false) $columnMap['branch'] = $i;
        // Phone detection: match "phone", "phone number", "contact", "mobile", "mobile number"
        elseif ((strpos($header, 'phone') !== false || strpos($header, 'mobile') !== false || strpos($header, 'contact') !== false) && strpos($header, 'email') === false) $columnMap['phone'] = $i;
        elseif (strpos($header, 'email') !== false || strpos($header, 'mail') !== false) $columnMap['email'] = $i;
        elseif (strpos($header, 'email') !== false || strpos($header, 'mail') !== false) $columnMap['email'] = $i;
    }

    // Validate presence of required columns
    $required = ['employee_id','name','designation','research_domain_expertise','years_of_experience','branch','phone','email'];
    foreach ($required as $col) {
        if (!isset($columnMap[$col])) {
            fclose($handle);
            throw new Exception('Missing required column: ' . $col);
        }
    }

    // Fetch current active academic year label
    $activeYear = '';
    $res = $conn->query("SELECT year_label FROM academic_years WHERE status = 'ACTIVE' LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        $activeYear = $row['year_label'];
    }

    while (($row = fgetcsv($handle)) !== FALSE) {
        // Safely get values from row with null checks
        $employee_id = isset($columnMap['employee_id']) && isset($row[$columnMap['employee_id']]) ? trim($row[$columnMap['employee_id']]) : '';
        $email = isset($columnMap['email']) && isset($row[$columnMap['email']]) ? trim($row[$columnMap['email']]) : '';
        
        // Require employee_id or email to identify guide
        if ($employee_id === '' && $email === '') continue;

        $data[] = [
            'employee_id' => $employee_id,
            'name' => isset($columnMap['name']) && isset($row[$columnMap['name']]) ? trim($row[$columnMap['name']]) : '',
            'designation' => isset($columnMap['designation']) && isset($row[$columnMap['designation']]) ? trim($row[$columnMap['designation']]) : '',
            'research_domain_expertise' => isset($columnMap['research_domain_expertise']) && isset($row[$columnMap['research_domain_expertise']]) ? trim($row[$columnMap['research_domain_expertise']]) : '',
            'years_of_experience' => isset($columnMap['years_of_experience']) && isset($row[$columnMap['years_of_experience']]) ? trim($row[$columnMap['years_of_experience']]) : '',
            'branch' => isset($columnMap['branch']) && isset($row[$columnMap['branch']]) ? trim($row[$columnMap['branch']]) : '',
            'phone' => isset($columnMap['phone']) && isset($row[$columnMap['phone']]) ? trim($row[$columnMap['phone']]) : '',
            'email' => $email,
            'academic_year' => $activeYear
        ];
    }
    fclose($handle);
    
    if (empty($data)) {
        throw new Exception('No valid data found in file');
    }
    
    $conn->begin_transaction();
    
    $inserted = 0;
    $skipped = 0;
    $errors = [];
    
    // Detect which columns exist in authorized_guides (migration may not have been run)
    $hasEmailCol = false;
    $hasPhoneCol = false;
    $hasNameCol = false;
    $hasDesignationCol = false;
    $hasResearchCol = false;
    $hasYearsCol = false;
    $hasBranchCol = false;
    $hasEmployeeIdCol = false;
    $colChk = $conn->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'authorized_guides'");
    $existingCols = [];
    if ($colChk) {
        $colChk->execute();
        $cres = $colChk->get_result();
        while ($c = $cres->fetch_assoc()) {
            $col = strtolower($c['COLUMN_NAME']);
            $existingCols[] = $col;
            if ($col === 'email') $hasEmailCol = true;
            if ($col === 'phone_number') $hasPhoneCol = true;  // Database column is 'phone_number'
            if ($col === 'name') $hasNameCol = true;
            if ($col === 'designation') $hasDesignationCol = true;
            if ($col === 'research_domain_expertise') $hasResearchCol = true;
            if ($col === 'years_of_experience') $hasYearsCol = true;
            if ($col === 'branch') $hasBranchCol = true;
            if ($col === 'employee_id') $hasEmployeeIdCol = true;
        }
        $colChk->close();
    }

    foreach ($data as $guide) {
        // Only deduplicate by employee_id - this is the unique identifier
        // Phone, email, name, branch can be duplicated
        if ($hasEmployeeIdCol && !empty($guide['employee_id'])) {
            // First check if this employee_id is already a registered coordinator
            $coordinatorQuery = 'SELECT id, approval_status, department FROM coordinators WHERE LOWER(employee_id) = LOWER(?)';
            $stmt = $conn->prepare($coordinatorQuery);
            if ($stmt) {
                $stmt->bind_param('s', $guide['employee_id']);
                $stmt->execute();
                $coordinatorResult = $stmt->get_result();
                
                if ($coordinatorResult->num_rows > 0) {
                    // This staff member is already a coordinator
                    $coordinator = $coordinatorResult->fetch_assoc();
                    
                    // If coordinator is approved, update their branch if it's empty
                    if ($coordinator['approval_status'] === 'approved' && !empty($guide['branch'])) {
                        $updateBranchQuery = 'UPDATE coordinators SET department = ? WHERE id = ?';
                        $updateStmt = $conn->prepare($updateBranchQuery);
                        if ($updateStmt) {
                            $updateStmt->bind_param('si', $guide['branch'], $coordinator['id']);
                            $updateStmt->execute();
                            $updateStmt->close();
                        }
                    }
                    
                    // Skip inserting as guide - coordinator already exists
                    $skipped++;
                    continue;
                }
            }
            
            // Check if this employee_id already exists in authorized_guides
            $checkQuery = 'SELECT id FROM authorized_guides WHERE LOWER(employee_id) = LOWER(?)';
            $stmt = $conn->prepare($checkQuery);
            if ($stmt) {
                $stmt->bind_param('s', $guide['employee_id']);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) {
                    $skipped++;
                    continue;
                }
            }
        }
        
        // Build insert including all available columns
        // Always include employee_id as the primary identifier
        $insertCols = [];
        $placeholders = [];
        $types = '';
        $vals = [];
        
        if ($hasEmployeeIdCol) { 
            $insertCols[] = 'employee_id'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['employee_id']; 
        }
        if ($hasNameCol) { 
            $insertCols[] = 'name'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['name']; 
        }
        if ($hasDesignationCol) { 
            $insertCols[] = 'designation'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['designation']; 
        }
        if ($hasResearchCol) { 
            $insertCols[] = 'research_domain_expertise'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['research_domain_expertise']; 
        }
        if ($hasYearsCol) { 
            $insertCols[] = 'years_of_experience'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['years_of_experience']; 
        }
        if ($hasBranchCol) { 
            $insertCols[] = 'branch'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['branch']; 
        }
        if ($hasPhoneCol) { 
            $insertCols[] = 'phone_number'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['phone']; 
        }
        if ($hasEmailCol) { 
            $insertCols[] = 'email'; 
            $placeholders[] = '?'; 
            $types .= 's'; 
            $vals[] = $guide['email']; 
        }

        if (count($insertCols) === 0) { 
            $errors[] = 'No suitable columns to insert guide'; 
            continue; 
        }

        $insertQuery = 'INSERT INTO authorized_guides (' . implode(', ', $insertCols) . ') VALUES (' . implode(', ', $placeholders) . ')';
        $stmt = $conn->prepare($insertQuery);
        if ($stmt) {
            $bindNames = []; 
            $bindNames[] = & $types;
            for ($i = 0; $i < count($vals); $i++) {
                $bindNames[] = & $vals[$i];
            }
            call_user_func_array([$stmt, 'bind_param'], $bindNames);
            if ($stmt->execute()) { 
                $inserted++; 
            } else { 
                $errors[] = "Failed to insert guide: " . ($guide['email'] ?: $guide['phone'] ?: $guide['name']); 
            }
        } else {
            $errors[] = 'Failed to prepare insert for guide';
        }
    }
    
    $conn->commit();
    
    sendJSON([
        'success' => true, 
        'message' => "Import completed: $inserted inserted, $skipped skipped",
        'details' => [
            'inserted' => $inserted,
            'skipped' => $skipped,
            'errors' => $errors
        ]
    ]);
    
} catch (Exception $e) {
    if ($conn->connect_errno === 0) {
        $conn->rollback();
    }
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
