<?php
require_once '../config/config.php';
if (!isLoggedIn()) {
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$notificationId = intval($_POST['notification_id'] ?? 0);

if (!$notificationId) {
    sendJSON(['success' => false, 'message' => 'Notification ID required']);
}

try {
    $query = "UPDATE notification_read_status SET is_read = 1, read_at = NOW() 
              WHERE notification_id = ? AND user_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $notificationId, $_SESSION['user_id']);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to mark notification as read');
    }
    
    sendJSON(['success' => true, 'message' => 'Notification marked as read']);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
