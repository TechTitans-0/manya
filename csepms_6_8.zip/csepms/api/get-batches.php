<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Get all distinct batches from groups table with student and group counts for the selected academic year
$query = "SELECT 
            g.batch,
            COUNT(DISTINCT g.id) as group_count,
            COUNT(DISTINCT s.id) as student_count
          FROM pgroups g
          LEFT JOIN students s ON s.group_id = g.id
          WHERE g.batch IS NOT NULL AND g.batch != '' AND g.academic_year_id = ?
          GROUP BY g.batch
          ORDER BY g.batch ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $selectedAcademicYearId);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$batches = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $batches[] = $row;
    }
}

sendJSON(['success' => true, 'batches' => $batches]);
?>
