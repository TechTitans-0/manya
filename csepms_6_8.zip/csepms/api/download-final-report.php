<?php
require_once '../config/config.php';
requireRole('student');

header('Content-Type: application/json');

$studentId = intval($_SESSION['role_id']);

try {
    // Fetch all approved grades for this student (grades authorized by coordinator)
    $query = "SELECT sg.*, es.phase, es.review, es.title as sheet_title, u.username as guide_name, s.usn, s.name as student_name
              FROM student_grades sg
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              INNER JOIN guides g ON sg.guide_id = g.id
              INNER JOIN users u ON g.user_id = u.id
              INNER JOIN students s ON sg.student_id = s.id
              WHERE sg.student_id = ? AND sg.status = 'approved'
              ORDER BY es.phase ASC, es.review ASC";

    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $res = $stmt->get_result();

    $grades = [];
    while ($row = $res->fetch_assoc()) {
        $grades[] = $row;
    }

    if (count($grades) === 0) {
        sendJSON(['success' => false, 'message' => 'No approved grades found']);
    }

    // Build aggregated per-phase summary table
    function imageToBase64($imagePath) {
        if (!file_exists($imagePath)) return '';
        $imageData = file_get_contents($imagePath);
        $mimeType = mime_content_type($imagePath);
        return 'data:' . $mimeType . ';base64,' . base64_encode($imageData);
    }

    $headerBase64 = imageToBase64(__DIR__ . '/../uploads/header.jpeg');
    $signatureBase64 = imageToBase64(__DIR__ . '/../uploads/signature.jpeg');

    // Aggregate grades by phase
    $aggQuery = "SELECT es.phase, SUM(sg.total_marks) as obtained, SUM(sg.max_marks) as max_marks
                 FROM student_grades sg
                 INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
                 WHERE sg.student_id = ? AND sg.status = 'approved'
                 GROUP BY es.phase
                 ORDER BY es.phase ASC";
    $astmt = $conn->prepare($aggQuery);
    $astmt->bind_param('i', $studentId);
    $astmt->execute();
    $ares = $astmt->get_result();

    $html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Final Grade Summary</title><style>body{font-family:Arial;margin:8mm;} .header img{width:100%} table{width:100%;border-collapse:collapse;margin-top:10px} th,td{border:1px solid #ccc;padding:8px;text-align:left} th{background:#f7f7f7}</style></head><body>';

    if (!empty($headerBase64)) {
        $html .= '<div class="header"><img src="' . $headerBase64 . '"/></div>';
    }

    $html .= '<h2>Final Grade Summary</h2>';
    $html .= '<table><thead><tr><th>Phase</th><th>Obtained Marks</th><th>Max Marks</th><th>Percentage</th></tr></thead><tbody>';

    while ($row = $ares->fetch_assoc()) {
        $obt = floatval($row['obtained']);
        $max = floatval($row['max_marks']);
        $perc = $max > 0 ? round(($obt / $max) * 100, 2) : 0;
        $html .= '<tr><td>Phase ' . intval($row['phase']) . '</td><td>' . number_format($obt,2) . '</td><td>' . number_format($max,2) . '</td><td>' . number_format($perc,2) . '%</td></tr>';
    }

    $html .= '</tbody></table>';

    if (!empty($signatureBase64)) {
        $html .= '<div style="text-align:right;margin-top:30px;"><img src="' . $signatureBase64 . '" style="max-width:200px;"/></div>';
    }

    $html .= '</body></html>';

    sendJSON(['success' => true, 'html' => $html, 'filename' => 'Final_Summary_' . $studentId . '.pdf']);

} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>
