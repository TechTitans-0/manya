<?php
require_once '../config/config.php';
if (!isLoggedIn()) {
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$currentPassword = $_POST['current_password'] ?? '';
$newPassword = $_POST['new_password'] ?? '';

if (empty($currentPassword) || empty($newPassword)) {
    sendJSON(['success' => false, 'message' => 'Both passwords are required']);
}

if (strlen($newPassword) < 6) {
    sendJSON(['success' => false, 'message' => 'New password must be at least 6 characters']);
}

try {
    // Verify current password
    $query = "SELECT password FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    
    if (!password_verify($currentPassword, $user['password'])) {
        throw new Exception('Current password is incorrect');
    }
    
    // Update password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $updateQuery = "UPDATE users SET password = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("si", $hashedPassword, $_SESSION['user_id']);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update password');
    }
    
    sendJSON(['success' => true, 'message' => 'Password changed successfully']);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
