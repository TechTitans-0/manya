<?php
require_once '../config/config.php';

// Allow both guides and coordinators to fetch group grades
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}
if (!hasRole('guide') && !hasRole('coordinator')) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

header('Content-Type: application/json');

if (!isset($_GET['group_id'])) {
    sendJSON(['success' => false, 'message' => 'Group ID is required']);
}

$groupId = intval($_GET['group_id']);
// Optional filter by evaluation_sheet_id
$evaluationSheetId = isset($_GET['evaluation_sheet_id']) ? intval($_GET['evaluation_sheet_id']) : 0;

// Determine academic year to consider (prefer session ACTIVE)
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    if ($ayRow && isset($ayRow['id'])) $academicYearId = intval($ayRow['id']);
}

// Verify the user (guide or coordinator) has access to this group
if (hasRole('guide')) {
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
} else {
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND coordinator_guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
}
$stmt->execute();

if ($stmt->get_result()->num_rows === 0) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

// Get all grades for this group with student details
$isMini = (isset($_SESSION['project_type']) && $_SESSION['project_type'] === 'mini');
if ($isMini) {
    $query = "SELECT sg.*, sg.overall_remarks, sg.max_marks AS grade_max,
              s.usn, u.username, s.name,
              es.title as sheet_title,
              sgd.criterion_id, sgd.marks_obtained,
              ec.criterion_name, ec.max_marks AS criterion_max
              FROM student_grades sg
              INNER JOIN (
                  SELECT student_id, evaluation_sheet_id, MAX(id) AS latest_grade_id
                  FROM student_grades
                  WHERE group_id = ?" . ($academicYearId ? " AND academic_year_id = ?" : "") . "
                  GROUP BY student_id, evaluation_sheet_id
              ) latest ON sg.id = latest.latest_grade_id
              INNER JOIN students s ON sg.student_id = s.id
              INNER JOIN users u ON s.user_id = u.id
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
              LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
              WHERE sg.group_id = ?" . ($evaluationSheetId ? " AND sg.evaluation_sheet_id = ?" : "") . ($academicYearId ? " AND sg.academic_year_id = ?" : "") . "";
} else {
    $query = "SELECT sg.*, sg.overall_remarks, sg.max_marks AS grade_max,
              s.usn, u.username, s.name,
              es.phase, es.review, es.title as sheet_title,
              sgd.criterion_id, sgd.marks_obtained,
              ec.criterion_name, ec.max_marks AS criterion_max
              FROM student_grades sg
              INNER JOIN (
                  SELECT student_id, evaluation_sheet_id, MAX(id) AS latest_grade_id
                  FROM student_grades
                  WHERE group_id = ?" . ($academicYearId ? " AND academic_year_id = ?" : "") . "
                  GROUP BY student_id, evaluation_sheet_id
              ) latest ON sg.id = latest.latest_grade_id
              INNER JOIN students s ON sg.student_id = s.id
              INNER JOIN users u ON s.user_id = u.id
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
              LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
              WHERE sg.group_id = ?" . ($evaluationSheetId ? " AND sg.evaluation_sheet_id = ?" : "") . ($academicYearId ? " AND sg.academic_year_id = ?" : "") . "";
}

// Remove the redundant extra filter; the sheet condition is already in the query string above

if ($isMini) {
    $query .= " ORDER BY s.usn ASC, ec.id ASC";
} else {
    $query .= " ORDER BY es.phase DESC, es.review DESC, s.usn ASC, ec.id ASC";
}

$stmt = $conn->prepare($query);
if (!$stmt) {
    error_log("Get group grades prepare error: " . $conn->error);
    sendJSON(['success' => false, 'message' => 'Database prepare error: ' . $conn->error]);
}

// Bind parameters depending on presence of evaluationSheetId and academicYearId
$bindParams = [];
$types = '';
if ($isMini) {
    // inner subquery: group_id[, academicYearId]
    $types .= 'i'; $bindParams[] = $groupId;
    if ($academicYearId) { $types .= 'i'; $bindParams[] = $academicYearId; }
    // outer where: sg.group_id
    $types .= 'i'; $bindParams[] = $groupId;
    if ($evaluationSheetId) { $types .= 'i'; $bindParams[] = $evaluationSheetId; }
    if ($academicYearId) { $types .= 'i'; $bindParams[] = $academicYearId; }
} else {
    $types .= 'i'; $bindParams[] = $groupId;
    if ($academicYearId) { $types .= 'i'; $bindParams[] = $academicYearId; }
    $types .= 'i'; $bindParams[] = $groupId;
    if ($evaluationSheetId) { $types .= 'i'; $bindParams[] = $evaluationSheetId; }
    if ($academicYearId) { $types .= 'i'; $bindParams[] = $academicYearId; }
}

// bind_param requires references; use call_user_func_array for dynamic params
$params = array_merge([$types], $bindParams);
$refs = [];
foreach ($params as $k => $v) $refs[$k] = &$params[$k];
call_user_func_array([$stmt, 'bind_param'], $refs);

if (!$stmt->execute()) {
    error_log("Get group grades execute error: " . $stmt->error);
    sendJSON(['success' => false, 'message' => 'Database execute error: ' . $stmt->error]);
}

$result = $stmt->get_result();
$grades = [];
$currentGradeId = null;
$currentGrade = null;

error_log("Get group grades - Total rows: " . $result->num_rows);

while ($row = $result->fetch_assoc()) {
    $gradeId = $row['id'];
    
    if ($currentGradeId !== $gradeId) {
        if ($currentGrade !== null) {
            $grades[] = $currentGrade;
        }
        
        $currentGradeId = $gradeId;
        $currentGrade = [
            'id' => $row['id'],
            'group_id' => intval($row['group_id']),
            'evaluation_sheet_id' => intval($row['evaluation_sheet_id']),
            'student_id' => $row['student_id'],
            'usn' => $row['usn'],
            'student_name' => $row['name'] ?: $row['username'],
            'phase' => $row['phase'] ?? null,
            'review' => $row['review'] ?? null,
            'sheet_title' => $row['sheet_title'],
            'total_marks' => floatval($row['total_marks']),
            'max_marks' => floatval($row['grade_max'] ?? $row['max_marks']),
            'percentage' => $row['max_marks'] > 0 ? round((floatval($row['total_marks']) / floatval($row['max_marks'])) * 100, 2) : 0,
            'status' => $row['status'],
            'graded_at' => $row['graded_at'],
            'overall_remarks' => $row['overall_remarks'] ?? '',
            'criteria' => []
        ];
    }
    
    if ($row['criterion_id']) {
        $currentGrade['criteria'][] = [
            'criterion_id' => intval($row['criterion_id']),
            'criterion_name' => $row['criterion_name'],
            'max_marks' => floatval($row['criterion_max'] ?? $row['max_marks']),
            'marks_obtained' => floatval($row['marks_obtained'])
        ];
    }
}

if ($currentGrade !== null) {
    $grades[] = $currentGrade;
}

error_log("Get group grades - Total grades returned: " . count($grades));
sendJSON(['success' => true, 'grades' => $grades]);
?>
