<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if (!isset($_GET['guide_user_id'])) {
    sendJSON(['success' => false, 'message' => 'Guide user ID required']);
}

$guide_user_id = intval($_GET['guide_user_id']);
$coordinator_id = $_SESSION['user_id'];

try {
    // Get all messages between coordinator and this guide
    $stmt = $conn->prepare("
        SELECT 
            cm.*,
            u.username as sender_name
        FROM chat_messages cm
        INNER JOIN users u ON cm.sender_id = u.id
        WHERE (cm.sender_id = ? AND cm.receiver_id = ?)
           OR (cm.sender_id = ? AND cm.receiver_id = ?)
        ORDER BY cm.sent_at ASC
    ");
    
    $stmt->bind_param("iiii", $coordinator_id, $guide_user_id, $guide_user_id, $coordinator_id);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    sendJSON(['success' => true, 'messages' => $messages]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
