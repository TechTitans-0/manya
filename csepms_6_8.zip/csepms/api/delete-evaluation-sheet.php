<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$sheetId = intval($_POST['sheet_id'] ?? 0);

if (!$sheetId) {
    sendJSON(['success' => false, 'message' => 'Sheet ID is required']);
}

try {
    $conn->begin_transaction();
    
    // Check if sheet exists
    $checkQuery = "SELECT id FROM evaluation_sheets WHERE id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("i", $sheetId);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows === 0) {
        throw new Exception('Evaluation sheet not found');
    }
    
    // Check if sheet is being used in grades (both old and new systems)
    $gradeCheck = "SELECT COUNT(*) as count FROM student_grades WHERE evaluation_sheet_id = ?";
    $stmt = $conn->prepare($gradeCheck);
    $stmt->bind_param("i", $sheetId);
    $stmt->execute();
    $gradeCount = $stmt->get_result()->fetch_assoc()['count'];
    
    if ($gradeCount > 0) {
        throw new Exception("Cannot delete: This evaluation sheet is being used by {$gradeCount} grade(s)");
    }
    
    // Delete evaluation criteria first (foreign key constraint)
    $deleteCriteria = "DELETE FROM evaluation_criteria WHERE evaluation_sheet_id = ?";
    $stmt = $conn->prepare($deleteCriteria);
    $stmt->bind_param("i", $sheetId);
    $stmt->execute();
    
    // Delete evaluation sheet
    $deleteSheet = "DELETE FROM evaluation_sheets WHERE id = ?";
    $stmt = $conn->prepare($deleteSheet);
    $stmt->bind_param("i", $sheetId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to delete evaluation sheet');
    }
    
    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Evaluation sheet deleted successfully']);
    
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
