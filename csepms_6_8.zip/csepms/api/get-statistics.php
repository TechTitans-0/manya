<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$type = $_GET['type'] ?? 'overview';

try {
    $statistics = [];
    
    if ($type === 'overview' || $type === 'all') {
        // General statistics
        $stats = [
            'total_students' => $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'],
            'total_guides' => $conn->query("SELECT COUNT(*) as count FROM guides")->fetch_assoc()['count'],
            'total_groups' => $conn->query("SELECT COUNT(*) as count FROM pgroups")->fetch_assoc()['count'],
            'total_batches' => $conn->query("SELECT COUNT(*) as count FROM batches")->fetch_assoc()['count'],
            'students_without_group' => $conn->query("SELECT COUNT(*) as count FROM students WHERE group_id IS NULL")->fetch_assoc()['count'],
            'groups_without_guide' => $conn->query("SELECT COUNT(*) as count FROM pgroups WHERE guide_id IS NULL")->fetch_assoc()['count']
        ];
        $statistics['overview'] = $stats;
    }
    
    if ($type === 'uploads' || $type === 'all') {
        // Upload statistics
        $uploadStats = [
            'total_uploads' => $conn->query("SELECT COUNT(*) as count FROM project_uploads")->fetch_assoc()['count'],
            'pending_reviews' => $conn->query("SELECT COUNT(*) as count FROM project_uploads WHERE status = 'pending'")->fetch_assoc()['count'],
            'approved' => $conn->query("SELECT COUNT(*) as count FROM project_uploads WHERE status = 'approved'")->fetch_assoc()['count'],
            'changes_required' => $conn->query("SELECT COUNT(*) as count FROM project_uploads WHERE status = 'changes_required'")->fetch_assoc()['count']
        ];
        
        // Uploads by phase
        $uploadsByPhase = $conn->query("SELECT phase, COUNT(*) as count 
                                        FROM project_uploads 
                                        GROUP BY phase")->fetch_all(MYSQLI_ASSOC);
        $uploadStats['by_phase'] = $uploadsByPhase;
        
        $statistics['uploads'] = $uploadStats;
    }
    
    if ($type === 'grades' || $type === 'all') {
        // Grading statistics
        $gradeStats = [
            'total_grades' => $conn->query("SELECT COUNT(*) as count FROM student_grades WHERE status IN ('pending', 'approved')")->fetch_assoc()['count'],
            'draft_grades' => $conn->query("SELECT COUNT(*) as count FROM student_grades WHERE status = 'draft'")->fetch_assoc()['count'],
            'groups_graded' => $conn->query("SELECT COUNT(DISTINCT group_id) as count FROM student_grades WHERE status IN ('pending', 'approved')")->fetch_assoc()['count']
        ];
        
        // Average grades by phase
        $avgGrades = $conn->query("SELECT es.phase, AVG(sg.total_marks) as avg_marks, 
                                   AVG((sg.total_marks/sg.max_marks)*100) as avg_percentage
                                   FROM student_grades sg
                                   INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
                                   WHERE sg.status IN ('pending', 'approved')
                                   GROUP BY es.phase")->fetch_all(MYSQLI_ASSOC);
        $gradeStats['average_by_phase'] = $avgGrades;
        
        $statistics['grades'] = $gradeStats;
    }
    
    if ($type === 'batches' || $type === 'all') {
        // Batch-wise statistics
        $batchStats = $conn->query("SELECT b.batch_name,
                                    COUNT(DISTINCT s.id) as student_count,
                                    COUNT(DISTINCT g.id) as group_count,
                                    COUNT(DISTINCT pu.id) as upload_count
                                    FROM batches b
                                    LEFT JOIN students s ON b.batch_name = s.batch
                                    LEFT JOIN pgroups g ON b.batch_name = g.batch
                                    LEFT JOIN project_uploads pu ON g.id = pu.group_id
                                    GROUP BY b.id
                                    ORDER BY b.start_year DESC")->fetch_all(MYSQLI_ASSOC);
        $statistics['batches'] = $batchStats;
    }
    
    if ($type === 'guides' || $type === 'all') {
        // Guide workload statistics
        $guideStats = $conn->query("SELECT u.username as guide_name,
                                    COUNT(DISTINCT gr.id) as group_count,
                                    COUNT(DISTINCT pu.id) as total_uploads,
                                    SUM(CASE WHEN pu.status = 'pending' THEN 1 ELSE 0 END) as pending_reviews
                                    FROM guides gd
                                    INNER JOIN users u ON gd.user_id = u.id
                                    LEFT JOIN pgroups gr ON gd.id = gr.guide_id
                                    LEFT JOIN project_uploads pu ON gr.id = pu.group_id
                                    GROUP BY gd.id
                                    ORDER BY group_count DESC")->fetch_all(MYSQLI_ASSOC);
        $statistics['guides'] = $guideStats;
    }
    
    sendJSON(['success' => true, 'statistics' => $statistics]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
