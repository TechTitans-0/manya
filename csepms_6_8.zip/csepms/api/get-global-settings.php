<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

try {
    // Get global settings (phase and review)
    $query = "SELECT setting_key, setting_value, updated_at 
              FROM global_settings 
              WHERE setting_key IN ('current_phase', 'current_review')";
    
    $result = $conn->query($query);
    
    $settings = [
        'current_phase' => 1,  // default values
        'current_review' => 1
    ];
    
    while ($row = $result->fetch_assoc()) {
        $settings[$row['setting_key']] = intval($row['setting_value']);
    }
    
    sendJSON([
        'success' => true,
        'phase' => $settings['current_phase'],
        'review' => $settings['current_review']
    ]);
    
} catch (Exception $e) {
    error_log("Get global settings error: " . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to fetch global settings']);
}
?>
