<?php
// get-current-academic-year.php
require_once '../includes/db_connect.php';
header('Content-Type: application/json');

$sql = "SELECT setting_value FROM global_settings WHERE setting_key = 'current_academic_year' LIMIT 1";
$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
    echo json_encode(['current_academic_year' => $row['setting_value']]);
} else {
    echo json_encode(['current_academic_year' => null]);
}
?>
