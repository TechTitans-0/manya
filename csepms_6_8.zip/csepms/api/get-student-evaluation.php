<?php
// This endpoint has been deprecated after UI changes removed evaluation viewing from the coordinator students page.
// We keep the file for historical reasons but immediately return a 404 so the route is effectively gone.
http_response_code(404);
header('Content-Type: application/json');
echo json_encode(['success' => false, 'message' => 'Not found']);
exit;

$student_id = intval($_GET['student_id']);
$phase = isset($_GET['phase']) ? intval($_GET['phase']) : 1;
$review = isset($_GET['review']) ? intval($_GET['review']) : 1;

try {
    // Get student details
    $student_query = "SELECT s.id, s.usn, u.username as name, s.group_id, 
                             g.batch, g.group_name, g.project_title,
                             gu.username as guide_name
                      FROM students s
                      INNER JOIN users u ON s.user_id = u.id
                      LEFT JOIN pgroups g ON s.group_id = g.id
                      LEFT JOIN guides gd ON g.guide_id = gd.id
                      LEFT JOIN users gu ON gd.user_id = gu.id
                      WHERE s.id = ?";
    
    $stmt = $conn->prepare($student_query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $student_result = $stmt->get_result();
    
    if ($student_result->num_rows === 0) {
        sendJSON(['success' => false, 'message' => 'Student not found']);
    }
    
    $student = $student_result->fetch_assoc();
    
    if (!$student['group_id']) {
        sendJSON(['success' => false, 'message' => 'Student is not assigned to any group']);
    }
    
    // Get evaluation details with marks
    $evaluations = [];
    $eval_query = "SELECT sg.*, sg.overall_remarks, es.id as sheet_id, es.phase, es.review, es.title as sheet_title,
                          sgd.criterion_id, sgd.marks_obtained, 
                          ec.criterion_name as criterion_name, ec.max_marks, ec.display_order
                   FROM student_grades sg
                   INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
                   LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
                   LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
                   WHERE sg.student_id = ? AND es.phase = ? AND es.review = ? AND sg.status IN ('approved', 'submitted')
                   ORDER BY ec.display_order ASC";
    
    $stmt = $conn->prepare($eval_query);
    $stmt->bind_param("iii", $student_id, $phase, $review);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $current_grade_id = null;
    $current_eval = null;
    
    while ($row = $result->fetch_assoc()) {
        if ($current_grade_id !== $row['id']) {
            if ($current_eval !== null) {
                $evaluations[] = $current_eval;
            }
            
            $current_grade_id = $row['id'];
            $current_eval = [
                'grade_id' => $row['id'],
                'phase' => $row['phase'],
                'review' => $row['review'],
                'sheet_title' => $row['sheet_title'],
                'total_marks' => number_format($row['total_marks'], 2),
                'max_marks' => number_format($row['max_marks'], 2),
                'percentage' => $row['max_marks'] > 0 ? number_format(($row['total_marks'] / $row['max_marks']) * 100, 2) : '0.00',
                'graded_at' => date('d-M-Y h:i A', strtotime($row['graded_at'])),
                'overall_remarks' => $row['overall_remarks'] ?? '',
                'criteria' => []
            ];
        }
        
        if ($row['criterion_id']) {
            $current_eval['criteria'][] = [
                'criterion_name' => $row['criterion_name'],
                'max_marks' => $row['max_marks'],
                'marks_obtained' => number_format($row['marks_obtained'], 2)
            ];
        }
    }
    
    if ($current_eval !== null) {
        $evaluations[] = $current_eval;
    }
    
    if (empty($evaluations)) {
        sendJSON(['success' => false, 'message' => 'No evaluation data found for this student']);
    }
    
    // Aggregate totals per phase from submitted student_grades
    $phaseTotals = [
        'phase1_total' => 0.0,
        'phase1_max' => 0.0,
        'phase2_total' => 0.0,
        'phase2_max' => 0.0
    ];

    $agg_query = "SELECT es.phase, SUM(sg.total_marks) AS phase_total, SUM(sg.max_marks) AS phase_max
                  FROM student_grades sg
                  INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
                  WHERE sg.student_id = ? AND sg.status IN ('approved', 'submitted')
                  GROUP BY es.phase";

    $agg_stmt = $conn->prepare($agg_query);
    if ($agg_stmt) {
        $agg_stmt->bind_param("i", $student_id);
        $agg_stmt->execute();
        $agg_res = $agg_stmt->get_result();
        while ($r = $agg_res->fetch_assoc()) {
            $phase_num = intval($r['phase']);
            if ($phase_num === 1) {
                $phaseTotals['phase1_total'] = floatval($r['phase_total']);
                $phaseTotals['phase1_max'] = floatval($r['phase_max']);
            } elseif ($phase_num === 2) {
                $phaseTotals['phase2_total'] = floatval($r['phase_total']);
                $phaseTotals['phase2_max'] = floatval($r['phase_max']);
            }
        }
    }
    
    // Get header and signature images (you can store these in a settings table or use default)
    // For now, using placeholders - you can update this to fetch from database
    $header_image = 'header.jpeg'; // Path relative to uploads folder
    $signature_image = 'signature.jpeg'; // Path relative to uploads folder
    
    $response_data = [
        'student_name' => $student['name'],
        'usn' => $student['usn'],
        'batch' => $student['batch'],
        'group_name' => $student['group_name'],
        'project_title' => $student['project_title'],
        'guide_name' => $student['guide_name'],
        'title' => "Phase $phase Review $review Evaluation Report",
        'evaluations' => $evaluations,
        'phase_totals' => $phaseTotals,
        'header_image' => $header_image,
        'signature_image' => $signature_image
    ];
    
    sendJSON(['success' => true, 'data' => $response_data]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
