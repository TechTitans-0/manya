<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$groupId = intval($_POST['group_id'] ?? 0);
$evaluationSheetId = isset($_POST['evaluation_sheet_id']) ? intval($_POST['evaluation_sheet_id']) : 0;

if (!$groupId) {
    sendJSON(['success' => false, 'message' => 'Group ID is required']);
}

try {
    $conn->begin_transaction();

    // Log for debugging
    error_log("Authorize Grades - Group ID: $groupId, Evaluation Sheet ID: $evaluationSheetId");

    // Approve ONLY submitted grades for this group (optionally filter by evaluation sheet)
    // Exclude 'approved' grades to prevent re-approval
    $query = "UPDATE student_grades 
              SET status = 'approved', updated_at = NOW() 
              WHERE group_id = ? AND status = 'submitted'";
    $types = "i";
    $params = [$groupId];

    if ($evaluationSheetId) {
        $query .= " AND evaluation_sheet_id = ?";
        $types .= "i";
        $params[] = $evaluationSheetId;
    }

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    if (!$stmt->execute()) {
        throw new Exception('Failed to authorize grades: ' . $stmt->error);
    }

    $affected = $stmt->affected_rows;
    
    error_log("Authorize Grades - Affected rows: $affected");
    
    if ($affected === 0) {
        throw new Exception('No grades found to authorize. Please ensure grades have been submitted by the guide first.');
    }

    $conn->commit();
    error_log("Authorize Grades - Transaction committed successfully");
    sendJSON(['success' => true, 'message' => "Grades authorized successfully for $affected students", 'updated' => $affected]);

} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
