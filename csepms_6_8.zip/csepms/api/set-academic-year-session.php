<?php
require_once '../config/config.php';

// API to set selected academic year in the user's session without performing
// administrative actions. Allows any authenticated user to change their
// session selection for viewing/filtering purposes.

header('Content-Type: application/json');

if (!isLoggedIn()) {
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}

$yearId = isset($_POST['year_id']) ? intval($_POST['year_id']) : null;

if (!$yearId) {
    sendJSON(['success' => false, 'message' => 'Year ID required'], 400);
}

// Verify the year exists
$year = $conn->query("SELECT id, status FROM academic_years WHERE id = " . intval($yearId) . " LIMIT 1")->fetch_assoc();
if (!$year) {
    sendJSON(['success' => false, 'message' => 'Academic year not found'], 404);
}

// Update session only
$_SESSION['academic_year_id'] = intval($yearId);

sendJSON(['success' => true, 'message' => 'Selected year saved', 'year_id' => $yearId, 'status' => $year['status']]);
?>
