<?php
require_once '../config/config.php';
requireRole('student');

header('Content-Type: application/json');

// Get students who are not in any group and are authorized
$query = "SELECT s.id, s.usn, u.username, s.branch 
          FROM students s
          INNER JOIN users u ON s.user_id = u.id
          WHERE s.group_id IS NULL 
          AND s.is_authorized = 1
          AND s.id != ?
          ORDER BY u.username ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

sendJSON(['success' => true, 'students' => $students]);
?>
