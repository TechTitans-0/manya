<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$query = "SELECT 
            g.id as group_id,
            g.batch,
            g.group_name,
            COALESCE(tl_user.username, tl_user.email) as team_lead_name,
            (SELECT COUNT(*) FROM students s WHERE s.group_id = g.id) as member_count
          FROM pgroups g
          LEFT JOIN students tl ON g.id = tl.group_id AND tl.is_team_lead = 1
          LEFT JOIN users tl_user ON tl.user_id = tl_user.id
          HAVING member_count <= 3
          ORDER BY g.batch ASC";

$result = $conn->query($query);
$batches = $result->fetch_all(MYSQLI_ASSOC);

sendJSON(['success' => true, 'batches' => $batches]);
?>