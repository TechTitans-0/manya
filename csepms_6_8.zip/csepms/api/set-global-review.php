<?php
require_once '../config/config.php';
requireLogin();
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$review = intval($_POST['review'] ?? 0);

// Validate review number (must be positive integer)
if ($review < 1 || $review > 10) {
    sendJSON(['success' => false, 'message' => 'Invalid review number. Must be between 1 and 10']);
}

try {
    $conn->begin_transaction();
    
    // Update global review setting
    $updateQuery = "UPDATE global_settings 
                    SET setting_value = ?, updated_by = ?, updated_at = NOW() 
                    WHERE setting_key = 'current_review'";
    
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("si", $review, $_SESSION['user_id']);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update global review');
    }
    
    // Check if the setting was updated or needs to be inserted
    if ($stmt->affected_rows === 0) {
        // Try to insert if it doesn't exist
        $insertQuery = "INSERT INTO global_settings (setting_key, setting_value, updated_by) 
                        VALUES ('current_review', ?, ?)
                        ON DUPLICATE KEY UPDATE 
                        setting_value = ?, updated_by = ?, updated_at = NOW()";
        
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("sisi", $review, $_SESSION['user_id'], $review, $_SESSION['user_id']);
        $stmt->execute();
    }
    
    $conn->commit();
    
    sendJSON([
        'success' => true, 
        'message' => "Global review updated to Review $review successfully",
        'review' => $review
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    error_log("Set global review error: " . $e->getMessage());
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
