<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

$groupId = intval($_GET['group_id'] ?? 0);
$review = $_GET['review'] ?? 'Review-1';
$academicYear = $_GET['academic_year'] ?? null;
$department = $_GET['department'] ?? 'CSE';

if (!$groupId) sendJSON(['success' => false, 'message' => 'group_id is required']);

// Access check: students may only access their own group
if (hasRole('student')) {
    if (empty($_SESSION['group_id']) || intval($_SESSION['group_id']) !== $groupId) {
        sendJSON(['success' => false, 'message' => 'Access denied']);
    }
}

try {
    // helper for images - WITH validation and error handling
    function imageToBase64($path) {
        if (!file_exists($path)) {
            error_log('Image not found: ' . $path);
            return '';
        }
        $data = file_get_contents($path);
        if ($data === false) {
            error_log('Failed to read image: ' . $path);
            return '';
        }
        $mime = mime_content_type($path);
        if (!$mime) $mime = 'image/jpeg'; // default to jpeg if detection fails
        $base64 = base64_encode($data);
        error_log('Image converted to base64: ' . $path . ' (size: ' . strlen($base64) . ' bytes)');
        return 'data:' . $mime . ';base64,' . $base64;
    }

    $headerImg = imageToBase64(__DIR__ . '/../uploads/header.jpeg');
    $footerImg = imageToBase64(__DIR__ . '/../uploads/footer.jpeg');

    // Prepare parameters for the include file (it uses $_GET)
    $_GET['group_id'] = $groupId;
    if (isset($_GET['evaluation_sheet_id'])) {
        $_GET['evaluation_sheet_id'] = intval($_GET['evaluation_sheet_id']);
    }
    // Accept numeric review or 'Review-1' string; also accept phase if provided
    if (isset($_GET['phase'])) $_GET['phase'] = intval($_GET['phase']);
    if ($review !== null) $_GET['review'] = $review;
    if ($academicYear) $_GET['academic_year'] = $academicYear;
    $_GET['department'] = $department;

    ob_start();
    include __DIR__ . '/../includes/evaluation_sheet_view.php';
    $middle = ob_get_clean();

    $html = '<!doctype html><html><head><meta charset="utf-8"><title>Evaluation Sheet</title>';
    $html .= '<style>'
        . '@page { size: A4; margin: 10mm; } '
        . 'body{font-family:Arial,Helvetica,sans-serif;margin:0;padding:0;background:#fff;color:#000;font-weight:700;-webkit-print-color-adjust:exact;} '
        . '.text-muted{color:#000 !important;font-weight:700 !important;} '
        . '.pdf-wrapper{width:210mm;max-width:100%;margin:0 auto;padding:8mm 6mm 6mm 6mm;background:#fff;page-break-inside:avoid;page-break-after:avoid;box-sizing:border-box;display:flex;flex-direction:column;} '
        . '.header{width:100%;padding:8px 0 10px 0;overflow:hidden;display:flex;justify-content:center;align-items:center;box-sizing:border-box;} '
        . '.header img{width:100%;height:auto;max-height:45mm;display:block;object-fit:contain;object-position:center;} '
        . '.sheet{margin:0 auto;padding:0;page-break-before:avoid;page-break-inside:avoid;flex:1;display:flex;flex-direction:column;box-sizing:border-box;} '
        . '.evaluation-sheet{width:min(98%,100%);margin:0 auto;padding:5px 6px 6px 6px;page-break-inside:avoid;box-sizing:border-box;display:flex;flex-direction:column;} '
        . '.evaluation-sheet .evaluation-content{flex:1;display:flex;flex-direction:column;gap:8px;} '
        . '.department-title{text-align:center;font-size:1rem;font-weight:700;margin:4px 0 10px 0;letter-spacing:0.08em;} '
        . '.signature-container{display:flex;flex-direction:column;margin-top:auto;padding-top:8px;page-break-inside:avoid;} '
        . '.evaluation-sheet .sheet-heading{text-align:center;margin-bottom:30px;padding-bottom:4px;border-bottom:none;} '
        . '.evaluation-sheet .sheet-heading h2{margin:0;font-size:1rem;line-height:1.1;letter-spacing:0;} '
        . '.evaluation-sheet table{width:100%;table-layout:fixed;border-collapse:collapse;margin-bottom:8px;color:#000;} '
        . '.evaluation-sheet th,.evaluation-sheet td{border:1px solid #000;padding:7px 6px;font-size:0.9rem;line-height:1.3;vertical-align:middle;word-break:break-word;} '
        . '.evaluation-sheet .label-cell{vertical-align:middle;} '
        . '.evaluation-sheet th{font-weight:700;background:#f4f4f4;text-align:center;} '
        . '.evaluation-sheet td{font-weight:700; color:#000} '
        . '.evaluation-sheet .label-cell{padding:8px 6px;} '
        . '.evaluation-sheet .remarks-section{margin:10px 0 120px 0;} '
        . '.evaluation-sheet .remarks-section strong{display:block;margin-bottom:8px;} '
        . '.evaluation-sheet .remarks-box{min-height:80px;border:1px solid #000;padding:10px;line-height:1.4;background:#fff;white-space:pre-wrap;word-break:break-word;} '
        . '.evaluation-sheet .signature-row{display:flex;justify-content:space-between;gap:8px;margin-top:12px;} '
        . '.evaluation-sheet .signature-field{flex:1;text-align:center;padding:0 6px 0 6px;box-sizing:border-box;} '
        . '.evaluation-sheet .signature-line{border-bottom:1px solid #000;height:30px;margin-bottom:6px;} '
        . '.evaluation-sheet .signature-label{font-size:0.8rem;font-weight:700;} '
        . 'h2,h3,h4{margin:0;padding:0;color:#000;}'
        . '</style>';
    $html .= '</head><body>';
    $html .= '<div class="pdf-wrapper">';
    if (!empty($headerImg)) $html .= '<div class="header"><img src="' . $headerImg . '" alt="Header"/></div>';
    $html .= '<div class="sheet">' . $middle . '</div>';
    $html .= '</div>';
    $html .= '</body></html>';

    $filename = 'Evaluation_Sheet_' . preg_replace('/[^A-Za-z0-9_-]/','_', $review) . '_G' . $groupId . '.pdf';

    sendJSON(['success' => true, 'html' => $html, 'filename' => $filename]);

} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>
