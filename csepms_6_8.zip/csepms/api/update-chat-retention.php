<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$retentionDays = intval($_POST['retention_days'] ?? 0);

if ($retentionDays < 1 || $retentionDays > 365) {
    sendJSON(['success' => false, 'message' => 'Retention period must be between 1 and 365 days']);
}

try {
    $query = "UPDATE project_config SET config_value = ? WHERE config_key = 'chat_retention_days'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $retentionDays);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update retention period');
    }
    
    sendJSON([
        'success' => true, 
        'message' => "Chat retention period updated to $retentionDays days"
    ]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
