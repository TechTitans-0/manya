<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$sheet_id = intval($_GET['sheet_id'] ?? 0);

if (!$sheet_id) {
    sendJSON(['success' => false, 'message' => 'Sheet ID is required']);
}

// Get evaluation sheet details with criteria
$query = "SELECT es.*, ec.id as criterion_id, ec.criterion_name, ec.max_marks, ec.display_order
          FROM evaluation_sheets es
          LEFT JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
          WHERE es.id = ?
          ORDER BY ec.display_order ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $sheet_id);
$stmt->execute();
$result = $stmt->get_result();

$sheet = null;
$criteria = [];

while ($row = $result->fetch_assoc()) {
    if (!$sheet) {
        $sheet = [
            'id' => $row['id'],
            'phase' => $row['phase'],
            'review' => $row['review'],
            'status' => $row['status'],
            'created_at' => $row['created_at']
        ];
    }
    
    if ($row['criterion_id']) {
        $criteria[] = [
            'id' => $row['criterion_id'],
            'name' => $row['criterion_name'],
            'max_marks' => $row['max_marks'],
            'display_order' => $row['display_order']
        ];
    }
}

$stmt->close();

if (!$sheet) {
    sendJSON(['success' => false, 'message' => 'Evaluation sheet not found']);
}

$sheet['criteria'] = $criteria;
sendJSON(['success' => true, 'sheet' => $sheet]);
?>
