<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

try {
    // Get selected academic year from session or default to ACTIVE
    $selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
    if (!$selectedAcademicYearId) {
        $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
    }

    // If no academic year exists, handle gracefully
    if (!$selectedAcademicYearId) {
        sendJSON(['success' => true, 'guides' => []]);
        exit;
    }

    // Get all guides - authorized guides first (includes registered and unregistered)
    // This ensures newly uploaded guides appear immediately on the staff page
    $query = "
        SELECT 
            COALESCE(g.id, ag.id) as id,
            g.user_id as user_id,
            ag.id as auth_id,
            g.id as guide_id,
            COALESCE(u.username, ag.name) as name,
            COALESCE(u.email, ag.email) as email,
            COALESCE(ag.designation, '') as designation,
            COALESCE(ag.research_domain_expertise, '') as research_domain_expertise,
            COALESCE(ag.years_of_experience, '') as years_of_experience,
            COALESCE(ag.branch, '') as branch,
            COALESCE(ag.phone_number, '') as phone_number,
            COALESCE(g.domain, '') as domain,
            COUNT(DISTINCT gr.id) as group_count,
            COALESCE(GROUP_CONCAT(DISTINCT gr.batch ORDER BY gr.batch SEPARATOR ', '), '') as batches,
            CASE WHEN u.id IS NOT NULL THEN 1 ELSE 0 END as is_registered,
            1 as is_authorized
        FROM authorized_guides ag
        LEFT JOIN guides g ON ag.employee_id = g.employee_id
        LEFT JOIN users u ON g.user_id = u.id AND u.role = 'guide'
        LEFT JOIN pgroups gr ON g.id = gr.guide_id AND gr.academic_year_id = ?
        GROUP BY ag.id, g.id
        ORDER BY COALESCE(u.username, ag.name) ASC";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception('Prepare statement failed: ' . $conn->error);
    }

    $stmt->bind_param('i', $selectedAcademicYearId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $guides = [];
    if ($result) {
        $guides = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        throw new Exception('Query execution failed: ' . $conn->error);
    }

    // Also include coordinators as guides, but exclude those who are already guides
    $coordQuery = "SELECT 
            c.id,
            NULL as auth_id,
            NULL as guide_id,
            COALESCE(u.username, '') as name,
            COALESCE(u.email, '') as email,
            COALESCE(c.designation, '') as designation,
            COALESCE(c.research_domain_expertise, '') as research_domain_expertise,
            COALESCE(c.years_of_experience, 0) as years_of_experience,
            COALESCE(c.department, '') as branch,
            COALESCE(u.phone, '') as phone_number,
            COALESCE(c.department, '') as domain,
            0 as group_count,
            '' as batches,
            1 as is_registered,
            0 as is_authorized
        FROM coordinators c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.id NOT IN (SELECT DISTINCT c1.id FROM coordinators c1 INNER JOIN guides g ON c1.employee_id = g.employee_id)
        ORDER BY COALESCE(u.username, '') ASC";

    $coordStmt = $conn->prepare($coordQuery);
    if (!$coordStmt) {
        throw new Exception('Coordinator query prepare failed: ' . $conn->error);
    }

    $coordStmt->execute();
    $coordRes = $coordStmt->get_result();
    
    if ($coordRes) {
        $coordinators = $coordRes->fetch_all(MYSQLI_ASSOC);
        // merge with guides
        $guides = array_merge($guides, $coordinators);
    }

    // optionally sort by name after merge
    usort($guides, function($a, $b) {
        return strcasecmp($a['name'] ?? '', $b['name'] ?? '');
    });

    sendJSON(['success' => true, 'guides' => $guides]);
} catch (Exception $e) {
    error_log('Error in get-guides.php: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to load guides: ' . $e->getMessage()]);
}
?>
