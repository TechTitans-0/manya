<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$query = "SELECT 
            s.id,
            s.usn,
            u.username as name,
            u.email
          FROM students s
          INNER JOIN users u ON s.user_id = u.id
          WHERE (s.group_id IS NULL OR s.group_id = 0)
          ORDER BY s.usn ASC";

$result = $conn->query($query);
$students = $result->fetch_all(MYSQLI_ASSOC);

sendJSON(['success' => true, 'students' => $students]);
?>