<?php
require_once '../config/config.php';
requireLogin();
// Prevent students from mutating project title/domain when academic year is completed
enforceReadOnlyForCompletedYear();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$projectTitle = isset($_POST['project_title']) ? trim($_POST['project_title']) : null;
$projectDomain = isset($_POST['project_domain']) ? trim($_POST['project_domain']) : null;
$customDomain = isset($_POST['custom_domain']) ? trim($_POST['custom_domain']) : null;

$groupId = $_SESSION['group_id'] ?? null;
if (!$groupId) {
    echo json_encode(['success' => false, 'message' => 'No group found for user.']);
    exit;
}

$fields = [];
$params = [];
$types = '';

if ($projectTitle !== null && $projectTitle !== '') {
    $fields[] = 'project_title = ?';
    $params[] = $projectTitle;
    $types .= 's';
}
if ($projectDomain !== null && $projectDomain !== '') {
    $finalDomain = ($projectDomain === 'Any others' && $customDomain) ? $customDomain : $projectDomain;
    $fields[] = 'domain = ?';
    $params[] = $finalDomain;
    $types .= 's';
}

if (empty($fields)) {
    echo json_encode(['success' => false, 'message' => 'No fields to update.']);
    exit;
}

$params[] = $groupId;
$types .= 'i';

$sql = 'UPDATE pgroups SET ' . implode(', ', $fields) . ' WHERE id = ?';
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Project title/domain updated successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update project title/domain.']);
}
$stmt->close();
?>
