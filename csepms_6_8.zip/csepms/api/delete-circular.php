<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Invalid circular ID']);
    exit;
}

// Fetch the circular to get the attachment path (if any)
// Fetch the circular to get identifying fields (we will delete all notifications that match these fields)
$stmt = $conn->prepare('SELECT title, message, attachment_path, created_at, academic_year_id, sender_id FROM notifications WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
if (!$row) {
    echo json_encode(['success' => false, 'message' => 'Circular not found']);
    exit;
}
$stmt->close();

$title = $row['title'];
$message = $row['message'];
$attachmentPath = $row['attachment_path'];
$createdAt = $row['created_at'];
$academicYearId = $row['academic_year_id'];
$senderId = $row['sender_id'];

// Check if the academic year is COMPLETED
if ($academicYearId) {
    $yearStmt = $conn->prepare('SELECT status FROM academic_years WHERE id = ?');
    $yearStmt->bind_param('i', $academicYearId);
    $yearStmt->execute();
    $yearResult = $yearStmt->get_result()->fetch_assoc();
    $yearStmt->close();
    
    if ($yearResult && $yearResult['status'] === 'COMPLETED') {
        echo json_encode(['success' => false, 'message' => 'Cannot modify data for completed academic years']);
        exit;
    }
}

// Delete all matching notifications for this sender, academic year, and exact circular signature
$delStmt = $conn->prepare('DELETE FROM notifications WHERE sender_id = ? AND academic_year_id = ? AND title = ? AND message = ? AND created_at = ?');
$delStmt->bind_param('iisss', $senderId, $academicYearId, $title, $message, $createdAt);
if ($delStmt->execute()) {
    // Optionally delete the attachment file (only once)
    if ($attachmentPath && file_exists('../' . $attachmentPath)) {
        @unlink('../' . $attachmentPath);
    }
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete circular']);
}
$delStmt->close();
