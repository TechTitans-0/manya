<?php
require_once __DIR__ . '/../config/config.php';
requireRole('coordinator');
header('Content-Type: application/json; charset=utf-8');

$review = isset($_POST['review']) ? intval($_POST['review']) : null;
$apply_all = isset($_POST['apply_all']) ? (int)$_POST['apply_all'] : 1;

if ($review === null) {
    echo json_encode(['success' => false, 'message' => 'Review is required']);
    exit;
}

// Update project_config (upsert)
$stmt = $conn->prepare("INSERT INTO project_config (config_key, config_value, description) VALUES ('current_review', ?, 'Current global review') ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)");
$val = (string)$review;
$stmt->bind_param('s', $val);
$stmt->execute();
$stmt->close();

// Update groups
if ($apply_all) {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_review = ?");
    $ustmt->bind_param('i', $review);
} else {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_review = ? WHERE project_status != 'completed'");
    $ustmt->bind_param('i', $review);
}
$ok = $ustmt->execute();
$affected = $ustmt->affected_rows;
$ustmt->close();

if ($ok) {
    echo json_encode(['success' => true, 'message' => "Current review set to {$review} (updated {$affected} groups)"]);
} else {
    echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
}

exit;
?>
