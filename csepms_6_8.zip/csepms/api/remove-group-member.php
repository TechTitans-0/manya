<?php
require_once '../config/config.php';
requireRole('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!$_SESSION['is_team_lead']) {
    sendJSON(['success' => false, 'message' => 'Only team leads can remove members'], 403);
}

$memberId = intval($_POST['member_id'] ?? 0);

if (!$memberId) {
    sendJSON(['success' => false, 'message' => 'Member ID is required']);
}

try {
    $conn->begin_transaction();

    // Check if group can still be edited (no guide assigned)
    $groupCheckQuery = "SELECT guide_id FROM pgroups WHERE id = ?";
    $stmt = $conn->prepare($groupCheckQuery);
    $stmt->bind_param("i", $_SESSION['group_id']);
    $stmt->execute();
    $groupData = $stmt->get_result()->fetch_assoc();

    if ($groupData['guide_id'] !== null) {
        throw new Exception('Cannot remove members after a guide is assigned');
    }

    // Check if member is in the same group and is not the team lead
    $memberQuery = "SELECT s.id, s.is_team_lead FROM students s WHERE s.id = ? AND s.group_id = ?";
    $stmt = $conn->prepare($memberQuery);
    $stmt->bind_param("ii", $memberId, $_SESSION['group_id']);
    $stmt->execute();
    $memberData = $stmt->get_result()->fetch_assoc();

    if (!$memberData) {
        throw new Exception('Member not found in your group');
    }

    if ($memberData['is_team_lead']) {
        throw new Exception('Cannot remove the team lead');
    }

    // Remove student from group
    $updateStudentQuery = "UPDATE students SET group_id = NULL WHERE id = ?";
    $stmt = $conn->prepare($updateStudentQuery);
    $stmt->bind_param("i", $memberId);
    $stmt->execute();

    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Member removed successfully']);

} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>