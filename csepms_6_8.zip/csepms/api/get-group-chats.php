<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

$groupChats = [];

if (hasRole('student')) {
    if (isset($_SESSION['group_id']) && $_SESSION['group_id']) {
        // Get project group chat (with guide and all group members)
        $groupQuery = "SELECT g.id as group_id, g.group_name, 
                   gu.username as guide_name,
                   COUNT(DISTINCT s.id) as member_count
                   FROM pgroups g
                   LEFT JOIN guides gd ON g.guide_id = gd.id
                   LEFT JOIN users gu ON gd.user_id = gu.id
                   LEFT JOIN students s ON s.group_id = g.id
                   WHERE g.id = ?
                   GROUP BY g.id";
        $stmt = $conn->prepare($groupQuery);
        $stmt->bind_param("i", $_SESSION['group_id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result) {
            $groupChats[] = [
                'id' => 'group_' . $result['group_id'],
                'name' => $result['group_name'] . ' (Team Chat)',
                'type' => 'project_group',
                'group_id' => $result['group_id'],
                'member_count' => $result['member_count'],
                'icon' => 'fa-users'
            ];
        }
    }
    
} elseif (hasRole('guide')) {
    // Get all groups assigned to this guide
    $groupsQuery = "SELECT g.id as group_id, g.group_name,
                    COUNT(DISTINCT s.id) as member_count
                    FROM pgroups g
                    LEFT JOIN students s ON s.group_id = g.id
                    WHERE g.guide_id = ?
                    GROUP BY g.id
                    ORDER BY g.group_name ASC";
    $stmt = $conn->prepare($groupsQuery);
    $stmt->bind_param("i", $_SESSION['role_id']);
    $stmt->execute();
    $groups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    foreach ($groups as $group) {
        $groupChats[] = [
            'id' => 'group_' . $group['group_id'],
            'name' => $group['group_name'] . ' (Team Chat)',
            'type' => 'project_group',
            'group_id' => $group['group_id'],
            'member_count' => $group['member_count'],
            'icon' => 'fa-users'
        ];
    }
    
} elseif (hasRole('coordinator')) {
    // All students group chat
    $studentsCount = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc();
    $groupChats[] = [
        'id' => 'all_students',
        'name' => 'All Students',
        'type' => 'all_students',
        'member_count' => $studentsCount['count'],
        'icon' => 'fa-user-graduate'
    ];
    
    // All guides group chat
    $guidesCount = $conn->query("SELECT COUNT(*) as count FROM guides")->fetch_assoc();
    $groupChats[] = [
        'id' => 'all_guides',
        'name' => 'All Guides',
        'type' => 'all_guides',
        'member_count' => $guidesCount['count'],
        'icon' => 'fa-chalkboard-teacher'
    ];
}

sendJSON(['success' => true, 'groupChats' => $groupChats]);
?>
