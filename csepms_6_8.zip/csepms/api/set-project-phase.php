<?php
require_once __DIR__ . '/../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json; charset=utf-8');

$phase = isset($_POST['phase']) ? intval($_POST['phase']) : null;
$review = isset($_POST['review']) ? intval($_POST['review']) : null;
$apply_all = isset($_POST['apply_all']) ? (int)$_POST['apply_all'] : 1;

if ($phase === null || $review === null) {
    echo json_encode(['success' => false, 'message' => 'Phase and review are required']);
    exit;
}

// Prepare update
if ($apply_all) {
    $stmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?, current_review = ?");
    $stmt->bind_param('ii', $phase, $review);
} else {
    // If not applying to all, update only groups that are not completed
    $stmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?, current_review = ? WHERE project_status != 'completed'");
    $stmt->bind_param('ii', $phase, $review);
}

$ok = $stmt->execute();
if ($ok) {
    $affected = $stmt->affected_rows;
    echo json_encode(['success' => true, 'message' => "Updated phase/review for {$affected} groups"]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$stmt->close();
exit;
?>
