<?php
require_once '../config/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hasRole('coordinator')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$projectType = getCurrentProjectType();
$lastYear = $conn->query("SELECT year_label FROM academic_years ORDER BY year_label DESC LIMIT 1");
$nextYear = '';
if ($row = $lastYear->fetch_assoc()) {
    if ($projectType === 'mini') {
        // For mini projects, year_label is just YYYY, increment by 1
        $currentYear = intval($row['year_label']);
        $nextYear = strval($currentYear + 1);
    } else {
        // For major projects, year_label is YYYY-YYYY format
        $parts = explode('-', $row['year_label']);
        if (count($parts) == 2) {
            $start = intval($parts[0]);
            $end = intval($parts[1]);
            $nextYear = ($start+1) . '-' . ($end+1);
        }
    }
}
if (!$nextYear) {
    $nextYear = ($projectType === 'mini') ? '2026' : '2026-2027';
}
$stmt = $conn->prepare("INSERT IGNORE INTO academic_years (year_label) VALUES (?)");
$stmt->bind_param('s', $nextYear);
$stmt->execute();
if ($stmt->affected_rows > 0) {
    echo json_encode(['success' => true, 'year' => $nextYear]);
} else {
    echo json_encode(['success' => false, 'message' => 'Academic year already exists or failed to add.']);
}
