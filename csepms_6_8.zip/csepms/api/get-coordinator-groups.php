<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

// Get coordinator's groups (where they are assigned as coordinator_guide)
$query = "SELECT g.* FROM pgroups g WHERE g.coordinator_guide_id = ? ORDER BY g.group_name";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$groups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

header('Content-Type: application/json');
sendJSON(['success' => true, 'groups' => $groups]);
?>
