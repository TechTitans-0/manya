<?php
require_once __DIR__ . '/../config/config.php';
requireRole('coordinator');
header('Content-Type: application/json; charset=utf-8');

$phase = isset($_POST['phase']) ? intval($_POST['phase']) : null;
$apply_all = isset($_POST['apply_all']) ? (int)$_POST['apply_all'] : 1;
$mark_completed = isset($_POST['mark_completed']) ? (int)$_POST['mark_completed'] : 0;

if ($phase === null) {
    echo json_encode(['success' => false, 'message' => 'Phase is required']);
    exit;
}

// Update project_config (upsert)
$stmt = $conn->prepare("INSERT INTO project_config (config_key, config_value, description) VALUES ('current_phase', ?, 'Current global phase') ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)");
$val = (string)$phase;
$stmt->bind_param('s', $val);
$stmt->execute();
$stmt->close();

// Update groups
if ($apply_all) {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?");
    $ustmt->bind_param('i', $phase);
} else {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ? WHERE project_status != 'completed'");
    $ustmt->bind_param('i', $phase);
}
$ok = $ustmt->execute();
$affected = $ustmt->affected_rows;
$ustmt->close();

// Optionally mark completed groups? (handled by complete endpoint)
if ($ok) {
    echo json_encode(['success' => true, 'message' => "Current phase set to {$phase} (updated {$affected} groups)"]);
} else {
    echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
}

exit;
?>
