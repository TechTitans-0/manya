<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

header('Content-Type: application/json');

$yearId = isset($_POST['year_id']) ? intval($_POST['year_id']) : null;

if (!$yearId) {
    sendJSON(['success' => false, 'message' => 'Year ID required'], 400);
}

// Verify the year exists
$year = $conn->query("SELECT id, status FROM academic_years WHERE id = " . intval($yearId) . " LIMIT 1")->fetch_assoc();
if (!$year) {
    sendJSON(['success' => false, 'message' => 'Academic year not found'], 404);
}

// Update session
$_SESSION['academic_year_id'] = intval($yearId);

sendJSON(['success' => true, 'message' => 'Year updated', 'year_id' => $yearId, 'status' => $year['status']]);
?>
