<?php
require_once '../config/config.php';

// Allow both guides and coordinators to fetch evaluation sheet criteria
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}
if (!hasRole('guide') && !hasRole('coordinator')) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

header('Content-Type: application/json');

$sheetId = intval($_GET['id'] ?? 0);

if (!$sheetId) {
    sendJSON(['success' => false, 'message' => 'Evaluation sheet ID is required']);
}

$isMiniProject = getCurrentProjectType() === 'mini';

if ($isMiniProject) {
    // For mini projects, no phase/review columns
    $query = "SELECT es.id, es.subject_code, es.title, es.status, ec.id as criterion_id, ec.criterion_name, ec.max_marks, ec.display_order
              FROM evaluation_sheets es
              INNER JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
              WHERE es.id = ?
              ORDER BY ec.display_order ASC";
} else {
    // For major projects, include phase/review
    $query = "SELECT es.*, ec.id as criterion_id, ec.criterion_name, ec.max_marks, ec.display_order
              FROM evaluation_sheets es
              INNER JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
              WHERE es.id = ?
              ORDER BY ec.display_order ASC";
}

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $sheetId);
$stmt->execute();
$result = $stmt->get_result();

$evaluationSheet = null;
$criteria = [];

while ($row = $result->fetch_assoc()) {
    if (!$evaluationSheet) {
        if ($isMiniProject) {
            $evaluationSheet = [
                'id' => $row['id'],
                'subject_code' => $row['subject_code'],
                'title' => $row['title'],
                'status' => $row['status']
            ];
        } else {
            $evaluationSheet = [
                'id' => $row['id'],
                'phase' => $row['phase'],
                'review' => $row['review'],
                'title' => $row['title']
            ];
        }
    }

    $criteria[] = [
        'id' => $row['criterion_id'],
        'name' => $row['criterion_name'],
        'max_marks' => $row['max_marks']
    ];
}

if (!$evaluationSheet) {
    sendJSON(['success' => false, 'message' => 'Evaluation sheet not found']);
}

sendJSON([
    'success' => true,
    'evaluation_sheet' => $evaluationSheet,
    'criteria' => $criteria
]);
?>