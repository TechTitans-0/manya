<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get all registered coordinators from coordinators table
$query = "SELECT c.id, u.username, u.email, u.phone, c.department,
          c.designation, c.research_domain_expertise, c.years_of_experience
          FROM coordinators c
          INNER JOIN users u ON c.user_id = u.id
          WHERE u.role = 'coordinator'";

$result = $conn->query($query);
$coordinators = [];
while ($row = $result->fetch_assoc()) {
    $coordinators[] = $row;
}

echo json_encode(['success' => true, 'coordinators' => $coordinators]);
