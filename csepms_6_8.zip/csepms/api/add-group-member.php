<?php
require_once '../config/config.php';
requireRole('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!$_SESSION['is_team_lead']) {
    sendJSON(['success' => false, 'message' => 'Only team leads can add members'], 403);
}

$memberName = sanitizeInput($_POST['member_name'] ?? '');
$memberUSN = strtoupper(sanitizeInput($_POST['member_usn'] ?? ''));

if (empty($memberName) || empty($memberUSN)) {
    sendJSON(['success' => false, 'message' => 'Member name and USN are required']);
}

try {
    $conn->begin_transaction();

    // Check if group can still be edited (no guide assigned)
    $groupCheckQuery = "SELECT guide_id FROM pgroups WHERE id = ?";
    $stmt = $conn->prepare($groupCheckQuery);
    $stmt->bind_param("i", $_SESSION['group_id']);
    $stmt->execute();
    $groupData = $stmt->get_result()->fetch_assoc();

    if ($groupData['guide_id'] !== null) {
        throw new Exception('Cannot add members after a guide is assigned');
    }

    // Check if student exists and is not in any group
    $studentQuery = "SELECT s.id, s.group_id, s.name FROM students s
                     WHERE UPPER(s.usn) = ?";
    $stmt = $conn->prepare($studentQuery);
    $stmt->bind_param("s", $memberUSN);
    $stmt->execute();
    $studentData = $stmt->get_result()->fetch_assoc();

    if (!$studentData) {
        throw new Exception('Student with USN ' . $memberUSN . ' not found in the system');
    }

    if ($studentData['group_id'] !== null) {
        throw new Exception('Student with USN ' . $memberUSN . ' is already in a group');
    }

    // Update student's name if provided
    if (!empty($memberName) && $memberName !== $studentData['name']) {
        $updateNameQuery = "UPDATE students SET name = ? WHERE id = ?";
        $stmt = $conn->prepare($updateNameQuery);
        $stmt->bind_param("si", $memberName, $studentData['id']);
        $stmt->execute();
    }

    // Add student to group
    $updateStudentQuery = "UPDATE students SET group_id = ? WHERE id = ?";
    $stmt = $conn->prepare($updateStudentQuery);
    $stmt->bind_param("ii", $_SESSION['group_id'], $studentData['id']);
    $stmt->execute();

    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Member added successfully']);

} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>