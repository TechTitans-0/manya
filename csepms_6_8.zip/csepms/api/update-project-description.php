<?php
require_once '../config/config.php';
requireRole('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!$_SESSION['is_team_lead']) {
    sendJSON(['success' => false, 'message' => 'Only team leads can update project description'], 403);
}

$projectDescription = sanitizeInput($_POST['project_description'] ?? '');

if (empty($projectDescription)) {
    sendJSON(['success' => false, 'message' => 'Project description is required']);
}

try {
    // Team lead can always update project description
    $updateQuery = "UPDATE pgroups SET project_description = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("si", $projectDescription, $_SESSION['group_id']);
    $stmt->execute();

    sendJSON(['success' => true, 'message' => 'Project description updated successfully']);

} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>