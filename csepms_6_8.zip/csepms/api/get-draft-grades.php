<?php
require_once '../config/config.php';
requireRole('guide');

header('Content-Type: application/json');

// Fetch draft grades (status != 'submitted') for groups assigned to this guide
$guideId = intval($_SESSION['role_id']);

$query = "SELECT sg.*, s.usn, u.username, s.name, g.id as group_id, g.group_name, es.id as evaluation_sheet_id, es.title as sheet_title, es.phase, es.review, sgd.criterion_id, sgd.marks_obtained, ec.criterion_name, ec.max_marks
          FROM student_grades sg
          INNER JOIN students s ON sg.student_id = s.id
          INNER JOIN users u ON s.user_id = u.id
          INNER JOIN pgroups g ON sg.group_id = g.id
          INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
          LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
          LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
          WHERE g.guide_id = ? AND sg.status = 'draft'
          ORDER BY g.group_name ASC, es.phase DESC, es.review DESC, s.usn ASC, ec.id ASC";

$stmt = $conn->prepare($query);
if (!$stmt) {
    sendJSON(['success' => false, 'message' => 'Database prepare error']);
}
$stmt->bind_param('i', $guideId);
$stmt->execute();
$result = $stmt->get_result();

$drafts = [];
$currentId = null;
$current = null;

while ($row = $result->fetch_assoc()) {
    $gradeId = $row['id'];
    if ($currentId !== $gradeId) {
        if ($current !== null) {
            $drafts[] = $current;
        }

        $currentId = $gradeId;
        $current = [
            'id' => $row['id'],
            'group_id' => intval($row['group_id']),
            'group_name' => $row['group_name'],
            'evaluation_sheet_id' => intval($row['evaluation_sheet_id']),
            'sheet_title' => $row['sheet_title'],
            'phase' => $row['phase'],
            'review' => $row['review'],
            'student_id' => intval($row['student_id']),
            'usn' => $row['usn'],
            'student_name' => $row['name'] ?: $row['username'],
            'total_marks' => floatval($row['total_marks']),
            'status' => $row['status'] ?: 'draft',
            'criteria' => []
        ];
    }

    if ($row['criterion_id']) {
        $current['criteria'][] = [
            'criterion_id' => intval($row['criterion_id']),
            'criterion_name' => $row['criterion_name'],
            'max_marks' => floatval($row['max_marks']),
            'marks_obtained' => floatval($row['marks_obtained'])
        ];
    }
}

if ($current !== null) $drafts[] = $current;

sendJSON(['success' => true, 'drafts' => $drafts]);

?>
