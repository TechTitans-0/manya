<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$currentPhase = isset($_GET['current_phase']) ? intval($_GET['current_phase']) : 1;

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

try {
    // Build main query for registered students - filter by academic_year_id
     $studentsQuery = "SELECT 
                     s.id,
                     s.usn,
                     u.username as name,
                     u.email,
                     s.year_of_passing,
                     s.group_id,
                     g.batch,
                     ay.year_label as academic_year,
                     g.group_name,
                     g.project_title,
                     gu.username as guide_name,
                     g.coordinator_guide_id,
                     c.username as coordinator_name,
                     (SELECT IFNULL(SUM(sg.total_marks),0)
                      FROM student_grades sg
                      WHERE sg.student_id = s.id AND sg.status IN ('submitted', 'approved')) as total_marks_obtained,
                     (SELECT IFNULL(SUM(sg.max_marks),0)
                      FROM student_grades sg
                      WHERE sg.student_id = s.id AND sg.status IN ('submitted', 'approved')) as total_marks_max
                  FROM students s
                  INNER JOIN users u ON s.user_id = u.id
                  LEFT JOIN pgroups g ON s.group_id = g.id AND g.academic_year_id = $selectedAcademicYearId
                  LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
                  LEFT JOIN guides gd ON g.guide_id = gd.id
                  LEFT JOIN users gu ON gd.user_id = gu.id
                  LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
                  LEFT JOIN users c ON cd.user_id = c.id
                  WHERE s.academic_year_id = $selectedAcademicYearId";

    // Build query for authorized-but-unregistered students (those in authorized_students but not in students)
    $authSelect = "SELECT NULL as id, a.usn, a.name as name, a.email as email, NULL as year_of_passing, NULL as group_id, NULL as batch, NULL as academic_year, NULL as group_name, NULL as project_title, NULL as guide_name, NULL as coordinator_guide_id, NULL as coordinator_name, NULL as total_marks_obtained, NULL as total_marks_max
                   FROM authorized_students a
                   LEFT JOIN students s ON LOWER(a.usn) = LOWER(s.usn) AND s.academic_year_id = $selectedAcademicYearId
                   WHERE s.id IS NULL AND a.academic_year_id = $selectedAcademicYearId";

    // Combine with UNION so we can show both sets together
    $query = "SELECT * FROM ( (" . $studentsQuery . ") UNION ALL (" . $authSelect . ") ) AS combined ORDER BY CASE WHEN group_id IS NULL OR group_id = 0 THEN 1 ELSE 0 END, batch ASC, usn ASC";
    
    $result = $conn->query($query);
    
    if (!$result) {
        throw new Exception($conn->error);
    }

    $result = $conn->query($query);
    
    if (!$result) {
        throw new Exception($conn->error);
    }
    
    $students = [];
    while ($row = $result->fetch_assoc()) {
        // For mini projects, use total marks instead of phase-specific reviews
        $row['phase1_review1_obtained'] = $row['total_marks_obtained'];
        $row['phase1_review1_total'] = $row['total_marks_max'];
        $row['phase1_review2_obtained'] = null; // No second review in mini projects
        $row['phase1_review2_total'] = null;
        $row['phase2_review1_obtained'] = null; // No phases in mini projects
        $row['phase2_review1_total'] = null;
        $row['phase2_review2_obtained'] = null;
        $row['phase2_review2_total'] = null;
        
        // Calculate marks flags for current phase reviews
        $review1Field = "phase{$currentPhase}_review1_obtained";
        $review2Field = "phase{$currentPhase}_review2_obtained";
        $row['phase' . $currentPhase . '_review1_marks'] = ($row[$review1Field] !== null && $row[$review1Field] > 0);
        $row['phase' . $currentPhase . '_review2_marks'] = false; // Always false for mini projects
        
        // Format marks with 2 decimal places
        if ($row[$review1Field] !== null) {
            $row[$review1Field] = number_format($row[$review1Field], 2);
            $row["phase{$currentPhase}_review1_total"] = number_format($row["phase{$currentPhase}_review1_total"], 2);
        }
        
        $students[] = $row;
    }

    sendJSON(['success' => true, 'students' => $students]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
