<?php
require_once '../config/config.php';
require_once '../includes/auth.class.php';

header('Content-Type: application/json');

if (!$conn) {
    sendJSON(['success' => false, 'message' => 'Database connection failed']);
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
    }

    $role = sanitizeInput($_POST['role'] ?? '');
    $password = $_POST['password'] ?? '';
    $projectType = sanitizeInput($_POST['project_type'] ?? '');

    if (empty($role) || empty($password)) {
        sendJSON(['success' => false, 'message' => 'All fields are required']);
    }

    // Update session project type if provided
    if (!empty($projectType) && in_array($projectType, ['major', 'mini'])) {
        $_SESSION['project_type'] = $projectType;
    }

    // Ensure database connection is correct for the project type
    if (isset($_SESSION['project_type'])) {
        global $conn;
        if ($conn) {
            $conn->close();
        }
        $dbName = getDatabaseName($_SESSION['project_type']);
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
        if ($conn->connect_error) {
            sendJSON(['success' => false, 'message' => 'Database connection failed']);
        } else {
            $conn->set_charset("utf8mb4");
        }
    }

    // Validate password strength
    if (strlen($password) < 6) {
        sendJSON(['success' => false, 'message' => 'Password must be at least 6 characters']);
    }

    $data = [
        'username' => strtolower(sanitizeInput($_POST['username'] ?? '')),
        'email' => sanitizeInput($_POST['email'] ?? ''),
        'phone' => sanitizeInput($_POST['phone'] ?? ''),
        'password' => $password
    ];

    if ($role === 'student') {
        $data['usn'] = strtoupper(sanitizeInput($_POST['usn'] ?? ''));
        $data['year_of_passing'] = intval($_POST['year_of_passing'] ?? 0);
        $data['branch'] = sanitizeInput($_POST['branch'] ?? '');
    } elseif ($role === 'guide') {
        $data['employee_id'] = strtoupper(sanitizeInput($_POST['employee_id'] ?? ''));
        $data['domain'] = sanitizeInput($_POST['domain'] ?? '');
        $data['department'] = sanitizeInput($_POST['department'] ?? '');
    } elseif ($role === 'coordinator') {
        $data['employee_id'] = strtoupper(sanitizeInput($_POST['employee_id'] ?? ''));
        $data['department'] = sanitizeInput($_POST['department'] ?? '');
        // professional details
        $data['designation'] = sanitizeInput($_POST['designation'] ?? '');
        $data['research_domain_expertise'] = sanitizeInput($_POST['research_domain_expertise'] ?? '');
        $data['years_of_experience'] = intval($_POST['years_of_experience'] ?? 0);
    }

    $auth = new Auth($conn);
    $result = $auth->register($data, $role);

    sendJSON($result);
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()]);
}
?>
