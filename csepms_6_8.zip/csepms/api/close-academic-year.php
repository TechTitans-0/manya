<?php
require_once '../config/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hasRole('coordinator')) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// 1. Fetch current ACTIVE academic year
$active = $conn->query("SELECT * FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
if (!$active) {
    echo json_encode(['success' => false, 'message' => 'No active academic year found.']);
    exit;
}

// 2. Mark it as COMPLETED
$conn->begin_transaction();
try {
    $conn->query("UPDATE academic_years SET status = 'COMPLETED' WHERE id = " . intval($active['id']));

// 3. Generate next academic year label
$projectType = getCurrentProjectType();
if ($projectType === 'mini') {
    // For mini projects, year_label is just YYYY, increment by 1
    $currentYear = intval($active['year_label']);
    $nextLabel = strval($currentYear + 1);
} else {
    // For major projects, year_label is YYYY-YYYY format
    $parts = explode('-', $active['year_label']);
    if (count($parts) == 2) {
        $start = intval($parts[0]);
        $end = intval($parts[1]);
        $nextLabel = ($start+1) . '-' . ($end+1);
    } else {
        throw new Exception('Invalid year label format.');
    }
}

    // 4. Insert new year as ACTIVE if not exists
    $stmt = $conn->prepare("INSERT IGNORE INTO academic_years (year_label, status) VALUES (?, 'ACTIVE')");
    $stmt->bind_param('s', $nextLabel);
    $stmt->execute();

    // 5. Get the new ACTIVE year
    $newYear = $conn->query("SELECT * FROM academic_years WHERE year_label = '".$conn->real_escape_string($nextLabel)."'")->fetch_assoc();
    if (!$newYear) throw new Exception('Failed to create new academic year.');

    $conn->commit();
    echo json_encode([
        'success' => true,
        'message' => 'Academic year closed and new year created: ' . $nextLabel,
        'new_year' => [
            'id' => $newYear['id'],
            'year_label' => $newYear['year_label'],
            'status' => $newYear['status']
        ]
    ]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
