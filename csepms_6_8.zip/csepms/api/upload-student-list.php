<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    sendJSON(['success' => false, 'message' => 'No file uploaded or upload error']);
}

$file = $_FILES['file'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

if (!in_array($ext, ['csv'])) {
    sendJSON(['success' => false, 'message' => 'Only CSV files are allowed']);
}

try {
    // Check if the academic year is COMPLETED
    $selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
    if (!$selectedAcademicYearId) {
        $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
    }
    
    if ($selectedAcademicYearId) {
        $yearStmt = $conn->prepare('SELECT status FROM academic_years WHERE id = ?');
        $yearStmt->bind_param('i', $selectedAcademicYearId);
        $yearStmt->execute();
        $yearResult = $yearStmt->get_result()->fetch_assoc();
        $yearStmt->close();
        
        if ($yearResult && $yearResult['status'] === 'COMPLETED') {
            sendJSON(['success' => false, 'message' => 'Cannot upload students for completed academic years']);
        }
    }

    $data = [];

    // Parse CSV file
    $handle = fopen($file['tmp_name'], 'r');
    if (!$handle) {
        throw new Exception('Failed to read file');
    }

    $headers = fgetcsv($handle);
    if (!$headers) {
        fclose($handle);
        throw new Exception('Empty or invalid CSV file');
    }

    // Map columns (flexible)
    $columnMap = [];
    foreach ($headers as $i => $h) {
        $h = strtolower(trim($h));
        if (strpos($h, 'usn') !== false || strpos($h, 'id') !== false) $columnMap['usn'] = $i;
        if (strpos($h, 'name') !== false) $columnMap['name'] = $i;
        if (strpos($h, 'email') !== false) $columnMap['email'] = $i;
        if (strpos($h, 'phone') !== false) $columnMap['phone'] = $i;
        if (strpos($h, 'year') !== false || strpos($h, 'academic') !== false) $columnMap['academic_year'] = $i;
        if (strpos($h, 'branch') !== false || strpos($h, 'department') !== false) $columnMap['department'] = $i;
    }

    // sensible defaults
    if (!isset($columnMap['usn'])) $columnMap['usn'] = 0;
    if (!isset($columnMap['name'])) $columnMap['name'] = 1;
    if (!isset($columnMap['email'])) $columnMap['email'] = 2;
    if (!isset($columnMap['phone'])) $columnMap['phone'] = 3;

    while (($row = fgetcsv($handle)) !== FALSE) {
        if (empty($row)) continue;
        $usn = trim($row[$columnMap['usn']] ?? '');
        if ($usn === '') continue;
        $entry = [
            'usn' => $usn,
            'name' => trim($row[$columnMap['name']] ?? ''),
            'email' => trim($row[$columnMap['email']] ?? ''),
            'phone' => trim($row[$columnMap['phone']] ?? ''),
            'academic_year' => isset($columnMap['academic_year']) ? trim($row[$columnMap['academic_year']] ?? '') : '',
            'department' => isset($columnMap['department']) ? trim($row[$columnMap['department']] ?? '') : ''
        ];
        $data[] = $entry;
    }
    fclose($handle);

    if (empty($data)) {
        throw new Exception('No valid rows found in CSV');
    }

    $conn->begin_transaction();

    $inserted = 0;
    $updated = 0;
    $errors = [];
    $rows = [];

    // Detect which optional columns exist in authorized_students
    $hasStatusCol = false;
    $hasAcademicCol = false; // corresponds to academic_year_id INT FK
    $hasDepartmentCol = false;
    $colStmt = $conn->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'authorized_students'");
    if ($colStmt) {
        $colStmt->execute();
        $colRes = $colStmt->get_result();
        while ($c = $colRes->fetch_assoc()) {
            $col = strtolower($c['COLUMN_NAME']);
            if ($col === 'status') $hasStatusCol = true;
            if ($col === 'academic_year_id') $hasAcademicCol = true;
            if ($col === 'department') $hasDepartmentCol = true;
        }
    }

    // Fetch current active academic year id (single-source)
    $activeYearId = null;
    $res = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        $activeYearId = (int)$row['id'];
    }
    if ($activeYearId === null) {
        throw new Exception('No active academic year configured');
    }

    foreach ($data as $student) {
        $usn = strtoupper($student['usn']);
        $email = $student['email'];
        $phone = $student['phone'];
        // Always set academic_year_id to the currently ACTIVE academic year (no manual selection)
        $academic_year_id = $activeYearId;
        $department = $student['department'] ?? '';

        // Check if authorized record exists (select columns depending on schema)
        if ($hasStatusCol) {
            $chk = $conn->prepare("SELECT id, status FROM authorized_students WHERE LOWER(usn) = LOWER(?)");
        } else {
            $chk = $conn->prepare("SELECT id FROM authorized_students WHERE LOWER(usn) = LOWER(?)");
        }
        $chk->bind_param('s', $usn);
        $chk->execute();
        $res = $chk->get_result();

        if ($res && $res->num_rows > 0) {
            $r = $res->fetch_assoc();
            $isRegistered = ($hasStatusCol && isset($r['status']) && strtolower($r['status']) === 'registered');
            // only update if not already registered
            if (!$isRegistered) {
                // build update SQL according to available columns
                $sets = ['name = ?', 'email = ?', 'phone = ?'];
                $types = 'sss';
                $params = [$student['name'], $email, $phone];
                if ($hasAcademicCol) {
                    $sets[] = 'academic_year_id = ?'; $types .= 'i'; $params[] = $academic_year_id;
                }
                if ($hasDepartmentCol) {
                    $sets[] = 'department = ?'; $types .= 's'; $params[] = $department;
                }
                // If status column exists, only set it to 'Authorized' when it is currently NULL/empty
                if ($hasStatusCol) {
                    $sets[] = "status = CASE WHEN status IS NULL OR status = '' THEN 'Authorized' ELSE status END";
                }
                $sets[] = 'uploaded_at = CURRENT_TIMESTAMP';
                $sql = 'UPDATE authorized_students SET ' . implode(', ', $sets) . ' WHERE id = ?';
                $types .= 'i'; $params[] = $r['id'];
                $upd = $conn->prepare($sql);
                if ($upd) {
                    // bind params dynamically
                    $bindNames = []; $bindNames[] = & $types;
                    for ($i = 0; $i < count($params); $i++) { $bindNames[] = & $params[$i]; }
                    call_user_func_array([$upd, 'bind_param'], $bindNames);
                    if ($upd->execute()) {
                        $updated++;
                    } else {
                        $errors[] = "Failed to update authorized record for $usn";
                    }
                } else {
                    $errors[] = "Failed to prepare update for $usn";
                }
            }
        } else {
            // build insert SQL according to available columns
            $cols = ['usn', 'name', 'email', 'phone'];
            $placeholders = ['?', '?', '?', '?'];
            $types = 'ssss';
            $params = [$usn, $student['name'], $email, $phone];
            if ($hasAcademicCol) { $cols[] = 'academic_year_id'; $placeholders[] = '?'; $types .= 'i'; $params[] = $academic_year_id; }
            if ($hasDepartmentCol) { $cols[] = 'department'; $placeholders[] = '?'; $types .= 's'; $params[] = $department; }
            // explicitly set status to 'Authorized' on insert when column exists
            if ($hasStatusCol) { $cols[] = 'status'; $placeholders[] = '?'; $types .= 's'; $params[] = 'Authorized'; }
            $cols[] = 'uploaded_at'; $placeholders[] = 'CURRENT_TIMESTAMP';
            $sql = 'INSERT INTO authorized_students (' . implode(', ', $cols) . ') VALUES (' . implode(', ', $placeholders) . ')';
            $ins = $conn->prepare($sql);
            if ($ins) {
                if (count($params) > 0) {
                    $bindNames = []; $bindNames[] = & $types;
                    for ($i = 0; $i < count($params); $i++) { $bindNames[] = & $params[$i]; }
                    call_user_func_array([$ins, 'bind_param'], $bindNames);
                }
                if ($ins->execute()) {
                    $inserted++;
                } else {
                    $errors[] = "Failed to insert authorized record for $usn";
                }
            } else {
                $errors[] = "Failed to prepare insert for $usn";
            }
        }

        $rows[] = ['usn' => $usn];
    }

    $conn->commit();

    sendJSON([
        'success' => true,
        'message' => "Import completed: $inserted inserted, $updated updated",
        'details' => ['inserted' => $inserted, 'updated' => $updated, 'errors' => $errors, 'rows' => $rows]
    ]);

} catch (Exception $e) {
    if ($conn && $conn->connect_errno === 0) {
        $conn->rollback();
    }
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>
