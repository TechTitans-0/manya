<?php
require_once '../config/config.php';
require_once '../includes/auth.class.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$email = sanitizeInput($_POST['email'] ?? '');

if (empty($email)) {
    sendJSON(['success' => false, 'message' => 'Email is required']);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJSON(['success' => false, 'message' => 'Invalid email format']);
}

$auth = new Auth($conn);
$result = $auth->requestPasswordReset($email);

sendJSON($result);
?>
