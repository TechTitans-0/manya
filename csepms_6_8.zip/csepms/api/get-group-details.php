<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

// Determine group_id based on role
$groupId = null;

if (hasRole('coordinator') || hasRole('guide')) {
    // For coordinator or guide, get group_id from request
    $groupId = intval($_GET['group_id'] ?? 0);
    if (!$groupId) {
        sendJSON(['success' => false, 'message' => 'Group ID is required']);
    }
} else {
    // For student, use their assigned group
    if (!isset($_SESSION['group_id']) || !$_SESSION['group_id']) {
        // Clear stale session if student has no group
        unset($_SESSION['group_id']);
        unset($_SESSION['is_team_lead']);
        sendJSON(['success' => false, 'message' => 'You are not part of any group']);
    }
    $groupId = $_SESSION['group_id'];
}

// Get group details

$groupQuery = "SELECT g.*, gu.username as guide_name, gu.email as guide_email, g.coordinator_guide_id, c.username as coordinator_name
               FROM pgroups g
               LEFT JOIN guides gd ON g.guide_id = gd.id
               LEFT JOIN users gu ON gd.user_id = gu.id
               LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
               LEFT JOIN users c ON cd.user_id = c.id
               WHERE g.id = ?";

$stmt = $conn->prepare($groupQuery);
$stmt->bind_param("i", $groupId);
$stmt->execute();
$group = $stmt->get_result()->fetch_assoc();

if (!$group) {
    // Clear stale session if group no longer exists
    if (hasRole('student')) {
        unset($_SESSION['group_id']);
        unset($_SESSION['is_team_lead']);
    }
    sendJSON(['success' => false, 'message' => 'Group not found']);
}

// Get global phase and review settings
$globalSettings = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$current_phase = 1;
$current_review = 1;
while ($row = $globalSettings->fetch_assoc()) {
    if ($row['setting_key'] === 'current_phase') $current_phase = intval($row['setting_value']);
    if ($row['setting_key'] === 'current_review') $current_review = intval($row['setting_value']);
}

// Add global phase/review to group data (override any group-specific values)
$group['current_phase'] = $current_phase;
$group['current_review'] = $current_review;

// Fetch academic year label for the group's academic_year_id if available
if (!empty($group['academic_year_id'])) {
    $ayStmt = $conn->prepare("SELECT year_label FROM academic_years WHERE id = ? LIMIT 1");
    $ayStmt->bind_param('i', $group['academic_year_id']);
    $ayStmt->execute();
    $ayRes = $ayStmt->get_result()->fetch_assoc();
    $group['academic_year_label'] = $ayRes ? formatAcademicYear($ayRes['year_label']) : null;
} else {
    $group['academic_year_label'] = null;
}

// Get group members
$membersQuery = "SELECT s.id, s.usn, s.is_team_lead, u.username, s.name, u.email, u.phone
                 FROM students s
                 INNER JOIN users u ON s.user_id = u.id
                 WHERE s.group_id = ?
                 ORDER BY s.is_team_lead DESC, u.username ASC";

$stmt = $conn->prepare($membersQuery);
$stmt->bind_param("i", $groupId);
$stmt->execute();
$members = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

sendJSON([
    'success' => true,
    'group' => $group,
    'members' => $members,
    'can_edit_members' => ($group['guide_id'] === null && $group['coordinator_guide_id'] === null && (!empty($_SESSION['is_team_lead']) && $_SESSION['is_team_lead'])),
    'can_edit_title' => (!empty($_SESSION['is_team_lead']) && $_SESSION['is_team_lead'] ? true : false),
    'can_edit_description' => (!empty($_SESSION['is_team_lead']) && $_SESSION['is_team_lead'] ? true : false)
]);
?>
