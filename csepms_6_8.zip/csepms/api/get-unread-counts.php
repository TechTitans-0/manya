<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'];

// Notifications unread - filter based on user role
// For guides: only count circulars from coordinator (target_type = 'all_guides')
// For students: count all notifications targeted to them
if ($userRole === 'guide') {
    $notifQuery = "SELECT COUNT(*) as cnt 
                   FROM notification_read_status nrs
                   INNER JOIN notifications n ON nrs.notification_id = n.id
                   WHERE nrs.user_id = ? 
                   AND nrs.is_read = 0
                   AND n.target_type = 'all_guides'";
} else {
    // For students and other roles, only count unread circulars sent by coordinators
    $notifQuery = "SELECT COUNT(*) as cnt 
                   FROM notification_read_status nrs
                   INNER JOIN notifications n ON nrs.notification_id = n.id
                   INNER JOIN users u ON n.sender_id = u.id
                   WHERE nrs.user_id = ? 
                     AND nrs.is_read = 0 
                     AND n.title LIKE 'Circular:%' 
                     AND u.role = 'coordinator'";
}

$stmt = $conn->prepare($notifQuery);
$stmt->bind_param('i', $userId);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$notifCount = intval($res['cnt'] ?? 0);

// Messages unread
$msgQuery = "SELECT COUNT(*) as cnt FROM chat_messages WHERE receiver_id = ? AND is_read = 0 AND sender_id != receiver_id";
$stmt = $conn->prepare($msgQuery);
$stmt->bind_param('i', $userId);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$msgCount = intval($res['cnt'] ?? 0);

sendJSON(['success' => true, 'notifications' => $notifCount, 'messages' => $msgCount]);

?>
