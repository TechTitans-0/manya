<?php
header('Content-Type: application/json');
$hasZip = class_exists('ZipArchive');
echo json_encode(['zip' => $hasZip]);
