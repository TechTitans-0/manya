<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$studentId = intval($_POST['student_id'] ?? 0);
$fullName = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if (!$studentId) {
    sendJSON(['success' => false, 'message' => 'Student ID is required']);
}

if (!$fullName || !$email) {
    sendJSON(['success' => false, 'message' => 'Full name and email are required']);
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJSON(['success' => false, 'message' => 'Invalid email format']);
}

try {
    // Verify student exists
    $checkStudent = "SELECT s.user_id FROM students s WHERE s.id = ?";
    $stmt = $conn->prepare($checkStudent);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Student not found');
    }
    
    $student = $result->fetch_assoc();
    $userId = $student['user_id'];
    
    // Check if email is already used by another user
    $checkEmail = "SELECT id FROM users WHERE email = ? AND id != ?";
    $stmt = $conn->prepare($checkEmail);
    $stmt->bind_param("si", $email, $userId);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        throw new Exception('Email already in use by another user');
    }
    
    // Update user information
    $updateUser = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?";
    $stmt = $conn->prepare($updateUser);
    $stmt->bind_param("sssi", $fullName, $email, $phone, $userId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update student information');
    }
    
    sendJSON([
        'success' => true,
        'message' => 'Student information updated successfully'
    ]);
    
} catch (Exception $e) {
    sendJSON([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
