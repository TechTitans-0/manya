<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get evaluation sheets with criteria count
$query = "SELECT es.*, 
          COUNT(ec.id) as criteria_count,
          COALESCE(SUM(ec.max_marks), 0) as total_marks
          FROM evaluation_sheets es
          LEFT JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
          GROUP BY es.id
          ORDER BY es.created_at DESC";

$sheets = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

// Remove title from payloads since UI no longer uses sheet names
foreach ($sheets as &$sh) {
    if (isset($sh['title'])) unset($sh['title']);
}

sendJSON(['success' => true, 'sheets' => $sheets]);
?>
