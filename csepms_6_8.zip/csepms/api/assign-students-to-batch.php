<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if (!isset($_POST['student_ids']) || !isset($_POST['target_batch'])) {
    sendJSON(['success' => false, 'message' => 'Missing required fields']);
}

$student_ids = $_POST['student_ids'];
$target_batch = trim($_POST['target_batch']);

if (empty($student_ids) || empty($target_batch)) {
    sendJSON(['success' => false, 'message' => 'Please select students and a target batch']);
}

try {
    // Get the group_id for the target batch
    $stmt = $conn->prepare("SELECT id FROM pgroups WHERE batch = ? LIMIT 1");
    $stmt->bind_param("s", $target_batch);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        sendJSON(['success' => false, 'message' => 'Target batch not found']);
    }
    
    $group = $result->fetch_assoc();
    $group_id = $group['id'];
    $stmt->close();
    
    // Check current member count
    $count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM students WHERE group_id = ?");
    $count_stmt->bind_param("i", $group_id);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $count_row = $count_result->fetch_assoc();
    $current_count = $count_row['count'];
    $count_stmt->close();
    
    $new_total = $current_count + count($student_ids);
    if ($new_total > 4) {
        sendJSON(['success' => false, 'message' => "Cannot assign. This would exceed the maximum of 4 members per group. Current: $current_count, Trying to add: " . count($student_ids)]);
    }
    
    // Assign students to the group
    $stmt = $conn->prepare("UPDATE students SET group_id = ? WHERE id = ?");
    
    foreach ($student_ids as $student_id) {
        $stmt->bind_param("ii", $group_id, $student_id);
        $stmt->execute();
    }
    $stmt->close();
    
    $student_count = count($student_ids);
    sendJSON(['success' => true, 'message' => "Successfully assigned $student_count student(s) to batch $target_batch"]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>