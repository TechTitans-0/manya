<?php
require_once __DIR__ . '/../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json; charset=utf-8');

$phase = isset($_POST['phase']) ? intval($_POST['phase']) : null;
$review = isset($_POST['review']) ? intval($_POST['review']) : null;

if ($phase === null || $review === null) {
    echo json_encode(['success' => false, 'message' => 'Phase and review are required']);
    exit;
}

// Mark matching groups as completed
$stmt = $conn->prepare("UPDATE `pgroups` SET project_status = 'completed' WHERE current_phase = ? AND current_review = ? AND project_status != 'completed'");
$stmt->bind_param('ii', $phase, $review);

$ok = $stmt->execute();
if ($ok) {
    $affected = $stmt->affected_rows;
    echo json_encode(['success' => true, 'message' => "Marked {$affected} groups as completed"]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$stmt->close();
exit;
?>
