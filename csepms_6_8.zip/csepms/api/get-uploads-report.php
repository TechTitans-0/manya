<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

try {
    // Get all groups with their batch, project title, team lead info - filter by academic_year_id
    $groupsQuery = "SELECT 
                        g.id as group_id,
                        g.batch,
                        ay.year_label as academic_year,
                        g.project_title,
                        g.group_name,
                        tl.name as team_lead_name,
                        u.phone as team_lead_phone,
                        tl.id as team_lead_id
                    FROM pgroups g
                    LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
                    LEFT JOIN students tl ON g.id = tl.group_id AND tl.is_team_lead = 1 AND tl.academic_year_id = $selectedAcademicYearId
                    LEFT JOIN users u ON tl.user_id = u.id
                    WHERE g.batch IS NOT NULL AND g.academic_year_id = $selectedAcademicYearId
                    ORDER BY g.batch ASC";
    
    $result = $conn->query($groupsQuery);
    if (!$result) {
        throw new Exception($conn->error);
    }
    $groups = $result->fetch_all(MYSQLI_ASSOC);
    
    $uploaded = [];
    $notUploaded = [];
    
    foreach ($groups as $group) {
        // Fetch all APPROVED uploads for the group in selected academic year
        // For mini projects, phase and review columns don't exist, so don't select them
        if ($_SESSION['project_type'] === 'mini') {
            $uploadCheckQuery = "SELECT pu.id as upload_id, pu.filename, 0 as phase, 0 as review FROM project_uploads pu WHERE pu.group_id = " . intval($group['group_id']) . " AND pu.academic_year_id = $selectedAcademicYearId AND pu.status = 'approved' ORDER BY pu.upload_date DESC";
        } else {
            $uploadCheckQuery = "SELECT pu.id as upload_id, pu.filename, pu.phase, pu.review FROM project_uploads pu WHERE pu.group_id = " . intval($group['group_id']) . " AND pu.academic_year_id = $selectedAcademicYearId AND pu.status = 'approved' ORDER BY pu.upload_date DESC";
        }
        $uploadResult = $conn->query($uploadCheckQuery);
        if (!$uploadResult) {
            throw new Exception($conn->error);
        }

        if ($uploadResult->num_rows > 0) {
            $files = [];
            $phases = [];
            $reviews = [];
            $upload_ids = [];
            while ($upload = $uploadResult->fetch_assoc()) {
                $files[] = $upload['filename'];
                $phases[] = $upload['phase'];
                $reviews[] = $upload['review'];
                $upload_ids[] = $upload['upload_id'];
            }
            $uploaded[] = [
                'batch' => $group['batch'],
                'academic_year' => $group['academic_year'],
                'project_title' => $group['project_title'] ?: $group['group_name'],
                'group_name' => $group['group_name'],
                'team_lead_name' => $group['team_lead_name'] ?: 'N/A',
                'team_lead_phone' => $group['team_lead_phone'] ?: 'N/A',
                'upload_ids' => $upload_ids,
                'filenames' => $files,
                'phases' => $phases,
                'reviews' => $reviews
            ];
        } else {
            // No APPROVED uploads - add to missing list
            $notUploaded[] = [
                'batch' => $group['batch'],
                'academic_year' => $group['academic_year'],
                'project_title' => $group['project_title'] ?: $group['group_name'],
                'group_name' => $group['group_name'],
                'team_lead_name' => $group['team_lead_name'] ?: 'N/A',
                'team_lead_phone' => $group['team_lead_phone'] ?: 'N/A',
                'files' => 'Not Uploaded'
            ];
        }
    }
    
    sendJSON([
        'success' => true,
        'uploaded' => $uploaded,
        'not_uploaded' => $notUploaded
    ]);
    
} catch (Exception $e) {
    sendJSON([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
