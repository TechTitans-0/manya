<?php
require_once '../config/config.php';

// This endpoint is for mini projects only
if (getCurrentProjectType() !== 'mini') {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'This endpoint is only for mini projects'], 400);
}

if (!isLoggedIn() || (!hasRole('guide') && !hasRole('coordinator'))) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

header('Content-Type: application/json');

$groupId = intval($_GET['group_id'] ?? 0);

if (!$groupId) {
    sendJSON(['success' => false, 'message' => 'Group ID is required']);
}


// Get the evaluation sheet for this mini project (any active or draft sheet, since mini has no phases/reviews)
$query = "SELECT id, subject_code, title, status 
          FROM evaluation_sheets 
          WHERE status IN ('active', 'draft') 
          LIMIT 1";

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $sheet = $result->fetch_assoc();
    sendJSON([
        'success' => true,
        'sheet' => [
            'id' => intval($sheet['id']),
            'subject_code' => $sheet['subject_code'],
            'title' => 'evaluation sheet',
            'status' => $sheet['status']
        ]
    ]);
} else {
    sendJSON(['success' => false, 'message' => 'No evaluation sheet found for mini project']);
}
?>
