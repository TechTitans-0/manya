<?php
require_once '../config/config.php';
requireLogin();


// Clean output buffer to prevent any output before JSON
if (ob_get_level()) {
    ob_clean();
}

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

if (empty($conn) || ($conn instanceof mysqli && $conn->connect_error)) {
    sendJSON(['success' => false, 'message' => 'Database connection is not available.']);
}

$users = [];
$currentUserId = $_SESSION['user_id'];

// Check whether the chat_messages table has a `sent_at` column. If not,
// fall back to ordering by `id` to avoid SQL errors on older databases.
$hasSentAt = false;
$colStmt = $conn ? $conn->prepare("SELECT COUNT(*) as cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'chat_messages' AND COLUMN_NAME = 'sent_at'") : false;
$dbName = function_exists('getDatabaseName') ? getDatabaseName() : null;
if ($colStmt && $dbName) {
    $colStmt->bind_param('s', $dbName);
    $colStmt->execute();
    $colRes = $colStmt->get_result()->fetch_assoc();
    if ($colRes && intval($colRes['cnt']) > 0) $hasSentAt = true;
    $colStmt->close();
}
$orderCol = $hasSentAt ? 'sent_at' : 'id';

if (hasRole('student')) {
    // For students: only include their guide and the coordinator
    if (isset($_SESSION['group_id']) && $_SESSION['group_id']) {
        // Get guide with conversation info
        $guideQuery = "SELECT u.id, u.username as name, u.username, u.email, 'guide' as role,
                   (SELECT message FROM chat_messages 
                WHERE ((sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id))
                AND deleted_at IS NULL
                ORDER BY " . $orderCol . " DESC LIMIT 1) as last_message,
                   (SELECT " . $orderCol . " FROM chat_messages 
                WHERE ((sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id))
                AND deleted_at IS NULL
                ORDER BY " . $orderCol . " DESC LIMIT 1) as last_message_time,
                   (SELECT COUNT(*) FROM chat_messages 
                WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0 AND deleted_at IS NULL) as unread_count
                   FROM pgroups g
                   INNER JOIN guides gd ON g.guide_id = gd.id
                   INNER JOIN users u ON gd.user_id = u.id
                   WHERE g.id = ?";
        $stmt = $conn->prepare($guideQuery);
        $stmt->bind_param("iiiiii", $currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId, $_SESSION['group_id']);
        $stmt->execute();
        $guide = $stmt->get_result()->fetch_assoc();
        if ($guide) $users[] = $guide;
    }

    // Get all coordinators with conversation info (allow students to see every coordinator)
    $coordQuery = "SELECT u.id, u.username as name, u.username, u.email, 'coordinator' as role,
                   (SELECT message FROM chat_messages 
                    WHERE ((sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id))
                    AND deleted_at IS NULL
                    ORDER BY " . $orderCol . " DESC LIMIT 1) as last_message,
                   (SELECT " . $orderCol . " FROM chat_messages 
                    WHERE ((sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id))
                    AND deleted_at IS NULL
                    ORDER BY " . $orderCol . " DESC LIMIT 1) as last_message_time,
                   (SELECT COUNT(*) FROM chat_messages 
                    WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0 AND deleted_at IS NULL) as unread_count
                   FROM coordinators c
                   INNER JOIN users u ON c.user_id = u.id";
    $stmt = $conn->prepare($coordQuery);
    $stmt->bind_param("iiiii", $currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId);
    $stmt->execute();
    $coords = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    if ($coords) {
        foreach ($coords as $coord) {
            $users[] = $coord;
        }
    }
    
    // Sort: unread first (by time), then read (by time)
    usort($users, function($a, $b) {
        $aUnread = intval($a['unread_count'] ?? 0);
        $bUnread = intval($b['unread_count'] ?? 0);
        
        // If both unread or both read, sort by time
        if (($aUnread > 0 && $bUnread > 0) || ($aUnread == 0 && $bUnread == 0)) {
            $aTime = strtotime($a['last_message_time'] ?? '1970-01-01');
            $bTime = strtotime($b['last_message_time'] ?? '1970-01-01');
            return $bTime - $aTime; // newest first
        }
        // Unread comes before read
        return $bUnread - $aUnread;
    });

} elseif (hasRole('guide')) {
    // Return project groups assigned to this guide with conversation info
    $groupsQuery = "SELECT g.id as group_id, g.group_name, g.batch, g.project_title, COUNT(s.id) as member_count,
                    cu.username as coordinator_name,
                    (SELECT cm.message FROM chat_messages cm
                     WHERE cm.group_id = g.id AND cm.deleted_at IS NULL
                     ORDER BY cm." . $orderCol . " DESC LIMIT 1) as last_message,
                    (SELECT cm." . $orderCol . " FROM chat_messages cm
                     WHERE cm.group_id = g.id AND cm.deleted_at IS NULL
                     ORDER BY cm." . $orderCol . " DESC LIMIT 1) as last_message_time,
                    (SELECT COUNT(*) FROM chat_messages cm
                     WHERE cm.group_id = g.id AND cm.receiver_id = ? AND cm.is_read = 0 AND cm.deleted_at IS NULL AND cm.sender_id != ?) as unread_count
                    FROM pgroups g
                    LEFT JOIN coordinators c ON g.coordinator_guide_id = c.id
                    LEFT JOIN users cu ON c.user_id = cu.id
                    LEFT JOIN students s ON s.group_id = g.id
                    WHERE g.guide_id = ?
                    GROUP BY g.id";
    $stmt = $conn->prepare($groupsQuery);
    $stmt->bind_param("iii", $currentUserId, $currentUserId, $_SESSION['role_id']);
    $stmt->execute();
    $groups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    foreach ($groups as $g) {
        $users[] = [
            'id' => $g['group_id'],
            'name' => $g['project_title'] ? $g['project_title'] : $g['group_name'],
            'group_name' => $g['group_name'],
            'batch' => $g['batch'],
            'member_count' => intval($g['member_count']),
            'role' => 'group',
            'chat_type' => 'project_group',
            'last_message' => $g['last_message'],
            'last_message_time' => $g['last_message_time'],
            'unread_count' => intval($g['unread_count'] ?? 0)
        ];
    }

    // Get all coordinators with conversation info (allow guides to see every coordinator)
    $coordQuery = "SELECT u.id, u.username as name, u.username, u.email, 'coordinator' as role,
                   (SELECT message FROM chat_messages 
                    WHERE ((sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id))
                    AND deleted_at IS NULL
                    ORDER BY " . $orderCol . " DESC LIMIT 1) as last_message,
                   (SELECT " . $orderCol . " FROM chat_messages 
                    WHERE ((sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id))
                    AND deleted_at IS NULL
                    ORDER BY " . $orderCol . " DESC LIMIT 1) as last_message_time,
                   (SELECT COUNT(*) FROM chat_messages 
                    WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0 AND deleted_at IS NULL) as unread_count
                   FROM coordinators c
                   INNER JOIN users u ON c.user_id = u.id";
    $stmt = $conn->prepare($coordQuery);
    $stmt->bind_param("iiiii", $currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId);
    $stmt->execute();
    $coords = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    if ($coords) {
        foreach ($coords as $coord) {
            $users[] = $coord;
        }
    }
    
    // Sort: unread first (by time), then read (by time)
    usort($users, function($a, $b) {
        $aUnread = intval($a['unread_count'] ?? 0);
        $bUnread = intval($b['unread_count'] ?? 0);
        
        // If both unread or both read, sort by time
        if (($aUnread > 0 && $bUnread > 0) || ($aUnread == 0 && $bUnread == 0)) {
            $aTime = strtotime($a['last_message_time'] ?? '1970-01-01');
            $bTime = strtotime($b['last_message_time'] ?? '1970-01-01');
            return $bTime - $aTime; // newest first
        }
        // Unread comes before read
        return $bUnread - $aUnread;
    });

} elseif (hasRole('coordinator')) {
    // Get all students and guides with additional info
     $allQuery = "SELECT 
                          u.id, 
                          u.username, 
                          u.email, 
                          u.role,
                          s.year_of_passing,
                          (SELECT MAX(cm." . $orderCol . ") 
                            FROM chat_messages cm 
                            WHERE (cm.sender_id = u.id AND cm.receiver_id = ?) 
                                OR (cm.sender_id = ? AND cm.receiver_id = u.id)
                          ) as last_message_time
                      FROM users u
                      LEFT JOIN students s ON u.id = s.user_id AND u.role = 'student'
                      WHERE u.role IN ('student', 'guide') AND u.id != ?
                      ORDER BY last_message_time DESC, u.role ASC, u.username ASC";
    $stmt = $conn->prepare($allQuery);
    $userId = $_SESSION['user_id'];
    $stmt->bind_param("iii", $userId, $userId, $userId);
    $stmt->execute();
    $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
// If no users were found (e.g., queries returned nothing), attempt a simple fallback: return all coordinators
if (empty($users)) {
    $users = [];
    $stmt = $conn->prepare("SELECT u.id, u.username as name, u.username, u.email, 'coordinator' as role,
                           NULL as last_message, NULL as last_message_time, 0 as unread_count FROM coordinators c INNER JOIN users u ON c.user_id = u.id");
    if ($stmt) {
        $stmt->execute();
        $coords = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        if ($coords) {
            foreach ($coords as $coord) $users[] = $coord;
        }
    }
}

}

// Return final result
sendJSON(['success' => true, 'users' => $users]);
?>
