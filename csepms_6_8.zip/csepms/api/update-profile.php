<?php
require_once '../config/config.php';
if (!isLoggedIn()) {
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$fullName = sanitizeInput($_POST['full_name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$phone = sanitizeInput($_POST['phone'] ?? '');
$branch = sanitizeInput($_POST['branch'] ?? '');
$yearOfPassing = intval($_POST['year_of_passing'] ?? 0);

if (empty($email)) {
    sendJSON(['success' => false, 'message' => 'Email is required']);
}

try {
    $conn->begin_transaction();

    // Update common users table - full name is stored in username column
    $userUpdateQuery = "UPDATE users SET username = ?, email = ?, phone = ? WHERE id = ?";
    $stmt = $conn->prepare($userUpdateQuery);
    $stmt->bind_param("sssi", $fullName, $email, $phone, $_SESSION['user_id']);
    if (!$stmt->execute()) {
        throw new Exception('Failed to update users table');
    }

    // Update role-specific table for students
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'student') {
        $studQuery = "UPDATE students SET branch = ?, year_of_passing = ? WHERE id = ?";
        $stmt = $conn->prepare($studQuery);
        $stmt->bind_param("sii", $branch, $yearOfPassing, $_SESSION['role_id']);
        if (!$stmt->execute()) {
            throw new Exception('Failed to update student profile');
        }
    }

    // For guides: update guides table fields
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'guide') {
        $domain = sanitizeInput($_POST['domain'] ?? '');
        $department = sanitizeInput($_POST['department'] ?? '');
        $guideQuery = "UPDATE guides SET domain = ?, department = ? WHERE id = ?";
        $stmt = $conn->prepare($guideQuery);
        $stmt->bind_param("ssi", $domain, $department, $_SESSION['role_id']);
        if (!$stmt->execute()) {
            throw new Exception('Failed to update guide profile');
        }
    }

    // For coordinators: update coordinators table fields (designation, research domain, years, department)
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'coordinator') {
        $designation = sanitizeInput($_POST['designation'] ?? '');
        $research = sanitizeInput($_POST['research_domain_expertise'] ?? '');
        $years = intval($_POST['years_of_experience'] ?? 0);
        $department = sanitizeInput($_POST['department'] ?? '');

        $coordQuery = "UPDATE coordinators SET designation = ?, research_domain_expertise = ?, years_of_experience = ?, department = ? WHERE id = ?";
        $stmt = $conn->prepare($coordQuery);
        if (!$stmt) {
            throw new Exception('Database prepare error: ' . $conn->error);
        }
        $stmt->bind_param("ssisi", $designation, $research, $years, $department, $_SESSION['role_id']);
        if (!$stmt->execute()) {
            throw new Exception('Failed to update coordinator profile');
        }
    }

    $conn->commit();

    // Update session values
    $_SESSION['email'] = $email;
    if (!empty($fullName)) {
        $_SESSION['username'] = $fullName;
    }

    // Re-fetch user row to return authoritative values
    $sel = $conn->prepare("SELECT username, email FROM users WHERE id = ?");
    $sel->bind_param("i", $_SESSION['user_id']);
    $sel->execute();
    $userRow = $sel->get_result()->fetch_assoc();

    sendJSON([
        'success' => true,
        'message' => 'Profile updated successfully',
        'username' => $userRow['username'] ?? '',
        'full_name' => $userRow['username'] ?? '',
        'email' => $userRow['email'] ?? ''
    ]);

} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
