<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Accepts POST with { group_id }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$groupId = intval($input['group_id'] ?? 0);

if (!$groupId) {
    echo json_encode(['success' => false, 'message' => 'Group ID is required']);
    exit;
}

try {
    $conn->begin_transaction();

    // Approve ONLY submitted grades for this group (idempotent)
    $query = "UPDATE student_grades SET status = 'approved', updated_at = NOW() WHERE group_id = ? AND status = 'submitted'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $groupId);
    $stmt->execute();
    $affected = $stmt->affected_rows;

    // Get all grades for this group after update
    $result = $conn->query("SELECT id, status FROM student_grades WHERE group_id = $groupId");
    $grades = [];
    while ($row = $result->fetch_assoc()) {
        $grades[] = $row;
    }

    $conn->commit();
    echo json_encode(['success' => true, 'result' => $grades, 'approved_count' => $affected]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
