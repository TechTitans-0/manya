<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

$otherUserId = intval($_GET['user_id'] ?? 0);
$groupId = isset($_GET['group_id']) ? intval($_GET['group_id']) : null;

if (!$otherUserId) {
    sendJSON(['success' => false, 'message' => 'User ID required']);
}

// Resolve if frontend provided a role-specific id (e.g., guides.id or coordinators.id)
$resolvedOtherUserId = $otherUserId;
$checkUserStmt = $conn->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
$checkUserStmt->bind_param('i', $resolvedOtherUserId);
$checkUserStmt->execute();
$userExists = ($checkUserStmt->get_result()->num_rows > 0);
$checkUserStmt->close();
if (!$userExists) {
    // Try mapping from guides table
    $mapStmt = $conn->prepare("SELECT user_id FROM guides WHERE id = ? LIMIT 1");
    if ($mapStmt) {
        $mapStmt->bind_param('i', $otherUserId);
        $mapStmt->execute();
        $res = $mapStmt->get_result()->fetch_assoc();
        $mapStmt->close();
        if ($res && !empty($res['user_id'])) {
            $resolvedOtherUserId = intval($res['user_id']);
            $userExists = true;
        }
    }
}
if (!$userExists) {
    // Try mapping from coordinators table
    $mapStmt = $conn->prepare("SELECT user_id FROM coordinators WHERE id = ? LIMIT 1");
    if ($mapStmt) {
        $mapStmt->bind_param('i', $otherUserId);
        $mapStmt->execute();
        $res = $mapStmt->get_result()->fetch_assoc();
        $mapStmt->close();
        if ($res && !empty($res['user_id'])) {
            $resolvedOtherUserId = intval($res['user_id']);
            $userExists = true;
        }
    }
}

// Log for debugging
error_log("Get messages - Current User: " . $_SESSION['user_id'] . ", Other User: $otherUserId, Group: " . ($groupId ?? 'null'));

// Get messages between current user and specified user
$query = "SELECT cm.*, 
          sender.username as sender_name,
          receiver.username as receiver_name
          FROM chat_messages cm
          INNER JOIN users sender ON cm.sender_id = sender.id
          INNER JOIN users receiver ON cm.receiver_id = receiver.id
          WHERE ((cm.sender_id = ? AND cm.receiver_id = ?)
          OR (cm.sender_id = ? AND cm.receiver_id = ?))
          AND cm.deleted_at IS NULL";

// Use resolved user id for parameter binding
$params = [$_SESSION['user_id'], $resolvedOtherUserId, $resolvedOtherUserId, $_SESSION['user_id']];
$types = "iiii";

if ($groupId) {
    $query .= " AND cm.group_id = ?";
    $params[] = $groupId;
    $types .= "i";
}

$query .= " ORDER BY cm.sent_at ASC";

$stmt = $conn->prepare($query);
if (!$stmt) {
    error_log("Get messages - Prepare error: " . $conn->error);
    sendJSON(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$stmt->bind_param($types, ...$params);
if (!$stmt->execute()) {
    error_log("Get messages - Execute error: " . $stmt->error);
    sendJSON(['success' => false, 'message' => 'Query error: ' . $stmt->error]);
}

$result = $stmt->get_result();
$messages = $result->fetch_all(MYSQLI_ASSOC);

error_log("Get messages - Found " . count($messages) . " messages");

// Mark messages as read
$markRead = "UPDATE chat_messages SET is_read = 1 
             WHERE receiver_id = ? AND sender_id = ? AND is_read = 0 AND deleted_at IS NULL";
$stmt = $conn->prepare($markRead);
if ($stmt) {
    $stmt->bind_param("ii", $_SESSION['user_id'], $resolvedOtherUserId);
    $stmt->execute();
    error_log("Get messages - Marked " . $stmt->affected_rows . " messages as read");
}

sendJSON(['success' => true, 'messages' => $messages]);
?>
