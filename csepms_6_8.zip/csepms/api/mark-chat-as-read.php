<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['chat_type'])) {
    sendJSON(['success' => false, 'message' => 'Chat type required']);
}

$coordinator_id = $_SESSION['user_id'];
$chat_type = $input['chat_type'];

try {
    if ($chat_type === 'guide') {
        if (!isset($input['guide_user_id'])) {
            sendJSON(['success' => false, 'message' => 'Guide user ID required']);
        }
        
        $guide_user_id = intval($input['guide_user_id']);
        
        // Mark all messages from this guide as read
        $stmt = $conn->prepare("
            UPDATE chat_messages 
            SET is_read = 1 
            WHERE sender_id = ? 
              AND receiver_id = ? 
              AND is_read = 0
              AND deleted_at IS NULL
        ");
        $stmt->bind_param("ii", $guide_user_id, $coordinator_id);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        
        sendJSON([
            'success' => true, 
            'message' => 'Messages marked as read',
            'marked_count' => $affected
        ]);
        
    } elseif ($chat_type === 'batch') {
        if (!isset($input['batch'])) {
            sendJSON(['success' => false, 'message' => 'Batch required']);
        }
        
        $batch = trim($input['batch']);
        
        // Get all students in this batch
        $stmt = $conn->prepare("
            SELECT DISTINCT s.user_id 
            FROM students s 
            INNER JOIN pgroups g ON s.group_id = g.id 
            WHERE g.batch = ?
        ");
        $stmt->bind_param("s", $batch);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $student_ids = [];
        while ($row = $result->fetch_assoc()) {
            $student_ids[] = $row['user_id'];
        }
        $stmt->close();
        
        if (empty($student_ids)) {
            sendJSON(['success' => true, 'message' => 'No students in batch', 'marked_count' => 0]);
        }
        
        // Mark all messages from students in this batch as read
        $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
        $query = "
            UPDATE chat_messages 
            SET is_read = 1 
            WHERE sender_id IN ($placeholders) 
              AND receiver_id = ? 
              AND is_read = 0
              AND deleted_at IS NULL
        ";
        
        $stmt = $conn->prepare($query);
        $types = str_repeat('i', count($student_ids) + 1);
        $params = array_merge($student_ids, [$coordinator_id]);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        
        sendJSON([
            'success' => true, 
            'message' => 'Messages marked as read',
            'marked_count' => $affected
        ]);
        
    } else {
        sendJSON(['success' => false, 'message' => 'Invalid chat type']);
    }
    
} catch (Exception $e) {
    sendJSON([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
