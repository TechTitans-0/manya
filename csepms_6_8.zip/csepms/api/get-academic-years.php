<?php
require_once '../config/config.php';
header('Content-Type: application/json');

$years = [];
$res = $conn->query("SELECT id, year_label, status FROM academic_years ORDER BY FIELD(status, 'ACTIVE') DESC, year_label DESC");
while ($row = $res->fetch_assoc()) {
    $formattedLabel = formatAcademicYear($row['year_label']);
    $years[] = [
        'id' => $row['id'],
        'year_label' => $row['year_label'],
        'formatted_label' => $formattedLabel,
        'status' => $row['status']
    ];
}
// If no years, add default
if (empty($years)) {
    $projectType = getCurrentProjectType();
    $defaultLabel = ($projectType === 'mini') ? '2026' : '2026-2027';
    $defaultFormatted = formatAcademicYear($defaultLabel);
    $years[] = [
        'id' => 1,
        'year_label' => $defaultLabel,
        'formatted_label' => $defaultFormatted,
        'status' => 'ACTIVE'
    ];
}
echo json_encode(['success' => true, 'years' => $years]);
