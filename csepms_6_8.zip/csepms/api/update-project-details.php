<?php
require_once '../config/config.php';
requireLogin();
// Prevent students from mutating project details when academic year is completed
enforceReadOnlyForCompletedYear();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$projectDomain = trim($_POST['project_domain'] ?? '');
$customDomain = trim($_POST['custom_domain'] ?? '');
$projectTitle = trim($_POST['project_title'] ?? '');
$projectDescription = trim($_POST['project_description'] ?? '');

if (!$projectDomain || ($projectDomain === 'Other' && !$customDomain) || !$projectTitle || !$projectDescription) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

// Use custom domain if "Other" is selected
$finalDomain = ($projectDomain === 'Other') ? $customDomain : $projectDomain;

// Get group id for current student
$groupId = $_SESSION['group_id'] ?? null;
if (!$groupId) {
    echo json_encode(['success' => false, 'message' => 'No group found for user.']);
    exit;
}

// Update group details
$stmt = $conn->prepare("UPDATE pgroups SET domain = ?, project_title = ?, project_description = ? WHERE id = ?");
$stmt->bind_param('sssi', $finalDomain, $projectTitle, $projectDescription, $groupId);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Project details updated successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update project details.']);
}
$stmt->close();
?>
