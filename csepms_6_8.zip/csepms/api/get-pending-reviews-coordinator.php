<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Get uploads for groups where this coordinator is assigned (coordinator_guide_id)
$query = "SELECT pu.*, pu.filename as file_name, pu.upload_date as uploaded_at, pu.review as review_type, pu.status as status, pu.feedback as feedback, g.group_name, g.batch, g.project_title, ay.year_label as academic_year, u.username as uploaded_by_name, pu.file_path
          FROM project_uploads pu
          INNER JOIN pgroups g ON pu.group_id = g.id
          LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
          INNER JOIN students s ON pu.uploaded_by = s.id
          INNER JOIN users u ON s.user_id = u.id
          WHERE g.coordinator_guide_id = ? AND pu.academic_year_id = ?
          ORDER BY pu.upload_date DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$pendingReviews = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

sendJSON(['success' => true, 'reviews' => $pendingReviews]);
?>
