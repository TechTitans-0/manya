<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$guideId = intval($_POST['guide_id'] ?? 0);
$name = sanitizeInput($_POST['name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$department = sanitizeInput($_POST['department'] ?? '');
$domain = sanitizeInput($_POST['domain'] ?? '');

if (!$guideId || empty($name) || empty($email)) {
    sendJSON(['success' => false, 'message' => 'Guide ID, name, and email are required']);
}

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJSON(['success' => false, 'message' => 'Invalid email format']);
}

try {
    $conn->begin_transaction();
    
    // Get user_id from guides table
    $getUserQuery = "SELECT user_id FROM guides WHERE id = ?";
    $stmt = $conn->prepare($getUserQuery);
    $stmt->bind_param("i", $guideId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Guide not found');
    }
    
    $userId = $result->fetch_assoc()['user_id'];
    
    // Update users table
    $updateUser = "UPDATE users SET username = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($updateUser);
    $stmt->bind_param("ssi", $name, $email, $userId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update user information');
    }
    
    // Update guides table
    $updateGuide = "UPDATE guides SET department = ?, domain = ? WHERE id = ?";
    $stmt = $conn->prepare($updateGuide);
    $stmt->bind_param("ssi", $department, $domain, $guideId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update guide information');
    }
    
    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Guide information updated successfully']);
    
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
