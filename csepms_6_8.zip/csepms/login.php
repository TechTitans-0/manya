<?php
require_once 'config/config.php';


// Check if project type is selected
if (!isset($_SESSION['project_type'])) {
    redirect('index.php');
}

$projectType = $_SESSION['project_type'];
$projectTitle = ($projectType === 'mini') ? 'Mini Project Management' : 'Final Year Project Management';
$projectLabel = ($projectType === 'mini') ? 'Mini Project' : 'Major Project';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login - <?php echo $projectTitle; ?></title>
    
    <!-- SB Admin 2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .bg-login-image {
            background: url('https://source.unsplash.com/K4mSJ7kc0As/600x800');
            background-position: center;
            background-size: cover;
        }
        .project-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
        .project-badge.major {
            background-color: #667eea;
            color: white;
        }
        .project-badge.mini {
            background-color: #764ba2;
            color: white;
        }
        .btn-change-project {
            font-size: 12px;
            padding: 5px 10px;
            margin-left: 10px;
        }
    </style>
</head>
<body class="bg-gradient-primary">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="row">
                            <!-- <div class="col-lg-6 d-none d-lg-block bg-login-image"></div> -->
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <div>
                                            <span class="project-badge <?php echo $projectType; ?>">
                                                <?php echo $projectLabel; ?>
                                            </span>
                                            <a href="logout-project.php" class="btn btn-sm btn-outline-primary btn-change-project">
                                                Change
                                            </a>
                                        </div>
                                        <h1 class="h4 text-gray-900 mb-2"><?php echo $projectTitle; ?></h1>
                                        <h2 class="h5 text-gray-800 mb-4">Welcome Back!</h2>
                                    </div>
                                    
                                    <div id="alertBox"></div>
                                    
                                    <form class="user" id="loginForm">
                                        <div class="form-group">
                                            <label class="small mb-1">Select Role</label>
                                            <select class="form-control" id="role" name="role" required>
                                                <option value="">-- Select Role --</option>
                                                <option value="student">Student</option>
                                                <option value="guide">Guide</option>
                                                <option value="coordinator">Coordinator</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="small mb-1" id="usernameLabel">USN / Employee ID</label>
                                            <input type="text" class="form-control form-control-user" 
                                                   id="identifier" name="identifier" 
                                                   placeholder="Enter USN or Employee ID" required>
                                        </div>
                                        
                                        <div class="form-group position-relative">
                                            <label class="small mb-1">Password</label>
                                            <input type="password" class="form-control form-control-user" 
                                                   id="password" name="password" 
                                                   placeholder="Password" required>
                                            <span class="position-absolute" style="right: 25px; top: 43px; cursor: pointer;" 
                                                  onclick="togglePassword()">
                                                <i class="fas fa-eye" id="toggleIcon"></i>
                                            </span>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </button>
                                    </form>
                                    
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="forgot-password.php">Forgot Password?</a>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="register.php">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Update label based on role
        document.getElementById('role').addEventListener('change', function() {
            const label = document.getElementById('usernameLabel');
            const input = document.getElementById('identifier');
            if (this.value === 'student') {
                label.textContent = 'USN';
                input.placeholder = 'Enter your USN';
            } else if (this.value === 'guide' || this.value === 'coordinator') {
                label.textContent = 'Employee ID';
                input.placeholder = 'Enter your Employee ID';
            } else {
                label.textContent = 'USN / Employee ID';
                input.placeholder = 'Enter USN or Employee ID';
            }
        });

        // Password eye toggle
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Handle form submission
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const alertBox = document.getElementById('alertBox');
            
            fetch('api/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alertBox.innerHTML = `<div class="alert alert-success">${data.message || 'Login successful! Redirecting...'}</div>`;
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 1000);
                } else {
                    alertBox.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                }
            })
            .catch(error => {
                alertBox.innerHTML = `<div class="alert alert-danger">An error occurred. Please try again.</div>`;
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
