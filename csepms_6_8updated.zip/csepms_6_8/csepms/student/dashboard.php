<?php
require_once '../config/config.php';
requireRole('student');

$currentPage = 'dashboard';
$pageTitle = 'Student Dashboard';

// Get global phase and review settings
$globalSettings = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$current_phase = 1;  // default values
$current_review = 1;
while ($row = $globalSettings->fetch_assoc()) {
    if ($row['setting_key'] === 'current_phase') $current_phase = intval($row['setting_value']);
    if ($row['setting_key'] === 'current_review') $current_review = intval($row['setting_value']);
}

// Get student details
$studentQuery = "SELECT s.*, u.username, u.email, u.phone, g.group_name, g.batch, g.project_title, 
                 g.overall_grade, g.project_status,
                 gu.username as guide_name,
                 g.coordinator_guide_id,
                 c.username as coordinator_name
                 FROM students s
                 INNER JOIN users u ON s.user_id = u.id
                 LEFT JOIN pgroups g ON s.group_id = g.id
                 LEFT JOIN guides gd ON g.guide_id = gd.id
                 LEFT JOIN users gu ON gd.user_id = gu.id
                 LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
                 LEFT JOIN users c ON cd.user_id = c.id
                 WHERE s.id = ?";
$stmt = $conn->prepare($studentQuery);
$stmt->bind_param("i", $_SESSION['role_id']);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// Add global phase/review to student array for easy access in the view
$student['current_phase'] = $current_phase;
$student['current_review'] = $current_review;

// Get group members if in a group
$groupMembers = [];
if ($student['group_id']) {
    $membersQuery = "SELECT u.username, s.usn, s.is_team_lead 
                     FROM students s 
                     INNER JOIN users u ON s.user_id = u.id 
                     WHERE s.group_id = ?";
    $stmt = $conn->prepare($membersQuery);
    $stmt->bind_param("i", $student['group_id']);
    $stmt->execute();
    $groupMembers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Academic year filtering
$selectedAcademicYearId = $student['academic_year_id'];
$_SESSION['academic_year_id'] = $selectedAcademicYearId;
$uploadsQuery = "SELECT * FROM project_uploads WHERE group_id = ? AND academic_year_id = ? ORDER BY upload_date DESC LIMIT 5";
$stmt = $conn->prepare($uploadsQuery);
$stmt->bind_param("ii", $student['group_id'], $selectedAcademicYearId);
$stmt->execute();
$recentUploads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Count completed reviews for selected academic year
$completedReviews = 0;
if ($student['group_id']) {
    if ($_SESSION['project_type'] === 'mini') {
        // For mini projects, count distinct approved uploads (no phase/review distinction)
        $reviewQuery = "SELECT COUNT(DISTINCT id) as count 
                        FROM project_uploads 
                        WHERE group_id = ? AND status = 'approved' AND academic_year_id = ?";
    } else {
        // For major projects, count distinct phase-review combinations
        $reviewQuery = "SELECT COUNT(DISTINCT CONCAT(phase, '-', review)) as count 
                        FROM project_uploads 
                        WHERE group_id = ? AND status = 'approved' AND academic_year_id = ?";
    }
    $stmt = $conn->prepare($reviewQuery);
    $stmt->bind_param("ii", $student['group_id'], $selectedAcademicYearId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $completedReviews = $result['count'];
}

include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
</div>

<!-- Content Row -->
<div class="row">
    <?php if ($_SESSION['project_type'] !== 'mini'): ?>
    <!-- Current Phase Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Current Phase</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Phase <?php echo $current_phase; ?>
                        </div>
                        <div class="small text-gray-600 mt-1">
                            Current Review: Review <?php echo $current_review; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-project-diagram fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Completed Reviews Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Completed Reviews</div>
                        <?php
                        // Count completed phases as distinct phases with at least one approved review
                        $completedPhases = 0;
                        if ($student['group_id'] && $_SESSION['project_type'] !== 'mini') {
                            $phaseQuery = "SELECT COUNT(DISTINCT phase) as count FROM project_uploads WHERE group_id = ? AND status = 'approved' AND academic_year_id = ?";
                            $stmt = $conn->prepare($phaseQuery);
                            $stmt->bind_param("ii", $student['group_id'], $selectedAcademicYearId);
                            $stmt->execute();
                            $res = $stmt->get_result()->fetch_assoc();
                            $completedPhases = $res['count'] ?? 0;
                        }
                        ?>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $completedReviews; ?> <small class="text-muted">(Phases: <?php echo $completedPhases; ?>)</small></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Group Members Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Group Members</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo count($groupMembers); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- My Grades Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            My Grades</div>
                        <?php
                        // Count student grades
                        $gradesCount = 0;
                        if ($student['group_id'] && isset($_SESSION['role_id'])) {
                            $gradesQuery = "SELECT COUNT(*) as count FROM student_grades WHERE student_id = ? AND status = 'approved'";
                            $stmt = $conn->prepare($gradesQuery);
                            $stmt->bind_param("i", $_SESSION['role_id']);
                            $stmt->execute();
                            $res = $stmt->get_result()->fetch_assoc();
                            $gradesCount = $res['count'] ?? 0;
                        }
                        ?>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $gradesCount; ?> <small class="text-muted">grades</small></div>
                        <a href="grades.php" class="small text-primary mt-1">View All →</a>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-award fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Overall Grade Card removed per request -->
</div>

<!-- Content Row -->
<div class="row">
    <!-- Group Details Card -->
    <div class="col-lg-6 mb-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">My Group Details</h6>
            </div>
            <div class="card-body">
                <?php if ($student['group_id']): ?>
                    <h5 class="mb-3"><?php echo htmlspecialchars($student['group_name'] ?? ''); ?></h5>
                    <p><strong>Batch:</strong> <?php echo htmlspecialchars($student['batch'] ?? 'Not assigned'); ?></p>
                    <p><strong>Project:</strong> <?php echo htmlspecialchars($student['project_title'] ?? 'Not submitted'); ?></p>
                    <p><strong>Guide:</strong> 
                        <?php
                        if (!empty($student['guide_name'])) {
                            echo htmlspecialchars($student['guide_name']);
                        } else if (!empty($student['coordinator_guide_id']) && !empty($student['coordinator_name'])) {
                            echo htmlspecialchars($student['coordinator_name']) . ' (Coordinator)';
                        } else {
                            echo 'Not assigned';
                        }
                        ?>
                    </p>
                    <!-- Status removed as per request -->
                    
                    <hr>
                    <h6 class="font-weight-bold">Team Members:</h6>
                    <ul class="list-unstyled">
                        <?php foreach ($groupMembers as $member): ?>
                            <li class="mb-2">
                                <i class="fas fa-user-circle"></i>
                                <?php echo htmlspecialchars($member['username']); ?> 
                                (<?php echo htmlspecialchars($member['usn']); ?>)
                                <?php if ($member['is_team_lead']): ?>
                                    <span class="badge badge-primary ml-2">Team Lead</span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-users fa-3x text-gray-300 mb-3"></i>
                        <p class="text-gray-600">You are not part of any group yet.</p>
                        <a href="group.php" class="btn btn-primary">Create or Join Group</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Project Progress Card (removed as per request) -->
</div>

<!-- Recent Grades Section (Major Projects Only) -->
<?php if ($_SESSION['project_type'] !== 'mini'): ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">My Recent Grades</h6>
                <a href="grades.php" class="btn btn-sm btn-primary">
                    <i class="fas fa-list"></i> View All Grades
                </a>
            </div>
            <div class="card-body">
                <?php
                // Get recent grades for the student
                $recentGradesQuery = "SELECT sg.*, es.phase, es.review, 
                                      u.username as guide_name, sg.total_marks, sg.max_marks
                                      FROM student_grades sg
                                      INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
                                      INNER JOIN guides gu ON sg.guide_id = gu.id
                                      INNER JOIN users u on gu.user_id = u.id
                                      WHERE sg.student_id = ? AND sg.status = 'approved' AND sg.academic_year_id = ?
                                      ORDER BY sg.graded_at DESC LIMIT 5";
                $stmt = $conn->prepare($recentGradesQuery);
                $stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
                $stmt->execute();
                $recentGrades = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                
                if (count($recentGrades) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Phase</th>
                                    <th>Review</th>
                                    <th>Graded By</th>
                                    <th>Total Marks</th>
                                    <th>Graded On</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentGrades as $grade): 
                                    // determine badge color based on ratio
                                    $badgeClass = ($grade['max_marks'] > 0 && ($grade['total_marks'] / $grade['max_marks']) >= 0.75) ? 'success' : (($grade['max_marks'] > 0 && ($grade['total_marks'] / $grade['max_marks']) >= 0.5) ? 'warning' : 'danger');
                                ?>
                                    <tr>
                                        <td>Phase <?php echo $grade['phase']; ?></td>
                                        <td>Review <?php echo $grade['review']; ?></td>
                                        <td><?php echo htmlspecialchars($grade['guide_name']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $badgeClass; ?>">
                                                <?php echo $grade['total_marks']; ?> / <?php echo $grade['max_marks']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d M Y', strtotime($grade['graded_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-chart-line fa-3x text-gray-300 mb-3"></i>
                        <p class="text-gray-600">No grades available yet. Your grades will appear here once your guide evaluates your work.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Recent Uploads -->
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Recent Uploads</h6>
            </div>
            <div class="card-body">
                <?php if (count($recentUploads) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                        <tr>
                                            <th>Phase</th>
                                            <th>Review</th>
                                            <th>Filename</th>
                                            <th>Upload Date</th>
                                            <th>Actions</th>
                                        </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUploads as $upload): ?>
                                    <tr>
                                        <td>Phase <?php echo $upload['phase']; ?></td>
                                        <td>Review <?php echo $upload['review']; ?></td>
                                        <td><?php echo htmlspecialchars($upload['filename']); ?></td>
                                        <td><?php echo date('d M Y, h:i A', strtotime($upload['upload_date'])); ?></td>
                                        <td>
                                            <a href="../<?php echo $upload['file_path']; ?>" class="btn btn-sm btn-info" target="_blank"><i class="fas fa-download"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right">
                        <a href="uploads.php" class="btn btn-primary btn-sm">View All Uploads</a>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-upload fa-3x text-gray-300 mb-3"></i>
                        <p class="text-gray-600">No uploads yet.</p>
                        <?php if ($student['is_team_lead']): ?>
                            <?php
                            $yearStatus = null;
                            if ($selectedAcademicYearId) {
                                $statusStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
                                $statusStmt->bind_param("i", $selectedAcademicYearId);
                                $statusStmt->execute();
                                $statusRes = $statusStmt->get_result();
                                if ($statusRes && $row = $statusRes->fetch_assoc()) {
                                    $yearStatus = $row['status'];
                                }
                            }
                            ?>
                            <?php if ($yearStatus === 'COMPLETED'): ?>
                                <button class="btn btn-primary" disabled title="View Only Mode">Upload Disabled</button>
                            <?php else: ?>
                                <a href="uploads.php" class="btn btn-primary">Upload Files</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Project progress chart removed -->

<?php include '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    // View grade details
    $('.view-grade-btn').on('click', function() {
        const gradeId = $(this).data('grade-id');
        const phase = $(this).data('phase');
        const review = $(this).data('review');
        
        // Redirect to grades page
        window.location.href = 'grades.php';
    });
    
    // Download grade PDF
    $('.download-grade-btn').on('click', function() {
        const gradeId = $(this).data('grade-id');
        
        $.ajax({
            url: '../api/download-grade-pdf.php',
            type: 'GET',
            data: { grade_id: gradeId },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Open HTML in new window for printing to PDF
                    const printWindow = window.open('', '', 'height=600,width=800');
                    printWindow.document.write(response.html);
                    printWindow.document.close();
                    
                    // Auto-trigger print dialog
                    setTimeout(function() {
                        printWindow.print();
                    }, 250);
                } else {
                    Swal.fire('Error', response.message || 'Failed to generate PDF', 'error');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                Swal.fire('Error', 'Failed to generate PDF', 'error');
            }
        });
    });
});
</script>
