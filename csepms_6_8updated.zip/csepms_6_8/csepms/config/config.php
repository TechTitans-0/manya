<?php
// Database configuration - prefer environment variables for production
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_PORT', getenv('DB_PORT') ?: 3306);

// Database names for both systems
define('DB_MAJOR_PROJECT', 'major_prj_db');
define('DB_MINI_PROJECT', 'mini_prj_db');

// Application settings
define('BASE_URL', getenv('BASE_URL') ?: '/csepms/');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 10485760); // 10MB

// Debug flag - should be false in production
define('DEBUG', filter_var(getenv('APP_DEBUG') ?: 'false', FILTER_VALIDATE_BOOLEAN));

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Error reporting (display_errors disabled for production safety; errors are still logged)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Start session if not already started (MUST be before database connection)
if (session_status() === PHP_SESSION_NONE) {
    session_name('csepms_session');
    session_start();
}

// Security headers for production (only if headers not already sent)
if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
}

// Function to get the current project type
function getCurrentProjectType() {
    if (isset($_SESSION['project_type'])) {
        return $_SESSION['project_type'];
    }
    return 'major'; // Default to major project
}

// Function to get the database name based on project type
function getDatabaseName($projectType = null) {
    if ($projectType === null) {
        $projectType = getCurrentProjectType();
    }
    return ($projectType === 'mini') ? DB_MINI_PROJECT : DB_MAJOR_PROJECT;
}

// Function to establish database connection
function establishDatabaseConnection() {
    global $conn;
    if ($conn) {
        $conn->close();
    }
    $dbName = getDatabaseName();
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, $dbName, DB_PORT);
        
        if ($conn->connect_error) {
            die("Database connection failed");
        } else {
            $conn->set_charset("utf8mb4");
        }
    } catch (Exception $e) {
        $conn = null; // Set to null on exception
    }
}

// Database connection - only establish if project type is set
$conn = null;
if (isset($_SESSION['project_type'])) {
    establishDatabaseConnection();
}

// Helper function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

// Helper function to check user role
function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

// Helper function to redirect
function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit();
}

// Helper function to sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Helper function to generate random token
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

// Helper function to hash passwords consistently
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Helper function for debug logging (no-op in production unless DEBUG is true)
function debugLog($message) {
    if (defined('DEBUG') && DEBUG) {
        error_log($message);
    }
}

// Helper function to send JSON response
function sendJSON($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

// Check login for protected pages
function requireLogin() {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
}

// Check specific role for page files (redirects instead of JSON errors)
function requireRole($role) {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
    if (!hasRole($role)) {
        // Redirect to appropriate dashboard or show access denied
        switch($role) {
            case 'student':
                redirect('login.php');
                break;
            case 'guide':
                redirect('login.php');
                break;
            case 'coordinator':
                redirect('login.php');
                break;
            default:
                redirect('login.php');
        }
    }
}

// Check specific role for API endpoints (returns JSON error instead of redirect)
function requireRoleAPI($role) {
    if (!isLoggedIn()) {
        sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
    }
    if (!hasRole($role)) {
        sendJSON(['success' => false, 'message' => $role . ' access required'], 403);
    }
}

// Ensure user has valid academic year selected
// For new sessions: defaults to ACTIVE year
// For existing selections: allows users to explicitly view COMPLETED years
// If year was deleted: falls back to ACTIVE year
function ensureValidActiveYear() {
    global $conn;
    
    if (!hasRole('coordinator') && !hasRole('guide')) {
        return; // Only applies to coordinators and guides
    }
    
    $selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
    
    // If no year selected, default to ACTIVE
    if (!$selectedAcademicYearId) {
        $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        if ($activeYear) {
            $_SESSION['academic_year_id'] = intval($activeYear['id']);
        }
        return;
    }
    
    // Check if the selected year still exists
    $yearExists = $conn->query("SELECT id, status FROM academic_years WHERE id = " . intval($selectedAcademicYearId) . " LIMIT 1")->fetch_assoc();
    
    if (!$yearExists) {
        // Selected year was deleted, default to ACTIVE
        $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        if ($activeYear) {
            $_SESSION['academic_year_id'] = intval($activeYear['id']);
        }
    }
    // If year exists (ACTIVE or COMPLETED), keep the user's selection
}

// Check if student's academic year is in COMPLETED status (read-only mode)
// Returns true if year is COMPLETED, false if ACTIVE or not found
function isStudentInReadOnlyYear() {
    global $conn;
    
    if (!hasRole('student')) {
        return false; // Only applies to students
    }
    
    if (!isset($_SESSION['role_id'])) {
        return false;
    }
    
    // Get student's academic_year_id
    $stmt = $conn->prepare("SELECT academic_year_id FROM students WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['role_id']);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if (!$result || !$result['academic_year_id']) {
        return false;
    }
    
    // Check if the academic year is COMPLETED
    $yearId = intval($result['academic_year_id']);
    $yearStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
    $yearStmt->bind_param("i", $yearId);
    $yearStmt->execute();
    $yearResult = $yearStmt->get_result()->fetch_assoc();
    
    return $yearResult && $yearResult['status'] === 'COMPLETED';
}

// Enforce read-only access for COMPLETED academic years
// For read API endpoints: allows access
// For mutation endpoints: blocks with 403 error
function enforceReadOnlyForCompletedYear() {
    global $conn;
    
    // Check if student's academic year is completed
    if (hasRole('student') && isStudentInReadOnlyYear()) {
        sendJSON(['success' => false, 'message' => 'Academic year is completed. Read-only access only.'], 403);
    }
    
    // Check if coordinator's selected academic year is completed
    if (hasRole('coordinator')) {
        $selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
        if (!$selectedAcademicYearId) {
            $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
            $selectedAcademicYearId = $activeYear ? $activeYear['id'] : null;
        }
        
        if ($selectedAcademicYearId) {
            $yearStmt = $conn->prepare("SELECT status FROM academic_years WHERE id = ?");
            $yearStmt->bind_param("i", $selectedAcademicYearId);
            $yearStmt->execute();
            $yearResult = $yearStmt->get_result()->fetch_assoc();
            $yearStmt->close();
            
            if ($yearResult && $yearResult['status'] === 'COMPLETED') {
                sendJSON(['success' => false, 'message' => 'Cannot modify data for completed academic years.'], 403);
            }
        }
    }
}

// Academic year formatting helper
function formatAcademicYear($yearLabel) {
    $projectType = getCurrentProjectType();
    
    // For mini projects, return just the year (YYYY)
    if ($projectType === 'mini') {
        // Extract the first 4 digits from the label
        $year = preg_match('/\d{4}/', $yearLabel, $matches) ? $matches[0] : $yearLabel;
        return $year;
    }
    
    // For major projects, return the full format (YYYY-YYYY)
    return $yearLabel;
}

// Get all academic years formatted appropriately
function getFormattedAcademicYears() {
    global $conn;
    $projectType = getCurrentProjectType();
    
    $query = "SELECT id, year_label, status FROM academic_years ORDER BY year_label DESC";
    $result = $conn->query($query);
    
    $years = [];
    while ($row = $result->fetch_assoc()) {
        $formatted = formatAcademicYear($row['year_label']);
        $years[] = [
            'id' => intval($row['id']),
            'year_label' => $row['year_label'],
            'formatted_label' => $formatted,
            'status' => $row['status']
        ];
    }
    
    return $years;
}
?>
