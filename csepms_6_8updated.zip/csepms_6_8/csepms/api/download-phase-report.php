<?php
require_once '../config/config.php';
requireRoleAPI('student');

header('Content-Type: application/json');

$studentId = intval($_SESSION['role_id']);
$phase = isset($_GET['phase']) ? intval($_GET['phase']) : 0;

if (!$phase) sendJSON(['success' => false, 'message' => 'Phase is required']);

try {
    // Fetch reviews for this phase for the student
    $query = "SELECT sg.id, es.phase, es.review, es.title as sheet_title, sg.total_marks, sg.max_marks, sg.graded_at, u.username as guide_name
              FROM student_grades sg
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              INNER JOIN guides g ON sg.guide_id = g.id
              INNER JOIN users u ON g.user_id = u.id
              WHERE sg.student_id = ? AND es.phase = ? AND sg.status = 'approved'
              ORDER BY es.review ASC";

    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $studentId, $phase);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = $res->fetch_all(MYSQLI_ASSOC);
    if (count($rows) === 0) {
        sendJSON(['success' => false, 'message' => 'No submitted grades found for this phase']);
    }

    // Build HTML
    function imageToBase64($imagePath) {
        if (!file_exists($imagePath)) return '';
        $imageData = file_get_contents($imagePath);
        $mimeType = mime_content_type($imagePath);
        return 'data:' . $mimeType . ';base64,' . base64_encode($imageData);
    }

    $headerBase64 = imageToBase64(__DIR__ . '/../uploads/header.jpeg');
    $signatureBase64 = imageToBase64(__DIR__ . '/../uploads/signature.jpeg');

    $html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Phase ' . $phase . ' Report</title><style>body{font-family:Arial;margin:8mm} .header img{width:100%} table{width:100%;border-collapse:collapse;margin-top:10px} th,td{border:1px solid #000;padding:8px;text-align:left} th{background:#fff}</style></head><body>';

    if (!empty($headerBase64)) $html .= '<div class="header"><img src="' . $headerBase64 . '"/></div>';

    $html .= '<h2>Phase ' . intval($phase) . ' - Detailed Report</h2>';
    $html .= '<table><thead><tr><th>Review</th><th>Evaluation</th><th>Obtained Marks</th><th>Max Marks</th><th>Graded By</th><th>Graded On</th></tr></thead><tbody>';

    $totalObt = 0; $totalMax = 0;
    foreach ($rows as $r) {
        $obt = floatval($r['total_marks']);
        $max = floatval($r['max_marks']);
        $totalObt += $obt; $totalMax += $max;
        $html .= '<tr><td>Review ' . intval($r['review']) . '</td><td>' . htmlspecialchars($r['sheet_title']) . '</td><td>' . number_format($obt,2) . '</td><td>' . number_format($max,2) . '</td><td>' . htmlspecialchars($r['guide_name']) . '</td><td>' . date('d-M-Y', strtotime($r['graded_at'])) . '</td></tr>';
    }

    $percent = $totalMax > 0 ? round(($totalObt / $totalMax) * 100, 2) : 0;
    $html .= '<tr class="font-weight-bold"><td colspan="2">Phase Total</td><td>' . number_format($totalObt,2) . '</td><td>' . number_format($totalMax,2) . '</td><td colspan="2">' . number_format($percent,2) . '%</td></tr>';

    $html .= '</tbody></table>';

    if (!empty($signatureBase64)) $html .= '<div style="text-align:right;margin-top:30px;"><img src="' . $signatureBase64 . '" style="max-width:200px;"/></div>';

    $html .= '</body></html>';

    sendJSON(['success' => true, 'html' => $html, 'filename' => 'Phase_' . $phase . '_Report_' . $studentId . '.pdf']);

} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>
