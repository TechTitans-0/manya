<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

// Prevent sending circulars for completed academic years
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}


$title = sanitizeInput($_POST['title'] ?? '');
$message = sanitizeInput($_POST['message'] ?? '');
$targetRole = sanitizeInput($_POST['target_role'] ?? 'all');

// Title and message are optional. Provide sensible defaults.
if (empty($title)) {
    $title = 'Circular';
} else {
    $title = 'Circular: ' . $title;
}

// Message may be empty string; DB accepts empty text (not NULL).

// Determine academic year for this notification (must be NOT NULL per schema)
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $res = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        $academicYearId = intval($row['id']);
        $_SESSION['academic_year_id'] = $academicYearId;
    }
}

// (title already prepared above with 'Circular' prefix when appropriate)

// Handle file upload
$attachmentPath = null;
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['attachment'];
    $allowedTypes = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'jpg', 'jpeg', 'png', 'zip'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($ext, $allowedTypes)) {
        sendJSON(['success' => false, 'message' => 'Invalid file type. Allowed: PDF, PPT, DOC, XLS, images, ZIP']);
    }
    
    // Check file size (100MB = 104857600 bytes)
    if ($file['size'] > 104857600) {
        sendJSON(['success' => false, 'message' => 'File size exceeds 100MB limit']);
    }
    
    $uploadDir = '../uploads/circulars/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $file['name']);
    $attachmentPath = 'uploads/circulars/' . $fileName;
    $fullAttachment = '../' . $attachmentPath;
    
    if (!move_uploaded_file($file['tmp_name'], $fullAttachment)) {
        sendJSON(['success' => false, 'message' => 'Failed to upload attachment']);
    }
    
    $resolved = realpath($fullAttachment);
    $uploadReal = realpath(UPLOAD_PATH);
    if ($resolved === false || strpos($resolved, $uploadReal . DIRECTORY_SEPARATOR) !== 0) {
        @unlink($fullAttachment);
        sendJSON(['success' => false, 'message' => 'Invalid file path']);
    }
}

try {
    $conn->begin_transaction();
    
    // Check if attachment_path column exists in notifications
    $checkCol = "SHOW COLUMNS FROM notifications LIKE 'attachment_path'";
    $result = $conn->query($checkCol);
    
    $senderId = $_SESSION['user_id'];
    
    // Create notification for students
    if ($targetRole === 'all' || $targetRole === 'student') {
        $insertNotif = "INSERT INTO notifications (sender_id, academic_year_id, title, message, attachment_path, target_type, target_value)
                        VALUES (?, ?, ?, ?, ?, 'all_students', NULL)";
        $stmt = $conn->prepare($insertNotif);
        $stmt->bind_param("iisss", $senderId, $academicYearId, $title, $message, $attachmentPath);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create student notification');
        }
        
        $notificationId = $conn->insert_id;
        
        // Create read status for all students
        $insertStatus = "INSERT INTO notification_read_status (notification_id, user_id, academic_year_id)
                SELECT ?, id, ? FROM users WHERE role = 'student'";
        $stmt = $conn->prepare($insertStatus);
        $stmt->bind_param("ii", $notificationId, $academicYearId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create notification status for students');
        }
    }
    
    // Create notification for guides
    if ($targetRole === 'all' || $targetRole === 'guide') {
        $insertNotif = "INSERT INTO notifications (sender_id, academic_year_id, title, message, attachment_path, target_type, target_value)
                        VALUES (?, ?, ?, ?, ?, 'all_guides', NULL)";
        $stmt = $conn->prepare($insertNotif);
        $stmt->bind_param("iisss", $senderId, $academicYearId, $title, $message, $attachmentPath);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create guide notification');
        }
        
        $notificationId = $conn->insert_id;
        
        // Create read status for all guides
        $insertStatus = "INSERT INTO notification_read_status (notification_id, user_id, academic_year_id)
                SELECT ?, id, ? FROM users WHERE role = 'guide'";
        $stmt = $conn->prepare($insertStatus);
        $stmt->bind_param("ii", $notificationId, $academicYearId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create notification status for guides');
        }
    }

    // Create notification for coordinators when 'all' selected
    // Note: mini_prj_db does not have 'all_coordinators' in notifications.target_type ENUM,
    // so we use 'specific_user' for each coordinator individually on mini projects.
    if ($targetRole === 'all') {
        $isMiniProject = (getCurrentProjectType() === 'mini');
        
        if ($isMiniProject) {
            // For mini projects: create individual notifications for each coordinator using 'specific_user'
            $coordUsers = $conn->query("SELECT id FROM users WHERE role = 'coordinator'");
            while ($coordRow = $coordUsers->fetch_assoc()) {
                $coordUserId = intval($coordRow['id']);
                $insertNotif = "INSERT INTO notifications (sender_id, academic_year_id, title, message, attachment_path, target_type, target_value)
                                VALUES (?, ?, ?, ?, ?, 'specific_user', ?)";
                $stmt = $conn->prepare($insertNotif);
                $coordUserIdStr = strval($coordUserId);
                $stmt->bind_param("iissss", $senderId, $academicYearId, $title, $message, $attachmentPath, $coordUserIdStr);
                if (!$stmt->execute()) {
                    throw new Exception('Failed to create coordinator notification');
                }
                $notificationId = $conn->insert_id;

                $insertStatus = "INSERT INTO notification_read_status (notification_id, user_id, academic_year_id) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($insertStatus);
                $stmt->bind_param("iii", $notificationId, $coordUserId, $academicYearId);
                if (!$stmt->execute()) {
                    throw new Exception('Failed to create notification status for coordinator');
                }
            }
        } else {
            // For major projects: use 'all_coordinators' ENUM value
            $insertNotif = "INSERT INTO notifications (sender_id, academic_year_id, title, message, attachment_path, target_type, target_value)
                            VALUES (?, ?, ?, ?, ?, 'all_coordinators', NULL)";
            $stmt = $conn->prepare($insertNotif);
            $stmt->bind_param("iisss", $senderId, $academicYearId, $title, $message, $attachmentPath);

            if (!$stmt->execute()) {
                throw new Exception('Failed to create coordinator notification');
            }

            $notificationId = $conn->insert_id;

            $insertStatus = "INSERT INTO notification_read_status (notification_id, user_id, academic_year_id)
                            SELECT ?, id, ? FROM users WHERE role = 'coordinator'";
            $stmt = $conn->prepare($insertStatus);
            $stmt->bind_param("ii", $notificationId, $academicYearId);

            if (!$stmt->execute()) {
                throw new Exception('Failed to create notification status for coordinators');
            }
        }
    }
    
    $conn->commit();
    
    sendJSON(['success' => true, 'message' => 'Circular sent successfully']);
    
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
