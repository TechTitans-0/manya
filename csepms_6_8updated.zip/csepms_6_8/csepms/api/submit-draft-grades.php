<?php
require_once '../config/config.php';

// Allow both guides and coordinators to submit grades
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}
if (!hasRole('guide') && !hasRole('coordinator')) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$groupId = intval($_POST['group_id'] ?? 0);
$evaluationSheetId = intval($_POST['evaluation_sheet_id'] ?? 0);

if (!$groupId || !$evaluationSheetId) {
    sendJSON(['success' => false, 'message' => 'Missing parameters']);
}

// Verify user (guide or coordinator) has access to this group
if (hasRole('guide')) {
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
} else {
    // coordinator
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND coordinator_guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
}
$stmt->execute();
if ($stmt->get_result()->num_rows === 0) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

// Count group members
$countQuery = "SELECT COUNT(*) as cnt FROM students WHERE group_id = ?";
$stmt = $conn->prepare($countQuery);
$stmt->bind_param("i", $groupId);
$stmt->execute();
$membersCount = intval($stmt->get_result()->fetch_assoc()['cnt'] ?? 0);

// Count distinct student grades with 'draft' status for this sheet
$gradesCountQuery = "SELECT COUNT(DISTINCT student_id) as cnt FROM student_grades WHERE group_id = ? AND evaluation_sheet_id = ? AND status = 'draft'";
$stmt = $conn->prepare($gradesCountQuery);
$stmt->bind_param("ii", $groupId, $evaluationSheetId);
$stmt->execute();
$gradesCount = intval($stmt->get_result()->fetch_assoc()['cnt'] ?? 0);

if ($membersCount === 0) {
    sendJSON(['success' => false, 'message' => 'No students in group']);
}

if ($gradesCount === 0) {
    sendJSON(['success' => false, 'message' => 'No draft grades found to submit']);
}

if ($gradesCount < $membersCount) {
    sendJSON(['success' => false, 'message' => 'Not all students have draft grades yet']);
}

// All students have draft grade entries, mark them as submitted
// Update grades that were created by this guide or coordinator
if (hasRole('guide')) {
    $update = "UPDATE student_grades SET status = 'submitted', updated_at = NOW() WHERE group_id = ? AND evaluation_sheet_id = ? AND guide_id = ? AND status = 'draft'";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("iii", $groupId, $evaluationSheetId, $_SESSION['role_id']);
} else {
    // coordinator
    $update = "UPDATE student_grades SET status = 'submitted', updated_at = NOW() WHERE group_id = ? AND evaluation_sheet_id = ? AND coordinator_guide_id = ? AND status = 'draft'";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("iii", $groupId, $evaluationSheetId, $_SESSION['role_id']);
}

if (!$stmt->execute()) {
    sendJSON(['success' => false, 'message' => 'Failed to submit grades']);
}

$affectedRows = $stmt->affected_rows;

sendJSON([
    'success' => true, 
    'message' => 'Grades submitted successfully',
    'affected_rows' => $affectedRows
]);

?>
