<?php
require_once __DIR__ . '/../config/config.php';
requireRoleAPI('coordinator');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json; charset=utf-8');

$phase = isset($_POST['phase']) ? intval($_POST['phase']) : null;
$review = isset($_POST['review']) ? intval($_POST['review']) : null;
$apply_all = isset($_POST['apply_all']) ? (int)$_POST['apply_all'] : 1;

if ($phase === null || $review === null) {
    sendJSON(['success' => false, 'message' => 'Phase and review are required']);
}

// Mini projects do not have current_phase/current_review columns in pgroups
if (getCurrentProjectType() === 'mini') {
    sendJSON(['success' => true, 'message' => 'Project phase/review not applicable to mini projects']);
}

// Determine selected academic year for scoping
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $ayRow ? intval($ayRow['id']) : null;
}

// Prepare update scoped to selected academic year
if ($selectedAcademicYearId && $apply_all) {
    $stmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?, current_review = ? WHERE academic_year_id = ?");
    $stmt->bind_param('iii', $phase, $review, $selectedAcademicYearId);
} elseif ($selectedAcademicYearId) {
    $stmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?, current_review = ? WHERE academic_year_id = ? AND project_status != 'completed'");
    $stmt->bind_param('iii', $phase, $review, $selectedAcademicYearId);
} elseif ($apply_all) {
    $stmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?, current_review = ?");
    $stmt->bind_param('ii', $phase, $review);
} else {
    $stmt = $conn->prepare("UPDATE `pgroups` SET current_phase = ?, current_review = ? WHERE project_status != 'completed'");
    $stmt->bind_param('ii', $phase, $review);
}

$ok = $stmt->execute();
if ($ok) {
    $affected = $stmt->affected_rows;
    sendJSON(['success' => true, 'message' => "Updated phase/review for {$affected} groups"]);
} else {
    debugLog('Set project phase error: ' . $conn->error);
    sendJSON(['success' => false, 'message' => 'Failed to update phase/review']);
}

$stmt->close();
