<?php
require_once '../config/config.php';
requireRole('coordinator');

header('Content-Type: application/json');

// Get selected academic year from session or default to ACTIVE
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Get global phase and review settings
$globalSettings = $conn->query("SELECT setting_key, setting_value FROM global_settings WHERE setting_key IN ('current_phase','current_review')");
$current_phase = 1;
$current_review = 1;
while ($row = $globalSettings->fetch_assoc()) {
    if ($row['setting_key'] === 'current_phase') $current_phase = intval($row['setting_value']);
    if ($row['setting_key'] === 'current_review') $current_review = intval($row['setting_value']);
}

// Get all groups with details + grade status summary - filter by academic_year_id
$query = "SELECT g.id, g.batch, g.group_name, g.project_title, g.project_description, 
          g.guide_id, g.coordinator_guide_id, g.academic_year_id, g.created_at,
          ay.year_label as academic_year,
          u.username as guide_name,
          c.username as coordinator_name,
          COUNT(DISTINCT s.id) as member_count,
          COALESCE(tl_user.username, tl_user.email) as team_lead_name,
          SUM(CASE WHEN sg.status = 'submitted' THEN 1 ELSE 0 END) AS submitted_grades,
          SUM(CASE WHEN sg.status = 'approved' THEN 1 ELSE 0 END) AS approved_grades
          FROM pgroups g
          LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
          LEFT JOIN guides gd ON g.guide_id = gd.id
          LEFT JOIN users u ON gd.user_id = u.id
          LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
          LEFT JOIN users c ON cd.user_id = c.id
          LEFT JOIN students s ON g.id = s.group_id AND s.academic_year_id = ?
          LEFT JOIN students tl ON g.id = tl.group_id AND tl.is_team_lead = 1 AND tl.academic_year_id = ?
          LEFT JOIN users tl_user ON tl.user_id = tl_user.id
          LEFT JOIN student_grades sg ON sg.group_id = g.id AND sg.academic_year_id = ?
          WHERE g.academic_year_id = ?
          GROUP BY g.id,g.batch,g.group_name,g.project_title,g.project_description,g.guide_id,g.coordinator_guide_id,g.academic_year_id,g.created_at,ay.year_label,u.username,c.username,tl_user.username,tl_user.email
          ORDER BY g.created_at DESC";

$stmt = $conn->prepare($query);
if (!$stmt) {
    sendJSON(['success' => false, 'message' => $conn->error]);
    exit;
}
$stmt->bind_param("iiii", $selectedAcademicYearId, $selectedAcademicYearId, $selectedAcademicYearId, $selectedAcademicYearId);
$stmt->execute();
$result = $stmt->get_result();
if (!$result) {
    sendJSON(['success' => false, 'message' => $conn->error]);
    exit;
}
$pgroups = $result->fetch_all(MYSQLI_ASSOC);

// Add global phase/review and derived grade status to each group
foreach ($pgroups as &$group) {
    $group['current_phase'] = $current_phase;
    $group['current_review'] = $current_review;
    $submitted = intval($group['submitted_grades'] ?? 0);
    $approved = intval($group['approved_grades'] ?? 0);
    // Status logic: if there are submitted grades waiting for approval, show 'submitted'
    // If only approved grades exist, show 'approved'
    // If neither, show 'none'
    $group['grade_status'] = $submitted > 0 ? 'submitted' : ($approved > 0 ? 'approved' : 'none');
}

sendJSON(['success' => true, 'groups' => $pgroups]);
?>
