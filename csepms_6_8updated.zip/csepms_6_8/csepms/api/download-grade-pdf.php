<?php
require_once '../config/config.php';
requireRoleAPI('student');

header('Content-Type: application/json');

$gradeId = intval($_GET['grade_id'] ?? 0);

if (!$gradeId) {
    sendJSON(['success' => false, 'message' => 'Grade ID is required']);
}

try {
    // Get grade details
    $query = "SELECT sg.*, es.phase, es.review, es.title as sheet_title, 
              s.usn, s.name as student_name,
              gu_user.username as guide_name
              FROM student_grades sg
              INNER JOIN students s ON sg.student_id = s.id
              INNER JOIN guides gu ON sg.guide_id = gu.id
              INNER JOIN users gu_user ON gu.user_id = gu_user.id
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              WHERE sg.id = ? AND sg.student_id = ? AND sg.status = 'approved'";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception('Database prepare error: ' . $conn->error);
    }

    $stmt->bind_param("ii", $gradeId, $_SESSION['role_id']);
    if (!$stmt->execute()) {
        throw new Exception('Database execute error: ' . $stmt->error);
    }

    $gradeResult = $stmt->get_result();

    if ($gradeResult->num_rows === 0) {
        throw new Exception('Grade not found');
    }

    $grade = $gradeResult->fetch_assoc();

    // Get grade details
    $detailsQuery = "SELECT sgd.*, ec.criterion_name, ec.max_marks
                     FROM student_grade_details sgd
                     INNER JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
                     WHERE sgd.student_grade_id = ?
                     ORDER BY ec.id ASC";

    $stmt = $conn->prepare($detailsQuery);
    if (!$stmt) {
        throw new Exception('Database prepare error for details');
    }

    $stmt->bind_param("i", $gradeId);
    if (!$stmt->execute()) {
        throw new Exception('Database execute error for details');
    }

    $detailsResult = $stmt->get_result();
    $criteria = $detailsResult->fetch_all(MYSQLI_ASSOC);

    // Function to convert image to base64
    function imageToBase64($imagePath) {
        if (!file_exists($imagePath)) {
            return '';
        }
        
        $imageData = file_get_contents($imagePath);
        $mimeType = mime_content_type($imagePath);
        return 'data:' . $mimeType . ';base64,' . base64_encode($imageData);
    }

    // Get header and signature images as base64
    $headerBase64 = imageToBase64(__DIR__ . '/../uploads/header.jpeg');
    $signatureBase64 = imageToBase64(__DIR__ . '/../uploads/signature.jpeg');

    // Generate HTML for PDF
    $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Grade Report</title>
    <style>
        @page { size: A4; margin: 8mm; }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 8mm;
            line-height: 1.4;
            color: #222;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header img {
            width: 100%;
            height: auto;
            display: block;
        }
        .title {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
        }
        .info-table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .info-table td:nth-child(odd) {
            font-weight: bold;
            width: 20%;
            background-color: #f9f9f9;
        }
        .criteria-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .criteria-table th {
            background-color: #f0f0f0;
            border: 1px solid #999;
            padding: 6px;
            text-align: left;
            font-weight: bold;
            font-size: 12px;
        }
        .criteria-table td {
            border: 1px solid #ddd;
            padding: 6px;
            font-size: 12px;
        }
        .criteria-table tr.total {
            background-color: #f9f9f9;
            font-weight: bold;
            border-top: 2px solid #999;
        }
        .criteria-table td.marks-center {
            text-align: center;
        }
        .criteria-table td.total-obtained {
            color: #28a745;
        }
        .signature {
            text-align: right;
            margin-top: 50px;
        }
        .signature img {
            width: 100%;
            height: auto;
            display: block;
            max-height: 220px;
            object-fit: contain;
        }
        .single-page { page-break-inside: avoid; }
        @media print {
            html, body { height: 100%; overflow: hidden; }
            body { margin: 0; padding: 0; }
            .no-print { display: none; }
            img { -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body>
    <div class="header">
';

    // Add header image if available
    if (!empty($headerBase64)) {
        $html .= '<img src="' . $headerBase64 . '" alt="Header">';
    }

    $html .= '
    </div>

    <div class="title">Grade Report</div>

    <table class="info-table">
        <tr>
            <td>Student Name:</td>
            <td>' . htmlspecialchars($grade['student_name']) . '</td>
            <td>USN:</td>
            <td>' . htmlspecialchars($grade['usn']) . '</td>
        </tr>
        <tr>
            <td>Phase:</td>
            <td>Phase ' . intval($grade['phase']) . '</td>
            <td>Review:</td>
            <td>Review ' . intval($grade['review']) . '</td>
        </tr>
        <tr>
            <td>Evaluation Sheet:</td>
            <td colspan="3">' . htmlspecialchars($grade['sheet_title']) . '</td>
        </tr>
        <tr>
            <td>Graded By:</td>
            <td>' . htmlspecialchars($grade['guide_name']) . '</td>
            <td>Graded On:</td>
            <td>' . date('d-M-Y H:i', strtotime($grade['graded_at'])) . '</td>
        </tr>
    </table>

    <div class="single-page">
    <table class="criteria-table">
        <thead>
            <tr>
                <th>Criteria</th>
                <th class="marks-center">Marks Obtained</th>
            </tr>
        </thead>
        <tbody>
';

    $totalObtained = 0;
    foreach ($criteria as $criterion) {
        $obtained = floatval($criterion['marks_obtained']);
        $totalObtained += $obtained;

        $html .= '<tr>
                    <td>' . htmlspecialchars($criterion['criterion_name']) . '</td>
                    <td class="marks-center">' . number_format($obtained, 2) . '</td>
                </tr>';
    }

    $html .= '
            <tr class="total">
                <td>Total</td>
                <td class="marks-center total-obtained">' . number_format($totalObtained, 2) . '</td>
            </tr>
        </tbody>
    </table>
    </div>
';

    // Add overall remarks if available
    if (!empty($grade['overall_remarks'])) {
        $html .= '
    <div style="margin-top: 20px; margin-bottom: 30px;">
        <h4 style="font-size: 14px; font-weight: bold; color: #333; margin-bottom: 10px;">Overall Remarks:</h4>
        <div style="padding: 12px; background-color: #f9f9f9; border-left: 4px solid #007bff; font-size: 12px; line-height: 1.6;">' 
            . nl2br(htmlspecialchars($grade['overall_remarks'])) . 
        '</div>
    </div>
';
    }

    // Add signature image if available
    if (!empty($signatureBase64)) {
        $html .= '
    <div class="signature">
        <img src="' . $signatureBase64 . '" alt="Signature">
    </div>
';
    }

    $html .= '
</body>
</html>';

    // Return HTML for printing/PDF conversion
    sendJSON([
        'success' => true,
        'html' => $html,
        'filename' => 'Grade_' . $grade['usn'] . '_Phase' . $grade['phase'] . '_Review' . $grade['review'] . '.pdf'
    ]);

} catch (Exception $e) {
    error_log("Grade PDF generation error: " . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>


