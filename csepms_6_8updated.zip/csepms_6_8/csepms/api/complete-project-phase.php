<?php
require_once __DIR__ . '/../config/config.php';
requireRoleAPI('coordinator');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json; charset=utf-8');

$phase = isset($_POST['phase']) ? intval($_POST['phase']) : null;
$review = isset($_POST['review']) ? intval($_POST['review']) : null;

if ($phase === null || $review === null) {
    sendJSON(['success' => false, 'message' => 'Phase and review are required']);
}

// Mini projects do not track phase/review per group
if (getCurrentProjectType() === 'mini') {
    sendJSON(['success' => true, 'message' => 'Project phase completion not applicable to mini projects']);
}

// Determine selected academic year for scoping
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $ayRow ? intval($ayRow['id']) : null;
}

// Mark matching groups as completed - scoped to selected academic year
if ($selectedAcademicYearId) {
    $stmt = $conn->prepare("UPDATE `pgroups` SET project_status = 'completed' WHERE current_phase = ? AND current_review = ? AND project_status != 'completed' AND academic_year_id = ?");
    $stmt->bind_param('iii', $phase, $review, $selectedAcademicYearId);
} else {
    $stmt = $conn->prepare("UPDATE `pgroups` SET project_status = 'completed' WHERE current_phase = ? AND current_review = ? AND project_status != 'completed'");
    $stmt->bind_param('ii', $phase, $review);
}

$ok = $stmt->execute();
if ($ok) {
    $affected = $stmt->affected_rows;
    sendJSON(['success' => true, 'message' => "Marked {$affected} groups as completed"]);
} else {
    debugLog('Complete project phase error: ' . $conn->error);
    sendJSON(['success' => false, 'message' => 'Failed to mark groups as completed']);
}

$stmt->close();
