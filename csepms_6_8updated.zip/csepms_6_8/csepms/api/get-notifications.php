<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

// Get recent notifications for the current user
// Only return circulars sent by coordinator (title prefixed with 'Circular:')
$selectedAcademicYear = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYear) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYear = $activeYear ? intval($activeYear['id']) : 0;
}

$query = "SELECT n.*, nrs.is_read, u.role as sender_role
          FROM notifications n
          INNER JOIN notification_read_status nrs ON n.id = nrs.notification_id
          INNER JOIN users u ON n.sender_id = u.id
          WHERE nrs.user_id = ? AND nrs.academic_year_id = ? AND nrs.is_read = 0 AND (n.title LIKE 'Circular:%' OR n.title = '' OR n.title IS NULL) AND u.role = 'coordinator'
          ORDER BY n.created_at DESC
          LIMIT 10";

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $_SESSION['user_id'], $selectedAcademicYear);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}

sendJSON([
    'success' => true,
    'notifications' => $notifications
]);
?>
