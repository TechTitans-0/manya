<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

// Accepts POST with { group_id }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);
$groupId = intval($input['group_id'] ?? 0);

if (!$groupId) {
    sendJSON(['success' => false, 'message' => 'Group ID is required']);
}

// Determine selected academic year for scoping
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $ayRow ? intval($ayRow['id']) : null;
}

try {
    $conn->begin_transaction();

    // Approve ONLY submitted grades for this group and academic year (idempotent)
    $query = "UPDATE student_grades SET status = 'approved', updated_at = NOW() WHERE group_id = ? AND status = 'submitted'";
    $params = [$groupId];
    $types = 'i';
    if ($selectedAcademicYearId) {
        $query .= " AND academic_year_id = ?";
        $params[] = $selectedAcademicYearId;
        $types .= 'i';
    }
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $affected = $stmt->affected_rows;

    // Get all grades for this group after update
    $getQuery = "SELECT id, status FROM student_grades WHERE group_id = ?";
    $getParams = [$groupId];
    $getTypes = 'i';
    if ($selectedAcademicYearId) {
        $getQuery .= " AND academic_year_id = ?";
        $getParams[] = $selectedAcademicYearId;
        $getTypes .= 'i';
    }
    $stmt = $conn->prepare($getQuery);
    $stmt->bind_param($getTypes, ...$getParams);
    $stmt->execute();
    $result = $stmt->get_result();
    $grades = [];
    while ($row = $result->fetch_assoc()) {
        $grades[] = $row;
    }

    $conn->commit();
    sendJSON(['success' => true, 'result' => $grades, 'approved_count' => $affected]);
} catch (Exception $e) {
    $conn->rollback();
    debugLog('Approve all grades error: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to approve grades']);
}
