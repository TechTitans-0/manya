<?php
require_once '../config/config.php';
requireRole('guide');

header('Content-Type: application/json');

// Determine selected academic year (session or active)
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Get uploads for this guide's groups (include all statuses so guide can review/see history)
// Return aliases matching frontend keys: file_name, uploaded_at, review_type, status, feedback
// For mini projects, phase and review columns don't exist
if ($_SESSION['project_type'] === 'mini') {
    $query = "SELECT pu.id, pu.group_id, pu.filename as file_name, pu.upload_date as uploaded_at, pu.file_path, pu.file_type, pu.project_title, pu.uploaded_by, pu.academic_year_id, pu.status, pu.feedback, 0 as phase, 0 as review, 0 as review_type, g.group_name, g.batch, g.project_title, u.username as uploaded_by_name
              FROM project_uploads pu
              INNER JOIN pgroups g ON pu.group_id = g.id
              INNER JOIN students s ON pu.uploaded_by = s.id
              INNER JOIN users u ON s.user_id = u.id
              WHERE g.guide_id = ? AND pu.academic_year_id = ?
              ORDER BY pu.upload_date DESC";
} else {
    $query = "SELECT pu.*, pu.filename as file_name, pu.upload_date as uploaded_at, pu.review as review_type, pu.status as status, pu.feedback as feedback, g.group_name, g.batch, g.project_title, u.username as uploaded_by_name, pu.file_path
              FROM project_uploads pu
              INNER JOIN pgroups g ON pu.group_id = g.id
              INNER JOIN students s ON pu.uploaded_by = s.id
              INNER JOIN users u ON s.user_id = u.id
              WHERE g.guide_id = ? AND pu.academic_year_id = ?
              ORDER BY pu.upload_date DESC";
}

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $_SESSION['role_id'], $selectedAcademicYearId);
$stmt->execute();
$pendingReviews = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

sendJSON(['success' => true, 'reviews' => $pendingReviews]);
?>
