<?php
require_once '../config/config.php';

// Allow both guides and coordinators to save grades
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}
if (!hasRole('guide') && !hasRole('coordinator')) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

// Prevent modifications for completed academic years (for coordinators)
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// Ensure no output before JSON
ob_clean();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$groupId = intval($_POST['group_id'] ?? 0);
$evaluationSheetId = intval($_POST['evaluation_sheet_id'] ?? 0);
$status = sanitizeInput($_POST['status'] ?? 'draft');
$overallRemarks = sanitizeInput($_POST['overall_remarks'] ?? '');
// Overall remarks are now optional for submission

// figure out which guide_id or coordinator_guide_id should be recorded
$guideId = null;
$coordinatorGuideId = null;

if ($groupId) {
    $gstmt = $conn->prepare("SELECT guide_id, coordinator_guide_id FROM pgroups WHERE id = ? LIMIT 1");
    $gstmt->bind_param('i', $groupId);
    $gstmt->execute();
    $ginfo = $gstmt->get_result()->fetch_assoc();
    if ($ginfo) {
        if (!empty($ginfo['guide_id'])) {
            $guideId = intval($ginfo['guide_id']);
        } elseif (!empty($ginfo['coordinator_guide_id'])) {
            $coordinatorGuideId = intval($ginfo['coordinator_guide_id']);
        }
    }
}

// fallback: if we still don't have one, check current user's role
if ($guideId === null && $coordinatorGuideId === null) {
    if (hasRole('guide')) {
        $guideId = $_SESSION['role_id'];
    } elseif (hasRole('coordinator')) {
        $coordinatorGuideId = $_SESSION['role_id'];
    }
}

if ($guideId === null && $coordinatorGuideId === null) {
    sendJSON(['success' => false, 'message' => 'Unable to determine guide or coordinator for grading'], 400);
}

// Allow draft, submitted, pending statuses (approved is only set by coordinator authorization)
if (!in_array($status, ['draft', 'submitted', 'pending'])) {
    $status = 'draft';
}

// Handle students data - could be JSON string or array
$studentsData = $_POST['students'] ?? '[]';
if (is_string($studentsData)) {
    $students = json_decode($studentsData, true);
} else {
    $students = $studentsData;
}

// Debug logging (suppressed in production)
debugLog("Save Grades Debug - Group ID: $groupId, Eval Sheet ID: $evaluationSheetId, Status: $status");

if (!$groupId || !$evaluationSheetId || empty($students) || !is_array($students)) {
    debugLog("Validation failed - Group: $groupId, Sheet: $evaluationSheetId, Students count: " . count($students));
    sendJSON(['success' => false, 'message' => 'Missing or invalid required parameters']);
}

// Verify the user (guide or coordinator) has access to this group
if (hasRole('guide')) {
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
} else {
    // coordinator
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND coordinator_guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
}
$stmt->execute();

if ($stmt->get_result()->num_rows === 0) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

try {
    $conn->begin_transaction();

    debugLog("Starting transaction for saving grades");

    // Get max marks for the evaluation sheet
    $maxMarksQuery = "SELECT SUM(max_marks) as total_max FROM evaluation_criteria WHERE evaluation_sheet_id = ?";
    $stmt = $conn->prepare($maxMarksQuery);
    if (!$stmt) {
        throw new Exception('Database prepare error: ' . $conn->error);
    }
    $stmt->bind_param("i", $evaluationSheetId);
    if (!$stmt->execute()) {
        throw new Exception('Database execute error: ' . $stmt->error);
    }
    $result = $stmt->get_result();
    $maxMarksRow = $result->fetch_assoc();
    $maxMarks = $maxMarksRow ? floatval($maxMarksRow['total_max']) : 0;

    debugLog("Max marks for evaluation sheet $evaluationSheetId: $maxMarks");

    if ($maxMarks == 0) {
        throw new Exception('Invalid evaluation sheet or no criteria found');
    }

    // Determine academic year for these grades (prefer session, fallback to ACTIVE)
    $academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
    if (!$academicYearId) {
        $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        if ($ayRow && isset($ayRow['id'])) $academicYearId = intval($ayRow['id']);
    }
    if (!$academicYearId) throw new Exception('Academic year not set');

    // Process each student's grades
    debugLog("Processing " . count($students) . " students");
    foreach ($students as $studentData) {
        $studentId = intval($studentData['student_id']);
        $criteria = $studentData['criteria'];

        debugLog("Processing student ID: $studentId with " . count($criteria) . " criteria");

        // Calculate total marks for this student
        $totalMarks = 0;
        foreach ($criteria as $criterion) {
            $totalMarks += floatval($criterion['obtained_marks']);
        }

        debugLog("Total marks for student $studentId: $totalMarks");

        // Check if student grade already exists for this academic year and use the latest row if duplicates exist
        $checkGrade = "SELECT id, status FROM student_grades WHERE student_id = ? AND evaluation_sheet_id = ? AND academic_year_id = ? ORDER BY updated_at DESC LIMIT 1";
        $stmt = $conn->prepare($checkGrade);
        if (!$stmt) {
            throw new Exception('Failed to prepare grade check: ' . $conn->error);
        }
        $stmt->bind_param("iii", $studentId, $evaluationSheetId, $academicYearId);
        if (!$stmt->execute()) {
            throw new Exception('Failed to execute grade check: ' . $stmt->error);
        }
        $existingGrade = $stmt->get_result()->fetch_assoc();

        if ($existingGrade) {
            // Allow updating grades with any status (guide can re-edit submitted/approved grades and resubmit)
            $gradeId = $existingGrade['id'];
            $updateGrade = "UPDATE student_grades SET total_marks = ?, max_marks = ?, status = ?, overall_remarks = ?, updated_at = NOW()
                            WHERE id = ?";
            $stmt = $conn->prepare($updateGrade);
            if (!$stmt) {
                throw new Exception('Failed to prepare grade update: ' . $conn->error);
            }
            $stmt->bind_param("ddssi", $totalMarks, $maxMarks, $status, $overallRemarks, $gradeId);
            if (!$stmt->execute()) {
                throw new Exception('Failed to update grade: ' . $stmt->error);
            }

            // Delete old grade details
            $deleteDetails = "DELETE FROM student_grade_details WHERE student_grade_id = ?";
            $stmt = $conn->prepare($deleteDetails);
            if (!$stmt) {
                throw new Exception('Failed to prepare delete details: ' . $conn->error);
            }
            $stmt->bind_param("i", $gradeId);
            if (!$stmt->execute()) {
                throw new Exception('Failed to delete grade details: ' . $stmt->error);
            }
        } else {
            // Insert new grade (include academic_year_id to satisfy FK)
            $insertGrade = "INSERT INTO student_grades (student_id, group_id, evaluation_sheet_id, guide_id, coordinator_guide_id, total_marks, max_marks, status, overall_remarks, academic_year_id)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertGrade);
            if (!$stmt) {
                throw new Exception('Failed to prepare grade insert: ' . $conn->error);
            }
            // types: i (student), i (group), i (evaluation), i (guide), i (coordinator_guide), d (totalMarks), d (maxMarks), s (status), s (remarks), i (academic_year)
            // format must have one type char per bound variable (10 variables)
            $stmt->bind_param("iiiiiddssi", $studentId, $groupId, $evaluationSheetId, $guideId, $coordinatorGuideId, $totalMarks, $maxMarks, $status, $overallRemarks, $academicYearId);
            if (!$stmt->execute()) {
                throw new Exception('Failed to insert grade: ' . $stmt->error);
            }
            $gradeId = $conn->insert_id;
        }

        // Remove any other grade rows/details for this student/evaluation/year — keep only the current one
        $deleteOtherDetails = "DELETE sgd FROM student_grade_details sgd INNER JOIN student_grades sg ON sgd.student_grade_id = sg.id WHERE sg.student_id = ? AND sg.evaluation_sheet_id = ? AND sg.academic_year_id = ? AND sg.id <> ?";
        $stmt = $conn->prepare($deleteOtherDetails);
        if (!$stmt) {
            throw new Exception('Failed to prepare delete other details: ' . $conn->error);
        }
        $stmt->bind_param("iiii", $studentId, $evaluationSheetId, $academicYearId, $gradeId);
        if (!$stmt->execute()) {
            throw new Exception('Failed to delete other grade details: ' . $stmt->error);
        }

        $deleteOtherGrades = "DELETE FROM student_grades WHERE student_id = ? AND evaluation_sheet_id = ? AND academic_year_id = ? AND id <> ?";
        $stmt = $conn->prepare($deleteOtherGrades);
        if (!$stmt) {
            throw new Exception('Failed to prepare delete other grades: ' . $conn->error);
        }
        $stmt->bind_param("iiii", $studentId, $evaluationSheetId, $academicYearId, $gradeId);
        if (!$stmt->execute()) {
            throw new Exception('Failed to delete other grades: ' . $stmt->error);
        }

        // Insert grade details
        // Insert grade details (include academic_year_id)
        $insertDetail = "INSERT INTO student_grade_details (student_grade_id, criterion_id, marks_obtained, academic_year_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertDetail);
        if (!$stmt) {
            throw new Exception('Failed to prepare detail insert: ' . $conn->error);
        }

        foreach ($criteria as $criterion) {
            $criterionId = intval($criterion['criterion_id']);
            $obtainedMarks = floatval($criterion['obtained_marks']);
            $stmt->bind_param("iidi", $gradeId, $criterionId, $obtainedMarks, $academicYearId);
            if (!$stmt->execute()) {
                throw new Exception('Failed to insert grade detail: ' . $stmt->error);
            }
        }
    }

    // Ensure overall remarks are persisted for this group and evaluation sheet
    if ($overallRemarks !== '') {
        $syncRemarks = "UPDATE student_grades SET overall_remarks = ? 
                        WHERE evaluation_sheet_id = ? AND group_id = ? AND academic_year_id = ?";
        $stmt = $conn->prepare($syncRemarks);
        if (!$stmt) {
            throw new Exception('Failed to prepare remarks sync: ' . $conn->error);
        }
        $stmt->bind_param('siii', $overallRemarks, $evaluationSheetId, $groupId, $academicYearId);
        if (!$stmt->execute()) {
            throw new Exception('Failed to sync overall remarks: ' . $stmt->error);
        }
        debugLog('Overall remarks synchronized for group ' . $groupId . ' sheet ' . $evaluationSheetId);
    }

    $conn->commit();
    debugLog("Transaction committed successfully");
    sendJSON(['success' => true, 'message' => 'Grades saved successfully']);

} catch (Exception $e) {
    $conn->rollback();
    debugLog("Exception caught: " . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'An error occurred while saving grades']);
}
?>