<?php
require_once '../config/config.php';
requireRoleAPI('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$uploadId = intval($_POST['upload_id'] ?? 0);
if (!$uploadId) {
    sendJSON(['success' => false, 'message' => 'Upload ID required']);
}

// Fetch upload record
$stmt = $conn->prepare("SELECT * FROM project_uploads WHERE id = ?");
$stmt->bind_param("i", $uploadId);
$stmt->execute();
$upload = $stmt->get_result()->fetch_assoc();

if (!$upload) {
    sendJSON(['success' => false, 'message' => 'Upload not found']);
}

$studentStmt = $conn->prepare("SELECT group_id, is_team_lead FROM students WHERE id = ?");
$studentStmt->bind_param("i", $_SESSION['role_id']);
$studentStmt->execute();
$student = $studentStmt->get_result()->fetch_assoc();

if (!$student || $student['group_id'] != $upload['group_id'] || empty($student['is_team_lead'])) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

try {
    $conn->begin_transaction();

    // Delete DB record
    $del = $conn->prepare("DELETE FROM project_uploads WHERE id = ?");
    $del->bind_param("i", $uploadId);
    if (!$del->execute()) {
        throw new Exception('Failed to delete upload record');
    }

    // Delete physical file if exists
    if (!empty($upload['file_path'])) {
        $fileFull = __DIR__ . '/../' . $upload['file_path'];
        if (file_exists($fileFull)) {
            $resolved = realpath($fileFull);
            $uploadReal = realpath(UPLOAD_PATH);
            if ($resolved === false || strpos($resolved, $uploadReal . DIRECTORY_SEPARATOR) !== 0) {
                sendJSON(['success' => false, 'message' => 'Invalid file path']);
            }
            @unlink($resolved);
        }
    }

    $conn->commit();
    sendJSON(['success' => true, 'message' => 'Upload deleted']);
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>
