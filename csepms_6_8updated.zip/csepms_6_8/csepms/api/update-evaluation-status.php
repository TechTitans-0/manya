<?php
require_once '../config/config.php';
requireRole('coordinator');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$sheetId = intval($_POST['sheet_id'] ?? 0);
$status = sanitizeInput($_POST['status'] ?? '');

if (!$sheetId || !in_array($status, ['active', 'draft'])) {
    sendJSON(['success' => false, 'message' => 'Invalid parameters']);
}

try {
    $updateQuery = "UPDATE evaluation_sheets SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("si", $status, $sheetId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update status');
    }
    
    if ($stmt->affected_rows === 0) {
        throw new Exception('Evaluation sheet not found');
    }
    
    $statusText = $status === 'active' ? 'activated' : 'deactivated';
    sendJSON(['success' => true, 'message' => "Evaluation sheet {$statusText} successfully"]);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
