<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'];

// Determine selected academic year (session or active)
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Notifications unread - filter based on user role
// For guides: only count circulars from coordinator (target_type = 'all_guides')
// For students: count all notifications targeted to them
if ($userRole === 'guide') {
    $notifQuery = "SELECT COUNT(*) as cnt 
                   FROM notification_read_status nrs
                   INNER JOIN notifications n ON nrs.notification_id = n.id
                   WHERE nrs.user_id = ? 
                   AND nrs.is_read = 0
                   AND nrs.academic_year_id = ?
                   AND n.target_type = 'all_guides'";
} else {
    // For students and other roles, only count unread circulars sent by coordinators
    $notifQuery = "SELECT COUNT(*) as cnt 
                   FROM notification_read_status nrs
                   INNER JOIN notifications n ON nrs.notification_id = n.id
                   INNER JOIN users u ON n.sender_id = u.id
                   WHERE nrs.user_id = ? 
                     AND nrs.is_read = 0 
                     AND nrs.academic_year_id = ?
                     AND n.title LIKE 'Circular:%' 
                     AND u.role = 'coordinator'";
}

$stmt = $conn->prepare($notifQuery);
$stmt->bind_param('ii', $userId, $selectedAcademicYearId);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$notifCount = intval($res['cnt'] ?? 0);

// Messages unread
$msgQuery = "SELECT COUNT(*) as cnt FROM chat_messages WHERE receiver_id = ? AND is_read = 0 AND sender_id != receiver_id AND academic_year_id = ?";
$stmt = $conn->prepare($msgQuery);
$stmt->bind_param('ii', $userId, $selectedAcademicYearId);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$msgCount = intval($res['cnt'] ?? 0);

sendJSON(['success' => true, 'notifications' => $notifCount, 'messages' => $msgCount]);

?>
