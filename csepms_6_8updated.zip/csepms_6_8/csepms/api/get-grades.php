<?php
require_once '../config/config.php';
requireRole('student');

// Prevent caching to ensure fresh data
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

if (!isset($_SESSION['user_id']) || !isset($_SESSION['group_id']) || !$_SESSION['group_id']) {
    sendJSON(['success' => false, 'message' => 'You are not part of any group']);
}

// Log for debugging (suppressed in production)
debugLog("Get Grades - User ID: " . $_SESSION['user_id'] . ", Role ID: " . ($_SESSION['role_id'] ?? 'NOT SET') . ", Group ID: " . $_SESSION['group_id']);

if (!isset($_SESSION['role_id'])) {
    sendJSON(['success' => false, 'message' => 'Session expired. Please login again']);
}

// Get all grades for the student as individual student grades
// Show ONLY 'approved' grades (grades authorized by coordinator)
// Determine academic year to consider (prefer session ACTIVE)
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    if ($ayRow && isset($ayRow['id'])) $academicYearId = intval($ayRow['id']);
}
if ($_SESSION['project_type'] === 'mini') {
    $query = "SELECT sg.*, sg.overall_remarks, sg.max_marks AS grade_max, es.title as sheet_title, u.username as guide_name, cu.username as coordinator_name,
              sgd.criterion_id, sgd.marks_obtained, ec.criterion_name, ec.max_marks AS criterion_max
              FROM student_grades sg
              INNER JOIN (
                  SELECT student_id, evaluation_sheet_id, MAX(id) AS latest_grade_id
                  FROM student_grades
                  WHERE student_id = ? AND status = 'approved'" . ($academicYearId ? " AND academic_year_id = ?" : "") . "
                  GROUP BY student_id, evaluation_sheet_id
              ) latest ON sg.id = latest.latest_grade_id
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              LEFT JOIN guides gu ON sg.guide_id = gu.id
              LEFT JOIN users u ON gu.user_id = u.id
              LEFT JOIN coordinators cd ON sg.coordinator_guide_id = cd.id
              LEFT JOIN users cu ON cd.user_id = cu.id
              LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
              LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
              WHERE sg.student_id = ? AND sg.status = 'approved'" . ($academicYearId ? " AND sg.academic_year_id = ?" : "") . "
              ORDER BY sg.graded_at DESC, ec.id ASC";
} else {
    $query = "SELECT sg.*, sg.overall_remarks, sg.max_marks AS grade_max, es.phase, es.review, es.title as sheet_title, u.username as guide_name, cu.username as coordinator_name,
              sgd.criterion_id, sgd.marks_obtained, ec.criterion_name, ec.max_marks AS criterion_max
              FROM student_grades sg
              INNER JOIN (
                  SELECT student_id, evaluation_sheet_id, MAX(id) AS latest_grade_id
                  FROM student_grades
                  WHERE student_id = ? AND status = 'approved'" . ($academicYearId ? " AND academic_year_id = ?" : "") . "
                      GROUP BY student_id, evaluation_sheet_id
              ) latest ON sg.id = latest.latest_grade_id
              INNER JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
              LEFT JOIN guides gu ON sg.guide_id = gu.id
              LEFT JOIN users u ON gu.user_id = u.id
              LEFT JOIN coordinators cd ON sg.coordinator_guide_id = cd.id
              LEFT JOIN users cu ON cd.user_id = cu.id
              LEFT JOIN student_grade_details sgd ON sg.id = sgd.student_grade_id
              LEFT JOIN evaluation_criteria ec ON sgd.criterion_id = ec.id
              WHERE sg.student_id = ? AND sg.status = 'approved'" . ($academicYearId ? " AND sg.academic_year_id = ?" : "") . "
              ORDER BY es.phase ASC, es.review ASC, ec.id ASC";
}

$stmt = $conn->prepare($query);
// Determine student id from session (role_id for student role or fallback to user_id)
$studentId = isset($_SESSION['role_id']) ? intval($_SESSION['role_id']) : intval($_SESSION['user_id'] ?? 0);
if ($academicYearId) {
    // Query contains 2 placeholders in the inner subquery and 2 in the outer WHERE when academic year is used
    // inner: student_id = ?, academic_year_id = ?
    // outer: sg.student_id = ?, sg.academic_year_id = ?
    $stmt->bind_param("iiii", $studentId, $academicYearId, $studentId, $academicYearId);
} else {
    $stmt->bind_param("ii", $studentId, $studentId);
}
$stmt->execute();
$result = $stmt->get_result();

debugLog("Get Grades - Query executed, rows found: " . $result->num_rows);

$grades = [];
$currentGradeId = null;

while ($row = $result->fetch_assoc()) {
    $gradeId = $row['id'];
    
    if ($currentGradeId !== $gradeId) {
        $grades[$gradeId] = [
            'id' => $row['id'],
            'phase' => ($_SESSION['project_type'] === 'mini') ? 0 : intval($row['phase']),
            'review' => ($_SESSION['project_type'] === 'mini') ? 0 : intval($row['review']),
            'title' => $row['sheet_title'],
            'total_marks' => $row['total_marks'],
            'max_marks' => floatval($row['grade_max'] ?? $row['max_marks']),
            'percentage' => ($row['max_marks'] > 0) ? round(($row['total_marks'] / $row['max_marks']) * 100, 2) : 0,
                'guide_name' => (!empty($row['guide_name']) ? $row['guide_name'] : (!empty($row['coordinator_name']) ? $row['coordinator_name'] . ' (Coordinator)' : '')),
            'graded_at' => $row['graded_at'],
            'overall_remarks' => $row['overall_remarks'] ?? '',
            'criteria' => []
        ];
        $currentGradeId = $gradeId;
    }
    
    if ($row['criterion_id']) {
        $grades[$gradeId]['criteria'][] = [
            'criterion_name' => $row['criterion_name'],
            'marks_obtained' => floatval($row['marks_obtained']),
            'max_marks' => floatval($row['criterion_max'] ?? $row['max_marks'])
        ];
    }
}

sendJSON(['success' => true, 'grades' => array_values($grades)]);
?>
