<?php
require_once '../config/config.php';
requireLogin();

// Clean output buffer to prevent any output before JSON
if (ob_get_level()) {
    ob_clean();
}

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$chatType = sanitizeInput($_POST['chat_type'] ?? '');
$groupId = isset($_POST['group_id']) ? intval($_POST['group_id']) : null;
$message = sanitizeInput($_POST['message'] ?? '');

// Determine academic year for the message
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ay = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    if ($ay) $academicYearId = intval($ay['id']);
}
if (!$academicYearId) sendJSON(['success' => false, 'message' => 'No academic year configured'], 400);

if (empty($message)) {
    sendJSON(['success' => false, 'message' => 'Message cannot be empty']);
}

try {
    if ($chatType === 'project_group' && $groupId) {
        // Create one group-level record (group_id present) and then individual direct copies for each student
        $groupInsert = "INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $gstmt = $conn->prepare($groupInsert);
        $senderId = intval($_SESSION['user_id']);
        $senderRole = $_SESSION['role'];
        // receiver_id set to sender to satisfy FK; receiver_role set to senderRole
        $recvId = $senderId;
        $recvRole = $senderRole;
        $gstmt->bind_param('isisisi', $senderId, $senderRole, $recvId, $recvRole, $groupId, $message, $academicYearId);
        $gstmt->execute();
        $gstmt->close();

        // Also create individual copies for each student in the group so they see the message in their direct chat
        $studentQuery = "SELECT u.id as user_id FROM students s INNER JOIN users u ON s.user_id = u.id WHERE s.group_id = ?";
        $sstmt = $conn->prepare($studentQuery);
        $sstmt->bind_param('i', $groupId);
        $sstmt->execute();
        $sres = $sstmt->get_result();

        $indQuery = "INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())";
        $istmt = $conn->prepare($indQuery);
        $studentRole = 'student';
        while ($row = $sres->fetch_assoc()) {
            $studentUserId = intval($row['user_id']);
            if ($studentUserId === $senderId) continue;
            $istmt->bind_param('isissi', $senderId, $senderRole, $studentUserId, $studentRole, $message, $academicYearId);
            $istmt->execute();
        }
        $istmt->close();
        $sstmt->close();

    } elseif ($chatType === 'all_students' && hasRole('coordinator')) {
        // Send to all students individually
        $stmt = $conn->prepare("SELECT u.id FROM users u WHERE u.role = 'student'");
        $stmt->execute();
        $res = $stmt->get_result();

        $ins = $conn->prepare("INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())");
        $senderId = intval($_SESSION['user_id']);
        $senderRole = $_SESSION['role'];
        while ($r = $res->fetch_assoc()) {
            $studentId = intval($r['id']);
            if ($studentId === $senderId) continue;
            $recvRole = 'student';
            $ins->bind_param('isissi', $senderId, $senderRole, $studentId, $recvRole, $message, $academicYearId);
            $ins->execute();
        }
        $ins->close();
        $stmt->close();

    } elseif ($chatType === 'all_guides' && hasRole('coordinator')) {
        // Send to all guides individually
        $stmt = $conn->prepare("SELECT u.id FROM users u WHERE u.role = 'guide'");
        $stmt->execute();
        $res = $stmt->get_result();

        $ins = $conn->prepare("INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())");
        $senderId = intval($_SESSION['user_id']);
        $senderRole = $_SESSION['role'];
        while ($r = $res->fetch_assoc()) {
            $guideId = intval($r['id']);
            if ($guideId === $senderId) continue;
            $recvRole = 'guide';
            $ins->bind_param('isissi', $senderId, $senderRole, $guideId, $recvRole, $message, $academicYearId);
            $ins->execute();
        }
        $ins->close();
        $stmt->close();

    } else {
        throw new Exception('Invalid chat type or insufficient permissions');
    }
    
    sendJSON(['success' => true, 'message' => 'Message sent successfully']);
    
} catch (Exception $e) {
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
