<?php
require_once '../config/config.php';
requireRoleAPI('guide');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$groupId = intval($_POST['group_id'] ?? 0);
$evaluationSheetId = intval($_POST['evaluation_sheet_id'] ?? 0);
$marks = $_POST['marks'] ?? [];
$status = sanitizeInput($_POST['status'] ?? 'draft');

if (!$groupId || !$evaluationSheetId || empty($marks)) {
    sendJSON(['success' => false, 'message' => 'Missing required parameters']);
}

// Verify guide has access to this group
$checkQuery = "SELECT id FROM pgroups WHERE id = ? AND guide_id = ?";
$stmt = $conn->prepare($checkQuery);
$stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
$stmt->execute();

if ($stmt->get_result()->num_rows === 0) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

// Determine academic year for the grade
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $academicYearId = $ayRow ? intval($ayRow['id']) : null;
}
if (!$academicYearId) {
    sendJSON(['success' => false, 'message' => 'No academic year configured']);
}

try {
    $conn->begin_transaction();
    
    // Calculate total marks
    $totalMarks = 0;
    $maxMarks = 0;
    
    foreach ($marks as $criterionId => $obtainedMarks) {
        // Get max marks for this criterion
        $maxQuery = "SELECT max_marks FROM evaluation_criteria WHERE id = ?";
        $stmt = $conn->prepare($maxQuery);
        $criterionId = intval($criterionId);
        $stmt->bind_param("i", $criterionId);
        $stmt->execute();
        $criterionMax = $stmt->get_result()->fetch_assoc()['max_marks'];
        
        $maxMarks += $criterionMax;
        $totalMarks += floatval($obtainedMarks);
    }
    
    // Check if grade already exists for this group/evaluation/year
    $checkGrade = "SELECT id FROM grades WHERE group_id = ? AND evaluation_sheet_id = ? AND academic_year_id = ?";
    $stmt = $conn->prepare($checkGrade);
    $stmt->bind_param("iii", $groupId, $evaluationSheetId, $academicYearId);
    $stmt->execute();
    $existingGrade = $stmt->get_result()->fetch_assoc();
    
    if ($existingGrade) {
        // Update existing grade (no updated_at column in grades)
        $gradeId = $existingGrade['id'];
        $updateGrade = "UPDATE grades SET total_marks = ?, max_marks = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($updateGrade);
        $stmt->bind_param("ddsi", $totalMarks, $maxMarks, $status, $gradeId);
        $stmt->execute();
        
        // Delete old grade details
        $deleteDetails = "DELETE FROM grade_details WHERE grade_id = ?";
        $stmt = $conn->prepare($deleteDetails);
        $stmt->bind_param("i", $gradeId);
        $stmt->execute();
    } else {
        // Insert new grade
        $insertGrade = "INSERT INTO grades (group_id, evaluation_sheet_id, guide_id, total_marks, max_marks, status, academic_year_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertGrade);
        $stmt->bind_param("iiiddsi", $groupId, $evaluationSheetId, $_SESSION['role_id'], $totalMarks, $maxMarks, $status, $academicYearId);
        $stmt->execute();
        $gradeId = $conn->insert_id;
    }
    
    // Insert grade details with academic year
    $insertDetail = "INSERT INTO grade_details (grade_id, criterion_id, marks_obtained, academic_year_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insertDetail);
    
    foreach ($marks as $criterionId => $obtainedMarks) {
        $criterionId = intval($criterionId);
        $obtainedMarks = floatval($obtainedMarks);
        $stmt->bind_param("iidi", $gradeId, $criterionId, $obtainedMarks, $academicYearId);
        $stmt->execute();
    }
    
    // Update group's overall grade if this is submitted (scoped to academic year)
    if ($status === 'submitted') {
        $updateGroup = "UPDATE pgroups g
                        SET overall_grade = (
                            SELECT AVG((total_marks / max_marks) * 100)
                            FROM grades
                            WHERE group_id = ? AND status = 'submitted' AND academic_year_id = ?
                        )
                        WHERE g.id = ?";
        $stmt = $conn->prepare($updateGroup);
        $stmt->bind_param("iii", $groupId, $academicYearId, $groupId);
        $stmt->execute();
    }
    
    $conn->commit();
    
    sendJSON([
        'success' => true,
        'message' => $status === 'submitted' ? 'Grade submitted successfully' : 'Grade saved as draft',
        'grade_id' => $gradeId
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    debugLog('Save grade error: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to save grade']);
}
?>
