<?php
require_once '../config/config.php';

// Allow both guides and coordinators to fetch active evaluation sheets
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}
if (!hasRole('guide') && !hasRole('coordinator')) {
    header('Content-Type: application/json');
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

header('Content-Type: application/json');

$isMiniProject = (getCurrentProjectType() === 'mini');
if ($isMiniProject) {
    $query = "SELECT id, subject_code, title, status, created_at FROM evaluation_sheets WHERE status = 'active' ORDER BY created_at DESC";
} else {
    $query = "SELECT id, subject_code, title, phase, review FROM evaluation_sheets WHERE status = 'active' ORDER BY phase ASC, review ASC";
}

$result = $conn->query($query);
$sheets = [];

while ($row = $result->fetch_assoc()) {
    $sheets[] = $row;
}

sendJSON([
    'success' => true,
    'sheets' => $sheets
]);
?>