<?php
// set-current-academic-year.php
require_once '../config/config.php';
header('Content-Type: application/json');

requireRoleAPI('coordinator');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Method not allowed'], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['academic_year']) || empty($data['academic_year'])) {
    sendJSON(['success' => false, 'message' => 'Missing academic_year'], 400);
}

$year = sanitizeInput($data['academic_year']);

// Update or insert the current academic year in global_settings
$stmt = $conn->prepare("INSERT INTO global_settings (setting_key, setting_value) VALUES ('current_academic_year', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
$stmt->bind_param('ss', $year, $year);
if ($stmt->execute()) {
    sendJSON(['success' => true, 'current_academic_year' => $year]);
} else {
    debugLog('Set current academic year error: ' . $conn->error);
    sendJSON(['success' => false, 'message' => 'Database error'], 500);
}
?>
