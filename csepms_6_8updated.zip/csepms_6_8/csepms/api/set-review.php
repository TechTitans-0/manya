<?php
require_once __DIR__ . '/../config/config.php';
requireRoleAPI('coordinator');
enforceReadOnlyForCompletedYear();
header('Content-Type: application/json; charset=utf-8');

$review = isset($_POST['review']) ? intval($_POST['review']) : null;
$apply_all = isset($_POST['apply_all']) ? (int)$_POST['apply_all'] : 1;

if ($review === null) {
    sendJSON(['success' => false, 'message' => 'Review is required']);
}

// Determine selected academic year for scoping
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $ayRow = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $ayRow ? intval($ayRow['id']) : null;
}

// Update project_config (upsert)
$stmt = $conn->prepare("INSERT INTO project_config (config_key, config_value, description) VALUES ('current_review', ?, 'Current global review') ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)");
$val = (string)$review;
$stmt->bind_param('s', $val);
$stmt->execute();
$stmt->close();

// Mini projects do not have current_phase/current_review columns in pgroups
if ($isMiniProject = (getCurrentProjectType() === 'mini')) {
    sendJSON(['success' => true, 'message' => 'Global review updated (reviews not applicable to mini projects)']);
}

// Update groups - scoped to active/selected academic year unless applying to all years
if ($selectedAcademicYearId && $apply_all) {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_review = ? WHERE academic_year_id = ?");
    $ustmt->bind_param('ii', $review, $selectedAcademicYearId);
} elseif ($selectedAcademicYearId) {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_review = ? WHERE academic_year_id = ? AND project_status != 'completed'");
    $ustmt->bind_param('ii', $review, $selectedAcademicYearId);
} elseif ($apply_all) {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_review = ?");
    $ustmt->bind_param('i', $review);
} else {
    $ustmt = $conn->prepare("UPDATE `pgroups` SET current_review = ? WHERE project_status != 'completed'");
    $ustmt->bind_param('i', $review);
}
$ok = $ustmt->execute();
$affected = $ustmt->affected_rows;
$ustmt->close();

if ($ok) {
    sendJSON(['success' => true, 'message' => "Current review set to {$review} (updated {$affected} groups)"]);
} else {
    debugLog('Set review error: ' . $conn->error);
    sendJSON(['success' => false, 'message' => 'Failed to update review']);
}
