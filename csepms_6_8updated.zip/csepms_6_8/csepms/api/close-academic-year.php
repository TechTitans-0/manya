<?php
require_once '../config/config.php';

requireRoleAPI('coordinator');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

// 1. Fetch current ACTIVE academic year
$active = $conn->query("SELECT * FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
if (!$active) {
    sendJSON(['success' => false, 'message' => 'No active academic year found.']);
}

// 2. Mark it as COMPLETED
$conn->begin_transaction();
try {
    $stmt = $conn->prepare("UPDATE academic_years SET status = 'COMPLETED' WHERE id = ?");
    $activeId = intval($active['id']);
    $stmt->bind_param('i', $activeId);
    $stmt->execute();

    // 3. Generate next academic year label
    $projectType = getCurrentProjectType();
    if ($projectType === 'mini') {
        // For mini projects, year_label is just YYYY, increment by 1
        $currentYear = intval($active['year_label']);
        $nextLabel = strval($currentYear + 1);
    } else {
        // For major projects, year_label is YYYY-YYYY format
        $parts = explode('-', $active['year_label']);
        if (count($parts) == 2) {
            $start = intval($parts[0]);
            $end = intval($parts[1]);
            $nextLabel = ($start+1) . '-' . ($end+1);
        } else {
            throw new Exception('Invalid year label format.');
        }
    }

    // 4. Insert new year as ACTIVE if not exists
    $stmt = $conn->prepare("INSERT IGNORE INTO academic_years (year_label, status) VALUES (?, 'ACTIVE')");
    $stmt->bind_param('s', $nextLabel);
    $stmt->execute();

    // 5. Get the new ACTIVE year
    $stmt = $conn->prepare("SELECT * FROM academic_years WHERE year_label = ? LIMIT 1");
    $stmt->bind_param('s', $nextLabel);
    $stmt->execute();
    $newYear = $stmt->get_result()->fetch_assoc();
    if (!$newYear) throw new Exception('Failed to create new academic year.');

    $conn->commit();
    sendJSON([
        'success' => true,
        'message' => 'Academic year closed and new year created: ' . $nextLabel,
        'new_year' => [
            'id' => $newYear['id'],
            'year_label' => $newYear['year_label'],
            'status' => $newYear['status']
        ]
    ]);
} catch (Exception $e) {
    $conn->rollback();
    debugLog('Close academic year error: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to close academic year']);
}
