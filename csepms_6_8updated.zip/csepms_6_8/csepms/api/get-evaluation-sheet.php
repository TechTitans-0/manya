<?php
require_once '../config/config.php';
requireRole('guide');

header('Content-Type: application/json');

// This endpoint is only applicable to major projects
if (getCurrentProjectType() === 'mini') {
    sendJSON(['success' => false, 'message' => 'Use get-mini-project-evaluation-sheet.php for mini projects'], 400);
}

$phase = intval($_GET['phase'] ?? 0);
$review = intval($_GET['review'] ?? 0);

if (!$phase || !$review) {
    sendJSON(['success' => false, 'message' => 'Phase and review are required']);
}

// Get active evaluation sheet for this phase and review
$query = "SELECT es.*, ec.id as criterion_id, ec.criterion_name, ec.max_marks, ec.display_order
          FROM evaluation_sheets es
          INNER JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
          WHERE es.phase = ? AND es.review = ? AND es.status = 'active'
          ORDER BY ec.display_order ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $phase, $review);
$stmt->execute();
$result = $stmt->get_result();

$evaluationSheet = null;
$criteria = [];

while ($row = $result->fetch_assoc()) {
    if (!$evaluationSheet) {
        $evaluationSheet = [
            'id' => $row['id'],
            'phase' => $row['phase'],
            'review' => $row['review'],
            'title' => $row['title']
        ];
    }
    
    $criteria[] = [
        'id' => $row['criterion_id'],
        'name' => $row['criterion_name'],
        'max_marks' => $row['max_marks']
    ];
}

if (!$evaluationSheet) {
    sendJSON(['success' => false, 'message' => 'No evaluation sheet found for this phase and review']);
}

sendJSON([
    'success' => true,
    'evaluation_sheet' => $evaluationSheet,
    'criteria' => $criteria
]);
?>
