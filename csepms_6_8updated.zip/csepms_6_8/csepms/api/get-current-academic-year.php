<?php
// get-current-academic-year.php
require_once '../config/config.php';
header('Content-Type: application/json');

requireLogin();

$sql = "SELECT setting_value FROM global_settings WHERE setting_key = 'current_academic_year' LIMIT 1";
$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
    sendJSON(['current_academic_year' => $row['setting_value']]);
} else {
    sendJSON(['current_academic_year' => null]);
}
?>
