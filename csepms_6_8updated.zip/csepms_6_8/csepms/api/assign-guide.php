<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

// Handle assignment for guide or coordinator
$groupId = intval($_POST['group_id'] ?? 0);
$guideIdRaw = $_POST['guide_id'] ?? '';

if (!$groupId || !$guideIdRaw) {
    sendJSON(['success' => false, 'message' => 'Group ID and Guide ID are required']);
}

if (strpos($guideIdRaw, 'coordinator_') === 0) {
    // Assign coordinator as guide
    $coordId = intval(substr($guideIdRaw, strlen('coordinator_')));
    // Set coordinator_guide_id, clear guide_id
    $updateQuery = "UPDATE pgroups SET guide_id = NULL, coordinator_guide_id = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ii", $coordId, $groupId);
    if (!$stmt->execute()) {
        sendJSON(['success' => false, 'message' => 'Failed to assign coordinator as guide']);
    }
    sendJSON(['success' => true, 'message' => 'Coordinator assigned as guide']);
} else {
    // Assign regular guide
    $guideId = intval($guideIdRaw);
    // Verify guide exists
    $checkGuide = "SELECT id FROM guides WHERE id = ?";
    $stmt = $conn->prepare($checkGuide);
    $stmt->bind_param("i", $guideId);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        sendJSON(['success' => false, 'message' => 'Guide not found'], 404);
    }
    // Assign guide to group, clear coordinator_guide_id
    $updateQuery = "UPDATE pgroups SET guide_id = ?, coordinator_guide_id = NULL WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ii", $guideId, $groupId);
    if (!$stmt->execute()) {
        sendJSON(['success' => false, 'message' => 'Failed to assign guide']);
    }
    sendJSON(['success' => true, 'message' => 'Guide assigned']);
}
// ...existing code...

?>
