<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

// Prevent sending messages for completed academic years
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if (!isset($_POST['guide_id']) || !isset($_POST['message'])) {
    sendJSON(['success' => false, 'message' => 'Missing required fields']);
}

$guide_user_id = intval($_POST['guide_id']); // This is now the user_id
$message = sanitizeInput(trim($_POST['message']));
$sender_id = $_SESSION['user_id'];

if (empty($message)) {
    sendJSON(['success' => false, 'message' => 'Message cannot be empty']);
}

try {
    // Determine academic year for the message
    $academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
    if (!$academicYearId) {
        $ay = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
        if ($ay) $academicYearId = intval($ay['id']);
    }
    if (!$academicYearId) {
        sendJSON(['success' => false, 'message' => 'No academic year configured']);
    }
    // Verify the guide exists
    $stmt = $conn->prepare("SELECT u.id, u.username 
                            FROM users u 
                            INNER JOIN guides g ON g.user_id = u.id 
                            WHERE u.id = ? AND u.role = 'guide'");
    $stmt->bind_param("i", $guide_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        sendJSON(['success' => false, 'message' => 'Guide not found']);
    }
    
    $guide = $result->fetch_assoc();
    $stmt->close();
    
    // Create notification for the guide
    $notification_title = "Message from Coordinator";
    $notification_message = substr($message, 0, 200) . (strlen($message) > 200 ? '...' : '');
    
    $stmt = $conn->prepare("
        INSERT INTO notifications (title, message, target_type, target_value, sender_id, academic_year_id, created_at) 
        VALUES (?, ?, 'specific_user', ?, ?, ?, NOW())
    ");
    $stmt->bind_param("ssiii", $notification_title, $notification_message, $guide_user_id, $sender_id, $academicYearId);
    $stmt->execute();
    $notification_id = $stmt->insert_id;
    $stmt->close();
    
    // Create notification read status for the guide
    $stmt = $conn->prepare("
        INSERT INTO notification_read_status (notification_id, user_id, academic_year_id, is_read, read_at) 
        VALUES (?, ?, ?, 0, NULL)
    ");
    $stmt->bind_param("iii", $notification_id, $guide_user_id, $academicYearId);
    $stmt->execute();
    $stmt->close();
    
    // Store message in chat_messages table
    $stmt = $conn->prepare("INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())");
    $senderRole = 'coordinator';
    $recvRole = 'guide';
    $stmt->bind_param("isissi", $sender_id, $senderRole, $guide_user_id, $recvRole, $message, $academicYearId);
    $stmt->execute();
    $stmt->close();
    
    sendJSON([
        'success' => true, 
        'message' => "Message sent to guide: " . $guide['username'],
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    debugLog('Guide message error: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to send guide message']);
}
?>
