<?php
require_once '../config/config.php';
requireLogin();
enforceReadOnlyForCompletedYear();

// Clean output buffer to prevent any output before JSON
if (ob_get_level()) {
    ob_clean();
}

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$receiverId = intval($_POST['receiver_id'] ?? 0);
$receiverRole = sanitizeInput($_POST['receiver_role'] ?? '');
$message = sanitizeInput($_POST['message'] ?? '');
$groupId = isset($_POST['group_id']) ? intval($_POST['group_id']) : null;

// Determine academic year for the message (use session selection or active year)
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ay = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    if ($ay) $academicYearId = intval($ay['id']);
}
if (!$academicYearId) sendJSON(['success' => false, 'message' => 'No academic year configured'], 400);

// Log for debugging (suppressed in production)
debugLog("Send message - Sender: " . $_SESSION['user_id'] . ", Receiver: $receiverId, Role: $receiverRole, Group: " . ($groupId ?? 'null'));

if (!$receiverId || !$receiverRole || empty($message)) {
    debugLog("Send message - Missing parameters");
    sendJSON(['success' => false, 'message' => 'Missing required parameters']);
}

try {
    if ($groupId && intval($groupId) > 0) {
        $query = "INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            throw new Exception('Prepare error: ' . $conn->error);
        }
        $stmt->bind_param("isisisi", $_SESSION['user_id'], $_SESSION['role'], $receiverId, $receiverRole, $groupId, $message, $academicYearId);
    } else {
        // Insert without group_id (NULL) to avoid FK issues
        $query = "INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at)
              VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            throw new Exception('Prepare error: ' . $conn->error);
        }
        // types: sender_id (i), sender_role (s), receiver_id (i), receiver_role (s), message (s)
        $stmt->bind_param("isissi", $_SESSION['user_id'], $_SESSION['role'], $receiverId, $receiverRole, $message, $academicYearId);
    }

    if (!$stmt->execute()) {
        throw new Exception('Failed to send message: ' . $stmt->error);
    }
    
    $insertedId = $conn->insert_id;
    debugLog("Send message - Success, ID: $insertedId");
    sendJSON(['success' => true, 'message' => 'Message sent successfully', 'id' => $insertedId]);
    
} catch (Exception $e) {
    debugLog("Send message - Error: " . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to send message']);
}
?>

