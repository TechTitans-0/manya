<?php
require_once '../config/config.php';

// Prevent modifications for completed academic years
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

// Allow both guides and coordinators to approve uploads (coordinators can act as guide for assigned pgroups)
if (!isLoggedIn()) {
    sendJSON(['success' => false, 'message' => 'Authentication required'], 401);
}

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['guide', 'coordinator'])) {
    sendJSON(['success' => false, 'message' => 'Guide or Coordinator access required'], 403);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$uploadId = intval($_POST['upload_id'] ?? 0);
// Accept either `action` (legacy) or `status` from client
$action = sanitizeInput($_POST['action'] ?? '');
$statusParam = sanitizeInput($_POST['status'] ?? '');
$feedback = sanitizeInput($_POST['feedback'] ?? '');

// Normalize to status values stored in DB
$status = '';
if ($action === 'approve' || $statusParam === 'approved') {
    $status = 'approved';
} elseif ($action === 'request_changes' || $statusParam === 'changes_required') {
    $status = 'changes_required';
} elseif ($statusParam === 'pending') {
    $status = 'pending';
}

if (!$uploadId || !$status) {
    sendJSON(['success' => false, 'message' => 'Invalid parameters']);
}

try {
    // Verify guide/coordinator has access to this upload
    if ($_SESSION['role'] === 'guide') {
        $checkQuery = "SELECT pu.id FROM project_uploads pu
                       INNER JOIN pgroups g ON pu.group_id = g.id
                       WHERE pu.id = ? AND g.guide_id = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("ii", $uploadId, $_SESSION['role_id']);
    } else {
        // coordinator
        $checkQuery = "SELECT pu.id FROM project_uploads pu
                       INNER JOIN pgroups g ON pu.group_id = g.id
                       WHERE pu.id = ? AND g.coordinator_guide_id = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("ii", $uploadId, $_SESSION['role_id']);
    }
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        throw new Exception('Access denied or upload not found');
    }
    
    // Update upload status and feedback
    $updateQuery = "UPDATE project_uploads SET status = ?, feedback = ?, upload_date = upload_date WHERE id = ?";
    
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssi", $status, $feedback, $uploadId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update upload status');
    }

    // Fetch updated upload record to return to client
    $isMiniProject = (getCurrentProjectType() === 'mini');
    if ($isMiniProject) {
        $fetchQuery = "SELECT pu.*, pu.filename as file_name, pu.upload_date as uploaded_at, 0 as review_type, u.username as uploaded_by_name
                       FROM project_uploads pu
                       INNER JOIN students s ON pu.uploaded_by = s.id
                       INNER JOIN users u ON s.user_id = u.id
                       WHERE pu.id = ?";
    } else {
        $fetchQuery = "SELECT pu.*, pu.filename as file_name, pu.upload_date as uploaded_at, pu.review as review_type, u.username as uploaded_by_name
                       FROM project_uploads pu
                       INNER JOIN students s ON pu.uploaded_by = s.id
                       INNER JOIN users u ON s.user_id = u.id
                       WHERE pu.id = ?";
    }
    $fstmt = $conn->prepare($fetchQuery);
    $fstmt->bind_param("i", $uploadId);
    $fstmt->execute();
    $updated = $fstmt->get_result()->fetch_assoc();

    sendJSON([
        'success' => true,
        'message' => $status === 'approved' ? 'Upload approved successfully' : 'Feedback sent to students',
        'upload' => $updated
    ]);
    
} catch (Exception $e) {
    debugLog('Approve upload error: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to process upload']);
}
?>
