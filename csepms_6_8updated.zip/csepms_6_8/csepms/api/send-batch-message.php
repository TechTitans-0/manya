<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

// Prevent sending messages for completed academic years
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if (!isset($_POST['batch']) || !isset($_POST['message'])) {
    sendJSON(['success' => false, 'message' => 'Missing required fields']);
}

$batch = sanitizeInput(trim($_POST['batch']));
$message = sanitizeInput(trim($_POST['message']));
$sender_id = $_SESSION['user_id'];

// Determine academic year for the message
$academicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$academicYearId) {
    $ay = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    if ($ay) $academicYearId = intval($ay['id']);
}
if (!$academicYearId) {
    sendJSON(['success' => false, 'message' => 'No academic year configured']);
}

if (empty($batch) || empty($message)) {
    sendJSON(['success' => false, 'message' => 'Batch and message are required']);
}

try {
    // Get all student user_ids in this batch
    $stmt = $conn->prepare("
        SELECT DISTINCT s.user_id 
        FROM students s 
        INNER JOIN pgroups g ON s.group_id = g.id 
        WHERE g.batch = ?
    ");
    $stmt->bind_param("s", $batch);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row['user_id'];
    }
    $stmt->close();
    
    if (empty($students)) {
        sendJSON(['success' => false, 'message' => 'No students found in this batch']);
    }
    
    // Create notification for the batch
    $notification_title = "Message from Coordinator";
    $notification_message = "New message for Batch " . htmlspecialchars($batch) . ": " . substr($message, 0, 100) . (strlen($message) > 100 ? '...' : '');
    
        $stmt = $conn->prepare("
            INSERT INTO notifications (title, message, target_type, target_value, sender_id, academic_year_id, created_at) 
            VALUES (?, ?, 'specific_batch', ?, ?, ?, NOW())
        ");
        $stmt->bind_param("sssii", $notification_title, $notification_message, $batch, $sender_id, $academicYearId);
        $stmt->execute();
        $notification_id = $stmt->insert_id;
        $stmt->close();
    
    // Create notification read status for each student
        $stmt = $conn->prepare("
            INSERT INTO notification_read_status (notification_id, user_id, academic_year_id, is_read, read_at) 
            VALUES (?, ?, ?, 0, NULL)
        ");
    
    foreach ($students as $student_id) {
            $stmt->bind_param("iii", $notification_id, $student_id, $academicYearId);
        $stmt->execute();
    }
    $stmt->close();
    
        // Store message in chat_messages table for each student (direct messages)
        $stmt = $conn->prepare("INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, group_id, message, academic_year_id, sent_at) VALUES (?, ?, ?, ?, NULL, ?, ?, NOW())");
        foreach ($students as $student_id) {
            $recvRole = 'student';
            $senderRole = 'coordinator';
            $stmt->bind_param("isissi", $sender_id, $senderRole, $student_id, $recvRole, $message, $academicYearId);
            $stmt->execute();
        }
        $stmt->close();
    
    sendJSON([
        'success' => true, 
        'message' => "Message sent to " . count($students) . " student(s) in $batch",
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    debugLog('Batch message error: ' . $e->getMessage());
    sendJSON(['success' => false, 'message' => 'Failed to send batch message']);
}
?>