<?php
require_once '../config/config.php';
requireRole('coordinator');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$groupId = intval($_POST['group_id'] ?? 0);
$domain = trim($_POST['domain'] ?? '');
// Note: Batch is auto-generated and should NOT be modified after creation

if (!$groupId) {
    sendJSON(['success' => false, 'message' => 'Group ID is required']);
}

try {
    // Verify group exists
    $checkGroup = "SELECT id FROM pgroups WHERE id = ?";
    $stmt = $conn->prepare($checkGroup);
    $stmt->bind_param("i", $groupId);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows === 0) {
        throw new Exception('Group not found');
    }
    
    // Update group details (domain only - batch is immutable after creation)
    $updateQuery = "UPDATE pgroups SET domain = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("si", $domain, $groupId);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to update group details');
    }
    
    sendJSON([
        'success' => true,
        'message' => 'Group details updated successfully'
    ]);
    
} catch (Exception $e) {
    sendJSON([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
