<?php
require_once '../config/config.php';
requireLogin();

$uploadId = intval($_GET['upload_id'] ?? 0);

if (!$uploadId) {
    http_response_code(400);
    die('Upload ID is required');
}

try {
    // Get upload details with proper authorization
    $query = "SELECT 
                pu.file_path,
                pu.filename,
                pu.file_type,
                pu.status,
                g.id as group_id,
                g.guide_id
              FROM project_uploads pu
              INNER JOIN pgroups g ON pu.group_id = g.id
              WHERE pu.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $uploadId);
    $stmt->execute();
    $upload = $stmt->get_result()->fetch_assoc();
    
    if (!$upload) {
        http_response_code(404);
        die('Upload not found');
    }
    
    // Authorization check
    $authorized = false;
    
    if (hasRole('coordinator')) {
        $authorized = true;
    } elseif (hasRole('guide')) {
        // Guide can only download uploads from their assigned groups
        if ($upload['guide_id'] == $_SESSION['role_id']) {
            $authorized = true;
        }
    } elseif (hasRole('student')) {
        // Student can only download uploads from their own group
        if ($upload['group_id'] == $_SESSION['group_id']) {
            $authorized = true;
        }
    }
    
    if (!$authorized) {
        http_response_code(403);
        die('Access denied');
    }
    
    // Convert relative path from database to absolute path
    // Database stores: 'uploads/project_files/filename.pdf'
    // Need absolute path: __DIR__ . '/../uploads/project_files/filename.pdf'
    $relativePath = $upload['file_path'];
    $filePath = __DIR__ . '/../' . $relativePath;
    
    if (!file_exists($filePath)) {
        http_response_code(404);
        die('File not found on server: ' . htmlspecialchars(basename($relativePath)));
    }
    
    $resolved = realpath($filePath);
    $uploadReal = realpath(UPLOAD_PATH);
    if ($resolved === false || strpos($resolved, $uploadReal . DIRECTORY_SEPARATOR) !== 0) {
        sendJSON(['success' => false, 'message' => 'Invalid file path']);
    }
    
    // Set headers for file viewing (inline display in browser)
    $safeFilename = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($upload['filename']));
    header('Content-Type: ' . ($upload['file_type'] ?: 'application/octet-stream'));
    header('Content-Disposition: inline; filename="' . $safeFilename . '"');
    header('Content-Length: ' . filesize($resolved));
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: public');
    
    // Clear output buffer
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    // Read and output file
    readfile($resolved);
    exit;
    
} catch (Exception $e) {
    http_response_code(500);
    debugLog('Download upload error: ' . $e->getMessage());
    die('Error downloading file');
}
?>
