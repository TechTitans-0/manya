<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

// Determine selected academic year (session or active)
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

$groupId = null;

// Determine group ID based on role
if (hasRole('student')) {
    $groupId = $_SESSION['group_id'] ?? null;
} elseif (hasRole('guide')) {
    $groupId = intval($_GET['group_id'] ?? 0);
    // Verify guide has access to this group
    $checkQuery = "SELECT id FROM pgroups WHERE id = ? AND guide_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $groupId, $_SESSION['role_id']);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        sendJSON(['success' => false, 'message' => 'Access denied']);
    }
} elseif (hasRole('coordinator')) {
    $groupId = intval($_GET['group_id'] ?? 0);
}

if (!$groupId) {
    sendJSON(['success' => false, 'message' => 'Group ID required']);
}

// Get uploads for the group
// For mini projects, phase and review columns don't exist, so use 0 as placeholders
if ($_SESSION['project_type'] === 'mini') {
    $query = "SELECT pu.id, pu.group_id, pu.filename as file_name, pu.upload_date as uploaded_at, pu.file_type, pu.project_title, pu.uploaded_by, pu.academic_year_id, pu.status, pu.feedback, 0 as phase, 0 as review, 0 as review_type, u.username as uploaded_by_name
              FROM project_uploads pu
              INNER JOIN students s ON pu.uploaded_by = s.id
              INNER JOIN users u ON s.user_id = u.id
              WHERE pu.group_id = ? AND pu.academic_year_id = ?
              ORDER BY pu.upload_date DESC";
} else {
    $query = "SELECT pu.*, pu.review as review_type, pu.filename as file_name, pu.upload_date as uploaded_at, u.username as uploaded_by_name
              FROM project_uploads pu
              INNER JOIN students s ON pu.uploaded_by = s.id
              INNER JOIN users u ON s.user_id = u.id
              WHERE pu.group_id = ? AND pu.academic_year_id = ?
              ORDER BY pu.upload_date DESC";
}

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $groupId, $selectedAcademicYearId);
$stmt->execute();
$uploads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

sendJSON(['success' => true, 'uploads' => $uploads]);
?>
