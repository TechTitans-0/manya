<?php
require_once __DIR__ . '/../config/config.php';
requireRole('coordinator');

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=students_report_' . date('Y-m-d') . '.csv');

$output = fopen('php://output', 'w');

// Add BOM for Excel UTF-8 support
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Determine project type
$projectType = $_SESSION['project_type'] ?? 'major';

// CSV header based on project type
if ($projectType === 'mini') {
    fputcsv($output, ['Student Name','USN','Batch','Guide Name','Project Title','Marks']);
} else {
    fputcsv($output, ['Student Name','USN','Batch','Guide Name','Project Title','Review 1 Marks','Review 2 Marks','Final Marks']);
}

// Get current phase from global settings (for major project)
$currentPhase = 1;
if ($projectType === 'major') {
    $phaseQuery = $conn->query("SELECT setting_value FROM global_settings WHERE setting_key = 'current_phase'");
    if ($phaseQuery && $row = $phaseQuery->fetch_assoc()) {
        $currentPhase = intval($row['setting_value']);
    }
}

$currentCoordinatorId = isset($_SESSION['role_id']) ? intval($_SESSION['role_id']) : 0;

// Determine selected academic year (session or active)
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

// Query with academic year join, ordered by batch
$query = "SELECT s.id as student_id, u.username as student_name, s.usn, g.id as group_id, g.batch, g.project_title,
          ay.year_label as academic_year,
          gd.id as guide_id, gu_user.username as guide_name,
          cd.id as coordinator_guide_id, c_user.username as coordinator_name
          FROM students s
          INNER JOIN users u ON s.user_id = u.id
          LEFT JOIN `pgroups` g ON s.group_id = g.id
          LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
          LEFT JOIN guides gd ON g.guide_id = gd.id
          LEFT JOIN users gu_user ON gd.user_id = gu_user.id
          LEFT JOIN coordinators cd ON g.coordinator_guide_id = cd.id
          LEFT JOIN users c_user ON cd.user_id = c_user.id
          WHERE s.academic_year_id = ?
          ORDER BY g.batch ASC, u.username ASC";

$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->bind_param("i", $selectedAcademicYearId);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = false;
}
if ($res) {
    if ($projectType === 'major') {
        // Prepare statement for summing marks by student, phase, and review
        $sumStudentStmt = $conn->prepare("SELECT IFNULL(SUM(sg.total_marks),0) as total, IFNULL(SUM(sg.max_marks),0) as maxm
                                    FROM student_grades sg
                                    JOIN evaluation_sheets es ON sg.evaluation_sheet_id = es.id
                                    WHERE sg.student_id = ? AND es.phase = ? AND es.review = ? AND sg.academic_year_id = ?");
    } else {
        // For mini, sum all marks for the student
        $sumStudentStmt = $conn->prepare("SELECT IFNULL(SUM(sg.total_marks),0) as total, IFNULL(SUM(sg.max_marks),0) as maxm
                                    FROM student_grades sg
                                    WHERE sg.student_id = ? AND sg.academic_year_id = ?");
    }

    while ($row = $res->fetch_assoc()) {
        $review1 = '';
        $review2 = '';
        $final = '';
        // determine appropriate guide name respecting coordinator logic
        $guideNameCsv = '';
        if (!empty($row['guide_name'])) {
            $guideNameCsv = $row['guide_name'];
        } elseif (!empty($row['coordinator_guide_id']) && !empty($row['coordinator_name'])) {
            if (intval($row['coordinator_guide_id']) === $currentCoordinatorId) {
                // logged-in coordinator is the guide, show plain name
                $guideNameCsv = $row['coordinator_name'];
            } else {
                // another coordinator is assigned
                $guideNameCsv = $row['coordinator_name'] . ' (Coordinator)';
            }
        }

        // Format batch: prefix 'B' and include academic year
        $batchRaw = isset($row['batch']) ? trim($row['batch']) : '';
        $batchLabel = '';
        if ($batchRaw !== '') {
            if (preg_match('/^B/i', $batchRaw)) {
                $batchLabel = $batchRaw;
            } elseif (is_numeric($batchRaw) && strlen($batchRaw) <= 2) {
                $batchLabel = 'B' . $batchRaw;
            } else {
                $batchLabel = $batchRaw;
            }
            // Append academic year if available
            if (!empty($row['academic_year'])) {
                $batchLabel .= ' (' . $row['academic_year'] . ')';
            }
        }

        $studentId = (int)$row['student_id'];

        if ($projectType === 'major') {
            // Get marks for Review 1 and Review 2 based on current phase
            $review1_total = 0; $review1_max = 0;
            $review2_total = 0; $review2_max = 0;

            // Review 1 marks (current phase, review 1)
            $rev1 = 1;
            $sumStudentStmt->bind_param('iiii', $studentId, $currentPhase, $rev1, $selectedAcademicYearId);
            $sumStudentStmt->execute();
            $r1 = $sumStudentStmt->get_result()->fetch_assoc();
            $review1_total = floatval($r1['total']);
            $review1_max = floatval($r1['maxm']);

            // Review 2 marks (current phase, review 2)
            $rev2 = 2;
            $sumStudentStmt->bind_param('iiii', $studentId, $currentPhase, $rev2, $selectedAcademicYearId);
            $sumStudentStmt->execute();
            $r2 = $sumStudentStmt->get_result()->fetch_assoc();
            $review2_total = floatval($r2['total']);
            $review2_max = floatval($r2['maxm']);

            // Format outputs
            $review1 = ($review1_total === 0 && $review1_max === 0) ? '' : number_format($review1_total, 2);
            $review2 = ($review2_total === 0 && $review2_max === 0) ? '' : number_format($review2_total, 2);
            $final_total = $review1_total + $review2_total;
            $final = ($final_total === 0) ? '' : number_format($final_total, 2);

            fputcsv($output, [
                $row['student_name'] ?: '',
                $row['usn'] ?: '',
                $batchLabel,
                $guideNameCsv ?: '',
                $row['project_title'] ?: '',
                $review1,
                $review2,
                $final
            ]);
        } else {
            // For mini project, get total marks
            $sumStudentStmt->bind_param('ii', $studentId, $selectedAcademicYearId);
            $sumStudentStmt->execute();
            $r = $sumStudentStmt->get_result()->fetch_assoc();
            $total_marks = floatval($r['total']);
            $marks = ($total_marks === 0) ? '' : number_format($total_marks, 2);

            fputcsv($output, [
                $row['student_name'] ?: '',
                $row['usn'] ?: '',
                $batchLabel,
                $guideNameCsv ?: '',
                $row['project_title'] ?: '',
                $marks
            ]);
        }
    }

    $sumStudentStmt->close();
}

fclose($output);
exit;
?>
