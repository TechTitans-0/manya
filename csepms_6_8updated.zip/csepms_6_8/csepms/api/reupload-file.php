<?php
require_once '../config/config.php';
requireRoleAPI('student');
enforceReadOnlyForCompletedYear();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (empty($_SESSION['is_team_lead'])) {
    sendJSON(['success' => false, 'message' => 'Only the team lead can reupload files'], 403);
}

$uploadId = intval($_POST['upload_id'] ?? 0);
if (!$uploadId) {
    sendJSON(['success' => false, 'message' => 'Upload ID required']);
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    sendJSON(['success' => false, 'message' => 'No file uploaded or upload error']);
}

// Fetch upload record
$stmt = $conn->prepare("SELECT * FROM project_uploads WHERE id = ?");
$stmt->bind_param("i", $uploadId);
$stmt->execute();
$upload = $stmt->get_result()->fetch_assoc();

if (!$upload) {
    sendJSON(['success' => false, 'message' => 'Upload not found']);
}

// Ensure upload belongs to same group as the team lead
if ($upload['group_id'] != ($_SESSION['group_id'] ?? 0)) {
    sendJSON(['success' => false, 'message' => 'Access denied']);
}

$file = $_FILES['file'];
$allowedTypes = ['application/pdf', 'application/msword', 
                 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                 'application/vnd.ms-powerpoint',
                 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mimeType, $allowedTypes)) {
    sendJSON(['success' => false, 'message' => 'Invalid file type. Only PDF, DOC, DOCX, PPT, PPTX allowed']);
}

if ($file['size'] > MAX_FILE_SIZE) {
    sendJSON(['success' => false, 'message' => 'File too large. Maximum size is 10MB']);
}

try {
    $conn->begin_transaction();

    // Move new file
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    // Validate extension against allowlist
    $allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx'];
    if (!in_array(strtolower($extension), $allowedExtensions)) {
        sendJSON(['success' => false, 'message' => 'Invalid file extension. Only PDF, DOC, DOCX, PPT, PPTX allowed']);
    }
    // For mini projects, phase/review columns don't exist; use simpler filename
    if (($_SESSION['project_type'] ?? '') === 'mini') {
        $filename = 'group_' . $upload['group_id'] . '_' . time() . '.' . $extension;
    } else {
        $filename = 'group_' . $upload['group_id'] . '_phase' . $upload['phase'] . '_review' . $upload['review'] . '_' . time() . '.' . $extension;
    }
    $uploadPath = UPLOAD_PATH . 'project_files/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        throw new Exception('Failed to move uploaded file');
    }

    $resolved = realpath($uploadPath);
    $uploadReal = realpath(UPLOAD_PATH);
    if ($resolved === false || strpos($resolved, $uploadReal . DIRECTORY_SEPARATOR) !== 0) {
        @unlink($uploadPath);
        sendJSON(['success' => false, 'message' => 'Invalid file path']);
    }

    $filePath = 'uploads/project_files/' . $filename;

    // Update DB record
    $update = $conn->prepare("UPDATE project_uploads SET filename = ?, file_path = ?, file_type = ?, upload_date = NOW(), status = 'pending' WHERE id = ?");
    $update->bind_param("sssi", $file['name'], $filePath, $mimeType, $uploadId);
    if (!$update->execute()) {
        // Remove uploaded file
        @unlink($uploadPath);
        throw new Exception('Failed to update upload record');
    }

    // Remove old file if exists
    if (!empty($upload['file_path'])) {
        $oldFull = __DIR__ . '/../' . $upload['file_path'];
        if (file_exists($oldFull)) {
            $resolved = realpath($oldFull);
            $uploadReal = realpath(UPLOAD_PATH);
            if ($resolved === false || strpos($resolved, $uploadReal . DIRECTORY_SEPARATOR) !== 0) {
                sendJSON(['success' => false, 'message' => 'Invalid file path']);
            }
            @unlink($resolved);
        }
    }

    $conn->commit();
    sendJSON(['success' => true, 'message' => 'File reuploaded successfully']);

} catch (Exception $e) {
    $conn->rollback();
    if (isset($uploadPath) && file_exists($uploadPath)) {
        @unlink($uploadPath);
    }
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}

?>