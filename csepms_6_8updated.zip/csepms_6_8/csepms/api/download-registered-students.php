<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="registered_students_' . date('Y-m-d_H-i-s') . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Write CSV headers
fputcsv($output, ['USN', 'Name', 'Email ID', 'Phone Number']);

try {
    // Query to get registered students (those with user accounts)
    $query = "SELECT
                s.usn,
                u.username as name,
                u.email,
                u.phone
              FROM students s
              INNER JOIN users u ON s.user_id = u.id
              WHERE u.role = 'student'
              ORDER BY s.usn ASC";

    $result = $conn->query($query);

    if (!$result) {
        throw new Exception($conn->error);
    }

    // Write data rows
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['usn'],
            $row['name'],
            $row['email'],
            $row['phone']
        ]);
    }

    $result->free();

} catch (Exception $e) {
    // If there's an error, write an error message to the CSV
    fputcsv($output, ['Error', 'Error generating report', $e->getMessage(), '']);
} finally {
    // Close the output stream
    fclose($output);
}
?>