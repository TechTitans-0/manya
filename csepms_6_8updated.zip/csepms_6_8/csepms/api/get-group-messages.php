<?php
require_once '../config/config.php';
requireLogin();

header('Content-Type: application/json');

// Determine selected academic year (session or active)
$selectedAcademicYearId = isset($_SESSION['academic_year_id']) ? intval($_SESSION['academic_year_id']) : null;
if (!$selectedAcademicYearId) {
    $activeYear = $conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
    $selectedAcademicYearId = $activeYear ? intval($activeYear['id']) : null;
}

$chatType = sanitizeInput($_GET['chat_type'] ?? '');
$groupId = intval($_GET['group_id'] ?? 0);

if (empty($chatType)) {
    sendJSON(['success' => false, 'message' => 'Chat type required']);
}

$messages = [];

if ($chatType === 'project_group' && $groupId > 0) {
    // Get messages for project group
    $query = "SELECT cm.*, 
              u.username as sender_name, u.username as sender_fullname, u.role as sender_role
              FROM chat_messages cm
              INNER JOIN users u ON cm.sender_id = u.id
              WHERE cm.group_id = ? AND cm.deleted_at IS NULL AND cm.academic_year_id = ?
              ORDER BY cm.sent_at ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $groupId, $selectedAcademicYearId);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Mark messages as read for this guide/student: mark messages in the group not sent by current user
    $markRead = "UPDATE chat_messages SET is_read = 1 
                 WHERE group_id = ? AND is_read = 0 AND sender_id != ? AND academic_year_id = ?";
    $stmt = $conn->prepare($markRead);
    $stmt->bind_param("iii", $groupId, $_SESSION['user_id'], $selectedAcademicYearId);
    $stmt->execute();
    
} elseif ($chatType === 'all_students' && hasRole('coordinator')) {
    // Get messages for all students group
    $query = "SELECT cm.*, 
              u.username as sender_name, u.username as sender_fullname, u.role as sender_role
              FROM chat_messages cm
              INNER JOIN users u ON cm.sender_id = u.id
              WHERE cm.group_id IS NULL 
              AND cm.receiver_role = 'all_students'
              AND cm.deleted_at IS NULL
              AND cm.academic_year_id = ?
              ORDER BY cm.sent_at ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $selectedAcademicYearId);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
} elseif ($chatType === 'all_guides' && hasRole('coordinator')) {
    // Get messages for all guides group
    $query = "SELECT cm.*, 
              u.username as sender_name, u.username as sender_fullname, u.role as sender_role
              FROM chat_messages cm
              INNER JOIN users u ON cm.sender_id = u.id
              WHERE cm.group_id IS NULL 
              AND cm.receiver_role = 'all_guides'
              AND cm.deleted_at IS NULL
              AND cm.academic_year_id = ?
              ORDER BY cm.sent_at ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $selectedAcademicYearId);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

sendJSON(['success' => true, 'messages' => $messages]);
?>
