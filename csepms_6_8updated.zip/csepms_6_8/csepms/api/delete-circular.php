<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$id = intval($_POST['id'] ?? 0);
if (!$id) {
    sendJSON(['success' => false, 'message' => 'Invalid circular ID']);
}

// Fetch the circular to get identifying fields
$stmt = $conn->prepare('SELECT title, message, attachment_path, created_at, academic_year_id, sender_id FROM notifications WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
if (!$row) {
    sendJSON(['success' => false, 'message' => 'Circular not found']);
}
$stmt->close();

$title = $row['title'];
$message = $row['message'];
$attachmentPath = $row['attachment_path'];
$createdAt = $row['created_at'];
$academicYearId = $row['academic_year_id'];
$senderId = $row['sender_id'];

// Only the sender can delete their own circular
if ($senderId != $_SESSION['user_id']) {
    sendJSON(['success' => false, 'message' => 'Access denied'], 403);
}

// Check if the academic year is COMPLETED
if ($academicYearId) {
    $yearStmt = $conn->prepare('SELECT status FROM academic_years WHERE id = ?');
    $yearStmt->bind_param('i', $academicYearId);
    $yearStmt->execute();
    $yearResult = $yearStmt->get_result()->fetch_assoc();
    $yearStmt->close();
    
    if ($yearResult && $yearResult['status'] === 'COMPLETED') {
        sendJSON(['success' => false, 'message' => 'Cannot modify data for completed academic years']);
    }
}

// Delete all matching notifications for this sender, academic year, and exact circular signature
$delStmt = $conn->prepare('DELETE FROM notifications WHERE sender_id = ? AND academic_year_id = ? AND title = ? AND message = ? AND created_at = ?');
$delStmt->bind_param('iisss', $senderId, $academicYearId, $title, $message, $createdAt);
if ($delStmt->execute()) {
    // Optionally delete the attachment file with realpath validation
    if ($attachmentPath) {
        $attachmentFull = realpath(__DIR__ . '/../' . $attachmentPath);
        $uploadReal = realpath(UPLOAD_PATH);
        if ($attachmentFull !== false && $uploadReal !== false && strpos($attachmentFull, $uploadReal . DIRECTORY_SEPARATOR) === 0 && file_exists($attachmentFull)) {
            @unlink($attachmentFull);
        }
    }
    sendJSON(['success' => true]);
} else {
    debugLog('Delete circular error: ' . $delStmt->error);
    sendJSON(['success' => false, 'message' => 'Failed to delete circular']);
}
$delStmt->close();
