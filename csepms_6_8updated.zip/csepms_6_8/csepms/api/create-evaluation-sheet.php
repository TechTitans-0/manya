<?php
require_once '../config/config.php';
requireRoleAPI('coordinator');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJSON(['success' => false, 'message' => 'Invalid request method'], 405);
}

$isMiniProject = (getCurrentProjectType() === 'mini');

$phase = intval($_POST['phase'] ?? 0);
$review = intval($_POST['review_type'] ?? 0);
$subject_code = sanitizeInput($_POST['subject_code'] ?? '');
$criteria = json_decode($_POST['criteria'] ?? '[]', true);

// For mini projects, force phase=1 and review=1
if ($isMiniProject) {
    $phase = 1;
    $review = 1;
}

if ($phase <= 0 || $review <= 0 || empty($subject_code) || empty($criteria)) {
    sendJSON(['success' => false, 'message' => 'Missing required parameters']);
}

// Get coordinator ID
$coordQuery = "SELECT id FROM coordinators WHERE user_id = ?";
$stmt = $conn->prepare($coordQuery);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$coordinator = $stmt->get_result()->fetch_assoc();

if (!$coordinator) {
    sendJSON(['success' => false, 'message' => 'Coordinator not found']);
}

try {
    $conn->begin_transaction();
    
    // Create evaluation sheet
    // For mini projects, don't include phase and review columns
    if ($isMiniProject) {
        $insertSheet = "INSERT INTO evaluation_sheets (subject_code, status, created_by)
                        VALUES (?, 'active', ?)";
        $stmt = $conn->prepare($insertSheet);
        $stmt->bind_param("si", $subject_code, $coordinator['id']);
    } else {
        // Major schema requires title (no default), so use subject_code as title
        $sheetTitle = $subject_code;
        $insertSheet = "INSERT INTO evaluation_sheets (phase, subject_code, review, title, status, created_by)
                        VALUES (?, ?, ?, ?, 'active', ?)";
        $stmt = $conn->prepare($insertSheet);
        $stmt->bind_param("isiss", $phase, $subject_code, $review, $sheetTitle, $coordinator['id']);
    }
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to create evaluation sheet');
    }
    
    $sheetId = $conn->insert_id;
    
    // Insert criteria
    $insertCriteria = "INSERT INTO evaluation_criteria (evaluation_sheet_id, criterion_name, max_marks, display_order)
                       VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insertCriteria);
    
    foreach ($criteria as $index => $criterion) {
        $name = sanitizeInput($criterion['name'] ?? '');
        $marks = intval($criterion['marks'] ?? 0);
        $order = $index + 1;
        
        if (empty($name) || $marks <= 0) {
            throw new Exception('Invalid criterion data');
        }
        
        $stmt->bind_param("isii", $sheetId, $name, $marks, $order);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to insert criterion: ' . $name);
        }
    }
    
    $conn->commit();
    
    // Fetch created sheet details to return (criteria count and total marks)
    if ($isMiniProject) {
        $sheetQuery = "SELECT es.id, es.status, es.created_at,
                              COALESCE(SUM(ec.max_marks),0) as total_marks,
                              COUNT(ec.id) as criteria_count
                       FROM evaluation_sheets es
                       LEFT JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
                       WHERE es.id = ?
                       GROUP BY es.id";
        $sstmt = $conn->prepare($sheetQuery);
        $sstmt->bind_param('i', $sheetId);
    } else {
        $sheetQuery = "SELECT es.id, es.phase, es.review, es.status, es.created_at,
                              COALESCE(SUM(ec.max_marks),0) as total_marks,
                              COUNT(ec.id) as criteria_count
                       FROM evaluation_sheets es
                       LEFT JOIN evaluation_criteria ec ON es.id = ec.evaluation_sheet_id
                       WHERE es.id = ?
                       GROUP BY es.id";
        $sstmt = $conn->prepare($sheetQuery);
        $sstmt->bind_param('i', $sheetId);
    }
    $sstmt->execute();
    $sheetRow = $sstmt->get_result()->fetch_assoc();

    sendJSON([
        'success' => true,
        'message' => 'Evaluation sheet created successfully',
        'sheet_id' => $sheetId,
        'sheet' => $sheetRow
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    sendJSON(['success' => false, 'message' => $e->getMessage()]);
}
?>
