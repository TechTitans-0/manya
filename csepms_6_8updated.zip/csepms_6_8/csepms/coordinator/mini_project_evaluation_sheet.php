<?php
require_once '../config/config.php';
requireRole('coordinator');

// Get parameters from URL or session
$groupId = isset($_GET['group_id']) ? intval($_GET['group_id']) : 0;
$phase = isset($_GET['phase']) ? intval($_GET['phase']) : 1;
$review = isset($_GET['review']) ? intval($_GET['review']) : 1;

if (!$groupId) {
    die('Invalid group ID');
}

// Fetch group details
$groupQuery = "SELECT g.*, b.batch_name, ay.year_label,
               (SELECT CONCAT(u.username, '|', u.phone) FROM students st 
                INNER JOIN users u ON st.user_id = u.id 
                WHERE st.group_id = g.id AND st.is_team_lead = 1 LIMIT 1) as team_lead_info
               FROM pgroups g
               LEFT JOIN batches b ON g.batch = b.batch_name
               LEFT JOIN academic_years ay ON g.academic_year_id = ay.id
               WHERE g.id = ?";
$stmt = $conn->prepare($groupQuery);
$stmt->bind_param("i", $groupId);
$stmt->execute();
$group = $stmt->get_result()->fetch_assoc();

if (!$group) {
    die('Group not found');
}

// Fetch students in the group
$studentsQuery = "SELECT s.*, u.name, u.username as usn
                  FROM students s
                  INNER JOIN users u ON s.user_id = u.id
                  WHERE s.group_id = ?
                  ORDER BY s.is_team_lead DESC, u.name ASC";
$stmt = $conn->prepare($studentsQuery);
$stmt->bind_param("i", $groupId);
$stmt->execute();
$students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch guide name
$guideQuery = "SELECT u.name FROM guides g INNER JOIN users u ON g.user_id = u.id WHERE g.id = ?";
$stmt = $conn->prepare($guideQuery);
$stmt->bind_param("i", $group['guide_id']);
$stmt->execute();
$guide = $stmt->get_result()->fetch_assoc();

// Fetch department from students (assuming all students in same department)
$department = '';
if (!empty($students)) {
    $deptQuery = "SELECT department FROM users WHERE id = ?";
    $stmt = $conn->prepare($deptQuery);
    $stmt->bind_param("i", $students[0]['user_id']);
    $stmt->execute();
    $deptResult = $stmt->get_result()->fetch_assoc();
    $department = $deptResult['department'] ?? '';
}

// Fetch subject code from evaluation sheet (mini project doesn't use phase/review)
$subjectCode = '';
$sheetQuery = "SELECT subject_code FROM evaluation_sheets WHERE status = 'active' ORDER BY id DESC LIMIT 1";
$sheetResult = $conn->query($sheetQuery);
if ($sheetResult && $sheet = $sheetResult->fetch_assoc()) {
    $subjectCode = $sheet['subject_code'];
}

// Fetch evaluation criteria (mini project doesn't use phase/review)
$criteriaQuery = "SELECT ec.criterion_name, ec.max_marks
                  FROM evaluation_criteria ec
                  INNER JOIN evaluation_sheets es ON ec.evaluation_sheet_id = es.id
                  WHERE es.status = 'active'
                  ORDER BY ec.display_order ASC";
$criteriaResult = $conn->query($criteriaQuery);
$criteria = $criteriaResult ? $criteriaResult->fetch_all(MYSQLI_ASSOC) : [];

// Calculate total max marks
$totalMaxMarks = 0;
foreach ($criteria as $criterion) {
    $totalMaxMarks += $criterion['max_marks'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Project Evaluation Sheet</title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            margin: 20px;
        }
        .header-img {
            width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        .title-section {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }
        .department {
            font-size: 14px;
            margin-bottom: 10px;
        }
        .main-title {
            font-size: 16px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #000;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        .project-details th {
            background-color: #f0f0f0;
            font-weight: bold;
        }
        .marks-table th {
            background-color: #f0f0f0;
            font-weight: bold;
            text-align: center;
        }
        .marks-table td {
            text-align: center;
        }
        .total-row {
            font-weight: bold;
        }
        .signature-section {
            margin-top: 50px;
            text-align: right;
        }
        .underline {
            border-bottom: 1px solid #000;
            display: inline-block;
            min-width: 200px;
        }
    </style>
</head>
<body>
    <!-- Header Image -->
    <img src="assets/images/header.jpeg" alt="Header" class="header-img">

    <!-- Title Section -->
    <div class="title-section">
        <div class="department">DEPARTMENT OF <?php echo htmlspecialchars(strtoupper($department)); ?></div>
        <div class="main-title">MINI PROJECT (<?php echo htmlspecialchars($subjectCode); ?>) EVALUATION SHEET</div>
    </div>

    <!-- Project Details Section -->
    <table class="project-details">
        <tr>
            <th width="30%">Mini-Project Title:</th>
            <td colspan="5"><?php echo htmlspecialchars($group['project_title'] ?? ''); ?></td>
        </tr>
        <tr>
            <th>Batch No:</th>
            <td width="20%"><?php echo htmlspecialchars($group['batch']); ?></td>
            <th width="15%">Date:</th>
            <td colspan="3"><?php echo date('d/m/Y'); ?></td>
        </tr>
        <tr>
            <th>Name of the Mini-Project Guide:</th>
            <td colspan="5"><?php echo htmlspecialchars($guide['name'] ?? ''); ?></td>
        </tr>
        <tr>
            <th>Student Names:</th>
            <?php for ($i = 0; $i < 4; $i++): ?>
                <td><?php echo htmlspecialchars($students[$i]['name'] ?? ''); ?></td>
            <?php endfor; ?>
        </tr>
        <tr>
            <th>USN:</th>
            <?php for ($i = 0; $i < 4; $i++): ?>
                <td><?php echo htmlspecialchars($students[$i]['usn'] ?? ''); ?></td>
            <?php endfor; ?>
        </tr>
    </table>

    <!-- Marks Evaluation Table -->
    <table class="marks-table">
        <thead>
            <tr>
                <th width="5%">Sl No</th>
                <th width="45%">Particulars</th>
                <th width="10%">Max Marks</th>
                <?php for ($i = 0; $i < 4; $i++): ?>
                    <th width="10%">Obtained Marks</th>
                <?php endfor; ?>
            </tr>
        </thead>
        <tbody>
            <?php $slNo = 1; ?>
            <?php foreach ($criteria as $criterion): ?>
                <tr>
                    <td><?php echo $slNo++; ?></td>
                    <td><?php echo htmlspecialchars($criterion['criterion_name']); ?></td>
                    <td><?php echo htmlspecialchars($criterion['max_marks']); ?></td>
                    <?php for ($i = 0; $i < 4; $i++): ?>
                        <td>&nbsp;</td>
                    <?php endfor; ?>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="2">TOTAL MARKS</td>
                <td><?php echo $totalMaxMarks; ?></td>
                <?php for ($i = 0; $i < 4; $i++): ?>
                    <td>&nbsp;</td>
                <?php endfor; ?>
            </tr>
        </tbody>
    </table>

    <!-- Signature Section -->
    <div class="signature-section">
        <div>Signature of Guide</div>
        <div class="underline">&nbsp;</div>
    </div>
</body>
</html>