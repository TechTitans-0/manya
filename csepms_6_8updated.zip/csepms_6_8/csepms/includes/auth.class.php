<?php
require_once __DIR__ . '/../config/config.php';

class Auth {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
private function hasCoordinatorApprovalColumn() {
        $result = $this->conn->query("SHOW COLUMNS FROM coordinators LIKE 'approval_status'");
        return $result && $result->num_rows > 0;
    }
    

    // Register new user
    public function register($data, $role) {
        try {
            $this->conn->begin_transaction();
            

            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

            // Determine usn_emp_id (always uppercase for USN/Employee ID)
            $usn_emp_id = '';
            if ($role === 'student') {
                $usn_emp_id = strtoupper($data['usn']);
            } elseif ($role === 'guide' || $role === 'coordinator') {
                $usn_emp_id = strtoupper($data['employee_id']);
            }

            // Always store name in lowercase for case-insensitive comparison
            $username = strtolower($data['username']);

            // Insert into users table
            $stmt = $this->conn->prepare("INSERT INTO users (usn_emp_id, username, email, password, role, phone) VALUES (?, ?, ?, ?, ?, ?)");
            if (!$stmt) {
                throw new Exception("Database prepare error: " . $this->conn->error);
            }
            $stmt->bind_param("ssssss", $usn_emp_id, $username, $data['email'], $hashedPassword, $role, $data['phone']);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create user account");
            }
            
            $userId = $this->conn->insert_id;
            
            // Insert into role-specific table
            if ($role === 'student') {
                // Check if USN is authorized and get academic_year_id
                $checkStmt = $this->conn->prepare("SELECT id, academic_year_id, department FROM authorized_students WHERE LOWER(usn) = LOWER(?)");
                if (!$checkStmt) {
                    throw new Exception("Database prepare error: " . $this->conn->error);
                }
                $checkStmt->bind_param("s", $data['usn']);
                $checkStmt->execute();
                $result = $checkStmt->get_result();
                
                if ($result->num_rows === 0) {
                    $result->free();
                    $checkStmt->close();
                    throw new Exception("You are not authorized to register.");
                }
                
                $authRow = $result->fetch_assoc();
                $result->free();
                $checkStmt->close();
                
                $stmt = $this->conn->prepare("INSERT INTO students (user_id, usn, name, email, phone, year_of_passing, branch, academic_year_id, is_authorized) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)");
                if (!$stmt) {
                    throw new Exception("Database prepare error: " . $this->conn->error);
                }
                $stmt->bind_param("issssisi", $userId, $data['usn'], $data['username'], $data['email'], $data['phone'], $data['year_of_passing'], $data['branch'], $authRow['academic_year_id']);
            } elseif ($role === 'guide') {
                // Check if Employee ID is authorized
                $checkStmt = $this->conn->prepare("SELECT id FROM authorized_guides WHERE LOWER(employee_id) = LOWER(?)");
                if (!$checkStmt) {
                    throw new Exception("Database prepare error: " . $this->conn->error);
                }
                $checkStmt->bind_param("s", $data['employee_id']);
                $checkStmt->execute();
                $result = $checkStmt->get_result();
                
                if ($result->num_rows === 0) {
                    $result->free();
                    $checkStmt->close();
                    throw new Exception("You are not authorized to register as a guide.");
                }
                $result->free();
                $checkStmt->close();
                
                $stmt = $this->conn->prepare("INSERT INTO guides (user_id, employee_id,domain, department) VALUES (?, ?, ?, ?)");
                if (!$stmt) {
                    throw new Exception("Database prepare error: " . $this->conn->error);
                }
                $stmt->bind_param("isss", $userId, $data['employee_id'],$data['domain'], $data['department']);
            } elseif ($role === 'coordinator') {
                // Coordinators require authorization, register directly
		$stmt = $this->conn->prepare("INSERT INTO coordinators (user_id, employee_id, designation, research_domain_expertise, years_of_experience, department, approval_status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");

               // $stmt = $this->conn->prepare("INSERT INTO coordinators (user_id, employee_id, designation, research_domain_expertise, years_of_experience, department) VALUES (?, ?, ?, ?, ?, ?)");
                if (!$stmt) {
                    throw new Exception("Database prepare error: " . $this->conn->error);
                }
                $stmt->bind_param("isssis", $userId, $data['employee_id'], $data['designation'], $data['research_domain_expertise'], $data['years_of_experience'], $data['department']);
            }
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create role-specific profile");
            }

            // Update authorized tables status after successful registration
            if ($role === 'student') {
                $authUpdate = $this->conn->prepare("UPDATE authorized_students SET status = 'Registered', registered_user_id = ?, registered_at = CURRENT_TIMESTAMP WHERE LOWER(usn) = LOWER(?) AND registered_user_id IS NULL");
                if ($authUpdate) {
                    $authUpdate->bind_param('is', $userId, $data['usn']);
                    $authUpdate->execute();
                }
            } elseif ($role === 'guide') {
                $authUpdate = $this->conn->prepare("UPDATE authorized_guides SET status = 'Registered', registered_user_id = ?, registered_at = CURRENT_TIMESTAMP WHERE LOWER(employee_id) = LOWER(?) AND registered_user_id IS NULL");
                if ($authUpdate) {
                    $authUpdate->bind_param('is', $userId, $data['employee_id']);
                    $authUpdate->execute();
                }
            }

            $this->conn->commit();
            return ['success' => true, 'message' => 'Registration successful'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Login user
    public function login($identifier, $password, $role) {
        try {
            $query = "SELECT u.*, ";
            
            if ($role === 'student') {
                $query .= "s.id as role_id, s.usn, s.group_id, s.is_team_lead, s.academic_year_id FROM users u 
                          INNER JOIN students s ON u.id = s.user_id 
                          WHERE LOWER(s.usn) = ? AND u.role = 'student'";
            } elseif ($role === 'guide') {
                $query .= "g.id as role_id, g.employee_id FROM users u 
                          INNER JOIN guides g ON u.id = g.user_id 
                          WHERE LOWER(g.employee_id) = ? AND u.role = 'guide'";
            } elseif ($role === 'coordinator') {
                // Include approval status so we can enforce HOD approval before login
                $query .= "c.id as role_id, c.employee_id, c.approval_status FROM users u 
                          INNER JOIN coordinators c ON u.id = c.user_id 
                          WHERE LOWER(c.employee_id) = ? AND u.role = 'coordinator'";
            }

            // Debug: Log the query and identifier (only when DEBUG is enabled)
            debugLog("Login query executed for role: $role");

            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("s", $identifier);
            $stmt->execute();
            $result = $stmt->get_result();
            
            // Debug: Log result count (only when DEBUG is enabled)
            debugLog("Query result count: " . $result->num_rows);
            
            if ($result->num_rows === 0) {
                return ['success' => false, 'message' => 'Invalid credentials'];
            }
            
            $user = $result->fetch_assoc();
            
            if (!password_verify($password, $user['password'])) {
                return ['success' => false, 'message' => 'Invalid credentials'];
            }
            
            if ($role === 'coordinator') {
                $approvalStatus = strtolower($user['approval_status'] ?? 'pending');
                if ($approvalStatus === 'pending') {
                    return ['success' => false, 'message' => 'Waiting for HOD approval'];
                }
                if ($approvalStatus === 'rejected') {
                    return ['success' => false, 'message' => 'Your request has been rejected by HOD'];
                }
            }
            
            if ($user['is_active'] != 1) {
                return ['success' => false, 'message' => 'Account is inactive'];
            }
            
            // Regenerate session ID to prevent session fixation attacks
            session_regenerate_id(true);
            
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role_id'] = $user['role_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            
            if ($role === 'student') {
                $_SESSION['usn'] = $user['usn'];
                $_SESSION['group_id'] = $user['group_id'];
                $_SESSION['is_team_lead'] = $user['is_team_lead'];
                // Do not persist user's previous academic year selection across logins.
                // Always set current active academic year on fresh login.
                $activeYearRow = $this->conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
                $activeYearId = $activeYearRow ? intval($activeYearRow['id']) : null;
                $_SESSION['academic_year_id'] = $activeYearId;
                // Also store as `current_academic_year_id` per new requirement
                $_SESSION['current_academic_year_id'] = $activeYearId;
            }
            // For guides and coordinators, ensure session uses ACTIVE academic year on fresh login
            if ($role === 'guide' || $role === 'coordinator') {
                $activeYearRow = $this->conn->query("SELECT id FROM academic_years WHERE status = 'ACTIVE' LIMIT 1")->fetch_assoc();
                $activeYearId = $activeYearRow ? intval($activeYearRow['id']) : null;
                $_SESSION['academic_year_id'] = $activeYearId;
                $_SESSION['current_academic_year_id'] = $activeYearId;
            }
            
            return ['success' => true, 'role' => $user['role']];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Logout user
    public function logout() {
        session_unset();
        session_destroy();
        return true;
    }
    
    // Request password reset
    public function requestPasswordReset($email) {
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return ['success' => false, 'message' => 'Email not found'];
            }
            
            $user = $result->fetch_assoc();
            $token = generateToken();
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            $stmt = $this->conn->prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?");
            $stmt->bind_param("ssi", $token, $expiry, $user['id']);
            $stmt->execute();
            
            // In production, the reset link should be sent to the user's email via SMTP.
            // It must never be returned in the API response because that would leak the token.
            // $resetLink = BASE_URL . "reset-password.php?token=" . $token;
            // (Email implementation placeholder)
            
            return ['success' => true, 'message' => 'If the email exists, a reset link has been sent.'];
            
        } catch (Exception $e) {
            debugLog('Password reset request error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Unable to process reset request'];
        }
    }
    
    // Reset password
    public function resetPassword($token, $newPassword) {
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_token_expiry > NOW()");
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return ['success' => false, 'message' => 'Invalid or expired reset token'];
            }
            
            $user = $result->fetch_assoc();
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            $stmt = $this->conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
            $stmt->bind_param("si", $hashedPassword, $user['id']);
            $stmt->execute();
            
            return ['success' => true, 'message' => 'Password reset successful'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
?>
