# CSEPMS Security & Bug-Fix Changelog

This document records the security audit and subsequent fixes applied to the CSEPMS codebase.

## CRITICAL Fixes

1. **send-circular.php**
   - **Issue:** Used `target_type = 'all_coordinators'`, which is **not** a valid ENUM value in `mini_prj_db`, causing the circular insert to fail for mini projects.
   - **Fix:** For mini projects, create individual `specific_user` notifications for each coordinator. Keep `all_coordinators` for major projects.
   - **Also:** Switched `requireRole('coordinator')` to `requireRoleAPI('coordinator')` for correct JSON API auth.

2. **reupload-file.php**
   - **Issue:** For mini projects the code referenced `$upload['phase']` and `$upload['review']`, which do not exist in the mini-project `project_uploads` table, causing undefined index warnings and wrong filenames.
   - **Fix:** Use a simpler filename pattern for mini projects (`group_X_timestamp.ext`) and preserve the phase/review pattern for major projects.
   - **Also:** Added extension allowlist and `realpath()` validation before deleting the old file to prevent path traversal.

3. **coordinator/mini_project_evaluation_sheet.php**
   - **Issue:** Used `require_once 'config/config.php'` (relative to the `coordinator/` directory), which would fail because `config.php` is at `../config/config.php`.
   - **Fix:** Corrected the include path to `../config/config.php`.

4. **api/assign-guide.php**
   - **Issue:** Threw `Exception` outside any `try/catch` block, leading to an uncaught fatal error/500 response.
   - **Fix:** Replaced `throw` statements with `sendJSON()` error responses and switched to `requireRoleAPI('coordinator')` for JSON consistency.

5. **api/save-student-grades.php**
   - **Issue:** Threw an `Exception` before the `try` block began, causing an unhandled fatal error when the guide/coordinator could not be determined.
   - **Fix:** Replaced the `throw` with `sendJSON(..., 400)`.

6. **api/get-coordinator-recent-chats.php**
   - **Issue:** SQL operator-precedence bug in the "most recent message" query caused `academic_year_id` and `deleted_at IS NULL` filters to be ignored for one side of the OR.
   - **Fix:** Added parentheses around the OR conditions so both branches are filtered correctly.

7. **api/send-group-message.php**
   - **Issue:** `bind_param` type string `'issisi'` did not match the parameter types `(int, string, int, string, string, int)`, which can cause silent data corruption / MySQL warnings.
   - **Fix:** Corrected type strings to `'isissi'` for both the `all_students` and `all_guides` branches.

8. **database/major_prj_db.sql**
   - **Issue:** The default coordinator seed was inserted with the implicit `approval_status` defaulting to `'pending'`, preventing the initial admin coordinator from logging in.
   - **Fix:** Added `approval_status = 'approved'` to the seed insert.

## HIGH Severity Fixes

9. **config/config.php**
   - **Issue:** `display_errors` was set to `1`, exposing errors and stack traces in production.
   - **Fix:** Set `display_errors` to `0` and enabled `log_errors`.

10. **api/upload-file.php**
    - **Issue:** File extension was taken directly from the user-supplied filename without an allowlist, allowing upload of files with dangerous extensions.
    - **Fix:** Added an extension allowlist check (`pdf`, `doc`, `docx`, `ppt`, `pptx`) before accepting uploads.

11. **XSS - JavaScript template literal escaping**
    - **Issue:** Many pages injected user-controlled values (chat messages, group/project names, grades, filenames, feedback) into HTML via unescaped JavaScript template literals, enabling stored and reflected XSS.
    - **Fix:**
      - Added a global `escapeHtml()` helper in `includes/footer.php`.
      - Wrapped vulnerable interpolations in `student/chat.php`, `student/group.php`, `student/grades.php`, `student/uploads.php`.
      - `guide/chat.php`, `guide/groups.php`, `guide/grading.php`, `guide/reviews.php` XSS fixes were also applied by a background subagent.

12. **Missing `enforceReadOnlyForCompletedYear()` on mutation APIs**
    - **Issue:** Several coordinator/guide mutation endpoints did not block writes against completed academic years, allowing data modification in closed years.
    - **Fix:** Added `enforceReadOnlyForCompletedYear()` to:
      - `api/create-batch.php`
      - `api/update-evaluation-sheet.php`
      - `api/delete-evaluation-sheet.php`
      - `api/update-evaluation-status.php`
      - `api/save-grade.php`
      - `api/submit-draft-grades.php`
      - `api/update-group-details.php`
      - `api/assign-students-to-batch.php`

## MEDIUM Severity Fixes

13. **File path traversal guards**
    - **Issue:** `delete-upload.php`, `reupload-file.php`, `download-upload.php`, and `bulk-download-uploads.php` constructed filesystem paths directly from database-stored `file_path` values without validating they stay inside the upload directory.
    - **Fix:** Added `realpath()` checks and verified the resolved path is under `UPLOAD_PATH` before `unlink`, `readfile`, or ZIP addition. Also added academic-year filtering to the bulk-download query.

14. **API auth consistency (`requireRole` vs `requireRoleAPI`)**
    - **Issue:** Several JSON/file API endpoints used `requireRole()`, which redirects to `login.php` on auth failure instead of returning a proper JSON error.
    - **Fix:** Converted to `requireRoleAPI()` / `requireLogin()` as appropriate in:
      - `api/send-circular.php`
      - `api/create-evaluation-sheet.php`
      - `api/bulk-download-uploads.php`
      - `api/download-final-report.php`
      - `api/download-phase-report.php`
      - `api/download-grade-pdf.php`
      - `api/download-registered-students.php`
      - `api/get-group-grades-coordinator.php`
      - `api/assign-guide.php`
      - `api/add-academic-year.php`
      - `api/close-academic-year.php`
      - `api/set-current-academic-year.php` (was unauthenticated - now authenticated)
      - `api/get-current-academic-year.php` (was unauthenticated - now authenticated)
      - `api/get-academic-years.php` (was unauthenticated - now authenticated)

15. **Notification academic year fallback**
    - **Issue:** `api/get-notifications.php` would bind `NULL` for the academic year when the session value was unset, returning incorrect results.
    - **Fix:** Added a fallback to the currently `ACTIVE` academic year before executing the query.

## Second Pass: Production-Hardening & Mini/Major Compatibility

### CRITICAL / HIGH

16. **config/config.php production hardening**
    - **Issue:** Database credentials, base URL, and debug mode were hardcoded; session cookies lacked `SameSite`/`use_strict_mode`; security response headers were missing.
    - **Fix:** 
      - DB config, `BASE_URL`, and `DEBUG` now read from environment variables with safe fallbacks.
      - Added `session.cookie_samesite = 'Strict'`, `session.use_strict_mode = 1`, custom session name.
      - Added `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `X-XSS-Protection` headers.
      - Added `debugLog()` helper so `error_log` calls are suppressed in production unless `DEBUG=true`.

17. **includes/auth.class.php**
    - **Issue:** No session regeneration after successful login (session fixation risk) and debug logging exposed raw login query and identifiers.
    - **Fix:** Added `session_regenerate_id(true)` after setting session variables; replaced raw query `error_log` with `debugLog()`.

18. **Sensitive debug logging removal**
    - **Issue:** `api/save-student-grades.php`, `api/get-messages.php`, `api/get-grades.php`, `api/send-message.php` logged raw student/grade data, user IDs, and query errors to `error_log`.
    - **Fix:** Replaced sensitive `error_log()` calls with `debugLog()` or removed them; converted internal error messages in `sendJSON` to generic user-facing messages.

### MEDIUM

19. **File path traversal hardening (additional endpoints)**
    - **Issue:** `send-circular.php` circular attachment and `delete-circular.php` attachment deletion did not validate that resolved paths stay under `UPLOAD_PATH`.
    - **Fix:** Added `realpath()` containment checks before using or deleting circular attachment files; `send-circular.php` `mkdir()` changed from `0777` to `0755`.

20. **API consistency (`echo json_encode` → `sendJSON`)**
    - **Issue:** Many JSON API endpoints used `echo json_encode` with manual `exit;` or leaked DB error details (`$conn->error`, `$e->getMessage()`).
    - **Fix:** Converted `api/close-academic-year.php`, `api/add-academic-year.php`, `api/set-phase.php`, `api/set-review.php`, `api/set-project-phase.php`, `api/complete-project-phase.php`, `api/approve-all-grades.php`, `api/delete-circular.php`, `api/send-batch-message.php`, `api/send-guide-message.php`, `api/set-current-academic-year.php`, `api/get-current-academic-year.php`, `api/get-academic-years.php` to use `sendJSON()` and hide internal DB errors.

21. **Academic-year scoping on global phase/review operations**
    - **Issue:** `api/set-phase.php`, `api/set-review.php`, `api/set-project-phase.php`, `api/complete-project-phase.php`, and `api/approve-all-grades.php` updated or read groups/grades across **all** academic years.
    - **Fix:** Added `academic_year_id` scoping using the session-selected year or currently `ACTIVE` year.

22. **Authorization / IDOR fixes**
    - **Issue:** `api/delete-circular.php` allowed any coordinator to delete any other coordinator's circular.
    - **Fix:** Enforced that the current `user_id` must match the notification's `sender_id`.
    - **Issue:** `api/send-batch-message.php` and `api/send-guide-message.php` used manual session role checks instead of `requireRoleAPI('coordinator')`.
    - **Fix:** Switched to `requireRoleAPI('coordinator')` and added `sanitizeInput()` on message content.

23. **SQL injection hardening in close-academic-year.php**
    - **Issue:** `UPDATE` and `SELECT` queries interpolated `intval()` and `real_escape_string()` instead of using prepared statements.
    - **Fix:** Converted both queries to parameterized prepared statements.

## Remaining Known Issues (not addressed)

- Some chat APIs still have IDOR concerns (sending/reading messages for arbitrary groups/users) and missing `deleted_at IS NULL` filters in secondary query branches. These were identified but not fully patched due to scope.
- DataTable column ordering indices may be wrong for mini projects in a few coordinator/student tables.
- `project_config` is global (no `academic_year_id`) so `current_phase`/`current_review` remain global per database.

---

## Third Pass: Mini/Major Compatibility & Critical Security

### CRITICAL / HIGH

24. **Password reset token leak**
    - **Issue:** `includes/auth.class.php` returned the `reset_link` containing the raw reset token in the JSON response, allowing anyone who POSTs an email to obtain a usable reset URL.
    - **Fix:** Removed `reset_link` from the API response. Added a generic message and `debugLog()` for the exception case.

25. **Mini/major SQL compatibility in upload APIs**
    - **Issue:** `api/approve-upload.php` and `api/get-pending-reviews-coordinator.php` selected `pu.review` unconditionally, which fails on mini projects where the column does not exist.
    - **Fix:** Branched the SQL queries: mini uses `0 as review_type`, major uses `pu.review as review_type`.

26. **Mini/major SQL compatibility in evaluation sheets**
    - **Issue:** 
      - `api/create-evaluation-sheet.php` omitted the NOT-NULL `title` column for major inserts.
      - `api/update-evaluation-sheet.php` tried to update non-existent `phase`/`review` columns for mini.
      - `api/get-active-evaluation-sheets.php` selected `phase`/`review` columns that don't exist in mini.
      - `api/get-evaluation-sheet.php` (major-only endpoint) was not guarded for mini.
      - `api/get-evaluation-sheet-by-id.php` always accessed `phase`/`review` keys.
    - **Fix:** Added project-type branching or mini guards for all these endpoints; major inserts now include `title = subject_code`.

27. **Mini/major phase/review mutation compatibility**
    - **Issue:** `api/set-phase.php`, `api/set-review.php`, `api/set-project-phase.php`, and `api/complete-project-phase.php` attempted to update `pgroups.current_phase` / `pgroups.current_review` columns that do not exist in the mini schema.
    - **Fix:** Added early returns for mini projects after updating `project_config` where applicable, so pgroups is not touched.

28. **api/save-grade.php schema mismatches**
    - **Issue:** `grades.updated_at` column does not exist; `grades` and `grade_details` inserts omitted the NOT-NULL `academic_year_id` column.
    - **Fix:** Removed `updated_at` from the update; added `academic_year_id` to both inserts and to the overall-grade recalculation query; switched to `requireRoleAPI()` and generic error messages.

29. **uploads/.htaccess**
    - **Issue:** Allowed direct unauthenticated access to uploaded files (`Allow from all` for PDF/DOC/etc.).
    - **Fix:** Denied direct access to all files in the uploads directory so files should be served only through `download-upload.php`.

30. **database/mini_prj_db.sql missing default admin**
    - **Issue:** A fresh mini install had no default user/coordinator to log in.
    - **Fix:** Added the same default `admin` user and approved `COORD001` coordinator seed that major has.

## Remaining Known Issues (not addressed)

- ~50 API endpoints still return raw exception/DB-error strings in `sendJSON`/`echo json_encode` catch blocks. These were identified but not fully patched due to the large number of occurrences. Search for `$e->getMessage()` and `$conn->error` in `api/` to find them.
- Hardcoded `/csepms/` redirects exist in `vendor/index.php`, `includes/index.php`, `uploads/index.php`, `database/index.php`, `config/index.php`.
- `api/get-all-groups.php.old` backup file still exists in the web root and should be removed before deployment.
- `session.cookie_secure` remains disabled (`0`) to support HTTP deployments; set to `1` and add HSTS/CSP headers once HTTPS is enforced.
- Environment variable fallbacks in `config/config.php` still include development defaults (`localhost`, `root`, empty password); remove these or make env vars mandatory before production.
- DataTable column ordering indices may still be wrong for mini projects in some coordinator/student tables.

---

*Generated from security audit and remediation session.*
