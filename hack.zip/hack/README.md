# IntelliSpec — AI-Powered Industrial Product Intelligence Platform

**A genuinely differentiated, evidence-driven industrial product intelligence engine for the "AI-Powered Product Intelligence for Industrial Commerce" hackathon challenge.**

---

## 1. Executive Summary

IntelliSpec transforms scattered industrial product information (nameplates, PDFs, CSVs, images, manual input) into **rich, validated, explainable, and commerce-ready product intelligence**. It is **not** a generic OCR-to-JSON pipeline. Instead, it builds a trustworthy product record by:

- Extracting information from multiple sources
- Tracking the evidence and trust score of every attribute
- Normalizing values deterministically
- Enriching incomplete records
- Detecting conflicts between sources
- Validating specifications with engineering and common-sense rules
- Mapping products to real industry standards (UNSPSC, eCl@ss, ETIM)
- Calculating evidence-based confidence scores
- Explaining every AI decision
- Requiring human approval for important changes
- Finding technically compatible replacement parts
- Generating a **Product Intelligence Passport**

### Central Positioning
> "An AI system that does not merely extract industrial product data, but builds a trustworthy product record from scattered evidence by enriching, validating, standardizing, explaining, and verifying the information before making it commerce-ready."

---

## 2. What Makes This Different from Common Hackathon Solutions

| Generic Approach | IntelliSpec |
|---|---|
| `Image → OCR → JSON → Dashboard` | `Input → Extract → Validate → Evidence → Enrich → Standards → Confidence → Explain → Approve → Passport` |
| Trusts extracted values blindly | Every value has a source, trust score, and evidence chain |
| LLM hallucinates missing specs | Missing attributes inferred only from deterministics or marked `insufficient evidence` |
| Invents standards codes | Verified lookup against real reference data; says `unavailable` if no match |
| Recommendations based on text similarity | Replacements ranked by technical compatibility (voltage, power, dimensions, etc.) |
| Silent overwrites | Before/After comparison with Accept/Reject controls and audit trail |
| Validates nothing | Engineering rules: power equations, speed limits, unit consistency, physical plausibility |

---

## 3. Folder Structure

```
hack/
├── PROJECT_PLAN.md                  # Complete technical proposal (20 sections)
├── README.md                        # This file
├── DATASET_REPORT.md                # Detailed dataset sources and licenses
├── API.md                           # API documentation
├── DEPLOYMENT.md                    # Deployment guide
├── REQUIREMENTS_TRACKER.md          # Requirements coverage status
├── .env.example                     # Environment variable template
├── backend/                         # FastAPI backend
│   ├── main.py                      # App entry + seed loader
│   ├── config.py                    # Configuration
│   ├── database.py                  # SQLAlchemy setup
│   ├── models.py                    # Database models
│   ├── schemas.py                   # Pydantic schemas
│   ├── requirements.txt             # Python dependencies
│   ├── routers/                     # API route modules
│   ├── engines/                     # Intelligence engines
│   ├── services/                    # Pipeline & passport services
│   ├── data/                        # Reference data, schemas, seed data
│   └── tests/                       # Unit tests (to be added)
└── frontend/                        # React + Vite frontend
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    ├── index.html
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css
        ├── api/client.js
        ├── components/
        └── pages/
```

---

## 4. Requirements to Run This Project

### 4.1 System Prerequisites
- **Operating System**: Windows 10/11, macOS, or Linux
- **Python**: Version 3.11 or higher (https://www.python.org/downloads/)
- **Node.js**: Version 18 or higher (https://nodejs.org/)
- **npm**: Comes bundled with Node.js
- **Git**: Optional, for version control
- **Tesseract OCR** (optional): Only needed if you want local OCR fallback
  - Download from: https://github.com/UB-Mannheim/tesseract/wiki
  - Add `tesseract.exe` to your system PATH
- **Groq API Key** (optional): For LLM-powered extraction and enrichment
  - Get one free at: https://console.groq.com/
  - The system works in fallback/mock mode without Groq

### 4.2 Recommended Machine Specs
- RAM: 8 GB or more (16 GB recommended for local sentence-transformers)
- Disk: 5 GB free space
- Internet: Required only for Groq API calls and optional model downloads

---

## 5. Step-by-Step Setup and Run Instructions

### Step 1: Clone or Extract the Project

If you downloaded this as a ZIP, extract it to a folder. If using Git:
```bash
cd C:\Users\Manya_V\hack
# or wherever the project is located
```

### Step 2: Configure Environment Variables

1. Copy the example environment file:
   ```bash
   copy .env.example .env
   ```
   On Linux/macOS:
   ```bash
   cp .env.example .env
   ```

2. Open `.env` in any text editor and fill in:
   ```env
   GROQ_API_KEY=your_groq_api_key_here      # Optional, leave blank for fallback mode
   DATABASE_URL=sqlite:///./intellispec.db # Default SQLite DB path
   ENVIRONMENT=development
   ```

   If you do **not** have a Groq API key, the system will operate in fallback mode using deterministic extraction, rule-based enrichment, and cached demo data.

### Step 3: Set Up the Python Backend

1. Open a terminal and navigate to the backend folder:
   ```bash
   cd backend
   ```

2. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   ```
   On Windows:
   ```bash
   venv\Scripts\activate
   ```
   On Linux/macOS:
   ```bash
   source venv/bin/activate
   ```

3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```
   This installs FastAPI, SQLAlchemy, Groq client, PyMuPDF, Pint, sentence-transformers, etc.

4. (Optional) Download the sentence-transformers embedding model locally:
   ```bash
   python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')"
   ```
   This downloads ~80 MB of model weights. It only needs to run once.

### Step 4: Start the Backend Server

From the `backend` folder with the virtual environment activated:
```bash
python main.py
```

You should see output similar to:
```
INFO:     Started server process [12345]
INFO:     Uvicorn running on http://0.0.0.0:8000
```

The API will be available at:
- http://localhost:8000
- API docs: http://localhost:8000/docs
- Health check: http://localhost:8000/api/v1/health

### Step 5: Set Up the React Frontend

1. Open a **new terminal** (keep the backend running) and navigate to the frontend folder:
   ```bash
   cd frontend
   ```

2. Install Node dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. The frontend will open at http://localhost:5173 and is already configured to proxy API calls to the backend.

### Step 6: Verify the Application

1. Open your browser to http://localhost:5173
2. The Dashboard will show system health and statistics
3. Go to **Product Analyzer** and upload one of the sample inputs or an image/PDF
4. Check the validation, standards, and replacement pages

---

## 6. How to Use the Demo

### 6.1 Quick Demo with Seed Data

To load the curated demo products into the database:

1. Make sure the backend dependencies are installed and virtual environment activated
2. Run the seed script from the `backend` folder:
   ```bash
   python scripts/seed_demo.py
   ```
3. Restart the backend server:
   ```bash
   python main.py
   ```
4. Open http://localhost:5173 and navigate to the Catalog to see demo products

### 6.2 Download IndustryBench-MIPU (Optional, for Evaluation)

To download the full IndustryBench-MIPU dataset for accuracy evaluation:

```bash
python scripts/download_industrybench.py
```

This requires `pip install datasets` and downloads the dataset to `backend/data/datasets/IndustryBench-MIPU/`.

### 6.2 End-to-End Demo Scenario

**Recommended demo flow:**

1. **Upload** the ABB motor nameplate or datasheet (or use the seed product `demo-motor-001`)
2. **Observe extraction**: Manufacturer, model, voltage, power, current, RPM, etc.
3. **Watch validation**: System checks the motor power equation `P = V × I × PF × √3`
4. **See conflict detection**: Manufacturer datasheet says 400V, distributor says 415V — both shown
5. **Review Before & After**: The original extracted value vs. the normalized/enriched value
6. **Approve or reject** enriched changes
7. **View standards matching**: UNSPSC, eCl@ss, ETIM codes (verified or unavailable)
8. **Find a replacement**: For the discontinued Siemens motor (`demo-motor-002`), see compatible alternatives
9. **Generate Product Intelligence Passport**: Export as JSON or CSV

---

## 7. Key Features

| Feature | Description |
|---|---|
| Scan & Extract | Image, PDF, CSV, manual input extraction with OCR and Groq Vision fallback |
| Engineering Validation | Deterministic Python rules for motors, bearings, pumps, valves, sensors, electrical |
| Trusted Source Scoring | Every attribute source scored by type, authority, and evidence quality |
| Before & After | Side-by-side comparison with Accept/Reject/View Evidence controls |
| Standards Matching | UNSPSC, eCl@ss, ETIM using verified reference data; no fabricated codes |
| Conflict Detection | Identifies contradictory values across sources |
| Enrichment | Fills missing attributes via deterministic rules (LLM optional) |
| Replacement Finder | Technical compatibility scoring, not text similarity |
| Product Intelligence Passport | Complete structured record with evidence, validation, standards, and export |

---

## 8. Technology Stack Justification

| Component | Choice | Why |
|---|---|---|
| Backend | FastAPI (Python) | High dev speed, async support, auto-generated docs, strong Python ML ecosystem |
| Frontend | React + Vite + TailwindCSS | Component ecosystem, fast builds, professional engineering UI |
| Database | SQLite via SQLAlchemy | Zero setup, easy to swap to PostgreSQL later |
| LLM | Groq API | Fast inference, low cost, good for hackathon |
| OCR | Groq Vision + Tesseract fallback | Tesseract works offline for fallback |
| Embeddings | sentence-transformers (all-MiniLM-L6-v2) | Local, no API cost, suitable for standards similarity |
| Unit handling | Pint | Deterministic unit conversions |

---

## 9. API Quick Reference

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/v1/products` | GET/POST | List / create products |
| `/api/v1/products/upload` | POST | Upload image/PDF/CSV |
| `/api/v1/products/{id}` | GET/PUT/DELETE | Product CRUD |
| `/api/v1/products/{id}/process` | POST | Run full intelligence pipeline |
| `/api/v1/products/{id}/validation` | GET/POST | Get / run validation |
| `/api/v1/products/{id}/standards` | GET/POST | Get / run standards matching |
| `/api/v1/products/{id}/replacements` | GET | Find replacement parts |
| `/api/v1/products/{id}/passport` | GET | Product Intelligence Passport |
| `/api/v1/products/{id}/export` | GET | Export JSON or CSV |
| `/api/v1/catalog` | GET | Browse catalog with filters |
| `/api/v1/catalog/stats` | GET | Dashboard statistics |
| `/api/v1/health` | GET | Health and Groq availability |

Full API documentation is automatically generated by FastAPI at `/docs`.

---

## 10. Architecture Highlights

```
Input Layer → Extraction Engine → Identification → Normalization → Enrichment
    → Evidence & Confidence → Conflict Detection → Engineering Validation
    → Standards Matching → Confidence Calculation → Explainability
    → Human Review (Before/After) → Replacement Finder → Product Passport
```

- **No LLM for calculations**: All unit conversions, power equations, speed checks, and confidence scores are deterministic Python.
- **Evidence-first**: Every attribute stores its original value, source, trust score, extraction method, and validation status.
- **Honest standards**: If a classification cannot be verified, the system explicitly says `unavailable`.
- **Scalable architecture**: Same code works for 1 product or 100,000 products; database can be swapped to PostgreSQL by changing one connection string.

---

## 11. Datasets and Data Sources

All dataset sources, licenses, and URLs are documented in **DATASET_REPORT.md**.

Summary:
- **IndustryBench-MIPU** on Hugging Face (MIT license) — evaluation and image extraction benchmark
- **UNSPSC** reference codes (free public download from UNDP)
- **eCl@ss** representative hierarchy (publicly searchable basic content)
- **ETIM** reference codes (Open Data Commons Attribution License, free)
- Curated prototype data compiled from public manufacturer specifications, clearly labeled
- Synthetic conflict scenarios, clearly labeled as `SYNTHETIC`

---

## 12. Future Enhancements

1. **PostgreSQL Migration**: Replace SQLite with PostgreSQL for production-scale catalogs
2. **Redis Caching**: Cache LLM responses, standards lookups, and embeddings
3. **Async Worker Queue**: Use Celery/RQ for batch processing of large catalogs
4. **Fine-tuned OCR**: Train/fine-tune LayoutLM or Donut on industrial nameplate images
5. **Real-time WebSocket Pipeline**: Show live pipeline progress in the UI
6. **Advanced Standards API**: Integrate official eCl@ss and ETIM web services with authentication
7. **Image Upload Evaluation**: Run IndustryBench-MIPU benchmark and report real accuracy metrics
8. **Multi-language Support**: Extract and normalize non-English industrial catalogs
9. **User Authentication**: Add role-based approvals for data stewards and engineers
10. **Cloud Deployment**: Docker container and Render/Railway/AWSEC2 deployment templates
11. **PDF Layout Understanding**: Use multimodal models to understand specification tables
12. **Explainable Graph**: Visual evidence-chain graph in the frontend

---

## 13. Troubleshooting

### `python not found`
- Install Python 3.11+ and check `python --version`
- On Windows, you may need to use `py -3.11` instead of `python`

### `pip install` fails
- Ensure you have a virtual environment activated
- Upgrade pip: `python -m pip install --upgrade pip`
- On Windows, install Visual C++ build tools if some packages fail to compile

### `npm install` fails
- Ensure Node.js 18+ is installed: `node -v`
- Delete `node_modules` and `package-lock.json`, then run `npm install` again

### Backend cannot find modules
- Make sure you run `python main.py` from the `backend` folder
- The `backend` folder should be at the project root level

### Groq API errors
- The system falls back to deterministic extraction and enrichment if `GROQ_API_KEY` is missing or invalid
- You do not need Groq to demonstrate the core platform

### CORS errors in browser
- The backend is configured to allow `http://localhost:5173` and `http://localhost:3000`
- If your frontend runs on a different port, add it to `backend/main.py` in the CORS middleware

---

## 14. License and Attribution

This is a student hackathon prototype. It uses open-source libraries and publicly available datasets. See `DATASET_REPORT.md` for full attribution of datasets and standards reference data.

---

## 15. Contact and Support

For questions, refer to:
- `PROJECT_PLAN.md` for the complete technical design
- `API.md` for endpoint details
- `DEPLOYMENT.md` for production deployment
- `DATASET_REPORT.md` for data provenance

Built for the AI-Powered Product Intelligence for Industrial Commerce hackathon.
