# API Documentation — IntelliSpec

**Base URL:** `http://localhost:8000/api/v1`

FastAPI auto-generates interactive docs at `http://localhost:8000/docs`.

---

## Authentication

The prototype does not require API authentication. In a production deployment, JWT or API-key authentication should be added.

---

## Products

### `GET /api/v1/products`
List all products with pagination and filters.

**Query parameters:**
- `page` (int, default: 1)
- `per_page` (int, default: 20)
- `category` (string, optional)
- `status` (string, optional)
- `min_confidence` (float, optional)
- `search` (string, optional) — searches name, manufacturer, model

**Response:**
```json
{
  "products": [...],
  "total": 10,
  "page": 1,
  "per_page": 20
}
```

### `POST /api/v1/products`
Create a product manually.

**Body:**
```json
{
  "name": "ABB Motor M3BP",
  "manufacturer": "ABB",
  "model_number": "M3BP 132SMB 4",
  "part_number": "3GBP132320-ADL",
  "category": "motors",
  "description": "Three-phase induction motor"
}
```

### `POST /api/v1/products/upload`
Upload an image, PDF, or CSV for extraction and full pipeline processing.

**Form data:**
- `file` (binary)
- `source_type` (string, default: `nameplate`)

**Response:**
```json
{
  "product_id": "uuid",
  "status": "completed",
  "stages": {...},
  "overall_confidence": 0.87,
  "product": {...}
}
```

### `POST /api/v1/products/bulk-upload`
Upload a CSV catalog with multiple products.

**Form data:**
- `file` (binary CSV)

### `GET /api/v1/products/{product_id}`
Get product details.

### `PUT /api/v1/products/{product_id}`
Update product identity.

### `DELETE /api/v1/products/{product_id}`
Delete a product.

### `POST /api/v1/products/{product_id}/process`
Re-run the full intelligence pipeline for a product.

### `GET /api/v1/products/{product_id}/before-after`
Get the Before & After comparison with evidence.

### `POST /api/v1/products/{product_id}/attributes/{attr_id}/approve`
Approve an enriched attribute.

### `POST /api/v1/products/{product_id}/attributes/{attr_id}/reject`
Reject an enriched attribute.

---

## Validation

### `GET /api/v1/products/{product_id}/validation`
Get validation results for a product.

### `POST /api/v1/products/{product_id}/validation`
Re-run engineering validation rules.

### `GET /api/v1/products/{product_id}/validation/summary`
Get a summary count of valid/warning/conflict results.

---

## Standards

### `GET /api/v1/products/{product_id}/standards`
Get standards matches for a product.

### `POST /api/v1/products/{product_id}/match-standards`
Run standards matching against UNSPSC, eCl@ss, and ETIM.

### `GET /api/v1/standards/search`
Search the standards reference database.

**Query parameters:**
- `q` (required) — search text
- `standard_type` (optional) — `unspsc`, `eclass`, or `etim`

---

## Replacement Parts

### `GET /api/v1/products/{product_id}/replacements`
Find replacement parts for a product.

**Query parameters:**
- `top_n` (int, default: 5, max: 20)

**Response:**
```json
{
  "product_id": "uuid",
  "category": "motors",
  "replacements": [
    {
      "replacement_product_id": "...",
      "compatibility_score": 0.95,
      "matched_attributes": [...],
      "mismatched_attributes": [...],
      "critical_differences": [...],
      "recommendation_reason": "Same voltage, power, and mounting."
    }
  ]
}
```

### `GET /api/v1/products/{product_id}/replacements/{replacement_id}/compare`
Compare original product with a specific replacement.

---

## Catalog

### `GET /api/v1/catalog`
Browse the catalog with filters.

**Query parameters:** same as `/products` plus `validation_status`.

### `GET /api/v1/catalog/stats`
Get dashboard statistics.

### `GET /api/v1/catalog/export`
Export catalog as JSON or CSV.

**Query parameters:**
- `format` (required): `json` or `csv`

### `GET /api/v1/catalog/compare`
Compare multiple products side-by-side.

**Query parameters:**
- `product_ids` (array of strings, repeated)

---

## Passport & Export

### `GET /api/v1/products/{product_id}/passport`
Generate the complete Product Intelligence Passport.

### `GET /api/v1/products/{product_id}/export?format=json`
Export a product as JSON.

### `GET /api/v1/products/{product_id}/export?format=csv`
Export a product as CSV.

### `POST /api/v1/catalog/export`
Export selected products as JSON or CSV.

**Body:**
```json
{
  "product_ids": ["uuid1", "uuid2"],
  "format": "csv"
}
```

---

## System

### `GET /api/v1/health`
Health check and Groq API availability.

### `GET /api/v1/categories`
List available product category schemas.

### `GET /api/v1/categories/{category}/schema`
Get the attribute schema for a category.
