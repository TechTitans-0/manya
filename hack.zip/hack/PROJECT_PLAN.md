# PROJECT PLAN: AI-Powered Industrial Product Intelligence Platform

## Project Name: **IntelliSpec** — Evidence-Driven Industrial Product Intelligence Engine

---

## 1. Complete Technical Proposal

### Problem Statement
Industrial companies manage vast product information scattered across nameplates, catalogs, PDFs, datasheets, and websites. Converting this into accurate, structured, commerce-ready data is time-consuming and error-prone. The challenge: build an AI-powered solution that transforms limited product information into rich, reliable, and commerce-ready product intelligence with emphasis on data enrichment, validation, and explainable outputs.

### Real Technical Challenge
The real challenge is NOT extraction (OCR/PDF parsing is well-solved). The challenge is:
1. **Trust**: Can the extracted data be trusted? What's the evidence?
2. **Completeness**: What's missing and how critical is it?
3. **Consistency**: Do values from different sources agree? Are they physically plausible?
4. **Standards**: Does this product map to real industry classification standards?
5. **Explainability**: Can every AI decision be traced to evidence?
6. **Replacements**: Can technically compatible alternatives be found based on engineering compatibility?

### Core Innovation
IntelliSpec is an **evidence-driven product intelligence engine** that doesn't just extract — it builds a trustworthy product record from scattered evidence by enriching, validating, standardizing, explaining, and verifying information before making it commerce-ready.

---

## 2. Unique Value Proposition & Innovation

### Common Hackathon Solutions & Their Weaknesses

| Common Solution | Approach | Weaknesses |
|---|---|---|
| PDF-to-JSON extractor | Upload PDF → parse → JSON | No validation, no enrichment, no standards, no trust scoring, no replacement finding |
| OCR-to-JSON pipeline | Image → OCR → structured output | Trusts OCR blindly, no cross-validation, no engineering checks |
| LLM product chatbot | Chat with product docs | No structured output, hallucination risk, no evidence tracking |
| Product recommendation | Text similarity matching | No technical compatibility, no attribute-level comparison |
| Dashboard with charts | Visualize product data | No intelligence — just visualization of existing data |

### How IntelliSpec Is Different

| Dimension | Generic Solutions | IntelliSpec |
|---|---|---|
| Data Trust | Assumes extracted data is correct | Every attribute has a source, evidence chain, and confidence score |
| Validation | None or LLM-based guessing | Deterministic Python engineering rules (unit checks, physics constraints, format validation) |
| Standards | LLM-hallucinated codes | Verified lookup against real UNSPSC/eCl@ss/ETIM reference data; says "unavailable" if not found |
| Enrichment | LLM generates missing data | Multi-source evidence retrieval with conflict detection |
| Explainability | Black-box AI output | Every decision has a traceable reason backed by stored evidence |
| Replacements | Text similarity | Technical attribute-level compatibility scoring with critical difference identification |
| Human Control | Auto-overwrites data | Before/After comparison with Accept/Reject/View Evidence |

### Unique Value Proposition
> "IntelliSpec doesn't just extract product data — it builds trustworthy product intelligence by validating every specification against engineering rules, tracking evidence from every source, matching to real industry standards, and explaining every decision before making data commerce-ready."

### Strongest Demo Moments
1. **Conflict Detection**: Upload a motor nameplate showing 400V, but the manufacturer datasheet says 415V — system detects the conflict, shows evidence from both sources, recommends the higher-trust source with explanation
2. **Engineering Validation**: System detects that a motor claims 10kW power but lists only 5A current at 415V (P ≠ V×I×PF) — flags as physically impossible with calculation shown
3. **Before/After Intelligence**: Show the raw extracted data vs. the enriched, validated, standards-matched Product Intelligence Passport with every change explained and traceable

---

## 3. System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         INTELLISPEC PLATFORM                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                    INPUT LAYER                                │   │
│  │  Image/Nameplate │ PDF │ CSV │ Manual │ URL │ Catalog Upload  │   │
│  └──────────────────────┬───────────────────────────────────────┘   │
│                         │                                           │
│  ┌──────────────────────▼───────────────────────────────────────┐   │
│  │               EXTRACTION ENGINE                               │   │
│  │  OCR (Tesseract) │ PDF Parser (PyMuPDF) │ CSV Parser          │   │
│  │  Groq Vision (multimodal) │ Manual Input Parser               │   │
│  └──────────────────────┬───────────────────────────────────────┘   │
│                         │                                           │
│  ┌──────────────────────▼───────────────────────────────────────┐   │
│  │            PRODUCT IDENTIFICATION & CATEGORIZATION            │   │
│  │  Groq LLM → Category Detection → Dynamic Attribute Schema    │   │
│  └──────────────────────┬───────────────────────────────────────┘   │
│                         │                                           │
│  ┌──────────────────────▼───────────────────────────────────────┐   │
│  │          ATTRIBUTE DISCOVERY & NORMALIZATION                   │   │
│  │  Dynamic Attribute Model │ Unit Normalization (deterministic) │   │
│  │  Value Parsing │ Format Standardization                       │   │
│  └──────────────────────┬───────────────────────────────────────┘   │
│                         │                                           │
│  ┌──────────────────────▼───────────────────────────────────────┐   │
│  │              INTELLIGENCE CORE                                │   │
│  │                                                               │   │
│  │  ┌─────────────┐ ┌──────────────┐ ┌─────────────────────┐   │   │
│  │  │ Enrichment  │ │  Evidence &  │ │  Engineering        │   │   │
│  │  │ Engine      │ │  Confidence  │ │  Validation Engine  │   │   │
│  │  │             │ │  Engine      │ │  (Deterministic)    │   │   │
│  │  └─────────────┘ └──────────────┘ └─────────────────────┘   │   │
│  │                                                               │   │
│  │  ┌─────────────┐ ┌──────────────┐ ┌─────────────────────┐   │   │
│  │  │ Conflict    │ │  Standards   │ │  Replacement        │   │   │
│  │  │ Detection   │ │  Matching    │ │  Part Finder        │   │   │
│  │  │ Engine      │ │  Engine      │ │                     │   │   │
│  │  └─────────────┘ └──────────────┘ └─────────────────────┘   │   │
│  │                                                               │   │
│  └──────────────────────┬───────────────────────────────────────┘   │
│                         │                                           │
│  ┌──────────────────────▼───────────────────────────────────────┐   │
│  │       HUMAN REVIEW & APPROVAL LAYER                           │   │
│  │  Before/After View │ Accept/Reject │ Evidence Panel           │   │
│  └──────────────────────┬───────────────────────────────────────┘   │
│                         │                                           │
│  ┌──────────────────────▼───────────────────────────────────────┐   │
│  │         OUTPUT LAYER                                          │   │
│  │  Product Intelligence Passport │ Catalog │ JSON/CSV/PDF Export│   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                    DATA LAYER                                 │   │
│  │  SQLite/PostgreSQL │ Standards Reference DB │ Evidence Store   │   │
│  │  Product Catalog │ Audit Trail │ Cache                        │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 4. End-to-End Workflow

### Processing Pipeline (per product)

```
1. INPUT → Image/PDF/CSV/Manual data received
        ↓
2. EXTRACT → OCR/PDF parsing extracts raw text and attributes
        ↓
3. IDENTIFY → LLM identifies product type, manufacturer, model
        ↓
4. CATEGORIZE → Dynamic category detection determines relevant attribute schema
        ↓
5. DISCOVER → System determines which attributes are relevant for this category
        ↓
6. NORMALIZE → Units converted to standard forms (deterministic), values parsed
        ↓
7. ENRICH → Missing attributes filled from reference data, LLM inference
        ↓
8. EVIDENCE → Track source of every attribute, calculate source trust scores
        ↓
9. CONFLICT → Compare values from multiple sources, detect disagreements
        ↓
10. VALIDATE → Engineering rules check physical plausibility, unit consistency
        ↓
11. STANDARDS → Match to UNSPSC/eCl@ss/ETIM using verified reference data
        ↓
12. CONFIDENCE → Calculate evidence-based confidence per attribute and overall
        ↓
13. EXPLAIN → Generate human-readable explanations for every AI decision
        ↓
14. REVIEW → Present Before/After with Accept/Reject/Evidence controls
        ↓
15. REPLACEMENT → If needed, find technically compatible alternatives
        ↓
16. PASSPORT → Generate complete Product Intelligence Passport
        ↓
17. CATALOG → Add approved product to structured catalog
        ↓
18. EXPORT → JSON, CSV, PDF export of commerce-ready data
```

### Catalog-Level Processing
For bulk uploads (CSV/catalog), the system processes products in batch:
- Parse catalog file → identify individual products → queue for processing
- Process each product through the pipeline
- Aggregate results in catalog view with filtering by confidence, validation status
- Support incremental updates (reprocess individual products)

---

## 5. Features & User Journeys

### Feature 1: Scan & Extract
**User Journey**: Upload nameplate image → OCR extracts text → LLM identifies structured attributes → Display extracted data with source markers
- Accepts: Images (JPG/PNG), PDFs, CSV files, manual input
- Extracts: Manufacturer, model, part number, specifications, units, ratings, dimensions
- Every extracted value tagged with source type and extraction confidence

### Feature 2: Engineering Validation Engine
**User Journey**: View extracted product → See validation results (valid/warning/conflict) → Click on any flag to see the rule and calculation
- Deterministic Python rules for:
  - Unit consistency (voltage/current/power relationships: P = V × I × PF × √3)
  - Physical plausibility (motor RPM within standard ranges, temperature ratings)
  - Format validation (part numbers, voltage formats, IP ratings)
  - Cross-attribute consistency (dimensions vs. weight, power vs. frame size)
  - Mathematical relationships (efficiency must be 0-100%, frequency = RPM × poles/120)

### Feature 3: Trusted Source Scoring
**User Journey**: View any attribute → See source, trust score, evidence → Compare with other sources
- Source hierarchy: Manufacturer datasheet > Nameplate > Official catalog > Distributor > Unknown
- Trust score based on: source type, attribute type relevance, evidence quality, agreement with other sources
- Confidence = weighted agreement across sources, NOT random numbers

### Feature 4: Standards Matching
**User Journey**: View product → See matched UNSPSC/eCl@ss/ETIM codes → See match explanation or "unavailable" notice
- Lookup against real verified reference data
- If no match found: clearly states "classification unavailable" with reason
- Shows why a classification was selected (matched attributes, category path)

### Feature 5: Before & After Intelligence
**User Journey**: View changes → See original vs. enriched values side-by-side → Accept/Reject each change → View evidence for each change
- Every AI change tracked with: original value, new value, reason, evidence, confidence
- Human approval required for important changes
- Audit trail maintained

### Feature 6: Replacement Part Finder
**User Journey**: Mark product as discontinued → System finds alternatives → Compare compatibility scores → View matched/mismatched attributes → Select replacement
- Technical compatibility scoring based on dynamic attribute matching
- Critical attributes weighted higher (voltage, power, mounting type)
- Shows: compatibility %, matched attributes, mismatched attributes, critical differences
- Explains why each replacement is recommended

### Additional Intelligence
- **Missing Attribute Prioritization**: Critical/High/Medium/Low priority for missing attributes
- **Conflict Resolution Panel**: Shows contradictory values from different sources
- **Evidence Chain**: Trace how each final value was selected
- **Product Intelligence Passport**: Complete product record with all intelligence

---

## 6. Dataset Research & Recommendations

### Primary Dataset: IndustryBench-MIPU

| Field | Details |
|---|---|
| **Dataset Name** | IndustryBench-MIPU |
| **Platform** | Hugging Face |
| **Original Publisher** | Alibaba Multimodal Industrial AI (alibaba-multimodal-industrial-ai) |
| **Official URL** | https://huggingface.co/datasets/alibaba-multimodal-industrial-ai/IndustryBench-MIPU |
| **GitHub** | https://github.com/alibaba-multimodal-industrial-ai/IndustryBench-MIPU |
| **Paper** | https://arxiv.org/abs/2606.14383 |
| **License** | MIT License |
| **Products** | 4,481 products across 26,310 images |
| **Categories** | 18 top-level categories, 2,301 leaf categories |
| **Property Names** | 4,554 unique property names |
| **Annotations** | 95,024 product-level annotations |
| **Fields Available** | Product images, attribute schemas, property-value pairs, category hierarchy |
| **Suitability** | Excellent for evaluation of attribute extraction, provides ground truth for accuracy measurement. Covers diverse industrial categories (valves, circuit breakers, motors, pumps, etc.) |
| **Limitations** | Focused on image-based extraction; does not include multi-source evidence, standards codes, or replacement data. These must be supplemented. |
| **Usage in Project** | Evaluation benchmark for extraction accuracy; source of realistic industrial product images for demo; ground truth for precision/recall measurement |

### Standards Reference Data

#### UNSPSC (United Nations Standard Products and Services Code)
| Field | Details |
|---|---|
| **Standard Name** | UNSPSC |
| **Publisher** | United Nations Development Programme (UNDP) |
| **URL** | https://www.undp.org/unspsc |
| **Access** | Free PDF download available; Excel requires membership |
| **License** | Free to browse and download current version at no cost |
| **Coverage** | 158,448+ codes across all product/service categories |
| **Usage in Project** | Primary standards matching for product classification. We will use the publicly available segment/family/class/commodity hierarchy for industrial products (Segments 23-31 cover industrial equipment). Curated subset of relevant industrial codes stored in reference database. |

#### eCl@ss
| Field | Details |
|---|---|
| **Standard Name** | eCl@ss |
| **Publisher** | eCl@ss e.V. |
| **URL** | https://eclass.eu/en/eclass-standard/search-content |
| **Access** | Free online search/browse; full download requires license |
| **License** | Application requires license; free search available |
| **Coverage** | ~45,000 classes with properties |
| **Usage in Project** | Secondary standards matching. We will use publicly searchable classification hierarchy for demo purposes. For classes that cannot be verified against the public search, the system will state "eCl@ss classification unavailable — requires licensed data access." |

#### ETIM (European Technical Information Model)
| Field | Details |
|---|---|
| **Standard Name** | ETIM |
| **Publisher** | ETIM International |
| **URL** | https://www.etim-international.com/classification/release-policy/ |
| **Access** | Open standard, free of charge; available via ETIM API and CMT |
| **License** | Open Data Commons Attribution License (ODC-By 1.0) |
| **Coverage** | ~5,000 product classes for technical products |
| **Usage in Project** | Standards matching for electrical/electronic/technical products. ETIM's open license allows academic use. Curated subset of relevant classes stored in reference database. |

### Supplementary: Curated Prototype Dataset
We will create a small curated dataset (~50-100 products) from publicly available manufacturer datasheets and catalogs:
- **Sources**: Public product pages from ABB, Siemens, SKF, Bosch Rexroth, Parker Hannifin (publicly available technical specifications)
- **Purpose**: Demonstrate multi-source evidence, conflict detection, enrichment scenarios
- **Clearly labeled** as curated prototype data with source attribution

### Synthetic Scenarios (Clearly Labeled)
- Conflicting voltage specifications between sources (for conflict detection demo)
- Discontinued products with compatible replacements (for replacement finder demo)
- Incomplete product records (for enrichment demo)
- All synthetic data clearly marked as "SYNTHETIC — for demonstration purposes"

---

## 7. Database Schema

### Core Tables

```sql
-- Products table
CREATE TABLE products (
    id TEXT PRIMARY KEY,  -- UUID
    name TEXT,
    manufacturer TEXT,
    model_number TEXT,
    part_number TEXT,
    category TEXT,
    subcategory TEXT,
    description TEXT,
    status TEXT DEFAULT 'draft',  -- draft, processing, reviewed, approved
    processing_stage TEXT,
    overall_confidence REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product attributes (dynamic, category-independent)
CREATE TABLE product_attributes (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES products(id),
    attribute_name TEXT NOT NULL,
    raw_value TEXT,           -- Original extracted value
    normalized_value TEXT,    -- Normalized/enriched value
    approved_value TEXT,      -- Human-approved final value
    unit TEXT,
    data_type TEXT,           -- numeric, text, boolean, enum
    confidence REAL,
    validation_status TEXT,   -- valid, warning, conflict, unvalidated
    approval_status TEXT DEFAULT 'pending',  -- pending, accepted, rejected
    is_enriched BOOLEAN DEFAULT FALSE,
    is_critical BOOLEAN DEFAULT FALSE,
    priority TEXT,            -- critical, high, medium, low
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Evidence/source tracking
CREATE TABLE attribute_sources (
    id TEXT PRIMARY KEY,
    attribute_id TEXT REFERENCES product_attributes(id),
    product_id TEXT REFERENCES products(id),
    source_type TEXT,         -- nameplate, datasheet, catalog, distributor, manual_input, ai_enriched
    source_name TEXT,         -- e.g., "ABB Motor Datasheet Rev.3"
    source_url TEXT,
    source_value TEXT,        -- Value from this source
    trust_score REAL,         -- Calculated trust score (0-1)
    extraction_method TEXT,   -- ocr, pdf_parse, csv_import, llm_extract, manual
    extracted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Validation results
CREATE TABLE validation_results (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES products(id),
    attribute_id TEXT,        -- NULL if cross-attribute validation
    rule_name TEXT,
    rule_type TEXT,           -- unit_check, physics_check, format_check, cross_attribute, range_check
    status TEXT,              -- valid, warning, conflict
    message TEXT,
    details TEXT,             -- JSON with calculation details
    severity TEXT,            -- critical, warning, info
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Standards matching
CREATE TABLE standards_matches (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES products(id),
    standard_type TEXT,       -- unspsc, eclass, etim
    standard_code TEXT,
    standard_description TEXT,
    match_confidence REAL,
    match_method TEXT,        -- exact_lookup, hierarchical_match, semantic_match
    match_explanation TEXT,
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Replacement parts
CREATE TABLE replacement_parts (
    id TEXT PRIMARY KEY,
    original_product_id TEXT REFERENCES products(id),
    replacement_product_id TEXT,
    compatibility_score REAL,
    matched_attributes TEXT,   -- JSON array
    mismatched_attributes TEXT, -- JSON array
    critical_differences TEXT,  -- JSON array
    recommendation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Processing audit trail
CREATE TABLE audit_trail (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES products(id),
    attribute_id TEXT,
    action TEXT,              -- extract, enrich, validate, approve, reject, modify
    old_value TEXT,
    new_value TEXT,
    reason TEXT,
    performed_by TEXT,        -- system, user, llm
    evidence TEXT,            -- JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Standards reference data
CREATE TABLE standards_reference (
    id TEXT PRIMARY KEY,
    standard_type TEXT,       -- unspsc, eclass, etim
    code TEXT,
    level INTEGER,
    description TEXT,
    parent_code TEXT,
    keywords TEXT,            -- Comma-separated for search
    category_path TEXT,       -- Full hierarchy path
    attributes TEXT           -- JSON: expected attributes for this class
);

-- Product category schemas (dynamic attribute model)
CREATE TABLE category_schemas (
    id TEXT PRIMARY KEY,
    category TEXT UNIQUE,
    display_name TEXT,
    attributes TEXT,          -- JSON: array of {name, type, unit, required, validation_rules}
    validation_rules TEXT,    -- JSON: cross-attribute rules
    common_standards TEXT,    -- JSON: typical UNSPSC/eCl@ss codes for this category
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 8. API Design

### Base URL: `/api/v1`

### Product Endpoints
```
POST   /products                    - Create product (manual input)
POST   /products/upload             - Upload image/PDF/CSV for extraction
POST   /products/bulk-upload        - Bulk CSV catalog upload
GET    /products                    - List products (with filters)
GET    /products/{id}               - Get product details
PUT    /products/{id}               - Update product
DELETE /products/{id}               - Delete product
POST   /products/{id}/reprocess     - Reprocess product through pipeline
GET    /products/{id}/passport      - Get Product Intelligence Passport
GET    /products/{id}/export        - Export product (JSON/CSV/PDF)
```

### Processing Pipeline Endpoints
```
POST   /products/{id}/extract       - Run extraction
POST   /products/{id}/identify      - Run identification & categorization
POST   /products/{id}/normalize     - Run normalization
POST   /products/{id}/enrich        - Run enrichment
POST   /products/{id}/validate      - Run validation
POST   /products/{id}/match-standards - Run standards matching
POST   /products/{id}/calculate-confidence - Calculate confidence scores
POST   /products/{id}/process       - Run full pipeline
```

### Attributes & Evidence
```
GET    /products/{id}/attributes    - Get all attributes with evidence
PUT    /products/{id}/attributes/{attr_id} - Update attribute
POST   /products/{id}/attributes/{attr_id}/approve - Approve change
POST   /products/{id}/attributes/{attr_id}/reject  - Reject change
GET    /products/{id}/attributes/{attr_id}/evidence - Get evidence chain
GET    /products/{id}/conflicts     - Get detected conflicts
GET    /products/{id}/before-after  - Get before/after comparison
```

### Validation
```
GET    /products/{id}/validation    - Get validation results
POST   /products/{id}/validate      - Run validation
```

### Standards
```
GET    /products/{id}/standards     - Get standards matches
POST   /products/{id}/match-standards - Run standards matching
GET    /standards/search            - Search standards reference data
```

### Replacement Parts
```
GET    /products/{id}/replacements  - Find replacement parts
POST   /products/{id}/replacements/search - Search with custom criteria
GET    /products/{id}/replacements/{rep_id}/compare - Compare with replacement
```

### Catalog
```
GET    /catalog                     - Browse catalog with filters
GET    /catalog/stats               - Catalog statistics
POST   /catalog/export              - Export catalog
GET    /catalog/compare             - Compare products side-by-side
```

### System
```
GET    /health                      - Health check
GET    /categories                  - Available product categories
GET    /categories/{cat}/schema     - Get category attribute schema
```

---

## 9. UI/UX Pages & Navigation

### Navigation Structure
```
┌─────────────────────────────────────────────┐
│  IntelliSpec                                │
│  ┌──────────────────────────────────────┐   │
│  │ Dashboard │ Product Analyzer │ Catalog│   │
│  │ Validation Center │ Standards │       │   │
│  │ Replacement Finder │ Reports │ About  │   │
│  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
```

### Pages

1. **Dashboard** — Overview statistics: total products, processing status, confidence distribution, validation summary, recent activity
2. **Product Analyzer** — Main product processing page:
   - Upload panel (image/PDF/CSV/manual)
   - Processing pipeline progress indicator
   - Extracted attributes display
   - Before/After comparison panel
   - Evidence & confidence panel
3. **Data Extraction** — Detailed view of extraction results from OCR/PDF with source markers
4. **Validation Center** — All validation results across products:
   - Filter by severity (critical/warning/info)
   - Validation rule details with calculations
   - Fix suggestions
5. **Evidence & Sources** — Source tracking and trust scoring:
   - Source hierarchy visualization
   - Trust score breakdown
   - Evidence chain for each attribute
6. **Standards Matching** — Standards classification results:
   - UNSPSC/eCl@ss/ETIM matching display
   - Match confidence and explanation
   - "Unavailable" notices with reasons
7. **Review Center** — Human approval workflow:
   - Before/After comparison for all AI changes
   - Accept/Reject controls per attribute
   - Bulk approve/reject
   - Evidence panel
8. **Replacement Finder** — Replacement part search:
   - Product selection
   - Compatibility results with scores
   - Attribute-level comparison table
   - Critical differences highlighted
9. **Product Catalog** — Catalog browser:
   - Search, filter, sort
   - Confidence filtering
   - Validation status filtering
   - Product comparison view
10. **Product Intelligence Passport** — Complete product record:
    - All sections: Identity, Specs, Classification, Evidence, Validation, Conflicts, Missing Data, Replacements, Approval Status
    - Export controls (JSON/CSV/PDF)
11. **Reports** — Analytics and accuracy metrics
12. **About/Settings** — System info, API key config

### User Journey Flow
```
Dashboard → Product Analyzer (Upload) → Extraction View → 
Validation Center → Evidence & Sources → Standards Matching → 
Review Center (Approve/Reject) → Replacement Finder (if needed) → 
Product Intelligence Passport → Catalog → Export
```

---

## 10. AI/ML Approach

### LLM Usage (Groq API)
- **Model**: llama-3.3-70b-versatile (via Groq)
- **Used for**:
  - Product identification and categorization from raw text
  - Attribute extraction from unstructured text
  - Semantic interpretation (understanding technical descriptions)
  - Enrichment reasoning (inferring missing attributes from context)
  - Conflict resolution explanation generation
  - Natural language explanation generation
- **NOT used for**:
  - Unit conversions (deterministic Python)
  - Mathematical calculations (deterministic Python)
  - Validation rule checks (deterministic Python)
  - Confidence score calculation (deterministic formula)
  - Standards code lookup (database query)
  - Compatibility scoring (deterministic algorithm)

### Groq Vision (Multimodal)
- **Model**: llama-3.2-90b-vision-preview or meta-llama/llama-4-scout-17b-16e-instruct (via Groq)
- **Used for**: Extracting text and attributes from nameplate/label images
- **Fallback**: Tesseract OCR if vision API unavailable

### Embeddings (Local)
- **Model**: all-MiniLM-L6-v2 (sentence-transformers, runs locally)
- **Used for**:
  - Product category matching
  - Standards code semantic search
  - Replacement part similarity search
  - Attribute name normalization

### Mock/Fallback Mode
- If Groq API is unavailable, system falls back to:
  - Tesseract OCR for images
  - Rule-based extraction patterns (regex)
  - Cached LLM responses for demo products
  - Pre-computed enrichment data

---

## 11. Validation, Confidence, Evidence & Explainability Engine

### Engineering Validation Rules (Deterministic Python)

#### Universal Rules (All Categories)
- Unit format validation (kW, V, A, RPM, kg, mm, °C, etc.)
- Numeric range plausibility (no negative power, weight > 0)
- Temperature range checks (-273°C minimum)
- IP rating format (IP + 2 digits, valid ranges 0-6, 0-9)
- Weight/dimension consistency

#### Category-Specific Rules (Dynamically Applied)
**Motors:**
- P = V × I × PF × √3 (3-phase) or P = V × I × PF (1-phase)
- RPM must be submultiple of sync speed: 120 × f / poles
- Efficiency: 0% < η ≤ 100%
- Frame size vs. power range consistency
- Frequency: 50Hz or 60Hz standard values

**Bearings:**
- Inner diameter < Outer diameter
- Width > 0 and proportional to diameter
- Dynamic load rating > Static load rating (typically)
- Speed rating consistency with type

**Pumps:**
- Flow rate × head × SG / (3960 × efficiency) ≈ power (imperial)
- Suction head < discharge head
- NPSH requirements consistency

**Electrical Components:**
- Voltage rating consistency with standard voltages
- Current rating vs. wire gauge compatibility
- Breaking capacity > rated current

### Confidence Calculation (Evidence-Based)

```python
confidence = (
    source_trust_weight × source_trust_score +
    agreement_weight × agreement_score +
    validation_weight × validation_score +
    completeness_weight × completeness_score
) / total_weight

# Where:
# source_trust_score: Based on source hierarchy (0-1)
# agreement_score: % of sources agreeing on this value
# validation_score: 1.0 if passes all rules, reduced per failure
# completeness_score: % of evidence fields filled
```

### Source Trust Hierarchy
```
Manufacturer Datasheet:  0.95
Product Nameplate:       0.90
Official Catalog:        0.85
Authorized Distributor:  0.75
Third-party Source:      0.60
AI Enrichment:           0.50
Unknown Source:          0.30
```

### Explainability Architecture
Every AI decision stored with:
```json
{
  "attribute": "voltage",
  "final_value": "415V",
  "original_value": "400V",
  "reason": "Manufacturer datasheet (trust: 0.95) and nameplate (trust: 0.90) both indicate 415V. Distributor listing shows 400V (trust: 0.75). Higher-trust sources agree on 415V.",
  "evidence": [
    {"source": "ABB Datasheet Rev.3", "value": "415V", "trust": 0.95},
    {"source": "Nameplate OCR", "value": "415V", "trust": 0.90},
    {"source": "RS Components listing", "value": "400V", "trust": 0.75}
  ],
  "confidence": 0.91,
  "decision_method": "highest_trust_agreement"
}
```

---

## 12. Standards-Matching Strategy

### Approach: Verified Lookup + Semantic Fallback

#### Step 1: Category-Based Lookup
- Identify product category → Look up common UNSPSC/eCl@ss/ETIM codes for that category
- Use reference database of curated industrial codes

#### Step 2: Keyword Matching
- Extract key terms from product name, category, attributes
- Match against standards descriptions using text search

#### Step 3: Semantic Matching (Embeddings)
- If no exact match, use sentence embeddings to find closest standard code
- Only accept if similarity score > threshold (0.75)
- Below threshold → report "classification unavailable"

#### Step 4: Verification
- Cross-check that matched code's expected attributes align with product attributes
- If mismatch → reduce confidence or report unavailable

#### Honesty Policy
- If exact match found and verified: Show code with high confidence
- If semantic match only: Show code with medium confidence + explanation
- If no reliable match: **Explicitly state "Classification unavailable"** with reason
- **NEVER fabricate a standards code**

---

## 13. Replacement-Part Recommendation Engine

### Algorithm

```
1. IDENTIFY critical attributes for the product category
   (e.g., for motors: voltage, power, RPM, mounting, frame size, frequency)

2. SEARCH catalog for products in same category

3. SCORE compatibility for each candidate:
   For each attribute:
     - If critical attribute matches exactly: +weight × 1.0
     - If critical attribute matches within tolerance: +weight × 0.8
     - If critical attribute doesn't match: +weight × 0.0
     - If non-critical attribute matches: +bonus

4. RANK by compatibility score

5. IDENTIFY critical differences (attributes that don't match)

6. EXPLAIN why each replacement is recommended:
   - "Same voltage (415V), same power (7.5kW), same mounting (B3).
      Frame size differs: original IE2 132M, replacement IE3 132S.
      Physical dimensions compatible. Higher efficiency class."
```

### Compatibility Scoring Formula
```python
compatibility_score = sum(
    attribute_weight[attr] * match_score(original[attr], candidate[attr])
    for attr in category_attributes
) / sum(attribute_weight.values())

# match_score returns:
# 1.0 for exact match
# 0.5-0.9 for within-tolerance match (e.g., 7.5kW vs 7.4kW)
# 0.0 for mismatch
```

---

## 14. Scalability & Performance Strategy

### Processing Optimization
| Strategy | Implementation |
|---|---|
| Selective LLM calls | Only use LLM for extraction, categorization, explanation — NOT for calculations |
| Caching | Cache LLM responses by input hash; cache standards lookups |
| Batch processing | Process CSV uploads in batches; batch LLM calls where possible |
| Database indexing | Index on product_id, category, standard_code, confidence |
| Incremental updates | Reprocess only changed attributes, not entire product |
| Preprocessing | Normalize units, validate formats before LLM calls |
| Embedding precomputation | Pre-compute embeddings for standards reference data |

### Performance Targets (Prototype)
| Metric | Target |
|---|---|
| Single product processing | < 30 seconds (including LLM calls) |
| OCR extraction | < 5 seconds per image |
| Validation rules | < 100ms (deterministic) |
| Standards matching | < 500ms (database lookup + embedding) |
| Batch processing (100 products) | < 15 minutes |
| API response time | < 200ms for reads, < 2s for processing triggers |

### Scalability Path
```
Prototype (Now):     SQLite, single server, <1000 products
Small Catalog:       PostgreSQL, same architecture, <10,000 products
Medium Catalog:      Add Redis caching, async workers, <100,000 products
Large Catalog:       PostgreSQL cluster, worker pool, embedding index, <1M products
```
The architecture supports this progression WITHOUT redesign — same models, same APIs, same pipeline.

---

## 15. Accuracy Evaluation Methodology

### Metrics

| Metric | What It Measures | How Calculated |
|---|---|---|
| Attribute Extraction Accuracy | Correct attributes extracted from source | Extracted ∩ Ground Truth / Ground Truth |
| Precision | Of extracted attributes, how many are correct | True Positives / (True Positives + False Positives) |
| Recall | Of actual attributes, how many were extracted | True Positives / (True Positives + False Negatives) |
| F1-Score | Harmonic mean of Precision and Recall | 2 × P × R / (P + R) |
| Classification Accuracy | Correct UNSPSC/eCl@ss code assignment | Correct Codes / Total Attempted |
| Normalization Accuracy | Values correctly normalized to standard units | Correct Normalizations / Total |
| Conflict Detection Rate | Conflicts correctly identified | Detected Conflicts / Actual Conflicts |
| Validation Accuracy | Correct validation results | (True Valid + True Invalid) / Total |
| Replacement Ranking Accuracy | Correct replacement ranked in top-3 | Correct in Top-3 / Total Replacements |
| Hallucination Rate | Attributes invented without evidence | Unsupported Claims / Total Claims |

### Evaluation Process
1. Use IndustryBench-MIPU ground truth for extraction accuracy
2. Create manual ground truth for 20-30 curated products
3. Run system on ground truth products
4. Compare system output vs. ground truth
5. Calculate metrics
6. Report actual numbers — DO NOT claim arbitrary percentages

### Anti-Hallucination Measures
- Confidence threshold: attributes below 0.3 confidence marked as "insufficient evidence"
- Source requirement: attributes without any source marked as "unverified"
- Validation gate: attributes failing engineering rules flagged, not silently accepted

---

## 16. Technology Comparison & Final Stack Selection

### Backend Framework Comparison

| Criteria | FastAPI (Python) | Flask (Python) | Express (Node.js) | Spring Boot (Java) |
|---|---|---|---|---|
| Development Speed | ★★★★★ | ★★★★ | ★★★★ | ★★★ |
| Performance | ★★★★ | ★★★ | ★★★★ | ★★★★★ |
| ML/AI Integration | ★★★★★ | ★★★★★ | ★★ | ★★★ |
| Async Support | ★★★★★ | ★★ | ★★★★★ | ★★★★ |
| Documentation | ★★★★★ | ★★★★ | ★★★★ | ★★★★ |
| Student Feasibility | ★★★★★ | ★★★★★ | ★★★★ | ★★★ |
| **Selected** | ✅ | | | |

**Rationale**: FastAPI offers the best balance of development speed, async support, automatic API documentation, and seamless Python ML/AI library integration.

### Frontend Framework Comparison

| Criteria | React + Vite | Vue.js | Streamlit | Next.js |
|---|---|---|---|---|
| Component Ecosystem | ★★★★★ | ★★★★ | ★★ | ★★★★★ |
| Customization | ★★★★★ | ★★★★★ | ★★ | ★★★★★ |
| Performance | ★★★★★ | ★★★★ | ★★ | ★★★★ |
| Professional UI | ★★★★★ | ★★★★ | ★★★ | ★★★★★ |
| Student Feasibility | ★★★★ | ★★★★ | ★★★★★ | ★★★ |
| **Selected** | ✅ | | | |

**Rationale**: React provides the component ecosystem needed for complex data-intensive UIs (evidence panels, comparison views, approval workflows). Vite for fast builds. TailwindCSS for utility-first styling. Streamlit is too limited for the complex UI needed here.

### Database Comparison

| Criteria | SQLite | PostgreSQL | MongoDB |
|---|---|---|---|
| Setup Complexity | ★★★★★ | ★★★ | ★★★ |
| JSON Support | ★★★ | ★★★★★ | ★★★★★ |
| Scalability | ★★ | ★★★★★ | ★★★★ |
| Indexing | ★★★ | ★★★★★ | ★★★★ |
| Hackathon Reliability | ★★★★★ | ★★★★ | ★★★ |
| **Selected** | ✅ (via SQLAlchemy, swappable) | | |

**Rationale**: SQLite requires zero setup (no separate database server), works everywhere, and via SQLAlchemy can be swapped to PostgreSQL by changing one connection string. Perfect for hackathon demo while demonstrating scalability-ready architecture.

### Final Technology Stack

| Component | Technology | Purpose |
|---|---|---|
| Backend Framework | **FastAPI** (Python 3.11+) | REST API, async processing |
| Frontend | **React 18** + Vite + TailwindCSS | Professional UI |
| Database | **SQLite** via SQLAlchemy | Product data, evidence, standards |
| LLM API | **Groq** (llama-3.3-70b-versatile) | Extraction, categorization, explanation |
| Vision/OCR | **Groq Vision** + Tesseract fallback | Image/nameplate extraction |
| Embeddings | **sentence-transformers** (all-MiniLM-L6-v2) | Similarity search, standards matching |
| PDF Parsing | **PyMuPDF** (fitz) | PDF text/table extraction |
| Unit Handling | **Pint** (Python) | Deterministic unit conversions |
| Validation | Custom Python rules engine | Engineering validation |
| Export | **ReportLab** (PDF), json, csv | Document generation |

---

## 17. Folder Structure

```
hack/
├── PROJECT_PLAN.md
├── REQUIREMENTS_TRACKER.md
├── README.md
├── backend/
│   ├── main.py                      # FastAPI application entry
│   ├── requirements.txt
│   ├── config.py                    # Configuration & env vars
│   ├── database.py                  # Database setup & connection
│   ├── models.py                    # SQLAlchemy models
│   ├── schemas.py                   # Pydantic schemas
│   ├── routers/
│   │   ├── products.py              # Product CRUD & upload
│   │   ├── processing.py           # Pipeline processing endpoints
│   │   ├── validation.py           # Validation endpoints
│   │   ├── standards.py            # Standards matching endpoints
│   │   ├── replacements.py         # Replacement finder endpoints
│   │   ├── catalog.py              # Catalog browsing endpoints
│   │   └── export.py               # Export endpoints
│   ├── engines/
│   │   ├── extraction.py           # OCR, PDF, CSV extraction
│   │   ├── identification.py       # Product identification & categorization
│   │   ├── normalization.py        # Unit normalization & value parsing
│   │   ├── enrichment.py           # Attribute enrichment
│   │   ├── validation_engine.py    # Engineering validation rules
│   │   ├── evidence.py             # Evidence & confidence scoring
│   │   ├── standards_matching.py   # Standards matching engine
│   │   ├── conflict_detection.py   # Conflict detection
│   │   ├── replacement_finder.py   # Replacement part algorithm
│   │   └── explainability.py       # Explanation generation
│   ├── services/
│   │   ├── groq_service.py         # Groq API integration
│   │   ├── pipeline.py             # Full processing pipeline orchestrator
│   │   └── passport.py             # Product Intelligence Passport generator
│   ├── data/
│   │   ├── standards/
│   │   │   ├── unspsc_reference.json
│   │   │   ├── eclass_reference.json
│   │   │   └── etim_reference.json
│   │   ├── category_schemas/
│   │   │   ├── motors.json
│   │   │   ├── bearings.json
│   │   │   ├── pumps.json
│   │   │   ├── valves.json
│   │   │   ├── sensors.json
│   │   │   └── electrical.json
│   │   ├── seed_products/
│   │   │   └── demo_products.json
│   │   └── sample_inputs/
│   │       ├── motor_nameplate.jpg
│   │       └── sample_catalog.csv
│   └── tests/
│       ├── test_validation.py
│       ├── test_normalization.py
│       └── test_confidence.py
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── index.html
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx
│   │   ├── api/
│   │   │   └── client.js            # API client
│   │   ├── components/
│   │   │   ├── Layout.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   ├── ConfidenceBadge.jsx
│   │   │   ├── ValidationStatus.jsx
│   │   │   ├── EvidencePanel.jsx
│   │   │   ├── BeforeAfterCard.jsx
│   │   │   ├── AttributeTable.jsx
│   │   │   ├── UploadPanel.jsx
│   │   │   ├── ProcessingPipeline.jsx
│   │   │   └── ComparisonView.jsx
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── ProductAnalyzer.jsx
│   │   │   ├── ValidationCenter.jsx
│   │   │   ├── EvidenceSources.jsx
│   │   │   ├── StandardsMatching.jsx
│   │   │   ├── ReviewCenter.jsx
│   │   │   ├── ReplacementFinder.jsx
│   │   │   ├── ProductCatalog.jsx
│   │   │   ├── ProductPassport.jsx
│   │   │   └── Reports.jsx
│   │   └── utils/
│   │       └── formatters.js
│   └── public/
└── .env.example
```

---

## 18. Detailed Implementation Roadmap

### Phase 1: Foundation (Core Backend)
1. Set up project structure
2. Create database models and migration
3. Build FastAPI application skeleton
4. Implement Groq API integration with fallback
5. Seed standards reference data

### Phase 2: Intelligence Engines
6. Build Extraction Engine (OCR + PDF + CSV + manual)
7. Build Product Identification & Categorization
8. Build Dynamic Attribute Schema system
9. Build Normalization Engine
10. Build Enrichment Engine
11. Build Evidence & Confidence Engine
12. Build Engineering Validation Engine
13. Build Conflict Detection Engine
14. Build Standards Matching Engine
15. Build Replacement Part Finder
16. Build Explainability Engine
17. Build Pipeline Orchestrator

### Phase 3: API Layer
18. Build Product CRUD endpoints
19. Build Processing endpoints
20. Build Validation endpoints
21. Build Standards endpoints
22. Build Replacement endpoints
23. Build Catalog endpoints
24. Build Export endpoints (JSON, CSV, PDF)

### Phase 4: Frontend
25. Set up React + Vite + TailwindCSS
26. Build Layout & Navigation
27. Build Dashboard page
28. Build Product Analyzer page (upload + processing)
29. Build Validation Center page
30. Build Evidence & Sources page
31. Build Standards Matching page
32. Build Review Center page (Before/After + Approve/Reject)
33. Build Replacement Finder page
34. Build Product Catalog page
35. Build Product Intelligence Passport page
36. Build Reports page

### Phase 5: Integration & Demo
37. Prepare demo seed data
38. End-to-end integration testing
39. Demo scenario walkthrough
40. Performance optimization

---

## 19. Hackathon Demo Scenario

### Demo Script: "From Scattered Data to Trusted Product Intelligence"

**Scene 1: The Problem (30 sec)**
- Show scattered product info: a nameplate image, a partial CSV row, conflicting specs

**Scene 2: Upload & Extract (1 min)**
- Upload motor nameplate image
- Watch extraction pipeline process
- See extracted attributes with source markers

**Scene 3: The Intelligence (2 min)**
- **Conflict Detection**: "Voltage conflict detected! Nameplate says 415V, CSV says 400V"
- **Engineering Validation**: "Power inconsistency: 7.5kW claimed, but V×I×PF×√3 = 5.2kW. Flagged as physically suspicious."
- **Standards Matching**: "Matched to UNSPSC 26101501 (Electric motors) with 0.92 confidence"

**Scene 4: Before & After (1 min)**
- Show Before/After comparison
- Original extracted data vs. enriched, validated data
- Each change has evidence and explanation
- Click Accept/Reject on changes

**Scene 5: Replacement Finder (1 min)**
- Mark original product as discontinued
- System finds compatible replacement
- Show compatibility score: 87%
- Highlight: "Same voltage, power, mounting. Frame size difference: 132M vs 132S — physically compatible."

**Scene 6: Product Intelligence Passport (30 sec)**
- Generate complete passport
- Show all sections: Identity, Specs, Classification, Evidence, Validation, Confidence
- Export as JSON

**Key Message**: "IntelliSpec doesn't just extract — it validates, explains, and builds trustworthy product intelligence."

---

## 20. Risks & Mitigations

| Risk | Impact | Probability | Mitigation |
|---|---|---|---|
| Groq API downtime during demo | High | Medium | Implement mock/fallback mode with cached responses |
| OCR accuracy on complex nameplates | Medium | Medium | Use Groq Vision as primary; Tesseract as fallback; pre-process images |
| Standards data access limitations | Medium | High | Use publicly available subsets; clearly state when classification unavailable |
| LLM hallucination in extraction | High | Medium | Cross-validate with deterministic rules; require evidence for claims |
| Processing time too long for demo | Medium | Low | Cache demo product results; optimize LLM call count |
| Database corruption | High | Low | Use SQLite WAL mode; keep backup seed data |
| Complex UI not loading | Medium | Low | Keep UI functional over fancy; test critical paths |
| Dataset licensing issues | Medium | Low | Use only MIT/open licensed data; clearly attribute sources |
| Validation rules too strict/loose | Medium | Medium | Calibrate against known products; use warning vs. error distinction |
| Demo product not representative | Medium | Low | Prepare 3-5 different product types as backup |

