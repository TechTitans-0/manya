"""
Seed demo products into the IntelliSpec database.
Run from the backend directory:
    python scripts/seed_demo.py
"""
import os
import sys
import json
import uuid
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import SessionLocal, init_db
from models import Product, ProductAttribute, AttributeSource, AuditTrail
from config import SOURCE_TRUST_SCORES
from engines.evidence import evidence_engine


def seed():
    init_db()
    db = SessionLocal()

    demo_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                             "data", "seed_products", "demo_products.json")
    with open(demo_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    for p in data["products"]:
        existing = db.query(Product).filter(Product.id == p["id"]).first()
        if existing:
            print(f"Skipping existing product {p['id']}")
            continue

        product = Product(
            id=p["id"],
            name=p["name"],
            manufacturer=p["manufacturer"],
            model_number=p.get("model_number"),
            part_number=p.get("part_number"),
            category=p.get("category", "general"),
            description=p.get("description", ""),
            status=p.get("status", "reviewed"),
            overall_confidence=0.75,
        )
        db.add(product)

        # Collect all unique attributes
        all_attrs = {}
        for src in p["sources"]:
            for attr_name, value in src["attributes"].items():
                if attr_name not in all_attrs:
                    all_attrs[attr_name] = []
                all_attrs[attr_name].append({
                    "source_type": src["source_type"],
                    "source_name": src["source_name"],
                    "value": value,
                })

        for attr_name, sources in all_attrs.items():
            # Use the first source as normalized value for seeding
            first = sources[0]
            attr = ProductAttribute(
                id=str(uuid.uuid4()),
                product_id=p["id"],
                attribute_name=attr_name,
                raw_value=str(first["value"]),
                normalized_value=str(first["value"]),
                data_type="text",
                validation_status="unvalidated",
                approval_status="accepted",
                is_enriched=False,
                confidence=0.75,
            )
            db.add(attr)

            for s in sources:
                source = AttributeSource(
                    id=str(uuid.uuid4()),
                    attribute_id=attr.id,
                    product_id=p["id"],
                    source_type=s["source_type"],
                    source_name=s["source_name"],
                    source_value=str(s["value"]),
                    trust_score=SOURCE_TRUST_SCORES.get(s["source_type"], 0.5),
                    extraction_method="seed_import",
                )
                db.add(source)

            audit = AuditTrail(
                id=str(uuid.uuid4()),
                product_id=p["id"],
                attribute_id=attr.id,
                action="extract",
                new_value=str(first["value"]),
                reason=f"Imported from demo seed ({first['source_name']})",
                performed_by="system",
            )
            db.add(audit)

    db.commit()
    db.close()
    print("Demo products seeded successfully.")


if __name__ == "__main__":
    seed()
