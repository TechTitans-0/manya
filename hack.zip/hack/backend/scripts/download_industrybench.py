"""
Optional helper to download IndustryBench-MIPU dataset from Hugging Face.
Run from the backend directory:
    python scripts/download_industrybench.py

Requires: pip install datasets
"""
import os
import sys

try:
    from datasets import load_dataset
except ImportError:
    print("Please install datasets: pip install datasets")
    sys.exit(1)


def download():
    ds_name = "alibaba-multimodal-industrial-ai/IndustryBench-MIPU"
    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "datasets", "IndustryBench-MIPU")
    os.makedirs(output_dir, exist_ok=True)

    print(f"Downloading {ds_name}...")
    ds = load_dataset(ds_name, trust_remote_code=True)
    ds.save_to_disk(output_dir)
    print(f"Dataset saved to {output_dir}")


if __name__ == "__main__":
    download()
