import os
import json
import uuid
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from database import init_db, get_db
from models import CategorySchema, StandardsReference
from config import UPLOAD_DIR
from services.groq_service import groq_service

from routers import products, validation, standards, replacements, catalog, export as export_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def load_seed_data():
    """Load reference data and category schemas into the database."""
    from sqlalchemy.orm import Session
    from database import SessionLocal
    db = SessionLocal()
    try:
        # Load standards reference data
        base_path = os.path.join(os.path.dirname(__file__), "data", "standards")
        std_files = {"unspsc": "unspsc_reference.json", "eclass": "eclass_reference.json", "etim": "etim_reference.json"}
        for std_type, filename in std_files.items():
            filepath = os.path.join(base_path, filename)
            if os.path.exists(filepath):
                with open(filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for item in data:
                    existing = db.query(StandardsReference).filter(
                        StandardsReference.standard_type == std_type,
                        StandardsReference.code == item["code"]
                    ).first()
                    if not existing:
                        record = StandardsReference(
                            id=str(uuid.uuid4()),
                            standard_type=std_type,
                            code=item["code"],
                            level=item.get("level", 0),
                            description=item.get("description", ""),
                            parent_code=item.get("parent_code"),
                            keywords=item.get("keywords", ""),
                            category_path=item.get("category_path", ""),
                            attributes=json.dumps(item.get("attributes", {})),
                        )
                        db.add(record)

        # Load category schemas
        schema_dir = os.path.join(os.path.dirname(__file__), "data", "category_schemas")
        if os.path.exists(schema_dir):
            for filename in os.listdir(schema_dir):
                if filename.endswith(".json"):
                    with open(os.path.join(schema_dir, filename), "r", encoding="utf-8") as f:
                        schema = json.load(f)
                    existing = db.query(CategorySchema).filter(CategorySchema.category == schema["category"]).first()
                    if not existing:
                        cs = CategorySchema(
                            id=str(uuid.uuid4()),
                            category=schema["category"],
                            display_name=schema.get("display_name", schema["category"]),
                            attributes=json.dumps(schema.get("attributes", [])),
                            validation_rules=json.dumps(schema.get("validation_rules", {})),
                            common_standards=json.dumps(schema.get("common_standards", {})),
                        )
                        db.add(cs)
        db.commit()
    except Exception as e:
        logger.error(f"Seed data loading error: {e}")
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    load_seed_data()
    logger.info(f"Groq API available: {groq_service.available}")
    yield


app = FastAPI(
    title="IntelliSpec - Industrial Product Intelligence Platform",
    description="Evidence-driven AI product intelligence for industrial commerce",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(products.router)
app.include_router(validation.router)
app.include_router(standards.router)
app.include_router(replacements.router)
app.include_router(catalog.router)
app.include_router(export_router.router)


@app.get("/api/v1/health")
async def health_check():
    return {
        "status": "healthy",
        "groq_available": groq_service.available,
        "version": "1.0.0",
    }


@app.get("/api/v1/categories")
async def list_categories(db: Session = Depends(get_db)):
    schemas = db.query(CategorySchema).all()
    return [{"category": s.category, "display_name": s.display_name,
             "attribute_count": len(json.loads(s.attributes or "[]"))} for s in schemas]


@app.get("/api/v1/categories/{category}/schema")
async def get_category_schema(category: str, db: Session = Depends(get_db)):
    schema = db.query(CategorySchema).filter(CategorySchema.category == category).first()
    if not schema:
        raise HTTPException(status_code=404, detail="Category not found")
    return {
        "category": schema.category,
        "display_name": schema.display_name,
        "attributes": json.loads(schema.attributes or "[]"),
        "validation_rules": json.loads(schema.validation_rules or "{}"),
        "common_standards": json.loads(schema.common_standards or "{}"),
    }


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(status_code=500, content={"detail": str(exc)})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
