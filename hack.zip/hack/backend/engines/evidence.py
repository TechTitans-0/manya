import json
import math
from typing import Dict, List, Any, Optional, Tuple

# ---------------------------------------------------------------------------
# Configuration constants
# ---------------------------------------------------------------------------

SOURCE_TRUST_HIERARCHY: Dict[str, float] = {
    "manufacturer_datasheet": 0.95,
    "nameplate": 0.90,
    "official_catalog": 0.85,
    "authorized_distributor": 0.75,
    "manual_input": 0.70,
    "third_party": 0.60,
    "ai_enriched": 0.50,
    "unknown": 0.30,
}

CONFIDENCE_WEIGHTS: Dict[str, float] = {
    "source_trust": 0.35,
    "agreement": 0.30,
    "validation": 0.20,
    "completeness": 0.15,
}

# Attribute categories used for trust-score bonuses
_TECHNICAL_SPEC_ATTRIBUTES = {
    "voltage", "power", "current", "frequency", "speed",
    "torque", "resistance", "impedance", "capacitance",
    "inductance", "wattage", "amperage",
}

_PHYSICAL_DIMENSION_ATTRIBUTES = {
    "width", "height", "depth", "length", "weight",
    "bore_diameter", "outer_diameter", "shaft_diameter",
    "diameter", "dimensions",
}

_PRICING_ATTRIBUTES = {
    "price", "unit_price", "list_price", "msrp", "cost",
}

# Critical attributes per category for prioritize_missing_attributes
_CRITICAL_ATTRIBUTES_BY_CATEGORY: Dict[str, List[str]] = {
    "motors": ["voltage", "power", "speed", "frequency", "manufacturer", "model_number"],
    "bearings": ["bore_diameter", "outer_diameter", "width", "manufacturer", "part_number"],
    "pumps": ["flow_rate", "head", "power", "manufacturer"],
    "general": ["manufacturer", "part_number", "category"],
}


class EvidenceEngine:
    """Evidence tracking and confidence scoring engine for IntelliSpec.

    All confidence calculations are deterministic — no LLM calls.
    """

    def __init__(self) -> None:
        pass

    # ------------------------------------------------------------------
    # 1. Source trust
    # ------------------------------------------------------------------
    def calculate_source_trust(
        self, source_type: str, attribute_type: str = None
    ) -> float:
        """Return a trust score for *source_type*, optionally adjusted for
        *attribute_type* relevance.
        """
        base_trust = SOURCE_TRUST_HIERARCHY.get(source_type, SOURCE_TRUST_HIERARCHY["unknown"])

        if attribute_type is not None:
            attr_lower = attribute_type.lower()

            # Technical specs bonus for manufacturer datasheets
            if attr_lower in _TECHNICAL_SPEC_ATTRIBUTES and source_type == "manufacturer_datasheet":
                base_trust += 0.03

            # Pricing bonus for authorized distributors
            if attr_lower in _PRICING_ATTRIBUTES and source_type == "authorized_distributor":
                base_trust += 0.05

            # Physical dimensions bonus for nameplate
            if attr_lower in _PHYSICAL_DIMENSION_ATTRIBUTES and source_type == "nameplate":
                base_trust += 0.03

        return max(0.0, min(1.0, base_trust))

    # ------------------------------------------------------------------
    # 2. Agreement score
    # ------------------------------------------------------------------
    def calculate_agreement_score(self, sources: List[dict]) -> float:
        """Measure how well multiple sources agree on a value.

        Each entry in *sources* must contain ``source_value`` and
        ``trust_score`` keys.
        """
        if not sources:
            return 0.0

        if len(sources) == 1:
            return 0.5  # single source — unknown agreement

        # Group by normalised value
        groups: Dict[str, float] = {}
        for src in sources:
            key = str(src["source_value"]).strip().lower()
            groups[key] = groups.get(key, 0.0) + src["trust_score"]

        total_trust = sum(groups.values())
        if total_trust == 0.0:
            return 0.0

        largest_group_trust = max(groups.values())
        agreement = largest_group_trust / total_trust
        return max(0.0, min(1.0, agreement))

    # ------------------------------------------------------------------
    # 3. Validation score
    # ------------------------------------------------------------------
    def calculate_validation_score(self, validation_results: List[dict]) -> float:
        """Compute a validation score starting at 1.0, deducting for issues.

        Each entry must contain ``status`` and ``severity`` keys.
        """
        score = 1.0

        for result in validation_results:
            status = result.get("status", "")
            severity = result.get("severity", "")

            if status == "conflict" and severity == "critical":
                score -= 0.3
            elif status == "conflict" and severity == "warning":
                score -= 0.15
            elif status == "warning" and severity == "critical":
                score -= 0.2
            elif status == "warning" and severity == "warning":
                score -= 0.1
            elif status == "warning" and severity == "info":
                score -= 0.05
            # status == "valid" → no change

        return max(0.0, min(1.0, score))

    # ------------------------------------------------------------------
    # 4. Completeness score
    # ------------------------------------------------------------------
    def calculate_completeness_score(
        self,
        present_attributes: List[str],
        required_attributes: List[str],
        category: str = None,
    ) -> float:
        """Fraction of *required_attributes* that are present."""
        if not required_attributes:
            return 1.0

        present_set = {a.lower() for a in present_attributes}
        present_count = sum(1 for r in required_attributes if r.lower() in present_set)
        return max(0.0, min(1.0, present_count / len(required_attributes)))

    # ------------------------------------------------------------------
    # 5. Attribute confidence (composite)
    # ------------------------------------------------------------------
    def calculate_attribute_confidence(
        self,
        sources: List[dict],
        validation_results: List[dict] = None,
        has_evidence: bool = True,
    ) -> float:
        """Deterministic composite confidence for a single attribute."""
        # Source trust — best among provided sources
        if sources:
            source_trust = max(s.get("trust_score", 0.3) for s in sources)
        else:
            source_trust = 0.3

        agreement = self.calculate_agreement_score(sources)
        validation = self.calculate_validation_score(validation_results or [])
        evidence_quality = 1.0 if has_evidence else 0.3

        confidence = (
            CONFIDENCE_WEIGHTS["source_trust"] * source_trust
            + CONFIDENCE_WEIGHTS["agreement"] * agreement
            + CONFIDENCE_WEIGHTS["validation"] * validation
            + CONFIDENCE_WEIGHTS["completeness"] * evidence_quality
        )

        return max(0.0, min(1.0, confidence))

    # ------------------------------------------------------------------
    # 6. Product-level confidence
    # ------------------------------------------------------------------
    def calculate_product_confidence(
        self, attribute_confidences: List[Tuple[str, float, bool]]
    ) -> float:
        """Weighted average confidence across all attributes.

        *attribute_confidences* is a list of
        ``(attr_name, confidence, is_critical)`` tuples.  Critical
        attributes receive 2× weight.
        """
        if not attribute_confidences:
            return 0.0

        total_weight = 0.0
        weighted_sum = 0.0

        for _attr_name, confidence, is_critical in attribute_confidences:
            weight = 2.0 if is_critical else 1.0
            weighted_sum += confidence * weight
            total_weight += weight

        if total_weight == 0.0:
            return 0.0

        product_confidence = weighted_sum / total_weight
        return max(0.0, min(1.0, product_confidence))

    # ------------------------------------------------------------------
    # 7. Select best value from multiple sources
    # ------------------------------------------------------------------
    def select_best_value(self, sources: List[dict]) -> dict:
        """Pick the best value when multiple sources provide candidates.

        Strategy: prefer the value from the highest-trust source that
        agrees with the most other sources.

        Returns a dict with ``selected_value``, ``reason``,
        ``confidence``, ``supporting_sources``, and
        ``conflicting_sources``.
        """
        if not sources:
            return {
                "selected_value": None,
                "reason": "No sources available",
                "confidence": 0.0,
                "supporting_sources": [],
                "conflicting_sources": [],
            }

        if len(sources) == 1:
            src = sources[0]
            return {
                "selected_value": src["source_value"],
                "reason": "Single source available",
                "confidence": src.get("trust_score", 0.3),
                "supporting_sources": [src],
                "conflicting_sources": [],
            }

        # Group by normalised value
        groups: Dict[str, List[dict]] = {}
        for src in sources:
            key = str(src["source_value"]).strip().lower()
            groups.setdefault(key, []).append(src)

        # Score each group: combined trust × number of agreeing sources
        best_key: Optional[str] = None
        best_score: float = -1.0
        for key, group in groups.items():
            max_trust = max(s.get("trust_score", 0.0) for s in group)
            group_score = max_trust * len(group)
            if group_score > best_score:
                best_score = group_score
                best_key = key

        supporting = groups[best_key]
        conflicting = [s for k, g in groups.items() if k != best_key for s in g]

        # Use the original (non-normalised) value from the highest-trust
        # source in the winning group.
        best_source = max(supporting, key=lambda s: s.get("trust_score", 0.0))
        selected_value = best_source["source_value"]

        agreement_count = len(supporting)
        total_count = len(sources)

        reason = (
            f"Selected from highest-trust source "
            f"(trust={best_source.get('trust_score', 0):.2f}) "
            f"with {agreement_count}/{total_count} sources agreeing"
        )

        confidence = self.calculate_attribute_confidence(sources)

        return {
            "selected_value": selected_value,
            "reason": reason,
            "confidence": confidence,
            "supporting_sources": supporting,
            "conflicting_sources": conflicting,
        }

    # ------------------------------------------------------------------
    # 8. Build evidence chain
    # ------------------------------------------------------------------
    def build_evidence_chain(
        self,
        attribute_name: str,
        sources: List[dict],
        validation_results: List[dict],
        final_value: str,
        selection_reason: str,
    ) -> dict:
        """Assemble a complete evidence-chain record for an attribute."""
        source_summaries = [
            {
                "source_type": s.get("source_type", "unknown"),
                "source_value": s.get("source_value"),
                "trust_score": s.get("trust_score", 0.0),
            }
            for s in sources
        ]

        validation_summaries = [
            {
                "status": v.get("status", "unknown"),
                "severity": v.get("severity", "info"),
                "message": v.get("message", ""),
            }
            for v in validation_results
        ]

        confidence = self.calculate_attribute_confidence(sources, validation_results)

        # Describe decision method
        if len(sources) == 0:
            decision_method = "No sources available; default value used"
        elif len(sources) == 1:
            decision_method = "Single source accepted directly"
        else:
            unique_values = {str(s.get("source_value", "")).strip().lower() for s in sources}
            if len(unique_values) == 1:
                decision_method = "All sources agree; unanimous value accepted"
            else:
                decision_method = (
                    "Multiple conflicting sources; value selected by "
                    "highest-trust source with most agreement"
                )

        return {
            "attribute": attribute_name,
            "final_value": final_value,
            "sources": source_summaries,
            "validation": validation_summaries,
            "confidence": confidence,
            "reason": selection_reason,
            "decision_method": decision_method,
        }

    # ------------------------------------------------------------------
    # 9. Prioritize missing attributes
    # ------------------------------------------------------------------
    def prioritize_missing_attributes(
        self,
        category: str,
        present_attributes: List[str],
        category_schema: dict,
    ) -> List[dict]:
        """Determine which attributes are missing and assign priorities.

        Priority levels:
        - **critical** — required for identification / safety
        - **high** — important for commerce
        - **medium** — useful for full specification
        - **low** — optional / nice-to-have
        """
        present_lower = {a.lower() for a in present_attributes}
        cat_key = (category or "general").lower()

        # Collect all known attributes from the schema
        all_schema_attrs: List[str] = []
        if isinstance(category_schema, dict):
            # Support schemas shaped as {"properties": {...}} or flat dicts
            props = category_schema.get("properties", category_schema)
            if isinstance(props, dict):
                all_schema_attrs = list(props.keys())

        # Determine which are missing
        missing_attrs = [a for a in all_schema_attrs if a.lower() not in present_lower]

        # Critical set for this category
        critical_set = {
            a.lower()
            for a in _CRITICAL_ATTRIBUTES_BY_CATEGORY.get(
                cat_key, _CRITICAL_ATTRIBUTES_BY_CATEGORY["general"]
            )
        }

        # High-importance commercial attributes
        high_set = {"price", "lead_time", "availability", "supplier", "warranty"}

        # Medium-importance descriptive attributes
        medium_set = {
            "description", "material", "color", "mounting_type",
            "efficiency", "insulation_class", "enclosure_type",
        }

        results: List[dict] = []
        for attr in missing_attrs:
            attr_lower = attr.lower()
            if attr_lower in critical_set:
                priority = "critical"
                reason = "Required for identification or safety"
            elif attr_lower in high_set:
                priority = "high"
                reason = "Important for commerce and procurement"
            elif attr_lower in medium_set:
                priority = "medium"
                reason = "Useful for complete specification"
            else:
                priority = "low"
                reason = "Optional supplementary attribute"

            results.append({
                "attribute_name": attr,
                "priority": priority,
                "reason": reason,
            })

        # Sort so critical items surface first
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        results.sort(key=lambda r: priority_order.get(r["priority"], 4))

        return results


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
evidence_engine = EvidenceEngine()
