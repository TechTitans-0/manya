import json
import re
import math
from typing import Dict, List, Any, Optional


class ConflictDetectionEngine:
    """Engine that identifies contradictory values from different sources for the same attribute."""

    def __init__(self):
        self.numeric_tolerance = {
            "voltage": 0.02,  # 2% tolerance
            "power": 0.05,
            "current": 0.05,
            "speed": 0.03,
            "weight": 0.10,
            "temperature": 5.0,  # absolute 5 degrees
            "pressure": 0.05,
            "flow_rate": 0.05,
            "frequency": 0.0,  # must be exact
            "default": 0.05,
        }

        self._critical_attributes = {
            "voltage", "power", "current", "frequency", "pressure",
            "temperature", "speed", "breaking_capacity",
        }

    def detect_conflicts(self, attribute_name: str, sources: List[dict]) -> dict:
        """Detect conflicting values from different sources for a single attribute.

        Args:
            attribute_name: The name of the attribute being compared.
            sources: List of dicts with keys: source_type, source_name, source_value, trust_score.

        Returns:
            Dict with conflict analysis results.
        """
        if len(sources) < 2:
            return {
                "attribute": attribute_name,
                "status": "no_conflict",
                "message": "Fewer than 2 sources; nothing to compare.",
            }

        # Group sources by value using tolerance-based matching
        value_groups: List[dict] = []

        for src in sources:
            matched_group = None
            for group in value_groups:
                if self._values_match(attribute_name, group["value"], str(src["source_value"])):
                    matched_group = group
                    break

            if matched_group is not None:
                matched_group["sources"].append(src["source_name"])
                matched_group["trust_scores"].append(src.get("trust_score", 0.5))
            else:
                value_groups.append({
                    "value": str(src["source_value"]),
                    "sources": [src["source_name"]],
                    "trust_scores": [src.get("trust_score", 0.5)],
                })

        # All values match – no conflict
        if len(value_groups) == 1:
            return {
                "attribute": attribute_name,
                "status": "no_conflict",
                "message": "All sources agree.",
                "agreed_value": value_groups[0]["value"],
                "source_count": len(sources),
            }

        # Conflict detected – build details
        conflicting_values = []
        for group in value_groups:
            conflicting_values.append({
                "value": group["value"],
                "sources": group["sources"],
                "trust_scores": group["trust_scores"],
            })

        # Determine recommended value from highest-trust group
        best_group = max(value_groups, key=lambda g: max(g["trust_scores"]))
        recommended_value = best_group["value"]
        best_trust = max(best_group["trust_scores"])
        best_source = best_group["sources"][best_group["trust_scores"].index(best_trust)]

        recommendation_reason = (
            f"Value '{recommended_value}' recommended based on highest trust score "
            f"({best_trust}) from source '{best_source}'."
        )

        severity = (
            "critical"
            if attribute_name.lower() in self._critical_attributes
            else "warning"
        )

        return {
            "attribute": attribute_name,
            "status": "conflict",
            "conflicting_values": conflicting_values,
            "recommended_value": recommended_value,
            "recommendation_reason": recommendation_reason,
            "severity": severity,
        }

    def detect_all_conflicts(self, product_attributes: dict) -> List[dict]:
        """Run conflict detection across all attributes of a product.

        Args:
            product_attributes: Dict mapping attribute_name -> list of source dicts.

        Returns:
            List of conflict result dicts (only those with actual conflicts).
        """
        conflicts: List[dict] = []
        for attr_name, source_list in product_attributes.items():
            result = self.detect_conflicts(attr_name, source_list)
            if result.get("status") == "conflict":
                conflicts.append(result)
        return conflicts

    def _values_match(self, attr_name: str, value1: str, value2: str) -> bool:
        """Compare two values considering tolerance.

        For numeric attributes the comparison uses the configured tolerance band.
        For text attributes a case-insensitive exact match is performed.

        Returns:
            True if the values are considered equivalent, False otherwise.
        """
        if self._is_numeric_attribute(attr_name):
            num1 = self._extract_numeric(value1)
            num2 = self._extract_numeric(value2)

            if num1 is not None and num2 is not None:
                tolerance_key = attr_name.lower()
                tolerance = self.numeric_tolerance.get(tolerance_key, self.numeric_tolerance["default"])

                # Temperature uses absolute tolerance; all others use relative
                if tolerance_key == "temperature":
                    return abs(num1 - num2) <= tolerance

                # Relative tolerance
                reference = max(abs(num1), abs(num2))
                if reference == 0:
                    return num1 == num2
                return abs(num1 - num2) / reference <= tolerance

        # Text comparison – case-insensitive exact match
        return value1.strip().lower() == value2.strip().lower()

    def _extract_numeric(self, value: str) -> Optional[float]:
        """Extract a numeric value from a string.

        Examples:
            '415V'   -> 415.0
            '7.5 kW' -> 7.5
            'N/A'    -> None
        """
        match = re.search(r"[-+]?\d*\.?\d+", str(value))
        if match:
            try:
                return float(match.group())
            except ValueError:
                return None
        return None

    def _is_numeric_attribute(self, attr_name: str) -> bool:
        """Return True for attributes expected to carry numeric values."""
        numeric_attrs = {
            "voltage", "power", "current", "speed", "weight",
            "temperature", "pressure", "flow_rate", "frequency",
            "bore_diameter", "outer_diameter", "width", "head",
            "dynamic_load_rating", "static_load_rating", "max_speed",
            "breaking_capacity", "accuracy", "response_time",
        }
        return attr_name.lower() in numeric_attrs


# Module-level singleton
conflict_engine = ConflictDetectionEngine()
