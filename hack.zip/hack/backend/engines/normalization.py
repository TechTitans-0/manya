"""
Unit normalization and value parsing engine for the IntelliSpec platform.

Normalizes values to standard units and formats using DETERMINISTIC Python
methods (no LLM calls). Handles unit conversions, format standardization,
and value parsing.
"""

import re
import math
from typing import Dict, List, Any, Optional, Tuple


class NormalizationEngine:
    """Engine for normalizing engineering values to standard units and formats."""

    def __init__(self) -> None:
        """Initialize unit conversion tables and format rules."""

        self.UNIT_CONVERSIONS: Dict[str, Any] = {
            "power": {
                "base_unit": "kW",
                "conversions": {
                    "w": 0.001, "W": 0.001,
                    "kw": 1.0, "kW": 1.0, "KW": 1.0,
                    "mw": 1000.0, "MW": 1000.0,
                    "hp": 0.7457, "HP": 0.7457,
                    "bhp": 0.7457, "BHP": 0.7457,
                },
            },
            "voltage": {
                "base_unit": "V",
                "conversions": {
                    "v": 1.0, "V": 1.0,
                    "kv": 1000.0, "kV": 1000.0, "KV": 1000.0,
                    "mv": 0.001, "mV": 0.001,
                },
            },
            "current": {
                "base_unit": "A",
                "conversions": {
                    "a": 1.0, "A": 1.0,
                    "ma": 0.001, "mA": 0.001,
                    "ka": 1000.0, "kA": 1000.0,
                },
            },
            "speed": {
                "base_unit": "RPM",
                "conversions": {
                    "rpm": 1.0, "RPM": 1.0, "r/min": 1.0,
                    "rad/s": 9.5493,
                },
            },
            "weight": {
                "base_unit": "kg",
                "conversions": {
                    "g": 0.001, "kg": 1.0, "t": 1000.0,
                    "lb": 0.4536, "lbs": 0.4536, "oz": 0.02835,
                },
            },
            "length": {
                "base_unit": "mm",
                "conversions": {
                    "mm": 1.0, "cm": 10.0, "m": 1000.0,
                    "in": 25.4, "ft": 304.8,
                },
            },
            "temperature": {
                "base_unit": "°C",
                "special": True,  # Needs special conversion (not multiplicative)
            },
            "pressure": {
                "base_unit": "bar",
                "conversions": {
                    "bar": 1.0, "psi": 0.06895, "PSI": 0.06895,
                    "mpa": 10.0, "MPa": 10.0, "kpa": 0.01, "kPa": 0.01,
                    "atm": 1.01325,
                },
            },
            "flow_rate": {
                "base_unit": "m³/h",
                "conversions": {
                    "m³/h": 1.0, "m3/h": 1.0,
                    "l/min": 0.06, "L/min": 0.06,
                    "gpm": 0.2271, "GPM": 0.2271,
                },
            },
            "frequency": {
                "base_unit": "Hz",
                "conversions": {
                    "hz": 1.0, "Hz": 1.0, "HZ": 1.0,
                    "khz": 1000.0, "kHz": 1000.0,
                },
            },
        }

        # Mapping from attribute name keywords to unit categories
        self._attribute_type_map: Dict[str, List[str]] = {
            "voltage": [
                "voltage", "rated_voltage", "supply_voltage", "line_voltage",
                "phase_voltage",
            ],
            "power": [
                "power", "rated_power", "output_power", "motor_power",
                "input_power", "shaft_power",
            ],
            "current": [
                "current", "rated_current", "full_load_current",
                "starting_current", "no_load_current",
            ],
            "speed": [
                "speed", "rpm", "rated_speed", "synchronous_speed",
                "motor_speed", "rotational_speed",
            ],
            "weight": [
                "weight", "mass", "net_weight", "gross_weight",
            ],
            "length": [
                "length", "width", "height", "depth", "diameter",
                "shaft_diameter", "bore", "dimension",
            ],
            "temperature": [
                "temperature", "ambient_temperature", "max_temperature",
                "operating_temperature", "temp",
            ],
            "pressure": [
                "pressure", "rated_pressure", "max_pressure",
                "operating_pressure", "discharge_pressure", "suction_pressure",
            ],
            "flow_rate": [
                "flow_rate", "flow", "rated_flow", "max_flow",
                "discharge_flow",
            ],
            "frequency": [
                "frequency", "rated_frequency", "supply_frequency",
            ],
        }

        # Attribute names that should be skipped during normalization (text fields)
        self._skip_attributes: List[str] = [
            "manufacturer", "model", "brand", "series", "description",
            "material", "color", "type", "category", "name",
            "part_number", "serial_number", "certificate",
        ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def normalize_value(self, attribute_name: str, raw_value: str) -> dict:
        """Parse the raw value string, identify the attribute type, extract
        numeric value and unit, convert to base unit, and return a result dict.

        Returns:
            dict with keys:
                - original_value (str)
                - normalized_value (str)  – e.g. "7.5 kW"
                - numeric_value (float | None)
                - unit (str | None)       – base unit
                - conversion_applied (bool)
                - conversion_details (str)
        """
        result: Dict[str, Any] = {
            "original_value": raw_value,
            "normalized_value": raw_value,
            "numeric_value": None,
            "unit": None,
            "conversion_applied": False,
            "conversion_details": "",
        }

        # Try format standardization first (IP ratings, efficiency class, etc.)
        standardized = self.standardize_format(attribute_name, raw_value)
        if standardized != raw_value:
            result["normalized_value"] = standardized
            result["conversion_applied"] = True
            result["conversion_details"] = (
                f"Format standardized: '{raw_value}' -> '{standardized}'"
            )

        # Identify what kind of attribute this is
        attr_type = self.identify_attribute_type(attribute_name)
        if attr_type is None:
            return result

        # Parse numeric value and unit from raw string
        numeric_value, parsed_unit = self.parse_value(raw_value)
        if numeric_value is None:
            return result

        type_info = self.UNIT_CONVERSIONS.get(attr_type)
        if type_info is None:
            return result

        base_unit: str = type_info["base_unit"]

        # --- Temperature (special, non-multiplicative) ---
        if type_info.get("special") and attr_type == "temperature":
            from_unit = parsed_unit if parsed_unit else "°C"
            converted = self.convert_temperature(numeric_value, from_unit, "°C")
            already_base = (from_unit in ("°C", "C", "c", "celsius"))
            result.update(
                {
                    "numeric_value": round(converted, 4),
                    "unit": base_unit,
                    "normalized_value": f"{round(converted, 4)} {base_unit}",
                    "conversion_applied": not already_base,
                    "conversion_details": (
                        f"Converted {numeric_value} {from_unit} -> "
                        f"{round(converted, 4)} {base_unit}"
                        if not already_base
                        else "Already in base unit"
                    ),
                }
            )
            return result

        # --- Multiplicative conversions ---
        conversions: Dict[str, float] = type_info.get("conversions", {})
        if not parsed_unit:
            # No unit found – assume base unit
            result.update(
                {
                    "numeric_value": round(numeric_value, 4),
                    "unit": base_unit,
                    "normalized_value": f"{round(numeric_value, 4)} {base_unit}",
                    "conversion_applied": False,
                    "conversion_details": "No unit detected; assumed base unit",
                }
            )
            return result

        factor = conversions.get(parsed_unit)
        if factor is None:
            # Try case-insensitive fallback
            for key, val in conversions.items():
                if key.lower() == parsed_unit.lower():
                    factor = val
                    break

        if factor is None:
            # Unknown unit — return what we have
            result.update(
                {
                    "numeric_value": numeric_value,
                    "unit": parsed_unit,
                    "normalized_value": f"{numeric_value} {parsed_unit}",
                    "conversion_applied": False,
                    "conversion_details": f"Unknown unit '{parsed_unit}' for type '{attr_type}'",
                }
            )
            return result

        converted_value = round(numeric_value * factor, 4)
        already_base = math.isclose(factor, 1.0)

        result.update(
            {
                "numeric_value": converted_value,
                "unit": base_unit,
                "normalized_value": f"{converted_value} {base_unit}",
                "conversion_applied": not already_base,
                "conversion_details": (
                    f"Converted {numeric_value} {parsed_unit} -> "
                    f"{converted_value} {base_unit} (factor={factor})"
                    if not already_base
                    else "Already in base unit"
                ),
            }
        )
        return result

    def parse_value(self, raw_value: str) -> Tuple[Optional[float], Optional[str]]:
        """Parse a value string into (numeric_value, unit).

        Supported formats:
            - "7.5 kW", "7.5kW", "415V", "1,450 RPM", "1450rpm"
            - Ranges: "380-415V" → takes the higher value
            - Fractions: "1/2 HP"

        Returns:
            (float_value, unit_string) or (None, None) if unparseable.
        """
        if not raw_value or not isinstance(raw_value, str):
            return None, None

        text = raw_value.strip()

        # ---- Handle fraction format: "1/2 HP", "3/4 hp" ----
        frac_match = re.match(
            r"(\d+)\s*/\s*(\d+)\s*([A-Za-z/°³]+.*)?$", text
        )
        if frac_match:
            numerator = float(frac_match.group(1))
            denominator = float(frac_match.group(2))
            if denominator != 0:
                value = numerator / denominator
                unit = (frac_match.group(3) or "").strip()
                return value, unit if unit else None

        # ---- Handle range format: "380-415V", "50-60Hz" ----
        range_match = re.match(
            r"([\d,]+\.?\d*)\s*[-–]\s*([\d,]+\.?\d*)\s*([A-Za-z/°³]+.*)?$",
            text,
        )
        if range_match:
            # Take the higher value
            val_str = range_match.group(2).replace(",", "")
            try:
                value = float(val_str)
            except ValueError:
                return None, None
            unit = (range_match.group(3) or "").strip()
            return value, unit if unit else None

        # ---- Standard numeric + unit: "7.5 kW", "415V", "1,450 RPM" ----
        std_match = re.match(
            r"([+-]?\d[\d,]*\.?\d*)\s*([A-Za-z/°³]+.*)?$", text
        )
        if std_match:
            val_str = std_match.group(1).replace(",", "")
            try:
                value = float(val_str)
            except ValueError:
                return None, None
            unit = (std_match.group(2) or "").strip()
            return value, unit if unit else None

        return None, None

    def identify_attribute_type(self, attribute_name: str) -> Optional[str]:
        """Map an attribute name to its unit category.

        Returns:
            Category string (e.g. "voltage", "power") or None.
        """
        if not attribute_name:
            return None

        name_lower = attribute_name.strip().lower()

        # Direct lookup in the keyword lists
        for category, keywords in self._attribute_type_map.items():
            if name_lower in keywords:
                return category

        # Substring / partial match fallback
        for category, keywords in self._attribute_type_map.items():
            for keyword in keywords:
                if keyword in name_lower or name_lower in keyword:
                    return category

        return None

    def normalize_product_attributes(self, attributes: dict) -> dict:
        """Normalize all attributes in a product.

        Args:
            attributes: dict mapping attribute_name -> raw value string.

        Returns:
            dict mapping attribute_name -> normalization result dict.
            Text-only fields (manufacturer, model, etc.) are skipped.
        """
        results: Dict[str, Any] = {}

        for attr_name, raw_value in attributes.items():
            # Skip pure-text fields that don't need unit normalization
            if attr_name.strip().lower() in self._skip_attributes:
                continue

            # Only attempt normalization on string values
            if not isinstance(raw_value, str):
                continue

            results[attr_name] = self.normalize_value(attr_name, raw_value)

        return results

    def convert_temperature(
        self, value: float, from_unit: str, to_unit: str = "°C"
    ) -> float:
        """Special temperature conversion (non-multiplicative).

        Supported units: °C / C, °F / F, K.

        Conversion formulae:
            F → C : (F - 32) × 5/9
            K → C : K - 273.15
            C → F : C × 9/5 + 32
            C → K : C + 273.15
        """
        # Normalize unit labels
        fu = from_unit.strip().upper().replace("°", "")
        tu = to_unit.strip().upper().replace("°", "")

        # Map common aliases
        _alias = {"CELSIUS": "C", "FAHRENHEIT": "F", "KELVIN": "K"}
        fu = _alias.get(fu, fu)
        tu = _alias.get(tu, tu)

        if fu == tu:
            return value

        # Step 1: convert *from* → Celsius
        if fu == "C":
            celsius = value
        elif fu == "F":
            celsius = (value - 32.0) * 5.0 / 9.0
        elif fu == "K":
            celsius = value - 273.15
        else:
            # Unknown source unit — return as-is
            return value

        # Step 2: convert Celsius → *to*
        if tu == "C":
            return celsius
        elif tu == "F":
            return celsius * 9.0 / 5.0 + 32.0
        elif tu == "K":
            return celsius + 273.15
        else:
            return celsius

    def standardize_format(self, attribute_name: str, value: str) -> str:
        """Standardize common engineering formats.

        Handles:
            - IP rating: "IP 55" → "IP55", "ip55" → "IP55"
            - Efficiency class: "ie2" → "IE2", "Ie3" → "IE3"
            - Part numbers: strip extra whitespace, uppercase
        """
        if not value or not isinstance(value, str):
            return value

        text = value.strip()
        name_lower = attribute_name.strip().lower() if attribute_name else ""

        # ---- IP rating ----
        ip_match = re.match(r"(?i)(ip)\s*(\d{2,3}[A-Za-z]?)", text)
        if ip_match:
            return f"IP{ip_match.group(2).upper()}"

        # ---- Efficiency class (IE1-IE5) ----
        ie_match = re.match(r"(?i)(ie)\s*([1-5])", text)
        if ie_match:
            return f"IE{ie_match.group(2)}"

        # ---- Part numbers / serial numbers: collapse whitespace, uppercase ----
        if name_lower in (
            "part_number", "serial_number", "model_number", "catalog_number",
        ):
            return re.sub(r"\s+", " ", text).strip().upper()

        return text


# Module-level convenience instance
normalization_engine = NormalizationEngine()
