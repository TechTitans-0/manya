"""
Replacement Part Finder Engine for IntelliSpec Platform.

Finds technically compatible replacement parts for discontinued or unavailable
industrial products. Uses attribute-level compatibility scoring — NOT simple
text similarity — to rank candidates by how well their specifications match
the original product's critical, important, and optional attributes.
"""

import json
import math
from typing import Dict, List, Any, Optional, Tuple


# ---------------------------------------------------------------------------
# Which attributes are critical for compatibility, per product category
# ---------------------------------------------------------------------------

CATEGORY_CRITICAL_ATTRIBUTES: Dict[str, Dict[str, List[str]]] = {
    "motors": {
        "critical": ["voltage", "power", "frequency", "mounting_type"],
        "important": ["speed", "frame_size", "efficiency_class", "ip_rating"],
        "optional": ["weight", "manufacturer", "insulation_class"],
    },
    "bearings": {
        "critical": ["bore_diameter", "outer_diameter", "width", "bearing_type"],
        "important": ["dynamic_load_rating", "max_speed", "seal_type"],
        "optional": ["weight", "material", "manufacturer"],
    },
    "pumps": {
        "critical": ["flow_rate", "head", "power", "pump_type"],
        "important": ["voltage", "frequency", "connection_size", "material"],
        "optional": ["weight", "ip_rating", "manufacturer"],
    },
    "valves": {
        "critical": ["size", "pressure_rating", "valve_type", "connection_type"],
        "important": ["material", "temperature_range", "media"],
        "optional": ["manufacturer", "weight", "actuator_type"],
    },
    "sensors": {
        "critical": ["sensor_type", "measurement_range", "output_signal", "supply_voltage"],
        "important": ["accuracy", "response_time", "ip_rating"],
        "optional": ["manufacturer", "weight", "cable_length"],
    },
    "electrical": {
        "critical": ["voltage", "current", "type"],
        "important": ["breaking_capacity", "poles", "mounting_type"],
        "optional": ["manufacturer", "ip_rating", "weight"],
    },
    "default": {
        "critical": ["category", "type"],
        "important": ["voltage", "power", "size"],
        "optional": ["manufacturer", "weight"],
    },
}

ATTRIBUTE_WEIGHTS: Dict[str, float] = {
    "critical": 1.0,
    "important": 0.6,
    "optional": 0.2,
}

TOLERANCE_RANGES: Dict[str, float] = {
    "voltage": 0.05,          # 5% tolerance
    "power": 0.10,            # 10% tolerance
    "current": 0.10,
    "speed": 0.05,
    "frequency": 0.0,         # Must be exact
    "bore_diameter": 0.0,     # Must be exact
    "outer_diameter": 0.0,
    "width": 0.02,
    "flow_rate": 0.15,
    "head": 0.10,
    "pressure_rating": 0.0,   # Must meet or exceed
    "size": 0.0,
    "temperature_range": 0.0,
}


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ReplacementFinder:
    """Scores and ranks catalog products as potential replacements for a
    given original product based on attribute-level compatibility."""

    def __init__(self) -> None:
        """Initialise the replacement finder (stateless — nothing to set up)."""
        pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def find_replacements(
        self,
        original_product: dict,
        catalog_products: List[dict],
        category: Optional[str] = None,
        top_n: int = 5,
    ) -> List[dict]:
        """Find the best replacement parts for *original_product*.

        Parameters
        ----------
        original_product:
            Dict mapping attribute names to their values
            (e.g. ``{"voltage": "415 V", "power": "7.5 kW", ...}``).
        catalog_products:
            List of candidate dicts, each containing at least ``id``,
            ``name``, and ``attributes`` (a dict of attribute→value).
        category:
            Product category (``"motors"``, ``"bearings"``, …).  If
            *None*, the engine tries to determine it from the original
            product's attributes.
        top_n:
            Maximum number of results to return.

        Returns
        -------
        List of result dicts sorted by ``compatibility_score`` (desc),
        each containing:
        - ``replacement_product_id``
        - ``product_name``
        - ``compatibility_score``
        - ``matched_attributes``
        - ``mismatched_attributes``
        - ``critical_differences``
        - ``recommendation_reason``
        """

        # Resolve category -------------------------------------------------
        if category is None:
            category = self._detect_category(original_product)
        category = category.lower() if category else "default"
        if category not in CATEGORY_CRITICAL_ATTRIBUTES:
            category = "default"

        # Score every candidate ---------------------------------------------
        scored: List[dict] = []
        for candidate in catalog_products:
            candidate_attrs = candidate.get("attributes", {})
            compat = self._calculate_compatibility(
                original_product, candidate_attrs, category
            )

            original_name = original_product.get("name", "Original product")
            candidate_name = candidate.get("name", "Unknown")

            reason = self._generate_recommendation_reason(
                original_name,
                candidate_name,
                compat["score"],
                compat["matched"],
                compat["mismatched"],
                compat["critical_diffs"],
            )

            scored.append({
                "replacement_product_id": candidate.get("id"),
                "product_name": candidate_name,
                "compatibility_score": round(compat["score"], 4),
                "matched_attributes": compat["matched"],
                "mismatched_attributes": compat["mismatched"],
                "critical_differences": compat["critical_diffs"],
                "recommendation_reason": reason,
            })

        # Sort descending by score, then by name for stability ---------------
        scored.sort(key=lambda r: (-r["compatibility_score"], r["product_name"]))

        return scored[:top_n]

    # ------------------------------------------------------------------
    # Compatibility scoring
    # ------------------------------------------------------------------

    def _calculate_compatibility(
        self, original: dict, candidate: dict, category: str
    ) -> dict:
        """Compare *original* and *candidate* attribute dicts and return a
        compatibility breakdown.

        Returns
        -------
        dict with keys ``score``, ``matched``, ``mismatched``,
        ``critical_diffs``.
        """

        attr_groups = CATEGORY_CRITICAL_ATTRIBUTES.get(
            category, CATEGORY_CRITICAL_ATTRIBUTES["default"]
        )

        matched: List[dict] = []
        mismatched: List[dict] = []
        critical_diffs: List[dict] = []

        weighted_match_sum = 0.0
        total_weight = 0.0

        # Build a flat mapping: attribute_name -> importance tier
        attr_tier: Dict[str, str] = {}
        for tier in ("critical", "important", "optional"):
            for attr in attr_groups.get(tier, []):
                attr_tier[attr] = tier

        # Also consider attributes present in the original but not listed
        # in the category schema — treat them as optional.
        for attr in original:
            if attr not in attr_tier and attr != "name":
                attr_tier[attr] = "optional"

        for attr_name, tier in attr_tier.items():
            original_value = original.get(attr_name)
            candidate_value = candidate.get(attr_name)

            weight = ATTRIBUTE_WEIGHTS[tier]

            # If the original doesn't specify this attribute, skip it — we
            # cannot penalise a candidate for something we don't know about
            # the original.
            if original_value is None:
                continue

            total_weight += weight

            if candidate_value is None:
                # Candidate is missing an attribute the original has.
                entry = {
                    "attribute": attr_name,
                    "original_value": str(original_value),
                    "candidate_value": None,
                    "tier": tier,
                    "description": f"Missing in candidate",
                }
                mismatched.append(entry)
                if tier == "critical":
                    critical_diffs.append(entry)
                continue

            score, description = self._compare_values(
                attr_name, str(original_value), str(candidate_value)
            )

            entry = {
                "attribute": attr_name,
                "original_value": str(original_value),
                "candidate_value": str(candidate_value),
                "tier": tier,
                "match_score": round(score, 4),
                "description": description,
            }

            weighted_match_sum += weight * score

            if score >= 0.8:
                matched.append(entry)
            else:
                mismatched.append(entry)
                if tier == "critical":
                    critical_diffs.append(entry)

        compatibility_score = (
            weighted_match_sum / total_weight if total_weight > 0 else 0.0
        )

        return {
            "score": compatibility_score,
            "matched": matched,
            "mismatched": mismatched,
            "critical_diffs": critical_diffs,
        }

    # ------------------------------------------------------------------
    # Value comparison
    # ------------------------------------------------------------------

    def _compare_values(
        self, attr_name: str, original_value: str, candidate_value: str
    ) -> Tuple[float, str]:
        """Compare two attribute values and return ``(match_score, description)``.

        * Numeric values are compared within the tolerance defined in
          ``TOLERANCE_RANGES``.
        * Exact-match attributes (frequency, bore_diameter, …) must be
          identical.
        * Text attributes are compared case-insensitively.
        """

        # Fast path: identical strings
        if original_value == candidate_value:
            return (1.0, "exact match")

        # Try numeric comparison first
        orig_num = self._extract_numeric(original_value)
        cand_num = self._extract_numeric(candidate_value)

        if orig_num is not None and cand_num is not None:
            tolerance = TOLERANCE_RANGES.get(attr_name)

            # For pressure_rating the candidate must meet or exceed the original.
            if attr_name == "pressure_rating":
                if cand_num >= orig_num:
                    return (1.0, f"meets or exceeds: {candidate_value} >= {original_value}")
                else:
                    return (0.0, f"mismatch: {original_value} vs {candidate_value}")

            if orig_num == 0:
                # Avoid division by zero — must match exactly.
                if cand_num == 0:
                    return (1.0, "exact match")
                return (0.0, f"mismatch: {original_value} vs {candidate_value}")

            relative_diff = abs(orig_num - cand_num) / abs(orig_num)

            if tolerance is not None:
                if tolerance == 0.0:
                    # Must be exact (no tolerance)
                    if relative_diff == 0.0:
                        return (1.0, "exact match")
                    return (0.0, f"mismatch: {original_value} vs {candidate_value}")

                if relative_diff <= tolerance:
                    return (
                        1.0 - (relative_diff / tolerance) * 0.2,
                        f"within tolerance: {original_value} vs {candidate_value}",
                    )
                else:
                    # Beyond tolerance — proportional penalty, capped at 0.
                    score = max(0.0, 1.0 - relative_diff)
                    return (
                        score,
                        f"mismatch: {original_value} vs {candidate_value}",
                    )
            else:
                # No explicit tolerance entry — use a general 10% tolerance.
                if relative_diff <= 0.10:
                    return (
                        1.0 - (relative_diff / 0.10) * 0.2,
                        f"within tolerance: {original_value} vs {candidate_value}",
                    )
                score = max(0.0, 1.0 - relative_diff)
                return (score, f"mismatch: {original_value} vs {candidate_value}")

        # Case-insensitive text comparison
        if original_value.strip().lower() == candidate_value.strip().lower():
            return (1.0, "exact match")

        return (0.0, f"mismatch: {original_value} vs {candidate_value}")

    # ------------------------------------------------------------------
    # Recommendation narrative
    # ------------------------------------------------------------------

    def _generate_recommendation_reason(
        self,
        original_name: str,
        candidate_name: str,
        compatibility_score: float,
        matched: List[dict],
        mismatched: List[dict],
        critical_diffs: List[dict],
    ) -> str:
        """Generate a human-readable explanation of why *candidate_name* is
        recommended as a replacement for *original_name*."""

        parts: List[str] = []

        # Headline ----------------------------------------------------------
        if compatibility_score >= 0.95:
            parts.append("Compatible replacement:")
        elif compatibility_score >= 0.80:
            parts.append("Close replacement:")
        elif compatibility_score >= 0.60:
            parts.append("Partial replacement:")
        else:
            parts.append("Low compatibility:")

        # Matched critical attributes ----------------------------------------
        critical_matches = [
            m for m in matched if m.get("tier") == "critical"
        ]
        if critical_matches:
            match_phrases = []
            for m in critical_matches:
                attr = m["attribute"].replace("_", " ")
                val = m.get("candidate_value", m.get("original_value", ""))
                match_phrases.append(f"Same {attr} ({val})")
            parts.append(", ".join(match_phrases) + ".")

        # Important matches --------------------------------------------------
        important_matches = [
            m for m in matched if m.get("tier") == "important"
        ]
        if important_matches:
            imp_phrases = []
            for m in important_matches:
                attr = m["attribute"].replace("_", " ")
                orig_val = m.get("original_value", "")
                cand_val = m.get("candidate_value", "")
                if orig_val == cand_val:
                    imp_phrases.append(f"Same {attr} ({cand_val})")
                else:
                    imp_phrases.append(
                        f"{attr.capitalize()}: {cand_val} vs {orig_val}"
                    )
            parts.append(" ".join(imp_phrases) + ".")

        # Critical differences -----------------------------------------------
        if critical_diffs:
            diff_phrases = []
            for d in critical_diffs:
                attr = d["attribute"].replace("_", " ")
                orig_val = d.get("original_value", "?")
                cand_val = d.get("candidate_value", "missing")
                diff_phrases.append(
                    f"{attr.capitalize()} differs: {orig_val} vs {cand_val}"
                )
            parts.append(" ".join(diff_phrases) + ".")

        # Non-critical mismatches (brief mention) ----------------------------
        non_critical_mismatches = [
            m for m in mismatched
            if m.get("tier") != "critical"
        ]
        if non_critical_mismatches:
            attrs = [m["attribute"].replace("_", " ") for m in non_critical_mismatches]
            if len(attrs) <= 3:
                parts.append(
                    "Minor differences in " + ", ".join(attrs) + "."
                )
            else:
                parts.append(
                    f"Minor differences in {', '.join(attrs[:3])} and "
                    f"{len(attrs) - 3} other attribute(s)."
                )

        return " ".join(parts)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_numeric(self, value: str) -> Optional[float]:
        """Extract the first numeric value from a string.

        Examples
        --------
        >>> _extract_numeric("7.5 kW")
        7.5
        >>> _extract_numeric("1,450 rpm")
        1450.0
        >>> _extract_numeric("N/A")
        None
        """
        if value is None:
            return None

        # Remove commas used as thousands separators (e.g. "1,450" -> "1450")
        cleaned = value.replace(",", "")

        # Walk through looking for the first valid numeric token, including
        # an optional leading minus sign.
        buf: List[str] = []
        found_digit = False
        found_dot = False

        for ch in cleaned:
            if ch == "-" and not buf:
                buf.append(ch)
            elif ch.isdigit():
                buf.append(ch)
                found_digit = True
            elif ch == "." and not found_dot and found_digit:
                buf.append(ch)
                found_dot = True
            elif ch == "." and not found_dot and not found_digit:
                # Leading dot like ".5" — allow it.
                buf.append(ch)
                found_dot = True
            elif found_digit:
                # We've collected digits and hit a non-numeric char → done.
                break
            else:
                # Haven't found digits yet — reset.
                buf.clear()
                found_dot = False

        if not found_digit:
            return None

        try:
            return float("".join(buf))
        except ValueError:
            return None

    # ------------------------------------------------------------------

    def _detect_category(self, product: dict) -> str:
        """Best-effort category detection from product attributes."""

        # Check if the product explicitly declares a category.
        explicit = product.get("category", "").strip().lower()
        if explicit and explicit in CATEGORY_CRITICAL_ATTRIBUTES:
            return explicit

        # Fall back to checking which category's critical attributes appear
        # most often in the product.
        best_category = "default"
        best_overlap = 0

        for cat, groups in CATEGORY_CRITICAL_ATTRIBUTES.items():
            if cat == "default":
                continue
            all_attrs = (
                groups.get("critical", [])
                + groups.get("important", [])
                + groups.get("optional", [])
            )
            overlap = sum(1 for a in all_attrs if a in product)
            if overlap > best_overlap:
                best_overlap = overlap
                best_category = cat

        return best_category


# ---------------------------------------------------------------------------
# Module-level convenience instance
# ---------------------------------------------------------------------------

replacement_finder = ReplacementFinder()
