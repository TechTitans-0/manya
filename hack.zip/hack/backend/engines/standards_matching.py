"""
Standards Matching Engine for IntelliSpec Platform.

Matches products to real industrial standards (UNSPSC, eCl@ss, ETIM)
using verified reference data. This engine NEVER fabricates or hallucates
codes. If no verified match is found, it clearly states
"classification unavailable."
"""

import json
import os
import re
from typing import Dict, List, Any, Optional


class StandardsMatchingEngine:
    """
    Matches products to industrial classification standards using only
    verified reference data loaded from curated JSON files.
    """

    # Words too common to be useful for keyword matching
    STOP_WORDS = frozenset({
        "a", "an", "the", "and", "or", "but", "in", "on", "at", "to",
        "for", "of", "with", "by", "from", "is", "it", "as", "be",
        "was", "are", "been", "being", "have", "has", "had", "do",
        "does", "did", "will", "would", "could", "should", "may",
        "might", "shall", "can", "not", "no", "nor", "so", "if",
        "then", "than", "too", "very", "just", "about", "above",
        "after", "again", "all", "also", "any", "because", "before",
        "between", "both", "each", "few", "more", "most", "other",
        "our", "out", "over", "own", "same", "some", "such", "that",
        "these", "this", "those", "through", "under", "until", "up",
        "we", "what", "when", "where", "which", "while", "who", "whom",
        "why", "how", "its", "into", "only", "per", "type", "etc",
        "product", "item", "general", "standard", "class", "group",
    })

    MATCH_THRESHOLD = 0.6

    def __init__(self) -> None:
        """
        Load reference data from JSON files.

        Expected files live under ``backend/data/standards/``:
        - ``unspsc.json``
        - ``eclass.json``
        - ``etim.json``

        If a file does not exist the corresponding dataset is initialised
        as an empty list and ``self.available`` is set to ``False``.
        """
        data_dir = os.path.join(
            os.path.dirname(__file__), '..', 'data', 'standards'
        )

        self.unspsc_data: List[Dict[str, Any]] = self._load_json(
            os.path.join(data_dir, 'unspsc.json')
        )
        self.eclass_data: List[Dict[str, Any]] = self._load_json(
            os.path.join(data_dir, 'eclass.json')
        )
        self.etim_data: List[Dict[str, Any]] = self._load_json(
            os.path.join(data_dir, 'etim.json')
        )

        # Engine is only fully available when at least one dataset loaded
        self.available: bool = bool(
            self.unspsc_data or self.eclass_data or self.etim_data
        )

    # ------------------------------------------------------------------
    # Public matching methods
    # ------------------------------------------------------------------

    def match_unspsc(
        self,
        category: str,
        product_name: str,
        attributes: dict,
    ) -> dict:
        """Match a product to a UNSPSC code using verified reference data."""
        return self._match_standard(
            standard_type="unspsc",
            reference_data=self.unspsc_data,
            category=category,
            product_name=product_name,
            attributes=attributes,
        )

    def match_eclass(
        self,
        category: str,
        product_name: str,
        attributes: dict,
    ) -> dict:
        """Match a product to an eCl@ss code using verified reference data."""
        return self._match_standard(
            standard_type="eclass",
            reference_data=self.eclass_data,
            category=category,
            product_name=product_name,
            attributes=attributes,
        )

    def match_etim(
        self,
        category: str,
        product_name: str,
        attributes: dict,
    ) -> dict:
        """Match a product to an ETIM code using verified reference data."""
        return self._match_standard(
            standard_type="etim",
            reference_data=self.etim_data,
            category=category,
            product_name=product_name,
            attributes=attributes,
        )

    def match_all_standards(
        self,
        category: str,
        product_name: str,
        attributes: dict,
    ) -> List[dict]:
        """
        Run all three standard matchers and return every result
        (including unavailable ones).
        """
        return [
            self.match_unspsc(category, product_name, attributes),
            self.match_eclass(category, product_name, attributes),
            self.match_etim(category, product_name, attributes),
        ]

    def search_standards(
        self,
        query: str,
        standard_type: Optional[str] = None,
    ) -> List[dict]:
        """
        Search reference data by a free-text *query*.

        Parameters
        ----------
        query : str
            Free-text search string.
        standard_type : str, optional
            Restrict search to ``"unspsc"``, ``"eclass"``, or ``"etim"``.
            When ``None`` all datasets are searched.

        Returns
        -------
        list[dict]
            Top matches sorted by descending score.
        """
        query_keywords = self._tokenise(query)
        if not query_keywords:
            return []

        datasets: List[tuple] = []
        if standard_type is None or standard_type == "unspsc":
            datasets.append(("unspsc", self.unspsc_data))
        if standard_type is None or standard_type == "eclass":
            datasets.append(("eclass", self.eclass_data))
        if standard_type is None or standard_type == "etim":
            datasets.append(("etim", self.etim_data))

        results: List[dict] = []
        for std_type, data in datasets:
            for entry in data:
                description = entry.get("description", "")
                score = self._keyword_score(query_keywords, description)
                if score > 0.0:
                    results.append({
                        "standard_type": std_type,
                        "standard_code": entry.get("code"),
                        "standard_description": description,
                        "match_score": round(score, 4),
                    })

        results.sort(key=lambda r: r["match_score"], reverse=True)
        return results[:20]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _match_standard(
        self,
        standard_type: str,
        reference_data: List[Dict[str, Any]],
        category: str,
        product_name: str,
        attributes: dict,
    ) -> dict:
        """
        Core matching logic shared by all three standard matchers.

        Matching strategy (in order of priority):
        1. **Exact category keyword match** – the category string is
           compared directly against reference descriptions.
        2. **Broader keyword match** – keywords extracted from the
           product name and attributes are scored against each
           reference entry.
        3. If no match exceeds the confidence threshold (0.6) the
           result clearly states "classification unavailable".
        """
        unavailable_label = {
            "unspsc": "UNSPSC",
            "eclass": "eCl@ss",
            "etim": "ETIM",
        }.get(standard_type, standard_type.upper())

        unavailable = {
            "standard_type": standard_type,
            "standard_code": None,
            "standard_description": None,
            "match_confidence": 0.0,
            "match_method": None,
            "match_explanation": (
                f"Classification unavailable: no verified {unavailable_label} "
                f"code found for this product category. The system only "
                f"assigns codes from verified reference data."
            ),
            "verified": False,
        }

        if not reference_data:
            return unavailable

        # --- Step 1: exact category keyword match -------------------------
        category_lower = category.strip().lower()
        best_exact: Optional[Dict[str, Any]] = None
        best_exact_score: float = 0.0

        for entry in reference_data:
            description = entry.get("description", "").lower()
            if category_lower and category_lower in description:
                # Weight by how large a proportion the category covers
                score = len(category_lower) / max(len(description), 1)
                score = min(score, 1.0)
                if score > best_exact_score:
                    best_exact_score = score
                    best_exact = entry

        if best_exact is not None and best_exact_score >= self.MATCH_THRESHOLD:
            return {
                "standard_type": standard_type,
                "standard_code": best_exact.get("code"),
                "standard_description": best_exact.get("description"),
                "match_confidence": round(best_exact_score, 4),
                "match_method": "exact_lookup",
                "match_explanation": (
                    f"Exact category match found in verified "
                    f"{unavailable_label} reference data."
                ),
                "verified": True,
            }

        # --- Step 2: broader keyword matching -----------------------------
        keywords = self._extract_keywords(category, product_name, attributes)

        if not keywords:
            return unavailable

        best_kw: Optional[Dict[str, Any]] = None
        best_kw_score: float = 0.0

        for entry in reference_data:
            description = entry.get("description", "")
            score = self._keyword_score(keywords, description)
            if score > best_kw_score:
                best_kw_score = score
                best_kw = entry

        if best_kw is not None and best_kw_score >= self.MATCH_THRESHOLD:
            return {
                "standard_type": standard_type,
                "standard_code": best_kw.get("code"),
                "standard_description": best_kw.get("description"),
                "match_confidence": round(best_kw_score, 4),
                "match_method": "keyword_match",
                "match_explanation": (
                    f"Keyword-based match found in verified "
                    f"{unavailable_label} reference data "
                    f"(confidence {round(best_kw_score * 100, 1)}%)."
                ),
                "verified": False,
            }

        # --- Step 3: no match above threshold -----------------------------
        return unavailable

    def _keyword_score(
        self,
        keywords: List[str],
        reference_text: str,
    ) -> float:
        """
        Calculate the overlap between product *keywords* and a
        *reference_text* description.

        Score = matched_keywords / total_keywords  (case-insensitive).

        Returns a float in the range [0.0, 1.0].
        """
        if not keywords:
            return 0.0

        ref_lower = reference_text.lower()
        matched = sum(1 for kw in keywords if kw.lower() in ref_lower)
        return matched / len(keywords)

    def _extract_keywords(
        self,
        category: str,
        product_name: str,
        attributes: dict,
    ) -> List[str]:
        """
        Extract meaningful keywords from product information.

        * Splits *category* and *product_name* into individual words.
        * Adds attribute names and values.
        * Removes common stop words and very short tokens.

        Returns a deduplicated list of lowercase keyword strings.
        """
        raw_tokens: List[str] = []

        # Tokenise category and product name
        raw_tokens.extend(self._tokenise(category))
        raw_tokens.extend(self._tokenise(product_name))

        # Tokenise attribute keys and values
        if attributes:
            for key, value in attributes.items():
                raw_tokens.extend(self._tokenise(str(key)))
                raw_tokens.extend(self._tokenise(str(value)))

        # Deduplicate while preserving rough insertion order
        seen: set = set()
        keywords: List[str] = []
        for token in raw_tokens:
            if token not in seen:
                seen.add(token)
                keywords.append(token)

        return keywords

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_json(path: str) -> List[Dict[str, Any]]:
        """Load a JSON file and return its contents, or ``[]`` on failure."""
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
                if isinstance(data, list):
                    return data
                return []
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return []

    def _tokenise(self, text: str) -> List[str]:
        """
        Split *text* into lowercase tokens, stripping non-alphanumeric
        characters and removing stop words / very short tokens.
        """
        if not text:
            return []
        tokens = re.split(r'[\s\-_/,;:.()\[\]{}]+', text.lower())
        return [
            t for t in tokens
            if len(t) > 1 and t not in self.STOP_WORDS
        ]


# Module-level singleton instance
standards_engine = StandardsMatchingEngine()
