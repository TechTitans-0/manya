import json
import os
from typing import Dict, List, Any, Optional


STANDARD_BEARING_TABLE = {
    "6200": {"bore": 10, "od": 30, "width": 9},
    "6201": {"bore": 12, "od": 32, "width": 10},
    "6202": {"bore": 15, "od": 35, "width": 11},
    "6203": {"bore": 17, "od": 40, "width": 12},
    "6204": {"bore": 20, "od": 47, "width": 14},
    "6205": {"bore": 25, "od": 52, "width": 15},
    "6206": {"bore": 30, "od": 62, "width": 16},
    "6207": {"bore": 35, "od": 72, "width": 17},
    "6208": {"bore": 40, "od": 80, "width": 18},
    "6209": {"bore": 45, "od": 85, "width": 19},
    "6210": {"bore": 50, "od": 90, "width": 20},
    "6305": {"bore": 25, "od": 62, "width": 17},
    "6306": {"bore": 30, "od": 72, "width": 19},
    "6307": {"bore": 35, "od": 80, "width": 21},
    "6308": {"bore": 40, "od": 90, "width": 23},
}

DEFAULT_CATEGORY_SCHEMAS = {
    "motors": [
        "manufacturer", "model_number", "part_number", "voltage", "power",
        "current", "speed", "frequency", "frame_size", "efficiency_class",
        "ip_rating", "mounting_type", "phase", "poles", "insulation_class",
        "weight",
    ],
    "bearings": [
        "manufacturer", "part_number", "bore_diameter", "outer_diameter",
        "width", "bearing_type", "dynamic_load_rating", "static_load_rating",
        "max_speed", "seal_type", "material", "weight",
    ],
    "pumps": [
        "manufacturer", "model_number", "pump_type", "flow_rate", "head",
        "power", "voltage", "frequency", "connection_size", "material",
        "ip_rating", "weight",
    ],
    "valves": [
        "manufacturer", "model_number", "valve_type", "size",
        "pressure_rating", "connection_type", "material", "temperature_range",
        "media", "actuator_type",
    ],
    "sensors": [
        "manufacturer", "model_number", "sensor_type", "measurement_range",
        "output_signal", "supply_voltage", "accuracy", "response_time",
        "ip_rating", "connection_type",
    ],
    "electrical": [
        "manufacturer", "model_number", "type", "voltage", "current",
        "breaking_capacity", "poles", "mounting_type", "ip_rating",
    ],
    "default": [
        "manufacturer", "model_number", "part_number", "category",
        "description", "voltage", "power", "weight", "dimensions",
    ],
}


class EnrichmentEngine:
    """Engine that fills in missing product attributes using inference and reference data."""

    def __init__(self):
        self.category_schemas: Dict[str, List[str]] = {}
        self._load_category_schemas()

    # ------------------------------------------------------------------
    # Schema loading
    # ------------------------------------------------------------------

    def _load_category_schemas(self):
        """Load category schemas from data/category_schemas/*.json if available."""
        schema_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data",
            "category_schemas",
        )
        if os.path.isdir(schema_dir):
            for filename in os.listdir(schema_dir):
                if filename.endswith(".json"):
                    filepath = os.path.join(schema_dir, filename)
                    try:
                        with open(filepath, "r", encoding="utf-8") as fh:
                            schema = json.load(fh)
                        category_name = os.path.splitext(filename)[0]
                        self.category_schemas[category_name] = schema
                    except (json.JSONDecodeError, IOError):
                        pass

    def _get_category_schema(self, category: str) -> dict:
        """Return the attribute schema for the given category.

        Falls back to DEFAULT_CATEGORY_SCHEMAS if no JSON file was loaded.
        """
        cat_key = category.lower().strip()

        if cat_key in self.category_schemas:
            return self.category_schemas[cat_key]

        if cat_key in DEFAULT_CATEGORY_SCHEMAS:
            return DEFAULT_CATEGORY_SCHEMAS[cat_key]

        return DEFAULT_CATEGORY_SCHEMAS["default"]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_missing_attributes(self, product_data: dict, category: str) -> List[str]:
        """Compare product attributes against the category schema.

        Returns:
            List of attribute names that are present in the schema but missing
            (or empty) in *product_data*.
        """
        schema_attrs = self._get_category_schema(category)
        if isinstance(schema_attrs, dict):
            schema_attrs = list(schema_attrs.keys())

        missing: List[str] = []
        for attr in schema_attrs:
            value = product_data.get(attr)
            if value is None or (isinstance(value, str) and not value.strip()):
                missing.append(attr)
        return missing

    async def enrich_product(
        self,
        product_data: dict,
        category: str,
        groq_service=None,
    ) -> dict:
        """Enrich a product record by filling in missing attributes.

        Steps:
            1. Identify missing attributes based on the category schema.
            2. Apply deterministic (rule-based) enrichment.
            3. If *groq_service* is provided, use LLM-based semantic enrichment
               for any remaining gaps.

        Returns:
            Dict with *enriched_attributes* and *enrichment_summary*.
        """
        missing_attrs = self.get_missing_attributes(product_data, category)

        enriched_attributes: Dict[str, dict] = {}

        # --- Step 1: deterministic enrichment ---
        deterministic = self._deterministic_enrichment(product_data, category)
        for attr_name, attr_info in deterministic.items():
            if attr_name in missing_attrs:
                enriched_attributes[attr_name] = attr_info
                missing_attrs.remove(attr_name)

        # --- Step 2: LLM-based enrichment for remaining gaps ---
        if groq_service is not None and missing_attrs:
            try:
                llm_enriched = await self._llm_enrichment(
                    product_data, category, missing_attrs, groq_service,
                )
                for attr_name, attr_info in llm_enriched.items():
                    if attr_name in missing_attrs:
                        enriched_attributes[attr_name] = attr_info
                        missing_attrs.remove(attr_name)
            except Exception:
                pass  # LLM enrichment is best-effort

        enrichment_summary = {
            "total_missing_before": len(self.get_missing_attributes(product_data, category)),
            "total_enriched": len(enriched_attributes),
            "still_missing": missing_attrs,
            "enrichment_sources": list(
                {v.get("source", "unknown") for v in enriched_attributes.values()}
            ),
        }

        return {
            "enriched_attributes": enriched_attributes,
            "enrichment_summary": enrichment_summary,
        }

    # ------------------------------------------------------------------
    # Deterministic enrichment rules
    # ------------------------------------------------------------------

    def _deterministic_enrichment(self, product_data: dict, category: str) -> dict:
        """Apply rule-based enrichment for known attribute derivations.

        Returns:
            Dict mapping attribute_name -> {value, source, confidence, reason}.
        """
        enriched: Dict[str, dict] = {}
        cat = category.lower().strip()

        # ----- Motor rules -----
        if cat == "motors":
            enriched.update(self._enrich_motor(product_data))

        # ----- Bearing rules -----
        if cat == "bearings":
            enriched.update(self._enrich_bearing(product_data))

        # ----- General rules -----
        enriched.update(self._enrich_general(product_data, cat))

        return enriched

    def _enrich_motor(self, data: dict) -> dict:
        enriched: Dict[str, dict] = {}

        voltage = self._to_float(data.get("voltage"))
        frequency = self._to_float(data.get("frequency"))
        power = self._to_float(data.get("power"))
        current = self._to_float(data.get("current"))
        poles = self._to_float(data.get("poles"))

        # Rule: 415V systems commonly use 50 Hz
        if voltage is not None and frequency is None:
            if 400 <= voltage <= 440:
                enriched["frequency"] = {
                    "value": "50 Hz",
                    "source": "deterministic_rule",
                    "confidence": 0.90,
                    "reason": "415V supply systems commonly operate at 50 Hz.",
                }

        # Rule: derive current from power and voltage  I = P / (V × PF × √3)
        if power is not None and voltage is not None and current is None:
            pf = 0.85
            sqrt3 = 1.7320508075688772
            derived_current = power * 1000 / (voltage * pf * sqrt3)
            enriched["current"] = {
                "value": f"{derived_current:.2f} A",
                "source": "deterministic_rule",
                "confidence": 0.80,
                "reason": (
                    f"Calculated as I = P / (V × PF × √3) with PF assumed 0.85. "
                    f"P={power} kW, V={voltage} V."
                ),
            }

        # Rule: synchronous speed from frequency and poles
        if frequency is not None and poles is not None and poles > 0:
            sync_speed = 120 * frequency / poles
            if data.get("speed") is None or (isinstance(data.get("speed"), str) and not data["speed"].strip()):
                enriched["speed"] = {
                    "value": f"{int(sync_speed)} RPM",
                    "source": "deterministic_rule",
                    "confidence": 0.85,
                    "reason": (
                        f"Synchronous speed = 120 × f / P = 120 × {frequency} / {int(poles)} "
                        f"= {int(sync_speed)} RPM."
                    ),
                }

        return enriched

    def _enrich_bearing(self, data: dict) -> dict:
        enriched: Dict[str, dict] = {}
        part_number = str(data.get("part_number", "")).strip()

        if part_number in STANDARD_BEARING_TABLE:
            bearing = STANDARD_BEARING_TABLE[part_number]

            if not data.get("bore_diameter"):
                enriched["bore_diameter"] = {
                    "value": f"{bearing['bore']} mm",
                    "source": "deterministic_rule",
                    "confidence": 0.99,
                    "reason": f"Derived from standard bearing table for part {part_number}.",
                }
            if not data.get("outer_diameter"):
                enriched["outer_diameter"] = {
                    "value": f"{bearing['od']} mm",
                    "source": "deterministic_rule",
                    "confidence": 0.99,
                    "reason": f"Derived from standard bearing table for part {part_number}.",
                }
            if not data.get("width"):
                enriched["width"] = {
                    "value": f"{bearing['width']} mm",
                    "source": "deterministic_rule",
                    "confidence": 0.99,
                    "reason": f"Derived from standard bearing table for part {part_number}.",
                }

        return enriched

    def _enrich_general(self, data: dict, category: str) -> dict:
        enriched: Dict[str, dict] = {}

        # Default IP rating for motors
        if category == "motors" and not data.get("ip_rating"):
            enriched["ip_rating"] = {
                "value": "IP55",
                "source": "deterministic_rule",
                "confidence": 0.75,
                "reason": "IP55 is the most common IP rating for industrial motors.",
            }

        return enriched

    # ------------------------------------------------------------------
    # LLM-based enrichment (best-effort)
    # ------------------------------------------------------------------

    async def _llm_enrichment(
        self,
        product_data: dict,
        category: str,
        missing_attrs: List[str],
        groq_service,
    ) -> dict:
        """Use an LLM service to infer missing attributes semantically."""
        prompt = (
            f"Given the following {category} product data:\n"
            f"{json.dumps(product_data, indent=2)}\n\n"
            f"Infer reasonable values for these missing attributes: {missing_attrs}\n"
            "Return a JSON object mapping each attribute name to its inferred value. "
            "Only include attributes you are reasonably confident about."
        )

        response = await groq_service.generate(prompt)

        try:
            inferred = json.loads(response) if isinstance(response, str) else response
        except (json.JSONDecodeError, TypeError):
            return {}

        enriched: Dict[str, dict] = {}
        for attr, value in inferred.items():
            if attr in missing_attrs and value:
                enriched[attr] = {
                    "value": str(value),
                    "source": "llm_inference",
                    "confidence": 0.60,
                    "reason": f"Inferred by LLM based on available product data for {category}.",
                }

        return enriched

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_float(value) -> Optional[float]:
        """Attempt to extract a numeric float from a value."""
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        import re
        match = re.search(r"[-+]?\d*\.?\d+", str(value))
        if match:
            try:
                return float(match.group())
            except ValueError:
                return None
        return None


# Module-level singleton
enrichment_engine = EnrichmentEngine()
