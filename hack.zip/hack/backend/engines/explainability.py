import json
from typing import Dict, List, Any, Optional


class ExplainabilityEngine:
    """Generates human-readable explanations for AI decisions."""

    def explain_value_selection(self, attribute_name: str, final_value: str,
                                 sources: List[dict], conflicts: List[dict] = None) -> str:
        if not sources:
            return f"No source evidence available for {attribute_name}."
        if len(sources) == 1:
            src = sources[0]
            return (f"{attribute_name} set to '{final_value}' based on {src.get('source_type', 'unknown')} "
                    f"source '{src.get('source_name', 'unknown')}' (trust: {src.get('trust_score', 0):.2f}).")
        agreeing = [s for s in sources if self._values_match(s.get('source_value', ''), final_value)]
        disagreeing = [s for s in sources if not self._values_match(s.get('source_value', ''), final_value)]
        parts = [f"{attribute_name} set to '{final_value}'."]
        if agreeing:
            agree_desc = ", ".join([f"{s.get('source_name', s.get('source_type', 'unknown'))} "
                                    f"(trust: {s.get('trust_score', 0):.2f})" for s in agreeing])
            parts.append(f"Supported by: {agree_desc}.")
        if disagreeing:
            for s in disagreeing:
                parts.append(f"Conflicts with {s.get('source_name', s.get('source_type', 'unknown'))} "
                           f"which reports '{s.get('source_value', '?')}' (trust: {s.get('trust_score', 0):.2f}).")
        if agreeing and disagreeing:
            max_agree_trust = max(s.get('trust_score', 0) for s in agreeing)
            max_disagree_trust = max(s.get('trust_score', 0) for s in disagreeing)
            if max_agree_trust > max_disagree_trust:
                parts.append(f"Selected '{final_value}' because higher-trust sources agree on this value.")
            else:
                parts.append(f"Selected '{final_value}' based on majority source agreement despite a higher-trust conflicting source. Manual review recommended.")
        return " ".join(parts)

    def explain_validation_result(self, result: dict) -> str:
        status = result.get('status', 'unknown')
        message = result.get('message', '')
        details = result.get('details', {})
        if status == 'valid':
            return f"Passed validation: {message}"
        prefix = "WARNING" if status == 'warning' else "CONFLICT" if status == 'conflict' else "INFO"
        explanation = f"[{prefix}] {message}"
        if details:
            if 'expected' in details and 'actual' in details:
                explanation += f" Expected: {details['expected']}, Found: {details['actual']}."
            if 'calculation' in details:
                explanation += f" Calculation: {details['calculation']}."
        return explanation

    def explain_enrichment(self, attribute_name: str, enriched_value: str,
                           source: str, confidence: float, reason: str) -> str:
        conf_label = "high" if confidence > 0.8 else "medium" if confidence > 0.5 else "low"
        return (f"{attribute_name} enriched to '{enriched_value}' ({conf_label} confidence: {confidence:.2f}). "
                f"Source: {source}. Reason: {reason}")

    def explain_standards_match(self, match: dict) -> str:
        if not match.get('standard_code'):
            return (f"{match.get('standard_type', 'Standard').upper()} classification unavailable. "
                    f"{match.get('match_explanation', 'No verified code found for this product.')}")
        verified = "verified" if match.get('verified', False) else "unverified (keyword match)"
        return (f"Matched to {match.get('standard_type', '').upper()} code {match['standard_code']}: "
                f"'{match.get('standard_description', '')}'. "
                f"Confidence: {match.get('match_confidence', 0):.2f}. "
                f"Method: {match.get('match_method', 'unknown')} ({verified}). "
                f"{match.get('match_explanation', '')}")

    def explain_replacement(self, replacement: dict) -> str:
        score = replacement.get('compatibility_score', 0)
        matched = replacement.get('matched_attributes', [])
        critical = replacement.get('critical_differences', [])
        mismatched = replacement.get('mismatched_attributes', [])
        parts = [f"Compatibility: {score:.0%}."]
        if matched:
            match_names = [m.get('attribute', m) if isinstance(m, dict) else str(m) for m in matched[:5]]
            parts.append(f"Matches: {', '.join(match_names)}.")
        if critical:
            crit_desc = [f"{c.get('attribute', '?')}: {c.get('original', '?')} vs {c.get('replacement', '?')}"
                        if isinstance(c, dict) else str(c) for c in critical]
            parts.append(f"Critical differences: {'; '.join(crit_desc)}.")
        if mismatched and not critical:
            mis_names = [m.get('attribute', m) if isinstance(m, dict) else str(m) for m in mismatched[:3]]
            parts.append(f"Minor differences in: {', '.join(mis_names)}.")
        reason = replacement.get('recommendation_reason', '')
        if reason:
            parts.append(reason)
        return " ".join(parts)

    def explain_confidence(self, confidence: float, sources_count: int,
                           validation_pass: bool, has_conflicts: bool) -> str:
        level = "high" if confidence > 0.8 else "medium" if confidence > 0.5 else "low"
        parts = [f"Overall confidence: {confidence:.2f} ({level})."]
        parts.append(f"Based on {sources_count} source(s).")
        if validation_pass:
            parts.append("All engineering validations passed.")
        else:
            parts.append("Some engineering validations raised concerns.")
        if has_conflicts:
            parts.append("Conflicting values detected from different sources — manual review recommended.")
        return " ".join(parts)

    def generate_before_after_explanation(self, attribute_name: str, original_value: str,
                                          new_value: str, reason: str, confidence: float) -> str:
        if original_value == new_value:
            return f"{attribute_name}: Value unchanged ('{original_value}'). Confirmed by validation."
        if not original_value:
            return (f"{attribute_name}: New value '{new_value}' discovered during enrichment. "
                    f"Confidence: {confidence:.2f}. {reason}")
        return (f"{attribute_name}: Changed from '{original_value}' to '{new_value}'. "
                f"Confidence: {confidence:.2f}. {reason}")

    def _values_match(self, val1: str, val2: str) -> bool:
        if not val1 or not val2:
            return False
        return val1.strip().lower() == val2.strip().lower()


explainability_engine = ExplainabilityEngine()
