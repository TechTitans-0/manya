import os
import re
import json
import base64
import uuid
import csv
import io
from typing import Dict, List, Any, Optional, Tuple

from PIL import Image

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

try:
    import pytesseract
except ImportError:
    pytesseract = None


class ExtractionEngine:
    """Engine for extracting product information from various input sources:
    images (nameplates/labels), PDFs, CSV files, and manual text input.
    """

    # -----------------------------------------------------------------
    # Standard header mappings: common CSV header variations -> canonical
    # -----------------------------------------------------------------
    HEADER_MAPPINGS: Dict[str, str] = {
        # Manufacturer
        "manufacturer": "manufacturer",
        "mfr": "manufacturer",
        "mfg": "manufacturer",
        "brand": "manufacturer",
        "make": "manufacturer",
        "vendor": "manufacturer",
        "supplier": "manufacturer",
        "oem": "manufacturer",
        # Part number
        "part_number": "part_number",
        "part number": "part_number",
        "part no": "part_number",
        "part no.": "part_number",
        "part_no": "part_number",
        "p/n": "part_number",
        "pn": "part_number",
        "partnumber": "part_number",
        "item number": "part_number",
        "item no": "part_number",
        "item no.": "part_number",
        "item_number": "part_number",
        "item #": "part_number",
        "catalog number": "part_number",
        "catalog no": "part_number",
        "catalog no.": "part_number",
        "cat no": "part_number",
        "cat no.": "part_number",
        "cat. no.": "part_number",
        "cat #": "part_number",
        # Model number
        "model_number": "model_number",
        "model number": "model_number",
        "model no": "model_number",
        "model no.": "model_number",
        "model": "model_number",
        "model_no": "model_number",
        # Name / description
        "name": "name",
        "product name": "name",
        "product_name": "name",
        "item name": "name",
        "item_name": "name",
        "description": "description",
        "desc": "description",
        "product description": "description",
        "product_description": "description",
        # Category
        "category": "category",
        "product category": "category",
        "product_category": "category",
        "type": "category",
        "product type": "category",
        "product_type": "category",
        # Voltage
        "voltage": "voltage",
        "rated voltage": "voltage",
        "rated_voltage": "voltage",
        "voltage (v)": "voltage",
        "volt": "voltage",
        "v": "voltage",
        # Current
        "current": "current",
        "rated current": "current",
        "rated_current": "current",
        "current (a)": "current",
        "amps": "current",
        # Power
        "power": "power",
        "rated power": "power",
        "rated_power": "power",
        "power (kw)": "power",
        "power (hp)": "power",
        "kw": "power",
        "hp": "power",
        "wattage": "power",
        # Speed / RPM
        "speed": "speed",
        "rpm": "speed",
        "rated speed": "speed",
        "rated_speed": "speed",
        "speed (rpm)": "speed",
        # Frequency
        "frequency": "frequency",
        "freq": "frequency",
        "frequency (hz)": "frequency",
        "hz": "frequency",
        # Weight
        "weight": "weight",
        "weight (kg)": "weight",
        "mass": "weight",
        "net weight": "weight",
        "net_weight": "weight",
        # IP rating
        "ip rating": "ip_rating",
        "ip_rating": "ip_rating",
        "protection": "ip_rating",
        "ip class": "ip_rating",
        "ip_class": "ip_rating",
        "enclosure": "ip_rating",
        # Temperature
        "temperature": "temperature",
        "temp": "temperature",
        "operating temperature": "temperature",
        "operating_temperature": "temperature",
        "ambient temperature": "temperature",
        "ambient_temperature": "temperature",
        # Frame size
        "frame": "frame_size",
        "frame size": "frame_size",
        "frame_size": "frame_size",
        # Efficiency
        "efficiency": "efficiency",
        "efficiency class": "efficiency",
        "efficiency_class": "efficiency",
        "ie class": "efficiency",
        "ie_class": "efficiency",
        # Dimensions
        "dimensions": "dimensions",
        "size": "dimensions",
        "l x w x h": "dimensions",
        # Pressure
        "pressure": "pressure",
        "pressure (bar)": "pressure",
        "pressure (psi)": "pressure",
        "rated pressure": "pressure",
        "rated_pressure": "pressure",
        # Flow rate
        "flow rate": "flow_rate",
        "flow_rate": "flow_rate",
        "flow": "flow_rate",
        "flow (l/min)": "flow_rate",
        "capacity": "flow_rate",
        # Bearing
        "bearing": "bearing",
        "bearing type": "bearing",
        "bearing_type": "bearing",
        "de bearing": "bearing_de",
        "nde bearing": "bearing_nde",
        # Material
        "material": "material",
        "housing material": "material",
        "body material": "material",
        # Connection
        "connection": "connection",
        "connection type": "connection",
        "connection_type": "connection",
        "port size": "connection",
        "port_size": "connection",
    }

    # ------------------------------------------------------------------
    # Compiled regex patterns for industrial product attribute extraction
    # ------------------------------------------------------------------
    _PATTERNS: Dict[str, re.Pattern] = {
        "voltage": re.compile(
            r"(?:voltage|rated\s*voltage|supply)[:\s]*"
            r"(\d{1,4}(?:\.\d+)?(?:\s*[-–/]\s*\d{1,4}(?:\.\d+)?)?)\s*V\b"
            r"|(\d{2,4}(?:\.\d+)?(?:\s*[-–/]\s*\d{2,4}(?:\.\d+)?)?)\s*V\b",
            re.IGNORECASE,
        ),
        "current": re.compile(
            r"(?:current|rated\s*current|full\s*load\s*current)[:\s]*"
            r"(\d{1,5}(?:\.\d+)?)\s*A\b"
            r"|(\d{1,5}(?:\.\d+)?)\s*A\b",
            re.IGNORECASE,
        ),
        "power": re.compile(
            r"(?:power|rated\s*power|output)[:\s]*"
            r"(\d{1,6}(?:\.\d+)?)\s*(?:kW|KW|kw)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:kW|KW|kw)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:HP|hp|Hp)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*W\b",
            re.IGNORECASE,
        ),
        "speed": re.compile(
            r"(?:speed|rated\s*speed)[:\s]*(\d{2,5})\s*(?:RPM|rpm|r/min|rev/min)\b"
            r"|(\d{3,5})\s*(?:RPM|rpm|r/min|rev/min)\b",
            re.IGNORECASE,
        ),
        "frequency": re.compile(
            r"(?:frequency|freq)[:\s]*"
            r"(\d{2,3}(?:\s*[/]\s*\d{2,3})?)\s*Hz\b"
            r"|(\d{2,3}(?:\s*[/]\s*\d{2,3})?)\s*Hz\b",
            re.IGNORECASE,
        ),
        "weight": re.compile(
            r"(?:weight|mass|net\s*weight)[:\s]*(\d{1,6}(?:\.\d+)?)\s*(?:kg|Kg|KG)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:kg|Kg|KG)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:lbs?|LBS?)\b",
            re.IGNORECASE,
        ),
        "ip_rating": re.compile(
            r"(?:IP|ip|Ip)\s*(\d{2}[A-Za-z]?)\b",
            re.IGNORECASE,
        ),
        "temperature": re.compile(
            r"(?:temperature|temp|ambient)[:\s]*"
            r"(-?\d{1,3}(?:\.\d+)?(?:\s*(?:to|[-–])\s*-?\d{1,3}(?:\.\d+)?)?)\s*°?\s*C\b"
            r"|(-?\d{1,3}(?:\.\d+)?(?:\s*(?:to|[-–])\s*-?\d{1,3}(?:\.\d+)?)?)\s*°\s*C\b",
            re.IGNORECASE,
        ),
        "frame_size": re.compile(
            r"(?:frame|frame\s*size)[:\s]*(\d{2,3}[A-Z]{0,3})\b"
            r"|frame\s+(\d{2,3}[A-Z]{0,3})\b",
            re.IGNORECASE,
        ),
        "efficiency": re.compile(
            r"(IE[1-5])\b"
            r"|(?:efficiency|eff)[:\s]*(\d{1,3}(?:\.\d+)?)\s*%",
            re.IGNORECASE,
        ),
        "dimensions": re.compile(
            r"(\d{1,5}(?:\.\d+)?\s*[xX×]\s*\d{1,5}(?:\.\d+)?"
            r"(?:\s*[xX×]\s*\d{1,5}(?:\.\d+)?)?)\s*(?:mm|MM|cm|CM|m\b|in\b)",
            re.IGNORECASE,
        ),
        "bearing": re.compile(
            r"(?:bearing)[:\s]*(\d{3,5}(?:\s*[-]\s*\d?[A-Z]{1,4})?)\b"
            r"|(\b\d{4,5}[-][A-Z0-9]{1,4}\b)",
            re.IGNORECASE,
        ),
        "pressure": re.compile(
            r"(?:pressure|rated\s*pressure)[:\s]*"
            r"(\d{1,6}(?:\.\d+)?)\s*(?:bar|Bar|BAR)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:PSI|psi|Psi)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:MPa|mpa)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:kPa|KPA|kpa)\b",
            re.IGNORECASE,
        ),
        "flow_rate": re.compile(
            r"(?:flow\s*rate|flow|capacity)[:\s]*"
            r"(\d{1,6}(?:\.\d+)?)\s*(?:l/min|L/min|lpm|LPM)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:m³/h|m3/h|CMH|cmh)\b"
            r"|(\d{1,6}(?:\.\d+)?)\s*(?:GPM|gpm)\b",
            re.IGNORECASE,
        ),
        "manufacturer": re.compile(
            r"(?:manufacturer|brand|make|mfr|mfg|oem)[:\s]*([A-Za-z][A-Za-z0-9\s&.'-]{1,50})",
            re.IGNORECASE,
        ),
        "model_number": re.compile(
            r"(?:model|model\s*no\.?|model\s*number|type)[:\s]*"
            r"([A-Za-z]{1,10}[\s-]?[A-Za-z0-9]{1,20}(?:[\s/-][A-Za-z0-9]{1,20})*)",
            re.IGNORECASE,
        ),
        "part_number": re.compile(
            r"(?:part\s*no\.?|part\s*number|p/n|cat\.?\s*no\.?|catalog\s*no\.?|item\s*no\.?)"
            r"[:\s]*([A-Za-z0-9][\w\-/.]{2,30})",
            re.IGNORECASE,
        ),
    }

    # ------------------------------------------------------------------

    def __init__(self) -> None:
        """Initialize the extraction engine and check availability of
        optional OCR / PDF tools."""
        self.ocr_available: bool = pytesseract is not None
        self.pdf_available: bool = fitz is not None

        if not self.ocr_available:
            print(
                "[ExtractionEngine] pytesseract not installed – "
                "OCR fallback disabled."
            )
        if not self.pdf_available:
            print(
                "[ExtractionEngine] PyMuPDF (fitz) not installed – "
                "PDF extraction disabled."
            )

    # ==================================================================
    # Public extraction methods
    # ==================================================================

    async def extract_from_image(
        self, image_path: str, groq_service=None
    ) -> dict:
        """Extract product information from an image (nameplate / label).

        Tries Groq vision first, then falls back to Tesseract OCR with
        regex-based attribute extraction.
        """

        # --- Attempt AI-powered vision extraction ----------------------
        if groq_service is not None and hasattr(groq_service, "extract_from_image"):
            try:
                with open(image_path, "rb") as f:
                    image_bytes = f.read()
                image_b64 = base64.b64encode(image_bytes).decode("utf-8")
                result = await groq_service.extract_from_image(image_b64)
                if result:
                    return {
                        "raw_text": result.get("raw_text", ""),
                        "extracted_attributes": result.get(
                            "extracted_attributes", {}
                        ),
                        "source_type": "nameplate",
                        "extraction_method": "llm_vision",
                    }
            except Exception as exc:
                print(
                    f"[ExtractionEngine] Groq vision extraction failed: {exc}"
                )

        # --- Fallback: Tesseract OCR -----------------------------------
        if not self.ocr_available:
            return {
                "raw_text": "",
                "extracted_attributes": {},
                "source_type": "nameplate",
                "extraction_method": "none",
                "error": "No OCR engine available (pytesseract not installed)",
            }

        try:
            img = Image.open(image_path)
            raw_text: str = pytesseract.image_to_string(img)
        except Exception as exc:
            return {
                "raw_text": "",
                "extracted_attributes": {},
                "source_type": "nameplate",
                "extraction_method": "ocr_failed",
                "error": str(exc),
            }

        extracted = self._regex_extract(raw_text)

        return {
            "raw_text": raw_text,
            "extracted_attributes": extracted,
            "source_type": "nameplate",
            "extraction_method": "ocr",
        }

    # ------------------------------------------------------------------

    async def extract_from_pdf(
        self, pdf_path: str, groq_service=None
    ) -> dict:
        """Extract product information from a PDF datasheet.

        Uses PyMuPDF to pull text (and tables when available), then
        optionally passes the text through Groq for structured extraction.
        Falls back to regex patterns.
        """

        if not self.pdf_available:
            return {
                "raw_text": "",
                "extracted_attributes": {},
                "source_type": "datasheet",
                "extraction_method": "none",
                "page_count": 0,
                "error": "PyMuPDF (fitz) not installed",
            }

        try:
            doc = fitz.open(pdf_path)
        except Exception as exc:
            return {
                "raw_text": "",
                "extracted_attributes": {},
                "source_type": "datasheet",
                "extraction_method": "pdf_parse_failed",
                "page_count": 0,
                "error": str(exc),
            }

        page_count: int = len(doc)
        full_text_parts: List[str] = []
        tables: List[List[List[str]]] = []

        for page in doc:
            page_text = page.get_text()
            if page_text:
                full_text_parts.append(page_text)

            # Attempt table extraction (PyMuPDF >= 1.23.0)
            if hasattr(page, "find_tables"):
                try:
                    page_tables = page.find_tables()
                    for table in page_tables:
                        table_data = table.extract()
                        if table_data:
                            tables.append(table_data)
                except Exception:
                    pass

        doc.close()

        raw_text = "\n".join(full_text_parts)

        # --- Try Groq structured extraction ---------------------------
        if groq_service is not None and hasattr(
            groq_service, "extract_from_text"
        ):
            try:
                result = await groq_service.extract_from_text(raw_text)
                if result:
                    return {
                        "raw_text": raw_text,
                        "extracted_attributes": result.get(
                            "extracted_attributes", {}
                        ),
                        "source_type": "datasheet",
                        "extraction_method": "llm_extract",
                        "page_count": page_count,
                        "tables": tables if tables else None,
                    }
            except Exception as exc:
                print(
                    f"[ExtractionEngine] Groq text extraction failed: {exc}"
                )

        # --- Fallback: regex ------------------------------------------
        extracted = self._regex_extract(raw_text)

        return {
            "raw_text": raw_text,
            "extracted_attributes": extracted,
            "source_type": "datasheet",
            "extraction_method": "pdf_parse",
            "page_count": page_count,
            "tables": tables if tables else None,
        }

    # ------------------------------------------------------------------

    async def extract_from_csv(self, csv_content: str) -> List[dict]:
        """Parse CSV content and map columns to standard attribute names.

        Returns a list of dicts, one per row/product.
        """
        reader = csv.DictReader(io.StringIO(csv_content))
        if reader.fieldnames is None:
            return []

        header_map = self._normalize_csv_headers(list(reader.fieldnames))

        products: List[dict] = []
        for row in reader:
            mapped: Dict[str, str] = {}
            unmapped: Dict[str, str] = {}

            for original_header, value in row.items():
                if value is None or str(value).strip() == "":
                    continue
                canonical = header_map.get(original_header)
                if canonical:
                    mapped[canonical] = str(value).strip()
                else:
                    unmapped[original_header] = str(value).strip()

            products.append(
                {
                    "extracted_attributes": mapped,
                    "unmapped_attributes": unmapped,
                    "source_type": "catalog",
                    "extraction_method": "csv_import",
                }
            )

        return products

    # ------------------------------------------------------------------

    async def extract_from_text(
        self, text: str, groq_service=None
    ) -> dict:
        """Extract product information from free-form text (manual input).

        Tries Groq structured extraction first, then falls back to regex.
        """

        if groq_service is not None and hasattr(
            groq_service, "extract_from_text"
        ):
            try:
                result = await groq_service.extract_from_text(text)
                if result:
                    return {
                        "raw_text": text,
                        "extracted_attributes": result.get(
                            "extracted_attributes", {}
                        ),
                        "source_type": "manual_input",
                        "extraction_method": "llm_extract",
                    }
            except Exception as exc:
                print(
                    f"[ExtractionEngine] Groq text extraction failed: {exc}"
                )

        extracted = self._regex_extract(text)

        return {
            "raw_text": text,
            "extracted_attributes": extracted,
            "source_type": "manual_input",
            "extraction_method": "regex",
        }

    # ==================================================================
    # Private helpers
    # ==================================================================

    def _regex_extract(self, text: str) -> dict:
        """Apply compiled regex patterns against *text* and return a dict
        of attribute-name -> extracted-value for every match found."""

        attributes: Dict[str, str] = {}

        for attr_name, pattern in self._PATTERNS.items():
            match = pattern.search(text)
            if match:
                # Grab the first non-None capturing group
                value = next(
                    (g for g in match.groups() if g is not None), None
                )
                if value is not None:
                    attributes[attr_name] = value.strip()

        return attributes

    # ------------------------------------------------------------------

    def _normalize_csv_headers(self, headers: list) -> dict:
        """Map raw CSV column headers to canonical attribute names.

        Returns ``{original_header: canonical_name}`` for every header
        that could be mapped; unmapped headers are omitted.
        """
        mapping: Dict[str, str] = {}

        for header in headers:
            lookup_key = header.strip().lower()
            canonical = self.HEADER_MAPPINGS.get(lookup_key)
            if canonical:
                mapping[header] = canonical
            else:
                # Try partial / fuzzy matching for common suffixes
                normalized = re.sub(r"[^a-z0-9]", "", lookup_key)
                for known_key, canon in self.HEADER_MAPPINGS.items():
                    known_norm = re.sub(r"[^a-z0-9]", "", known_key)
                    if known_norm and known_norm == normalized:
                        mapping[header] = canon
                        break

        return mapping


# ======================================================================
# Module-level singleton
# ======================================================================
extraction_engine = ExtractionEngine()
