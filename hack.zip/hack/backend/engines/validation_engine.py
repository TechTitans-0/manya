import re
import math
import json
from typing import Dict, List, Any, Optional, Tuple


class ValidationEngine:
    """Deterministic engineering validation engine for industrial products.

    All validation rules are implemented in pure Python — no LLM calls.
    The engine validates product attributes for engineering consistency.
    """

    def __init__(self) -> None:
        """Initialize the validation engine with a rule registry.

        Each rule entry contains:
            name              – unique rule identifier
            type              – classification (universal / motor / bearing / pump / electrical / valve_sensor)
            severity          – "error", "warning", or "info"
            applicable_categories – list of category strings, or "all"
            function          – bound method reference
        """
        self.rules: List[Dict[str, Any]] = [
            # ── Universal rules ──────────────────────────────────────────
            {
                "name": "numeric_ranges",
                "type": "universal",
                "severity": "error",
                "applicable_categories": "all",
                "function": self.validate_numeric_ranges,
            },
            {
                "name": "unit_formats",
                "type": "universal",
                "severity": "warning",
                "applicable_categories": "all",
                "function": self.validate_unit_formats,
            },
            {
                "name": "ip_rating",
                "type": "universal",
                "severity": "error",
                "applicable_categories": "all",
                "function": self.validate_ip_rating,
            },
            {
                "name": "temperature_ranges",
                "type": "universal",
                "severity": "error",
                "applicable_categories": "all",
                "function": self.validate_temperature_ranges,
            },
            {
                "name": "weight_dimensions",
                "type": "universal",
                "severity": "warning",
                "applicable_categories": "all",
                "function": self.validate_weight_dimensions,
            },
            # ── Motor-specific rules ─────────────────────────────────────
            {
                "name": "motor_power",
                "type": "motor",
                "severity": "warning",
                "applicable_categories": ["motor", "motors", "electric_motor", "electric motor"],
                "function": self.validate_motor_power,
            },
            {
                "name": "motor_speed",
                "type": "motor",
                "severity": "warning",
                "applicable_categories": ["motor", "motors", "electric_motor", "electric motor"],
                "function": self.validate_motor_speed,
            },
            {
                "name": "motor_efficiency",
                "type": "motor",
                "severity": "error",
                "applicable_categories": ["motor", "motors", "electric_motor", "electric motor"],
                "function": self.validate_motor_efficiency,
            },
            {
                "name": "motor_frame",
                "type": "motor",
                "severity": "info",
                "applicable_categories": ["motor", "motors", "electric_motor", "electric motor"],
                "function": self.validate_motor_frame,
            },
            # ── Bearing-specific rules ───────────────────────────────────
            {
                "name": "bearing_dimensions",
                "type": "bearing",
                "severity": "error",
                "applicable_categories": ["bearing", "bearings", "ball_bearing", "roller_bearing"],
                "function": self.validate_bearing_dimensions,
            },
            {
                "name": "bearing_load_ratings",
                "type": "bearing",
                "severity": "warning",
                "applicable_categories": ["bearing", "bearings", "ball_bearing", "roller_bearing"],
                "function": self.validate_bearing_load_ratings,
            },
            {
                "name": "bearing_speed",
                "type": "bearing",
                "severity": "warning",
                "applicable_categories": ["bearing", "bearings", "ball_bearing", "roller_bearing"],
                "function": self.validate_bearing_speed,
            },
            # ── Pump-specific rules ──────────────────────────────────────
            {
                "name": "pump_performance",
                "type": "pump",
                "severity": "warning",
                "applicable_categories": ["pump", "pumps", "centrifugal_pump", "centrifugal pump"],
                "function": self.validate_pump_performance,
            },
            {
                "name": "pump_npsh",
                "type": "pump",
                "severity": "error",
                "applicable_categories": ["pump", "pumps", "centrifugal_pump", "centrifugal pump"],
                "function": self.validate_pump_npsh,
            },
            # ── Electrical component rules ───────────────────────────────
            {
                "name": "voltage_standard",
                "type": "electrical",
                "severity": "info",
                "applicable_categories": [
                    "electrical", "switchgear", "circuit_breaker", "contactor",
                    "relay", "transformer", "motor", "motors", "electric_motor",
                    "electric motor", "drive", "vfd",
                ],
                "function": self.validate_voltage_standard,
            },
            {
                "name": "current_capacity",
                "type": "electrical",
                "severity": "error",
                "applicable_categories": [
                    "electrical", "switchgear", "circuit_breaker", "contactor",
                    "relay", "fuse",
                ],
                "function": self.validate_current_capacity,
            },
            # ── Valve / Sensor rules ─────────────────────────────────────
            {
                "name": "pressure_rating",
                "type": "valve_sensor",
                "severity": "error",
                "applicable_categories": [
                    "valve", "valves", "pressure_sensor", "pressure sensor",
                    "pressure_transmitter", "pump", "pumps",
                ],
                "function": self.validate_pressure_rating,
            },
            {
                "name": "sensor_range",
                "type": "valve_sensor",
                "severity": "error",
                "applicable_categories": [
                    "sensor", "sensors", "pressure_sensor", "temperature_sensor",
                    "flow_sensor", "level_sensor", "transmitter",
                    "pressure_transmitter",
                ],
                "function": self.validate_sensor_range,
            },
        ]

    # ──────────────────────────────────────────────────────────────────────
    #  Helpers
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _get_numeric_value(value_str: Any) -> Optional[float]:
        """Extract the first numeric value from a string like '7.5 kW' or '415V'.

        Returns *None* when no number can be parsed.
        """
        if value_str is None:
            return None
        if isinstance(value_str, (int, float)):
            return float(value_str)
        value_str = str(value_str).strip()
        if not value_str:
            return None
        match = re.search(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", value_str)
        if match:
            try:
                return float(match.group())
            except ValueError:
                return None
        return None

    @staticmethod
    def _get_unit(value_str: Any) -> Optional[str]:
        """Extract the unit suffix from a value string like '7.5 kW' -> 'kW'."""
        if value_str is None:
            return None
        if isinstance(value_str, (int, float)):
            return None
        value_str = str(value_str).strip()
        if not value_str:
            return None
        match = re.search(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?\s*(.+)", value_str)
        if match:
            unit = match.group(1).strip()
            return unit if unit else None
        return None

    @staticmethod
    def _result(
        rule_name: str,
        rule_type: str,
        status: str,
        message: str,
        details: Dict[str, Any],
        severity: str,
    ) -> Dict[str, Any]:
        """Build a standardised validation-result dictionary."""
        return {
            "rule_name": rule_name,
            "rule_type": rule_type,
            "status": status,
            "message": message,
            "details": details,
            "severity": severity,
        }

    def _attr_value(self, attrs: Dict[str, Any], *keys: str) -> Optional[str]:
        """Return the first attribute value found for any of the given keys (case-insensitive)."""
        lower_attrs = {k.lower().replace(" ", "_"): v for k, v in attrs.items()}
        for key in keys:
            normalised = key.lower().replace(" ", "_")
            if normalised in lower_attrs and lower_attrs[normalised] is not None:
                return lower_attrs[normalised]
        return None

    # ──────────────────────────────────────────────────────────────────────
    #  Universal validation rules
    # ──────────────────────────────────────────────────────────────────────

    def validate_numeric_ranges(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check that numeric values are positive where expected and within sane bounds."""
        results: List[Dict[str, Any]] = []
        positive_fields = [
            "power", "weight", "voltage", "current", "speed", "rpm",
            "frequency", "rated_power", "rated_voltage", "rated_current",
            "max_speed", "flow_rate", "head", "pressure", "torque",
            "capacity", "width", "height", "length", "diameter",
            "inner_diameter", "outer_diameter",
        ]
        for field in positive_fields:
            raw = self._attr_value(attrs, field)
            if raw is None:
                continue
            val = self._get_numeric_value(raw)
            if val is None:
                continue
            if val < 0:
                results.append(self._result(
                    "numeric_ranges", "universal", "conflict",
                    f"'{field}' has a negative value ({val}) but must be positive.",
                    {"field": field, "value": val},
                    "error",
                ))
            elif val == 0:
                results.append(self._result(
                    "numeric_ranges", "universal", "warning",
                    f"'{field}' is zero — please verify.",
                    {"field": field, "value": val},
                    "warning",
                ))
            elif val > 1e9:
                results.append(self._result(
                    "numeric_ranges", "universal", "warning",
                    f"'{field}' has an extremely large value ({val}) — please verify.",
                    {"field": field, "value": val},
                    "warning",
                ))
            elif val < 1e-9 and val > 0:
                results.append(self._result(
                    "numeric_ranges", "universal", "warning",
                    f"'{field}' has an extremely small value ({val}) — please verify.",
                    {"field": field, "value": val},
                    "warning",
                ))
        if not results:
            results.append(self._result(
                "numeric_ranges", "universal", "valid",
                "All numeric ranges are within expected bounds.",
                {}, "info",
            ))
        return results

    def validate_unit_formats(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check that units attached to values match expected engineering patterns."""
        results: List[Dict[str, Any]] = []
        unit_expectations: Dict[str, List[str]] = {
            "power": ["kW", "W", "MW", "HP", "hp", "kw", "w", "mw"],
            "rated_power": ["kW", "W", "MW", "HP", "hp", "kw", "w", "mw"],
            "voltage": ["V", "kV", "v", "kv", "mV"],
            "rated_voltage": ["V", "kV", "v", "kv", "mV"],
            "current": ["A", "mA", "a", "ma", "kA"],
            "rated_current": ["A", "mA", "a", "ma", "kA"],
            "speed": ["RPM", "rpm", "r/min", "rad/s"],
            "rpm": ["RPM", "rpm", "r/min", "rad/s"],
            "max_speed": ["RPM", "rpm", "r/min", "rad/s"],
            "frequency": ["Hz", "hz", "kHz", "MHz"],
            "weight": ["kg", "g", "lb", "lbs", "ton", "tons", "t"],
            "temperature": ["\u00b0C", "C", "\u00b0F", "F", "K", "degC", "degF"],
            "operating_temperature": ["\u00b0C", "C", "\u00b0F", "F", "K", "degC", "degF"],
            "ambient_temperature": ["\u00b0C", "C", "\u00b0F", "F", "K", "degC", "degF"],
            "width": ["mm", "cm", "m", "in", "inch", "ft"],
            "height": ["mm", "cm", "m", "in", "inch", "ft"],
            "length": ["mm", "cm", "m", "in", "inch", "ft"],
            "diameter": ["mm", "cm", "m", "in", "inch", "ft"],
            "inner_diameter": ["mm", "cm", "m", "in", "inch", "ft"],
            "outer_diameter": ["mm", "cm", "m", "in", "inch", "ft"],
            "pressure": ["bar", "Bar", "psi", "PSI", "kPa", "MPa", "Pa", "atm"],
            "flow_rate": ["m3/h", "m\u00b3/h", "l/min", "L/min", "GPM", "gpm", "l/s", "L/s", "m3/s"],
            "head": ["m", "ft", "mm"],
            "torque": ["Nm", "N.m", "N\u00b7m", "lb-ft", "kgf.m"],
        }

        for field, expected_units in unit_expectations.items():
            raw = self._attr_value(attrs, field)
            if raw is None:
                continue
            unit = self._get_unit(raw)
            if unit is None:
                continue
            # Normalise comparison: strip leading/trailing whitespace
            unit_clean = unit.strip()
            matched = any(
                unit_clean.lower() == eu.lower() or unit_clean == eu
                for eu in expected_units
            )
            if not matched:
                results.append(self._result(
                    "unit_formats", "universal", "warning",
                    f"'{field}' has unit '{unit_clean}' which is not in the expected set {expected_units}.",
                    {"field": field, "unit_found": unit_clean, "expected_units": expected_units},
                    "warning",
                ))
        if not results:
            results.append(self._result(
                "unit_formats", "universal", "valid",
                "All unit formats match expected patterns.",
                {}, "info",
            ))
        return results

    def validate_ip_rating(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """IP rating must match format IPxy where x=0-6, y=0-9."""
        results: List[Dict[str, Any]] = []
        raw = self._attr_value(attrs, "ip_rating", "ip", "protection", "ingress_protection")
        if raw is None:
            return results  # Nothing to validate
        raw_str = str(raw).strip().upper()
        pattern = r"^IP([0-6X])([0-9X])([A-Z]?)$"
        match = re.match(pattern, raw_str)
        if not match:
            results.append(self._result(
                "ip_rating", "universal", "conflict",
                f"IP rating '{raw}' does not match expected format IPxy (x=0-6, y=0-9).",
                {"value": raw},
                "error",
            ))
        else:
            results.append(self._result(
                "ip_rating", "universal", "valid",
                f"IP rating '{raw_str}' is valid.",
                {"value": raw_str},
                "info",
            ))
        return results

    def validate_temperature_ranges(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Temperature values must be > -273.15 degC; operating temp typically < 500 degC."""
        results: List[Dict[str, Any]] = []
        temp_fields = [
            "temperature", "operating_temperature", "ambient_temperature",
            "max_temperature", "min_temperature", "temp", "operating_temp",
        ]
        for field in temp_fields:
            raw = self._attr_value(attrs, field)
            if raw is None:
                continue
            val = self._get_numeric_value(raw)
            if val is None:
                continue
            # Determine if Fahrenheit
            unit = self._get_unit(raw)
            is_fahrenheit = unit is not None and unit.upper().replace("\u00b0", "") in ("F", "DEGF")
            abs_zero = -459.67 if is_fahrenheit else -273.15
            op_limit = 932.0 if is_fahrenheit else 500.0

            if val <= abs_zero:
                results.append(self._result(
                    "temperature_ranges", "universal", "conflict",
                    f"'{field}' value {val} is at or below absolute zero ({abs_zero}).",
                    {"field": field, "value": val, "absolute_zero": abs_zero},
                    "error",
                ))
            elif val > op_limit:
                results.append(self._result(
                    "temperature_ranges", "universal", "warning",
                    f"'{field}' value {val} exceeds typical industrial limit ({op_limit}) — please verify.",
                    {"field": field, "value": val, "typical_limit": op_limit},
                    "warning",
                ))
        if not results:
            for field in temp_fields:
                if self._attr_value(attrs, field) is not None:
                    results.append(self._result(
                        "temperature_ranges", "universal", "valid",
                        "Temperature values are within acceptable range.",
                        {}, "info",
                    ))
                    break
        return results

    def validate_weight_dimensions(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """If weight and dimensions both exist, check plausible density (not 0.001 or 10000 kg/m cubed)."""
        results: List[Dict[str, Any]] = []
        weight_raw = self._attr_value(attrs, "weight", "mass")
        if weight_raw is None:
            return results

        weight_kg = self._get_numeric_value(weight_raw)
        if weight_kg is None or weight_kg <= 0:
            return results

        weight_unit = self._get_unit(weight_raw)
        if weight_unit:
            wu = weight_unit.lower()
            if wu in ("g",):
                weight_kg /= 1000.0
            elif wu in ("lb", "lbs"):
                weight_kg *= 0.453592
            elif wu in ("ton", "tons", "t"):
                weight_kg *= 1000.0

        # Try to compute volume from length/width/height or diameter/length
        length_raw = self._attr_value(attrs, "length", "l")
        width_raw = self._attr_value(attrs, "width", "w")
        height_raw = self._attr_value(attrs, "height", "h")

        def _to_metres(raw: Any) -> Optional[float]:
            if raw is None:
                return None
            val = self._get_numeric_value(raw)
            if val is None or val <= 0:
                return None
            unit = self._get_unit(raw)
            if unit:
                u = unit.lower()
                if u == "mm":
                    val /= 1000.0
                elif u == "cm":
                    val /= 100.0
                elif u in ("in", "inch"):
                    val *= 0.0254
                elif u == "ft":
                    val *= 0.3048
                # else assume metres
            else:
                # Default: assume mm for industrial products
                val /= 1000.0
            return val

        l_m = _to_metres(length_raw)
        w_m = _to_metres(width_raw)
        h_m = _to_metres(height_raw)

        volume_m3: Optional[float] = None
        if l_m and w_m and h_m:
            volume_m3 = l_m * w_m * h_m

        if volume_m3 is None:
            # Try cylindrical: diameter + length
            dia_raw = self._attr_value(attrs, "diameter", "outer_diameter")
            len_raw = self._attr_value(attrs, "length", "width", "height")
            d_m = _to_metres(dia_raw)
            cyl_l = _to_metres(len_raw)
            if d_m and cyl_l:
                volume_m3 = math.pi * (d_m / 2.0) ** 2 * cyl_l

        if volume_m3 is None or volume_m3 <= 0:
            return results

        density = weight_kg / volume_m3  # kg/m^3

        if density < 0.001:
            results.append(self._result(
                "weight_dimensions", "universal", "conflict",
                f"Computed density ({density:.4f} kg/m\u00b3) is implausibly low — check weight/dimensions.",
                {"weight_kg": weight_kg, "volume_m3": volume_m3, "density_kg_m3": density},
                "warning",
            ))
        elif density > 25000:
            results.append(self._result(
                "weight_dimensions", "universal", "conflict",
                f"Computed density ({density:.1f} kg/m\u00b3) is implausibly high — check weight/dimensions.",
                {"weight_kg": weight_kg, "volume_m3": volume_m3, "density_kg_m3": density},
                "warning",
            ))
        else:
            results.append(self._result(
                "weight_dimensions", "universal", "valid",
                f"Weight/dimension density ({density:.1f} kg/m\u00b3) is plausible.",
                {"weight_kg": weight_kg, "volume_m3": volume_m3, "density_kg_m3": density},
                "info",
            ))
        return results

    # ──────────────────────────────────────────────────────────────────────
    #  Motor-specific validation rules
    # ──────────────────────────────────────────────────────────────────────

    def validate_motor_power(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check P ~ V x I x PF x sqrt(3) for 3-phase, or P = V x I x PF for 1-phase.

        Allows 20% tolerance.  Assumes PF = 0.85 when not provided.
        """
        results: List[Dict[str, Any]] = []

        power_raw = self._attr_value(attrs, "power", "rated_power", "output_power")
        voltage_raw = self._attr_value(attrs, "voltage", "rated_voltage")
        current_raw = self._attr_value(attrs, "current", "rated_current", "full_load_current")

        if power_raw is None or voltage_raw is None or current_raw is None:
            return results

        power_val = self._get_numeric_value(power_raw)
        voltage_val = self._get_numeric_value(voltage_raw)
        current_val = self._get_numeric_value(current_raw)

        if power_val is None or voltage_val is None or current_val is None:
            return results
        if power_val <= 0 or voltage_val <= 0 or current_val <= 0:
            return results

        # Normalise power to watts
        power_unit = self._get_unit(power_raw)
        power_w = power_val
        if power_unit:
            pu = power_unit.lower()
            if pu == "kw":
                power_w = power_val * 1000.0
            elif pu == "mw":
                power_w = power_val * 1_000_000.0
            elif pu in ("hp",):
                power_w = power_val * 746.0

        # Power factor
        pf_raw = self._attr_value(attrs, "power_factor", "pf", "cos_phi")
        pf = 0.85  # default assumption
        pf_assumed = True
        if pf_raw is not None:
            pf_parsed = self._get_numeric_value(pf_raw)
            if pf_parsed is not None and 0 < pf_parsed <= 1.0:
                pf = pf_parsed
                pf_assumed = False

        # Phase detection
        phase_raw = self._attr_value(attrs, "phase", "phases", "no_of_phases", "number_of_phases")
        is_three_phase = True  # default
        if phase_raw is not None:
            phase_val = self._get_numeric_value(phase_raw)
            if phase_val is not None:
                is_three_phase = phase_val == 3
            else:
                is_three_phase = "3" in str(phase_raw)

        # Efficiency
        eff_raw = self._attr_value(attrs, "efficiency", "eff", "motor_efficiency")
        eff = 1.0  # assume output power = input power if not given
        if eff_raw is not None:
            eff_parsed = self._get_numeric_value(eff_raw)
            if eff_parsed is not None:
                if eff_parsed > 1.0:
                    eff = eff_parsed / 100.0  # given as percentage
                else:
                    eff = eff_parsed
                if eff <= 0:
                    eff = 1.0

        if is_three_phase:
            calc_input_power = voltage_val * current_val * pf * math.sqrt(3)
        else:
            calc_input_power = voltage_val * current_val * pf

        # Output power = input power * efficiency
        calc_output_power = calc_input_power * eff

        # Compare
        tolerance = 0.20
        ratio = power_w / calc_output_power if calc_output_power > 0 else float("inf")

        if abs(ratio - 1.0) <= tolerance:
            results.append(self._result(
                "motor_power", "motor", "valid",
                f"Motor power ({power_w:.1f} W) is consistent with V*I*PF"
                f"{' *sqrt(3)' if is_three_phase else ''}"
                f" = {calc_input_power:.1f} W input, {calc_output_power:.1f} W output"
                f" (ratio {ratio:.2f}).",
                {
                    "power_w": power_w, "voltage": voltage_val, "current": current_val,
                    "pf": pf, "pf_assumed": pf_assumed, "three_phase": is_three_phase,
                    "efficiency": eff, "calculated_input_w": calc_input_power,
                    "calculated_output_w": calc_output_power, "ratio": ratio,
                },
                "info",
            ))
        else:
            results.append(self._result(
                "motor_power", "motor", "warning",
                f"Motor power ({power_w:.1f} W) differs from calculated"
                f" ({calc_output_power:.1f} W) by ratio {ratio:.2f} — exceeds 20% tolerance."
                f"{' PF assumed 0.85.' if pf_assumed else ''}",
                {
                    "power_w": power_w, "voltage": voltage_val, "current": current_val,
                    "pf": pf, "pf_assumed": pf_assumed, "three_phase": is_three_phase,
                    "efficiency": eff, "calculated_input_w": calc_input_power,
                    "calculated_output_w": calc_output_power, "ratio": ratio,
                },
                "warning",
            ))
        return results

    def validate_motor_speed(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """RPM should be a sub-multiple of synchronous speed (120 * freq / poles).

        Standard poles: 2, 4, 6, 8.  Standard freq: 50, 60 Hz.
        Rated RPM must be less than synchronous RPM.
        """
        results: List[Dict[str, Any]] = []

        speed_raw = self._attr_value(attrs, "speed", "rpm", "rated_speed", "rated_rpm")
        if speed_raw is None:
            return results
        speed_val = self._get_numeric_value(speed_raw)
        if speed_val is None or speed_val <= 0:
            return results

        freq_raw = self._attr_value(attrs, "frequency", "freq", "supply_frequency")
        poles_raw = self._attr_value(attrs, "poles", "no_of_poles", "number_of_poles")

        standard_freqs = [50, 60]
        standard_poles = [2, 4, 6, 8]

        freq_val: Optional[float] = None
        if freq_raw is not None:
            freq_val = self._get_numeric_value(freq_raw)

        poles_val: Optional[int] = None
        if poles_raw is not None:
            pv = self._get_numeric_value(poles_raw)
            if pv is not None:
                poles_val = int(pv)

        # If both frequency and poles are known, do a direct check
        if freq_val is not None and poles_val is not None:
            sync_speed = 120.0 * freq_val / poles_val
            if speed_val >= sync_speed:
                results.append(self._result(
                    "motor_speed", "motor", "warning",
                    f"Rated speed ({speed_val} RPM) >= synchronous speed ({sync_speed:.0f} RPM) "
                    f"for {freq_val} Hz / {poles_val} poles. Induction motors run below synchronous speed.",
                    {"speed": speed_val, "sync_speed": sync_speed, "frequency": freq_val, "poles": poles_val},
                    "warning",
                ))
            else:
                slip = (sync_speed - speed_val) / sync_speed * 100.0
                if slip > 15:
                    results.append(self._result(
                        "motor_speed", "motor", "warning",
                        f"Slip is {slip:.1f}% which is unusually high for standard motors (typical < 5%).",
                        {"speed": speed_val, "sync_speed": sync_speed, "slip_pct": slip},
                        "warning",
                    ))
                else:
                    results.append(self._result(
                        "motor_speed", "motor", "valid",
                        f"Speed {speed_val} RPM is consistent with synchronous speed {sync_speed:.0f} RPM "
                        f"({slip:.1f}% slip).",
                        {"speed": speed_val, "sync_speed": sync_speed, "slip_pct": slip},
                        "info",
                    ))
            return results

        # Otherwise, try to find a plausible freq/pole combination
        matched = False
        freqs_to_try = [freq_val] if freq_val else standard_freqs
        poles_to_try = [poles_val] if poles_val else standard_poles

        for freq in freqs_to_try:
            if freq is None:
                continue
            for poles in poles_to_try:
                if poles is None or poles <= 0:
                    continue
                sync_speed = 120.0 * freq / poles
                if 0 < speed_val < sync_speed:
                    slip = (sync_speed - speed_val) / sync_speed * 100.0
                    if slip <= 10:
                        matched = True
                        break
            if matched:
                break

        if not matched:
            results.append(self._result(
                "motor_speed", "motor", "warning",
                f"Speed {speed_val} RPM does not correspond to a standard synchronous speed "
                f"for common pole/frequency combinations.",
                {"speed": speed_val},
                "warning",
            ))
        else:
            results.append(self._result(
                "motor_speed", "motor", "valid",
                f"Speed {speed_val} RPM matches a plausible synchronous speed configuration.",
                {"speed": speed_val},
                "info",
            ))
        return results

    def validate_motor_efficiency(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Motor efficiency must be 0 < efficiency <= 100%."""
        results: List[Dict[str, Any]] = []
        eff_raw = self._attr_value(attrs, "efficiency", "eff", "motor_efficiency", "rated_efficiency")
        if eff_raw is None:
            return results
        eff_val = self._get_numeric_value(eff_raw)
        if eff_val is None:
            return results

        if eff_val <= 0:
            results.append(self._result(
                "motor_efficiency", "motor", "conflict",
                f"Motor efficiency ({eff_val}) must be greater than 0.",
                {"efficiency": eff_val},
                "error",
            ))
        elif eff_val > 100:
            results.append(self._result(
                "motor_efficiency", "motor", "conflict",
                f"Motor efficiency ({eff_val}%) exceeds 100% — physically impossible.",
                {"efficiency": eff_val},
                "error",
            ))
        else:
            pct = eff_val if eff_val > 1 else eff_val * 100.0
            results.append(self._result(
                "motor_efficiency", "motor", "valid",
                f"Motor efficiency ({pct:.1f}%) is within valid range.",
                {"efficiency": pct},
                "info",
            ))
        return results

    def validate_motor_frame(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check frame size against common IEC frame sizes."""
        results: List[Dict[str, Any]] = []
        frame_raw = self._attr_value(attrs, "frame", "frame_size", "iec_frame")
        if frame_raw is None:
            return results

        iec_frames = [56, 63, 71, 80, 90, 100, 112, 132, 160, 180, 200, 225, 250, 280, 315, 355]

        frame_str = str(frame_raw).strip()
        # Extract leading numeric part (e.g. "132M" -> 132)
        match = re.match(r"(\d+)", frame_str)
        if match:
            frame_num = int(match.group(1))
            if frame_num in iec_frames:
                results.append(self._result(
                    "motor_frame", "motor", "valid",
                    f"Frame size {frame_str} corresponds to standard IEC frame {frame_num}.",
                    {"frame": frame_str, "frame_number": frame_num},
                    "info",
                ))
            else:
                results.append(self._result(
                    "motor_frame", "motor", "warning",
                    f"Frame size {frame_str} (numeric: {frame_num}) is not a standard IEC frame. "
                    f"Standard sizes: {iec_frames}.",
                    {"frame": frame_str, "frame_number": frame_num, "standard_frames": iec_frames},
                    "info",
                ))
        else:
            results.append(self._result(
                "motor_frame", "motor", "warning",
                f"Could not parse numeric frame size from '{frame_str}'.",
                {"frame": frame_str},
                "info",
            ))
        return results

    # ──────────────────────────────────────────────────────────────────────
    #  Bearing-specific validation rules
    # ──────────────────────────────────────────────────────────────────────

    def validate_bearing_dimensions(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """inner_diameter < outer_diameter, width > 0."""
        results: List[Dict[str, Any]] = []

        id_raw = self._attr_value(attrs, "inner_diameter", "bore", "bore_diameter", "id", "d")
        od_raw = self._attr_value(attrs, "outer_diameter", "od", "outside_diameter", "D")
        w_raw = self._attr_value(attrs, "width", "bearing_width", "B", "b")

        id_val = self._get_numeric_value(id_raw) if id_raw is not None else None
        od_val = self._get_numeric_value(od_raw) if od_raw is not None else None
        w_val = self._get_numeric_value(w_raw) if w_raw is not None else None

        if id_val is not None and od_val is not None:
            if id_val >= od_val:
                results.append(self._result(
                    "bearing_dimensions", "bearing", "conflict",
                    f"Inner diameter ({id_val}) must be less than outer diameter ({od_val}).",
                    {"inner_diameter": id_val, "outer_diameter": od_val},
                    "error",
                ))
            else:
                results.append(self._result(
                    "bearing_dimensions", "bearing", "valid",
                    f"Bearing dimensions valid: ID {id_val} < OD {od_val}.",
                    {"inner_diameter": id_val, "outer_diameter": od_val},
                    "info",
                ))

        if w_val is not None:
            if w_val <= 0:
                results.append(self._result(
                    "bearing_dimensions", "bearing", "conflict",
                    f"Bearing width ({w_val}) must be greater than 0.",
                    {"width": w_val},
                    "error",
                ))
            else:
                results.append(self._result(
                    "bearing_dimensions", "bearing", "valid",
                    f"Bearing width ({w_val}) is positive.",
                    {"width": w_val},
                    "info",
                ))
        return results

    def validate_bearing_load_ratings(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Dynamic load rating typically >= static load rating."""
        results: List[Dict[str, Any]] = []

        dyn_raw = self._attr_value(attrs, "dynamic_load_rating", "dynamic_load", "C", "cr")
        stat_raw = self._attr_value(attrs, "static_load_rating", "static_load", "C0", "cor")

        dyn_val = self._get_numeric_value(dyn_raw) if dyn_raw is not None else None
        stat_val = self._get_numeric_value(stat_raw) if stat_raw is not None else None

        if dyn_val is not None and stat_val is not None:
            if dyn_val < stat_val:
                results.append(self._result(
                    "bearing_load_ratings", "bearing", "warning",
                    f"Dynamic load rating ({dyn_val}) is less than static load rating ({stat_val}) — "
                    f"this is unusual for most bearing types.",
                    {"dynamic_load_rating": dyn_val, "static_load_rating": stat_val},
                    "warning",
                ))
            else:
                results.append(self._result(
                    "bearing_load_ratings", "bearing", "valid",
                    f"Dynamic load rating ({dyn_val}) >= static load rating ({stat_val}).",
                    {"dynamic_load_rating": dyn_val, "static_load_rating": stat_val},
                    "info",
                ))
        return results

    def validate_bearing_speed(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """max_speed > 0, reasonable range based on size."""
        results: List[Dict[str, Any]] = []

        speed_raw = self._attr_value(attrs, "max_speed", "limiting_speed", "reference_speed", "max_rpm")
        if speed_raw is None:
            return results
        speed_val = self._get_numeric_value(speed_raw)
        if speed_val is None:
            return results

        if speed_val <= 0:
            results.append(self._result(
                "bearing_speed", "bearing", "conflict",
                f"Bearing max speed ({speed_val}) must be greater than 0.",
                {"max_speed": speed_val},
                "error",
            ))
            return results

        # Check against bore size for reasonableness (DN value = bore_mm * RPM)
        bore_raw = self._attr_value(attrs, "inner_diameter", "bore", "bore_diameter", "id", "d")
        bore_val = self._get_numeric_value(bore_raw) if bore_raw is not None else None

        if bore_val is not None and bore_val > 0:
            dn_value = bore_val * speed_val  # mm * RPM
            if dn_value > 2_000_000:
                results.append(self._result(
                    "bearing_speed", "bearing", "warning",
                    f"DN value ({dn_value:,.0f} mm\u00b7RPM) is very high — verify bearing speed limit.",
                    {"max_speed": speed_val, "bore_mm": bore_val, "dn_value": dn_value},
                    "warning",
                ))
            else:
                results.append(self._result(
                    "bearing_speed", "bearing", "valid",
                    f"Bearing speed ({speed_val} RPM) with DN={dn_value:,.0f} is within reasonable range.",
                    {"max_speed": speed_val, "bore_mm": bore_val, "dn_value": dn_value},
                    "info",
                ))
        else:
            if speed_val > 500_000:
                results.append(self._result(
                    "bearing_speed", "bearing", "warning",
                    f"Bearing max speed ({speed_val} RPM) seems unusually high.",
                    {"max_speed": speed_val},
                    "warning",
                ))
            else:
                results.append(self._result(
                    "bearing_speed", "bearing", "valid",
                    f"Bearing max speed ({speed_val} RPM) is positive.",
                    {"max_speed": speed_val},
                    "info",
                ))
        return results

    # ──────────────────────────────────────────────────────────────────────
    #  Pump-specific validation rules
    # ──────────────────────────────────────────────────────────────────────

    def validate_pump_performance(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Power ~ (flow_rate * head * SG) / (efficiency * conversion_factor).

        Uses: P (kW) = (Q_m3h * H_m * rho * g) / (3600 * 1000 * eta)
        which simplifies to P = (Q * H * SG) / (367.2 * eta)  [kW, m^3/h, m]
        """
        results: List[Dict[str, Any]] = []

        power_raw = self._attr_value(attrs, "power", "rated_power", "motor_power", "shaft_power")
        flow_raw = self._attr_value(attrs, "flow_rate", "flow", "capacity", "discharge", "Q")
        head_raw = self._attr_value(attrs, "head", "total_head", "H", "tdh", "total_dynamic_head")

        if power_raw is None or flow_raw is None or head_raw is None:
            return results

        power_val = self._get_numeric_value(power_raw)
        flow_val = self._get_numeric_value(flow_raw)
        head_val = self._get_numeric_value(head_raw)

        if power_val is None or flow_val is None or head_val is None:
            return results
        if power_val <= 0 or flow_val <= 0 or head_val <= 0:
            return results

        # Normalise power to kW
        power_kw = power_val
        power_unit = self._get_unit(power_raw)
        if power_unit:
            pu = power_unit.lower()
            if pu == "w":
                power_kw = power_val / 1000.0
            elif pu == "hp":
                power_kw = power_val * 0.746

        # Normalise flow to m3/h
        flow_m3h = flow_val
        flow_unit = self._get_unit(flow_raw)
        if flow_unit:
            fu = flow_unit.lower().replace(" ", "")
            if fu in ("l/min",):
                flow_m3h = flow_val * 0.06
            elif fu in ("l/s",):
                flow_m3h = flow_val * 3.6
            elif fu in ("gpm",):
                flow_m3h = flow_val * 0.227124
            elif fu in ("m3/s", "m\u00b3/s"):
                flow_m3h = flow_val * 3600.0

        # Specific gravity
        sg_raw = self._attr_value(attrs, "specific_gravity", "sg", "density", "fluid_density")
        sg = 1.0  # default water
        if sg_raw is not None:
            sg_parsed = self._get_numeric_value(sg_raw)
            if sg_parsed is not None and sg_parsed > 0:
                sg = sg_parsed
                if sg > 100:
                    # Likely given as kg/m^3
                    sg = sg / 1000.0

        # Pump efficiency
        eff_raw = self._attr_value(attrs, "efficiency", "pump_efficiency", "eff", "eta")
        eff = 0.70  # default pump efficiency
        if eff_raw is not None:
            eff_parsed = self._get_numeric_value(eff_raw)
            if eff_parsed is not None and eff_parsed > 0:
                eff = eff_parsed
                if eff > 1.0:
                    eff = eff / 100.0

        # P = Q * H * SG / (367.2 * eta)
        calc_power = (flow_m3h * head_val * sg) / (367.2 * eff)

        tolerance = 0.30  # 30% tolerance for pumps (motor oversizing is common)
        ratio = power_kw / calc_power if calc_power > 0 else float("inf")

        if abs(ratio - 1.0) <= tolerance:
            results.append(self._result(
                "pump_performance", "pump", "valid",
                f"Pump power ({power_kw:.2f} kW) is consistent with hydraulic calculation "
                f"({calc_power:.2f} kW), ratio {ratio:.2f}.",
                {
                    "power_kw": power_kw, "flow_m3h": flow_m3h, "head_m": head_val,
                    "sg": sg, "efficiency": eff, "calculated_power_kw": calc_power, "ratio": ratio,
                },
                "info",
            ))
        else:
            results.append(self._result(
                "pump_performance", "pump", "warning",
                f"Pump power ({power_kw:.2f} kW) differs from hydraulic calculation "
                f"({calc_power:.2f} kW) by ratio {ratio:.2f} — exceeds 30% tolerance.",
                {
                    "power_kw": power_kw, "flow_m3h": flow_m3h, "head_m": head_val,
                    "sg": sg, "efficiency": eff, "calculated_power_kw": calc_power, "ratio": ratio,
                },
                "warning",
            ))
        return results

    def validate_pump_npsh(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """NPSH_available should be > NPSH_required to avoid cavitation."""
        results: List[Dict[str, Any]] = []

        npsha_raw = self._attr_value(attrs, "npsh_available", "npsha", "npsh_a")
        npshr_raw = self._attr_value(attrs, "npsh_required", "npshr", "npsh_r")

        if npsha_raw is None or npshr_raw is None:
            return results

        npsha_val = self._get_numeric_value(npsha_raw)
        npshr_val = self._get_numeric_value(npshr_raw)

        if npsha_val is None or npshr_val is None:
            return results

        if npsha_val <= npshr_val:
            results.append(self._result(
                "pump_npsh", "pump", "conflict",
                f"NPSH available ({npsha_val} m) is not greater than NPSH required ({npshr_val} m) — "
                f"risk of cavitation!",
                {"npsh_available": npsha_val, "npsh_required": npshr_val},
                "error",
            ))
        else:
            margin = npsha_val - npshr_val
            results.append(self._result(
                "pump_npsh", "pump", "valid",
                f"NPSH available ({npsha_val} m) > NPSH required ({npshr_val} m) "
                f"with {margin:.2f} m margin.",
                {"npsh_available": npsha_val, "npsh_required": npshr_val, "margin": margin},
                "info",
            ))
        return results

    # ──────────────────────────────────────────────────────────────────────
    #  Electrical component validation rules
    # ──────────────────────────────────────────────────────────────────────

    def validate_voltage_standard(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check voltage against common standard voltages."""
        results: List[Dict[str, Any]] = []
        standard_voltages = [
            12, 24, 48, 110, 115, 120, 200, 208, 220, 230, 240, 277,
            380, 400, 415, 440, 460, 480, 600, 690, 1000, 3300, 6600, 11000,
        ]

        voltage_fields = ["voltage", "rated_voltage", "supply_voltage", "operating_voltage"]
        for field in voltage_fields:
            raw = self._attr_value(attrs, field)
            if raw is None:
                continue
            val = self._get_numeric_value(raw)
            if val is None:
                continue

            # Allow 5% tolerance for matching standard voltages
            matched_std = None
            for sv in standard_voltages:
                if abs(val - sv) / sv <= 0.05:
                    matched_std = sv
                    break

            if matched_std is not None:
                results.append(self._result(
                    "voltage_standard", "electrical", "valid",
                    f"Voltage {val} V matches standard voltage {matched_std} V.",
                    {"field": field, "value": val, "standard_voltage": matched_std},
                    "info",
                ))
            else:
                results.append(self._result(
                    "voltage_standard", "electrical", "warning",
                    f"Voltage {val} V is not a common standard voltage. "
                    f"Standard values: {standard_voltages}.",
                    {"field": field, "value": val, "standard_voltages": standard_voltages},
                    "info",
                ))
        return results

    def validate_current_capacity(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Breaking capacity should be > rated current."""
        results: List[Dict[str, Any]] = []

        breaking_raw = self._attr_value(
            attrs, "breaking_capacity", "breaking_current",
            "short_circuit_capacity", "icu", "ics",
        )
        rated_raw = self._attr_value(attrs, "rated_current", "current", "In", "nominal_current")

        if breaking_raw is None or rated_raw is None:
            return results

        breaking_val = self._get_numeric_value(breaking_raw)
        rated_val = self._get_numeric_value(rated_raw)

        if breaking_val is None or rated_val is None:
            return results

        # Normalise units — breaking capacity often in kA, rated current in A
        breaking_unit = self._get_unit(breaking_raw)
        rated_unit = self._get_unit(rated_raw)

        breaking_a = breaking_val
        if breaking_unit and breaking_unit.lower() == "ka":
            breaking_a = breaking_val * 1000.0

        rated_a = rated_val
        if rated_unit and rated_unit.lower() == "ka":
            rated_a = rated_val * 1000.0

        if breaking_a <= rated_a:
            results.append(self._result(
                "current_capacity", "electrical", "conflict",
                f"Breaking capacity ({breaking_a} A) must be greater than rated current ({rated_a} A).",
                {"breaking_capacity_a": breaking_a, "rated_current_a": rated_a},
                "error",
            ))
        else:
            results.append(self._result(
                "current_capacity", "electrical", "valid",
                f"Breaking capacity ({breaking_a} A) > rated current ({rated_a} A).",
                {"breaking_capacity_a": breaking_a, "rated_current_a": rated_a},
                "info",
            ))
        return results

    # ──────────────────────────────────────────────────────────────────────
    #  Valve / Sensor validation rules
    # ──────────────────────────────────────────────────────────────────────

    def validate_pressure_rating(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Pressure must be positive, within reasonable industrial range."""
        results: List[Dict[str, Any]] = []

        pressure_fields = [
            "pressure", "rated_pressure", "max_pressure", "working_pressure",
            "design_pressure", "test_pressure", "operating_pressure",
        ]
        for field in pressure_fields:
            raw = self._attr_value(attrs, field)
            if raw is None:
                continue
            val = self._get_numeric_value(raw)
            if val is None:
                continue
            unit = self._get_unit(raw)

            # Normalise to bar for limit checking
            val_bar = val
            if unit:
                u = unit.lower()
                if u == "psi":
                    val_bar = val * 0.0689476
                elif u == "kpa":
                    val_bar = val * 0.01
                elif u == "mpa":
                    val_bar = val * 10.0
                elif u == "pa":
                    val_bar = val * 0.00001
                elif u == "atm":
                    val_bar = val * 1.01325

            if val <= 0:
                results.append(self._result(
                    "pressure_rating", "valve_sensor", "conflict",
                    f"'{field}' pressure ({val}) must be positive.",
                    {"field": field, "value": val},
                    "error",
                ))
            elif val_bar > 10000:
                results.append(self._result(
                    "pressure_rating", "valve_sensor", "warning",
                    f"'{field}' pressure ({val} {unit or 'bar'}, ~{val_bar:.1f} bar) "
                    f"is extremely high — verify.",
                    {"field": field, "value": val, "value_bar": val_bar},
                    "warning",
                ))
            else:
                results.append(self._result(
                    "pressure_rating", "valve_sensor", "valid",
                    f"'{field}' pressure ({val} {unit or 'bar'}) is within reasonable range.",
                    {"field": field, "value": val, "value_bar": val_bar},
                    "info",
                ))
        return results

    def validate_sensor_range(self, attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Min range < Max range."""
        results: List[Dict[str, Any]] = []

        range_pairs = [
            ("min_range", "max_range"),
            ("range_min", "range_max"),
            ("lower_range", "upper_range"),
            ("measurement_min", "measurement_max"),
        ]

        for min_key, max_key in range_pairs:
            min_raw = self._attr_value(attrs, min_key)
            max_raw = self._attr_value(attrs, max_key)
            if min_raw is None or max_raw is None:
                continue

            min_val = self._get_numeric_value(min_raw)
            max_val = self._get_numeric_value(max_raw)
            if min_val is None or max_val is None:
                continue

            if min_val >= max_val:
                results.append(self._result(
                    "sensor_range", "valve_sensor", "conflict",
                    f"Sensor min range ({min_val}) must be less than max range ({max_val}).",
                    {"min_key": min_key, "min_value": min_val, "max_key": max_key, "max_value": max_val},
                    "error",
                ))
            else:
                results.append(self._result(
                    "sensor_range", "valve_sensor", "valid",
                    f"Sensor range valid: {min_val} to {max_val}.",
                    {"min_key": min_key, "min_value": min_val, "max_key": max_key, "max_value": max_val},
                    "info",
                ))

        # Also check a single "range" field with format "min-max" or "min to max"
        range_raw = self._attr_value(attrs, "range", "measurement_range", "sensor_range")
        if range_raw is not None:
            range_str = str(range_raw).strip()
            # Try "min - max", "min to max", "min~max"
            range_match = re.match(
                r"([-+]?\d*\.?\d+)\s*(?:[-–~]|to)\s*([-+]?\d*\.?\d+)",
                range_str, re.IGNORECASE,
            )
            if range_match:
                min_val = float(range_match.group(1))
                max_val = float(range_match.group(2))
                if min_val >= max_val:
                    results.append(self._result(
                        "sensor_range", "valve_sensor", "conflict",
                        f"Sensor range min ({min_val}) must be less than max ({max_val}) "
                        f"in '{range_str}'.",
                        {"range_string": range_str, "min_value": min_val, "max_value": max_val},
                        "error",
                    ))
                else:
                    results.append(self._result(
                        "sensor_range", "valve_sensor", "valid",
                        f"Sensor range '{range_str}' is valid ({min_val} to {max_val}).",
                        {"range_string": range_str, "min_value": min_val, "max_value": max_val},
                        "info",
                    ))
        return results

    # ──────────────────────────────────────────────────────────────────────
    #  Main validation entry point
    # ──────────────────────────────────────────────────────────────────────

    def validate_product(self, category: str, attributes: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Run all applicable validation rules for a given product category.

        Args:
            category:   Product category string (e.g. "motor", "bearing", "pump").
            attributes: Dictionary of product attributes.

        Returns:
            A list of validation result dictionaries, each containing:
                rule_name, rule_type, status, message, details, severity
        """
        all_results: List[Dict[str, Any]] = []
        category_lower = category.lower().strip()

        for rule in self.rules:
            applicable = rule["applicable_categories"]
            if applicable == "all" or category_lower in [c.lower() for c in applicable]:
                try:
                    rule_results = rule["function"](attributes)
                    all_results.extend(rule_results)
                except Exception as exc:
                    all_results.append(self._result(
                        rule["name"],
                        rule["type"],
                        "warning",
                        f"Rule '{rule['name']}' raised an exception: {exc}",
                        {"exception": str(exc)},
                        "error",
                    ))
        return all_results


# Module-level convenience instance
validation_engine = ValidationEngine()
