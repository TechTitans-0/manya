import pytest
from engines.validation_engine import validation_engine
from engines.normalization import normalization_engine
from engines.evidence import evidence_engine


def test_motor_power_validation():
    attrs = {
        "voltage": "400 V",
        "current": "14.7 A",
        "power": "7.5 kW",
        "frequency": "50 Hz",
        "poles": "4",
        "phase": "3",
        "power_factor": "0.84",
    }
    results = validation_engine.validate_product("motors", attrs)
    statuses = [r["status"] for r in results]
    assert "valid" in statuses or "warning" in statuses


def test_bearing_dimension_validation():
    attrs = {
        "bore_diameter": "25 mm",
        "outer_diameter": "52 mm",
        "width": "15 mm",
        "dynamic_load_rating": "14.8 kN",
        "static_load_rating": "7.8 kN",
    }
    results = validation_engine.validate_product("bearings", attrs)
    assert any(r["status"] == "valid" for r in results)


def test_normalization_power():
    result = normalization_engine.normalize_value("power", "7.5 kW")
    assert result["numeric_value"] == 7.5
    assert result["unit"] == "kW"


def test_evidence_source_trust():
    assert evidence_engine.calculate_source_trust("manufacturer_datasheet") > 0.9
    assert evidence_engine.calculate_source_trust("unknown") < 0.4


def test_evidence_confidence_range():
    sources = [{"source_value": "400 V", "trust_score": 0.95}]
    conf = evidence_engine.calculate_attribute_confidence(sources, [], True)
    assert 0.0 <= conf <= 1.0
