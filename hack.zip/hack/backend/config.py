import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./intellispec.db")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

GROQ_CHAT_MODEL = "llama-3.3-70b-versatile"
GROQ_VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"
GROQ_API_URL = "https://api.groq.com/openai/v1"

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

SOURCE_TRUST_SCORES = {
    "manufacturer_datasheet": 0.95,
    "nameplate": 0.90,
    "official_catalog": 0.85,
    "authorized_distributor": 0.75,
    "third_party": 0.60,
    "ai_enriched": 0.50,
    "manual_input": 0.70,
    "unknown": 0.30,
}

CONFIDENCE_WEIGHTS = {
    "source_trust": 0.35,
    "agreement": 0.30,
    "validation": 0.20,
    "completeness": 0.15,
}
