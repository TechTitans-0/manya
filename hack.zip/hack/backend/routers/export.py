import io
import json
import csv
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.orm import Session

from database import get_db
from models import Product
from services.passport import passport_service
from schemas import ExportRequest

router = APIRouter(prefix="/api/v1", tags=["Export"])


@router.get("/products/{product_id}/passport")
async def get_passport(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return passport_service.generate_passport(db, product_id)


@router.get("/products/{product_id}/export")
async def export_product(product_id: str, format: str = "json", db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    passport = passport_service.generate_passport(db, product_id)
    if "error" in passport:
        raise HTTPException(status_code=404, detail=passport["error"])

    if format == "json":
        return JSONResponse(content=passport)
    elif format == "csv":
        rows = passport_service.passport_to_csv_rows(passport)
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
        output.seek(0)
        filename = f"{product_id}_passport.csv"
        return StreamingResponse(io.BytesIO(output.getvalue().encode()), media_type="text/csv",
                                headers={"Content-Disposition": f"attachment; filename={filename}"})
    else:
        raise HTTPException(status_code=400, detail="Unsupported format. Use json or csv.")


@router.post("/catalog/export")
async def export_catalog(request: ExportRequest, db: Session = Depends(get_db)):
    products = db.query(Product).filter(Product.id.in_(request.product_ids)).all()
    if request.format == "json":
        data = [passport_service.generate_passport(db, p.id) for p in products if "error" not in passport_service.generate_passport(db, p.id)]
        return JSONResponse(content={"format": "json", "count": len(data), "products": data})
    elif request.format == "csv":
        rows = []
        for p in products:
            passport = passport_service.generate_passport(db, p.id)
            if "error" not in passport:
                rows.extend(passport_service.passport_to_csv_rows(passport))
        output = io.StringIO()
        if rows:
            writer = csv.DictWriter(output, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        output.seek(0)
        return StreamingResponse(io.BytesIO(output.getvalue().encode()), media_type="text/csv",
                                headers={"Content-Disposition": "attachment; filename=catalog_export.csv"})
    else:
        raise HTTPException(status_code=400, detail="Unsupported format")
