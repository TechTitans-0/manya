from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import get_db
from models import Product, ProductAttribute, ReplacementPart
from engines.replacement_finder import replacement_finder

router = APIRouter(prefix="/api/v1/products/{product_id}/replacements", tags=["Replacements"])


@router.get("")
async def find_replacements(
    product_id: str,
    top_n: int = Query(5, ge=1, le=20),
    db: Session = Depends(get_db),
):
    import json, uuid
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == product_id).all()
    original = {attr.attribute_name: attr.normalized_value or attr.raw_value for attr in attrs}
    original["category"] = product.category
    original["name"] = product.name or ""
    original["manufacturer"] = product.manufacturer or ""
    original["model_number"] = product.model_number or ""

    # Build candidate list from other products in same category
    candidates_query = db.query(Product).filter(
        Product.category == product.category,
        Product.id != product_id
    ).all()
    candidates = []
    for c in candidates_query:
        c_attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == c.id).all()
        cand_data = {a.attribute_name: a.normalized_value or a.raw_value for a in c_attrs}
        cand_data["id"] = c.id
        cand_data["name"] = c.name or c.model_number or c.id
        cand_data["manufacturer"] = c.manufacturer or ""
        cand_data["model_number"] = c.model_number or ""
        cand_data["category"] = c.category
        candidates.append(cand_data)

    if not candidates:
        # Load from seed replacement catalog
        try:
            with open("data/seed_products/demo_products.json", "r", encoding="utf-8") as f:
                seed = json.load(f)
            for rep in seed.get("replacement_catalog", []):
                rep["id"] = rep.get("id", "")
                candidates.append(rep)
        except Exception:
            pass

    matches = replacement_finder.find_replacements(original, candidates, product.category, top_n=top_n)

    # Store results
    db.query(ReplacementPart).filter(ReplacementPart.original_product_id == product_id).delete()
    for m in matches:
        rp = ReplacementPart(
            id=str(uuid.uuid4()), original_product_id=product_id,
            replacement_product_id=m.get("replacement_product_id", ""),
            compatibility_score=m.get("compatibility_score", 0),
            matched_attributes=json.dumps(m.get("matched_attributes", [])),
            mismatched_attributes=json.dumps(m.get("mismatched_attributes", [])),
            critical_differences=json.dumps(m.get("critical_differences", [])),
            recommendation_reason=m.get("recommendation_reason", ""),
        )
        db.add(rp)
    db.commit()

    return {"product_id": product_id, "category": product.category, "replacements": matches}


@router.get("/{replacement_id}/compare")
async def compare_replacement(product_id: str, replacement_id: str, db: Session = Depends(get_db)):
    # For demo, we return stored replacement details with full comparison
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    rp = db.query(ReplacementPart).filter(ReplacementPart.id == replacement_id).first()
    if not rp:
        raise HTTPException(status_code=404, detail="Replacement not found")
    import json
    return {
        "product_id": product_id,
        "replacement_id": replacement_id,
        "compatibility_score": rp.compatibility_score,
        "recommendation_reason": rp.recommendation_reason,
        "matched_attributes": json.loads(rp.matched_attributes) if rp.matched_attributes else [],
        "mismatched_attributes": json.loads(rp.mismatched_attributes) if rp.mismatched_attributes else [],
        "critical_differences": json.loads(rp.critical_differences) if rp.critical_differences else [],
    }
