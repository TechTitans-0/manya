import uuid
import json
import os
import base64
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query
from sqlalchemy.orm import Session

from database import get_db
from models import Product, ProductAttribute, AttributeSource, AuditTrail
from schemas import ProductCreate, ProductUpdate, ProductResponse, ProductListResponse
from services.groq_service import groq_service
from services.pipeline import pipeline_service
from engines.extraction import extraction_engine
from engines.evidence import evidence_engine
from config import UPLOAD_DIR

router = APIRouter(prefix="/api/v1/products", tags=["Products"])


@router.post("", response_model=ProductResponse)
async def create_product(product_data: ProductCreate, db: Session = Depends(get_db)):
    product = Product(
        id=str(uuid.uuid4()),
        name=product_data.name, manufacturer=product_data.manufacturer,
        model_number=product_data.model_number, part_number=product_data.part_number,
        category=product_data.category, description=product_data.description,
        status="draft",
    )
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


@router.post("/upload")
async def upload_product(
    file: UploadFile = File(...),
    source_type: str = Form("nameplate"),
    db: Session = Depends(get_db),
):
    content = await file.read()
    filename = file.filename or "upload"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    file_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}.{ext}")
    with open(file_path, "wb") as f:
        f.write(content)

    product = Product(id=str(uuid.uuid4()), status="processing", processing_stage="extraction")
    db.add(product)
    db.commit()

    try:
        if ext in ("jpg", "jpeg", "png", "bmp", "tiff", "webp"):
            result = await extraction_engine.extract_from_image(file_path, groq_service)
        elif ext == "pdf":
            result = await extraction_engine.extract_from_pdf(file_path, groq_service)
        elif ext == "csv":
            csv_text = content.decode("utf-8", errors="replace")
            results = await extraction_engine.extract_from_csv(csv_text)
            if results:
                result = results[0]
                result["source_type"] = "catalog"
            else:
                raise HTTPException(status_code=400, detail="No products found in CSV")
        else:
            text = content.decode("utf-8", errors="replace")
            result = await extraction_engine.extract_from_text(text, groq_service)

        extracted = result.get("extracted_attributes", {})
        product.name = extracted.get("product_name", extracted.get("manufacturer", filename))
        product.manufacturer = extracted.get("manufacturer")
        product.model_number = extracted.get("model_number")
        product.part_number = extracted.get("part_number")
        db.commit()

        raw_data = {
            "extracted_attributes": extracted,
            "source_name": result.get("source_name", filename),
            "extraction_method": result.get("extraction_method", "unknown"),
            "category": extracted.get("category", ""),
        }

        pipeline_result = await pipeline_service.process_product(
            db, product.id, raw_data,
            source_type=result.get("source_type", source_type),
            groq_service=groq_service,
        )

        db.refresh(product)
        return {
            "product_id": product.id, "status": pipeline_result.get("status", "completed"),
            "stages": pipeline_result.get("stages", {}),
            "overall_confidence": pipeline_result.get("overall_confidence"),
            "product": {"id": product.id, "name": product.name, "manufacturer": product.manufacturer,
                       "category": product.category, "status": product.status},
        }
    except Exception as e:
        product.status = "draft"
        product.processing_stage = "error"
        db.commit()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/bulk-upload")
async def bulk_upload(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    csv_text = content.decode("utf-8", errors="replace")
    rows = await extraction_engine.extract_from_csv(csv_text)

    results = []
    for row in rows:
        product = Product(id=str(uuid.uuid4()), status="processing",
                         name=row.get("extracted_attributes", {}).get("product_name", ""),
                         manufacturer=row.get("extracted_attributes", {}).get("manufacturer", ""))
        db.add(product)
        db.commit()

        raw_data = {"extracted_attributes": row.get("extracted_attributes", {}),
                    "source_name": file.filename, "extraction_method": "csv_import"}
        pipeline_result = await pipeline_service.process_product(
            db, product.id, raw_data, source_type="catalog", groq_service=groq_service)
        results.append({"product_id": product.id, "status": pipeline_result.get("status")})

    return {"total": len(results), "products": results}


@router.get("", response_model=ProductListResponse)
async def list_products(
    page: int = Query(1, ge=1), per_page: int = Query(20, ge=1, le=100),
    category: Optional[str] = None, status: Optional[str] = None,
    min_confidence: Optional[float] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
):
    query = db.query(Product)
    if category:
        query = query.filter(Product.category == category)
    if status:
        query = query.filter(Product.status == status)
    if min_confidence is not None:
        query = query.filter(Product.overall_confidence >= min_confidence)
    if search:
        query = query.filter(
            (Product.name.ilike(f"%{search}%")) |
            (Product.manufacturer.ilike(f"%{search}%")) |
            (Product.model_number.ilike(f"%{search}%"))
        )

    total = query.count()
    products = query.order_by(Product.updated_at.desc()).offset((page - 1) * per_page).limit(per_page).all()
    return ProductListResponse(products=products, total=total, page=page, per_page=per_page)


@router.get("/{product_id}", response_model=ProductResponse)
async def get_product(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.put("/{product_id}", response_model=ProductResponse)
async def update_product(product_id: str, data: ProductUpdate, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(product, field, value)
    db.commit()
    db.refresh(product)
    return product


@router.delete("/{product_id}")
async def delete_product(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    db.delete(product)
    db.commit()
    return {"message": "Product deleted"}


@router.post("/{product_id}/process")
async def process_product(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == product_id).all()
    raw_data = {attr.attribute_name: attr.raw_value or attr.normalized_value for attr in attrs}
    result = await pipeline_service.process_product(
        db, product_id, {"extracted_attributes": raw_data, "category": product.category},
        groq_service=groq_service)
    return result


@router.get("/{product_id}/before-after")
async def get_before_after(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return await pipeline_service.get_before_after(db, product_id)


@router.post("/{product_id}/attributes/{attr_id}/approve")
async def approve_attribute(product_id: str, attr_id: str, db: Session = Depends(get_db)):
    attr = db.query(ProductAttribute).filter(
        ProductAttribute.id == attr_id, ProductAttribute.product_id == product_id).first()
    if not attr:
        raise HTTPException(status_code=404, detail="Attribute not found")
    attr.approval_status = "accepted"
    attr.approved_value = attr.normalized_value or attr.raw_value
    audit = AuditTrail(id=str(uuid.uuid4()), product_id=product_id, attribute_id=attr_id,
                       action="approve", old_value=attr.raw_value, new_value=attr.approved_value,
                       reason="Human approved", performed_by="user")
    db.add(audit)
    db.commit()
    return {"status": "accepted", "attribute": attr.attribute_name, "approved_value": attr.approved_value}


@router.post("/{product_id}/attributes/{attr_id}/reject")
async def reject_attribute(product_id: str, attr_id: str, db: Session = Depends(get_db)):
    attr = db.query(ProductAttribute).filter(
        ProductAttribute.id == attr_id, ProductAttribute.product_id == product_id).first()
    if not attr:
        raise HTTPException(status_code=404, detail="Attribute not found")
    attr.approval_status = "rejected"
    audit = AuditTrail(id=str(uuid.uuid4()), product_id=product_id, attribute_id=attr_id,
                       action="reject", old_value=attr.normalized_value, reason="Human rejected", performed_by="user")
    db.add(audit)
    db.commit()
    return {"status": "rejected", "attribute": attr.attribute_name}
