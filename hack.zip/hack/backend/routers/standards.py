from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import get_db
from models import Product, StandardsMatch
from engines.standards_matching import standards_engine
from schemas import StandardsMatchResponse

router = APIRouter(prefix="/api/v1", tags=["Standards"])


@router.get("/products/{product_id}/standards")
async def get_standards(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    matches = db.query(StandardsMatch).filter(StandardsMatch.product_id == product_id).all()
    return {"product_id": product_id, "standards_matches": matches}


@router.post("/products/{product_id}/match-standards")
async def match_standards(product_id: str, db: Session = Depends(get_db)):
    from models import ProductAttribute
    import uuid, json
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == product_id).all()
    attributes = {attr.attribute_name: attr.normalized_value or attr.raw_value for attr in attrs}
    results = standards_engine.match_all_standards(product.category or "general", product.name or "", attributes)

    db.query(StandardsMatch).filter(StandardsMatch.product_id == product_id).delete()
    for sr in results:
        record = StandardsMatch(
            id=str(uuid.uuid4()), product_id=product_id,
            standard_type=sr.get("standard_type", ""), standard_code=sr.get("standard_code"),
            standard_description=sr.get("standard_description", ""),
            match_confidence=sr.get("match_confidence", 0), match_method=sr.get("match_method", ""),
            match_explanation=sr.get("match_explanation", ""), verified=sr.get("verified", False),
        )
        db.add(record)
    db.commit()
    return {"product_id": product_id, "standards_matches": results}


@router.get("/standards/search")
async def search_standards(
    q: str = Query(..., min_length=1),
    standard_type: str = Query(None, regex="^(unspsc|eclass|etim)$"),
):
    results = standards_engine.search_standards(q, standard_type)
    return {"query": q, "standard_type": standard_type, "results": results}
