from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Product, ProductAttribute
from services.passport import passport_service

router = APIRouter(prefix="/api/v1/catalog", tags=["Catalog"])


@router.get("")
async def get_catalog(
    page: int = Query(1, ge=1), per_page: int = Query(20, ge=1, le=200),
    category: str = Query(None), status: str = Query(None),
    min_confidence: float = Query(None), validation_status: str = Query(None),
    search: str = Query(None), db: Session = Depends(get_db),
):
    query = db.query(Product)
    if category:
        query = query.filter(Product.category == category)
    if status:
        query = query.filter(Product.status == status)
    if min_confidence is not None:
        query = query.filter(Product.overall_confidence >= min_confidence)
    if validation_status:
        # products with at least one attribute in this validation status
        from sqlalchemy import exists
        query = query.filter(
            exists().where(ProductAttribute.product_id == Product.id,
                           ProductAttribute.validation_status == validation_status)
        )
    if search:
        query = query.filter(
            (Product.name.ilike(f"%{search}%")) |
            (Product.manufacturer.ilike(f"%{search}%")) |
            (Product.model_number.ilike(f"%{search}%"))
        )
    total = query.count()
    items = query.order_by(Product.updated_at.desc()).offset((page - 1) * per_page).limit(per_page).all()
    return {"total": total, "page": page, "per_page": per_page, "items": items}


@router.get("/stats")
async def catalog_stats(db: Session = Depends(get_db)):
    from sqlalchemy import func
    total = db.query(Product).count()
    by_status = dict(db.query(Product.status, func.count(Product.id)).group_by(Product.status).all())
    by_category = dict(db.query(Product.category, func.count(Product.id)).group_by(Product.category).all())
    avg_conf = db.query(func.avg(Product.overall_confidence)).scalar() or 0
    valid_count = db.query(ProductAttribute).filter(ProductAttribute.validation_status == "valid").count()
    warning_count = db.query(ProductAttribute).filter(ProductAttribute.validation_status == "warning").count()
    conflict_count = db.query(ProductAttribute).filter(ProductAttribute.validation_status == "conflict").count()
    return {
        "total_products": total,
        "by_status": by_status,
        "by_category": by_category,
        "average_confidence": round(float(avg_conf), 3),
        "validation_summary": {"valid": valid_count, "warning": warning_count, "conflict": conflict_count},
    }


@router.get("/compare")
async def compare_products(product_ids: List[str] = Query(...), db: Session = Depends(get_db)):
    if len(product_ids) < 2:
        raise HTTPException(status_code=400, detail="Provide at least 2 product IDs")
    products = db.query(Product).filter(Product.id.in_(product_ids)).all()
    result = []
    for p in products:
        attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == p.id).all()
        result.append({
            "id": p.id, "name": p.name, "manufacturer": p.manufacturer,
            "category": p.category, "attributes": {a.attribute_name: a.normalized_value for a in attrs},
            "overall_confidence": p.overall_confidence,
        })
    common = set(result[0]["attributes"].keys())
    for r in result[1:]:
        common &= set(r["attributes"].keys())
    differing = []
    for c in common:
        values = set(r["attributes"].get(c) for r in result)
        if len(values) > 1:
            differing.append(c)
    return {"products": result, "common_attributes": list(common), "differing_attributes": differing}


@router.get("/export")
async def export_catalog(format: str = Query(..., regex="^(json|csv)$"), db: Session = Depends(get_db)):
    import json, csv, io
    products = db.query(Product).all()
    if format == "json":
        data = []
        for p in products:
            passport = passport_service.generate_passport(db, p.id)
            if "error" not in passport:
                data.append(passport)
        return {"format": "json", "count": len(data), "data": data}
    else:
        output = io.StringIO()
        writer = None
        rows = []
        for p in products:
            passport = passport_service.generate_passport(db, p.id)
            if "error" not in passport:
                rows.extend(passport_service.passport_to_csv_rows(passport))
        if rows:
            writer = csv.DictWriter(output, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        return {"format": "csv", "count": len(rows), "csv": output.getvalue()}
