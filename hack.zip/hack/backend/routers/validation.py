from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models import Product, ProductAttribute, ValidationResult
from engines.validation_engine import validation_engine
from engines.evidence import evidence_engine

router = APIRouter(prefix="/api/v1/products/{product_id}/validation", tags=["Validation"])


@router.get("")
async def get_validation(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    results = db.query(ValidationResult).filter(ValidationResult.product_id == product_id).all()
    return {"product_id": product_id, "category": product.category,
            "validation_results": [{"id": r.id, "rule_name": r.rule_name, "rule_type": r.rule_type,
                                  "status": r.status, "message": r.message, "severity": r.severity,
                                  "details": r.details} for r in results]}


@router.post("")
async def run_validation(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == product_id).all()
    attributes = {attr.attribute_name: attr.normalized_value or attr.raw_value for attr in attrs}
    results = validation_engine.validate_product(product.category or "general", attributes)

    # Clear old validation results and store new
    db.query(ValidationResult).filter(ValidationResult.product_id == product_id).delete()
    import json, uuid
    for vr in results:
        attr = next((a for a in attrs if a.attribute_name == vr.get("attribute_name")), None)
        record = ValidationResult(
            id=str(uuid.uuid4()), product_id=product_id,
            attribute_id=attr.id if attr else None,
            rule_name=vr.get("rule_name", ""), rule_type=vr.get("rule_type", ""),
            status=vr.get("status", ""), message=vr.get("message", ""),
            details=json.dumps(vr.get("details", {})), severity=vr.get("severity", "info"),
        )
        db.add(record)
        if attr:
            attr.validation_status = vr.get("status", attr.validation_status)
    db.commit()
    return {"product_id": product_id, "validation_results": results}


@router.get("/summary")
async def validation_summary(product_id: str, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    results = db.query(ValidationResult).filter(ValidationResult.product_id == product_id).all()
    summary = {"valid": 0, "warning": 0, "conflict": 0, "critical": 0, "info": 0}
    for r in results:
        if r.status in summary:
            summary[r.status] += 1
        if r.severity in ("critical", "warning"):
            summary[r.severity] += 1
    return {"product_id": product_id, "summary": summary, "total": len(results)}
