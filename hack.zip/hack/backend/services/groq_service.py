"""
Groq API integration service for IntelliSpec.

Provides LLM-powered extraction, enrichment, categorization, and explanation
capabilities via the Groq cloud API (OpenAI-compatible endpoint).
"""

import json
import re
import logging
from typing import Optional

import httpx

from config import GROQ_API_KEY, GROQ_CHAT_MODEL, GROQ_VISION_MODEL, GROQ_API_URL

logger = logging.getLogger(__name__)

# ── Helpers ──────────────────────────────────────────────────────────────────


def _parse_json_response(text: str) -> dict:
    """Extract and parse JSON from an LLM text response.

    Handles plain JSON, ```json fenced blocks, and ``` fenced blocks.
    Falls back to returning the raw text wrapped in a dict.
    """
    if not text:
        return {}

    # 1. Try to pull JSON from a fenced code block (```json ... ``` or ``` ... ```)
    fence_match = re.search(r"```(?:json)?\s*\n?(.*?)```", text, re.DOTALL)
    if fence_match:
        try:
            return json.loads(fence_match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # 2. Try to parse the whole response as JSON directly
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        pass

    # 3. Try to find the first { ... } or [ ... ] block in the text
    brace_match = re.search(r"(\{.*\})", text, re.DOTALL)
    if brace_match:
        try:
            return json.loads(brace_match.group(1))
        except json.JSONDecodeError:
            pass

    bracket_match = re.search(r"(\[.*\])", text, re.DOTALL)
    if bracket_match:
        try:
            parsed = json.loads(bracket_match.group(1))
            return {"items": parsed} if isinstance(parsed, list) else parsed
        except json.JSONDecodeError:
            pass

    # 4. Last resort – return raw text so callers always get a dict
    return {"raw_text": text}


# ── Service ──────────────────────────────────────────────────────────────────


class GroqService:
    """Async wrapper around the Groq chat-completion & vision APIs."""

    def __init__(self) -> None:
        self.available: bool = bool(GROQ_API_KEY)
        self.chat_model: str = GROQ_CHAT_MODEL
        self.vision_model: str = GROQ_VISION_MODEL

        if not self.available:
            logger.warning(
                "GROQ_API_KEY is not set – GroqService running in fallback mode"
            )
            self._client: Optional[httpx.AsyncClient] = None
            return

        self._client = httpx.AsyncClient(
            base_url=GROQ_API_URL,
            headers={
                "Authorization": f"Bearer {GROQ_API_KEY}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(60.0, connect=10.0),
        )

    # ── Core request ─────────────────────────────────────────────────────

    async def chat_completion(
        self,
        messages: list,
        temperature: float = 0.1,
        max_tokens: int = 4096,
        model: Optional[str] = None,
    ) -> dict:
        """Send a chat-completion request to the Groq API.

        Returns the parsed API response dict, or an error dict on failure.
        """
        if not self.available or self._client is None:
            return self._fallback_response("chat_completion")

        payload = {
            "model": model or self.chat_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
        }

        try:
            response = await self._client.post("/chat/completions", json=payload)
            response.raise_for_status()
            data = response.json()
            return data
        except httpx.HTTPStatusError as exc:
            logger.error("Groq API HTTP error %s: %s", exc.response.status_code, exc.response.text)
            return {
                "error": True,
                "status_code": exc.response.status_code,
                "message": f"Groq API error: {exc.response.status_code}",
                "details": exc.response.text,
            }
        except httpx.RequestError as exc:
            logger.error("Groq API request error: %s", exc)
            return {
                "error": True,
                "message": f"Groq API request failed: {exc}",
            }
        except Exception as exc:
            logger.exception("Unexpected error during Groq chat completion")
            return {
                "error": True,
                "message": f"Unexpected error: {exc}",
            }

    # ── Text extraction ──────────────────────────────────────────────────

    async def extract_from_text(
        self, raw_text: str, source_type: str = "unknown"
    ) -> dict:
        """Extract structured product attributes from raw text using the LLM.

        Returns a JSON dict with manufacturer, product_name, model_number,
        part_number, category, and a specifications mapping.
        """
        if not self.available:
            return self._fallback_extract_text(raw_text)

        system_prompt = (
            "You are an expert industrial product data extraction system. "
            "Analyze the provided text and extract all product attributes.\n\n"
            "Return a JSON object with exactly these top-level keys:\n"
            "- \"manufacturer\": string or null\n"
            "- \"product_name\": string or null\n"
            "- \"model_number\": string or null\n"
            "- \"part_number\": string or null\n"
            "- \"category\": string or null (e.g. \"Motor\", \"Valve\", \"Pump\", \"Sensor\")\n"
            "- \"description\": string or null\n"
            "- \"specifications\": object mapping attribute names to objects with "
            "\"value\" (string/number) and \"unit\" (string or null) keys\n\n"
            "Rules:\n"
            "1. Preserve original values exactly as they appear.\n"
            "2. Include ALL technical specifications (voltage, current, power, "
            "pressure, temperature, dimensions, weight, material, etc.).\n"
            "3. If a value has a unit, separate it into the \"unit\" field.\n"
            "4. If information is not present, set the field to null.\n"
            "5. Return ONLY valid JSON – no commentary."
        )

        user_prompt = (
            f"Source type: {source_type}\n\n"
            f"Text to extract from:\n\"\"\"\n{raw_text}\n\"\"\""
        )

        try:
            result = await self.chat_completion(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
            )

            if result.get("error"):
                return result

            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            return _parse_json_response(content)

        except Exception as exc:
            logger.exception("Error in extract_from_text")
            return {"error": True, "message": f"Extraction failed: {exc}"}

    # ── Image extraction (vision) ────────────────────────────────────────

    async def extract_from_image(
        self, image_base64: str, image_type: str = "image/jpeg"
    ) -> dict:
        """Extract product attributes from an image using the vision model.

        Suitable for nameplates, product labels, spec stickers, etc.
        Returns structured JSON with all visible text and attributes.
        """
        if not self.available:
            return self._fallback_extract_image()

        system_prompt = (
            "You are an expert industrial product identification system "
            "specializing in reading nameplates, product labels, and "
            "specification stickers.\n\n"
            "Analyze the image and extract ALL visible text and product "
            "attributes.\n\n"
            "Return a JSON object with these keys:\n"
            "- \"raw_text\": string – all visible text transcribed from the image\n"
            "- \"manufacturer\": string or null\n"
            "- \"product_name\": string or null\n"
            "- \"model_number\": string or null\n"
            "- \"part_number\": string or null\n"
            "- \"serial_number\": string or null\n"
            "- \"category\": string or null\n"
            "- \"specifications\": object mapping attribute names to objects with "
            "\"value\" and \"unit\" keys\n"
            "- \"certifications\": list of certification marks/logos visible\n"
            "- \"confidence_notes\": string – note any text that was hard to read\n\n"
            "Return ONLY valid JSON."
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Extract all product information from this image.",
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{image_type};base64,{image_base64}",
                        },
                    },
                ],
            },
        ]

        try:
            result = await self.chat_completion(
                messages=messages,
                temperature=0.1,
                model=self.vision_model,
            )

            if result.get("error"):
                return result

            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            return _parse_json_response(content)

        except Exception as exc:
            logger.exception("Error in extract_from_image")
            return {"error": True, "message": f"Image extraction failed: {exc}"}

    # ── Product identification ───────────────────────────────────────────

    async def identify_product(self, attributes: dict) -> dict:
        """Identify the product category and suggest a relevant attribute schema.

        Given a set of extracted attributes, determines the product category,
        subcategory, and which additional attributes are typically relevant.
        """
        if not self.available:
            return self._fallback_identify()

        system_prompt = (
            "You are an expert industrial product classification system.\n\n"
            "Given a set of product attributes, determine:\n"
            "1. The product category (e.g. Motor, Pump, Valve, Sensor, "
            "Bearing, Gearbox, Compressor, Heat Exchanger, etc.)\n"
            "2. A more specific subcategory\n"
            "3. A list of additional attributes that are typically important "
            "for this product type but may be missing from the input\n\n"
            "Return a JSON object with:\n"
            "- \"category\": string\n"
            "- \"subcategory\": string\n"
            "- \"confidence\": float 0-1\n"
            "- \"reasoning\": string explaining the classification\n"
            "- \"suggested_attributes\": list of objects with \"name\" (string), "
            "\"description\" (string), \"importance\" (\"critical\" | \"important\" "
            "| \"optional\"), and \"typical_unit\" (string or null)\n\n"
            "Return ONLY valid JSON."
        )

        user_prompt = (
            "Identify and classify this product based on its attributes:\n\n"
            f"{json.dumps(attributes, indent=2)}"
        )

        try:
            result = await self.chat_completion(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
            )

            if result.get("error"):
                return result

            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            return _parse_json_response(content)

        except Exception as exc:
            logger.exception("Error in identify_product")
            return {"error": True, "message": f"Product identification failed: {exc}"}

    # ── Enrichment ───────────────────────────────────────────────────────

    async def enrich_product(
        self, product_data: dict, missing_attributes: list
    ) -> dict:
        """Infer or enrich missing attribute values for a product.

        Each enriched value includes a confidence indicator and reasoning
        explaining how the value was derived.
        """
        if not self.available:
            return self._fallback_enrich(missing_attributes)

        system_prompt = (
            "You are an expert industrial product knowledge base.\n\n"
            "Given existing product data and a list of missing attributes, "
            "attempt to infer reasonable values for the missing attributes "
            "based on your knowledge of the product and its category.\n\n"
            "Return a JSON object with:\n"
            "- \"enriched_attributes\": list of objects, each containing:\n"
            "  - \"name\": attribute name\n"
            "  - \"value\": inferred value (string or number)\n"
            "  - \"unit\": string or null\n"
            "  - \"confidence\": float 0-1 indicating certainty\n"
            "  - \"reasoning\": string explaining how the value was inferred\n"
            "  - \"source\": always \"ai_enriched\"\n"
            "- \"unable_to_enrich\": list of attribute names you could NOT "
            "confidently infer, each with a \"reason\" string\n\n"
            "Rules:\n"
            "1. Only provide values you are reasonably confident about.\n"
            "2. Set confidence below 0.5 for educated guesses.\n"
            "3. Never fabricate specific serial numbers or unique identifiers.\n"
            "4. Base inferences on the product's manufacturer, model, and "
            "category when available.\n"
            "5. Return ONLY valid JSON."
        )

        user_prompt = (
            "Product data:\n"
            f"{json.dumps(product_data, indent=2)}\n\n"
            "Missing attributes to enrich:\n"
            f"{json.dumps(missing_attributes, indent=2)}"
        )

        try:
            result = await self.chat_completion(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
            )

            if result.get("error"):
                return result

            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            return _parse_json_response(content)

        except Exception as exc:
            logger.exception("Error in enrich_product")
            return {"error": True, "message": f"Enrichment failed: {exc}"}

    # ── Explanation generation ───────────────────────────────────────────

    async def generate_explanation(self, context: dict) -> str:
        """Generate a human-readable explanation for a decision.

        Context should describe the decision (e.g. conflict resolution,
        value selection, validation override) with relevant details.
        """
        if not self.available:
            return self._fallback_explanation(context)

        system_prompt = (
            "You are a technical documentation assistant for an industrial "
            "product data management system called IntelliSpec.\n\n"
            "Generate a clear, concise, human-readable explanation for the "
            "decision described below. The explanation should:\n"
            "1. State what decision was made\n"
            "2. Explain why (evidence, reasoning)\n"
            "3. Note any caveats or alternative interpretations\n"
            "4. Be written for a technical procurement or engineering audience\n\n"
            "Return a JSON object with a single key \"explanation\" whose value "
            "is the explanation string."
        )

        user_prompt = (
            "Generate an explanation for this decision:\n\n"
            f"{json.dumps(context, indent=2)}"
        )

        try:
            result = await self.chat_completion(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
                max_tokens=1024,
            )

            if result.get("error"):
                return f"Unable to generate explanation: {result.get('message', 'Unknown error')}"

            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )

            parsed = _parse_json_response(content)
            return parsed.get("explanation", content)

        except Exception as exc:
            logger.exception("Error in generate_explanation")
            return f"Explanation generation failed: {exc}"

    # ── Categorization ───────────────────────────────────────────────────

    async def categorize_product(self, product_info: dict) -> dict:
        """Categorize a product into a supported IntelliSpec category.

        Returns category, subcategory, and confidence.
        """
        if not self.available:
            return self._fallback_categorize()

        system_prompt = (
            "You are an industrial product classification expert.\n\n"
            "Categorize the product into ONE of these supported categories:\n"
            "- Motor (AC Motor, DC Motor, Servo Motor, Stepper Motor)\n"
            "- Pump (Centrifugal, Positive Displacement, Submersible, Gear)\n"
            "- Valve (Ball, Gate, Globe, Butterfly, Check, Solenoid)\n"
            "- Sensor (Temperature, Pressure, Flow, Level, Proximity, Vibration)\n"
            "- Bearing (Ball, Roller, Thrust, Linear, Sleeve)\n"
            "- Gearbox (Helical, Planetary, Worm, Bevel)\n"
            "- Compressor (Reciprocating, Rotary Screw, Centrifugal)\n"
            "- Heat Exchanger (Shell-Tube, Plate, Air-Cooled)\n"
            "- Controller (PLC, VFD, Soft Starter, DCS)\n"
            "- Instrument (Transmitter, Gauge, Analyzer, Recorder)\n"
            "- Other (specify subcategory)\n\n"
            "Return a JSON object with:\n"
            "- \"category\": one of the above categories\n"
            "- \"subcategory\": specific sub-type\n"
            "- \"confidence\": float 0-1\n"
            "- \"reasoning\": brief explanation\n\n"
            "Return ONLY valid JSON."
        )

        user_prompt = (
            "Categorize this product:\n\n"
            f"{json.dumps(product_info, indent=2)}"
        )

        try:
            result = await self.chat_completion(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
                max_tokens=512,
            )

            if result.get("error"):
                return result

            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            return _parse_json_response(content)

        except Exception as exc:
            logger.exception("Error in categorize_product")
            return {"error": True, "message": f"Categorization failed: {exc}"}

    # ── Fallback responses ───────────────────────────────────────────────

    @staticmethod
    def _fallback_response(method: str) -> dict:
        return {
            "error": False,
            "fallback": True,
            "message": f"Groq API unavailable – returning fallback for {method}",
            "choices": [
                {
                    "message": {
                        "content": json.dumps({"fallback": True, "method": method}),
                    }
                }
            ],
        }

    @staticmethod
    def _fallback_extract_text(raw_text: str) -> dict:
        return {
            "fallback": True,
            "manufacturer": None,
            "product_name": None,
            "model_number": None,
            "part_number": None,
            "category": None,
            "description": raw_text[:200] if raw_text else None,
            "specifications": {},
        }

    @staticmethod
    def _fallback_extract_image() -> dict:
        return {
            "fallback": True,
            "raw_text": "",
            "manufacturer": None,
            "product_name": None,
            "model_number": None,
            "part_number": None,
            "serial_number": None,
            "category": None,
            "specifications": {},
            "certifications": [],
            "confidence_notes": "Vision model unavailable – fallback mode",
        }

    @staticmethod
    def _fallback_identify() -> dict:
        return {
            "fallback": True,
            "category": "Other",
            "subcategory": "Unknown",
            "confidence": 0.0,
            "reasoning": "Groq API unavailable – unable to identify product",
            "suggested_attributes": [],
        }

    @staticmethod
    def _fallback_enrich(missing_attributes: list) -> dict:
        return {
            "fallback": True,
            "enriched_attributes": [],
            "unable_to_enrich": [
                {"name": attr, "reason": "Groq API unavailable"}
                for attr in (missing_attributes or [])
            ],
        }

    @staticmethod
    def _fallback_explanation(context: dict) -> str:
        decision = context.get("decision", "unknown decision")
        return (
            f"Automated explanation unavailable (Groq API not configured). "
            f"Decision: {decision}. Please review the evidence manually."
        )

    @staticmethod
    def _fallback_categorize() -> dict:
        return {
            "fallback": True,
            "category": "Other",
            "subcategory": "Unknown",
            "confidence": 0.0,
            "reasoning": "Groq API unavailable – unable to categorize product",
        }


# ── Module-level singleton ───────────────────────────────────────────────────

groq_service = GroqService()
