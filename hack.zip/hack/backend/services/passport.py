import json
from datetime import datetime
from typing import Dict, List, Any, Optional


class PassportService:
    """Generates Product Intelligence Passports."""

    def generate_passport(self, db, product_id: str) -> dict:
        from models import Product, ProductAttribute, AttributeSource, ValidationResult, StandardsMatch, ReplacementPart, AuditTrail

        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return {"error": "Product not found"}

        attributes = db.query(ProductAttribute).filter(ProductAttribute.product_id == product_id).all()
        validation_results = db.query(ValidationResult).filter(ValidationResult.product_id == product_id).all()
        standards_matches = db.query(StandardsMatch).filter(StandardsMatch.product_id == product_id).all()
        replacements = db.query(ReplacementPart).filter(ReplacementPart.original_product_id == product_id).all()
        audit_entries = db.query(AuditTrail).filter(AuditTrail.product_id == product_id).order_by(AuditTrail.created_at.desc()).limit(50).all()

        passport = {
            "product_id": product_id,
            "generated_at": datetime.utcnow().isoformat(),
            "product_identity": {
                "name": product.name, "manufacturer": product.manufacturer,
                "model_number": product.model_number, "part_number": product.part_number,
                "category": product.category, "subcategory": product.subcategory,
                "description": product.description, "status": product.status,
            },
            "technical_specifications": [],
            "classifications": [],
            "evidence_summary": [],
            "validation_results": [],
            "conflicts": [],
            "missing_attributes": [],
            "replacement_options": [],
            "approval_status": {"overall_status": product.status, "pending_approvals": 0, "accepted": 0, "rejected": 0},
            "overall_confidence": product.overall_confidence or 0.0,
            "audit_trail": [],
        }

        pending = accepted = rejected = 0
        for attr in attributes:
            sources = db.query(AttributeSource).filter(AttributeSource.attribute_id == attr.id).all()
            spec = {
                "attribute": attr.attribute_name, "raw_value": attr.raw_value,
                "normalized_value": attr.normalized_value, "approved_value": attr.approved_value,
                "unit": attr.unit, "confidence": attr.confidence,
                "validation_status": attr.validation_status, "approval_status": attr.approval_status,
                "is_enriched": attr.is_enriched, "is_critical": attr.is_critical, "priority": attr.priority,
                "sources": [{"source_type": s.source_type, "source_name": s.source_name,
                           "value": s.source_value, "trust_score": s.trust_score, "method": s.extraction_method} for s in sources],
            }
            passport["technical_specifications"].append(spec)
            if attr.approval_status == "pending": pending += 1
            elif attr.approval_status == "accepted": accepted += 1
            elif attr.approval_status == "rejected": rejected += 1

        passport["approval_status"].update({"pending_approvals": pending, "accepted": accepted, "rejected": rejected})

        for sm in standards_matches:
            passport["classifications"].append({
                "standard_type": sm.standard_type, "code": sm.standard_code,
                "description": sm.standard_description, "confidence": sm.match_confidence,
                "method": sm.match_method, "explanation": sm.match_explanation, "verified": sm.verified,
            })

        all_sources = db.query(AttributeSource).filter(AttributeSource.product_id == product_id).all()
        source_types = {}
        for s in all_sources:
            st = s.source_type or "unknown"
            if st not in source_types:
                source_types[st] = {"count": 0, "values": []}
            source_types[st]["count"] += 1
            source_types[st]["values"].append(s.trust_score or 0)
        for st, data in source_types.items():
            avg_trust = sum(data["values"]) / len(data["values"]) if data["values"] else 0
            passport["evidence_summary"].append({"source_type": st, "attribute_count": data["count"], "average_trust_score": round(avg_trust, 3)})

        for vr in validation_results:
            passport["validation_results"].append({
                "rule_name": vr.rule_name, "rule_type": vr.rule_type, "status": vr.status,
                "message": vr.message, "severity": vr.severity,
                "details": json.loads(vr.details) if vr.details else {},
            })
        passport["conflicts"] = [v for v in passport["validation_results"] if v["status"] == "conflict"]

        from engines.evidence import evidence_engine
        present = [attr.attribute_name for attr in attributes]
        missing = evidence_engine.prioritize_missing_attributes(product.category or "general", present, {})
        passport["missing_attributes"] = missing

        for rep in replacements:
            passport["replacement_options"].append({
                "replacement_product_id": rep.replacement_product_id, "compatibility_score": rep.compatibility_score,
                "matched_attributes": json.loads(rep.matched_attributes) if rep.matched_attributes else [],
                "mismatched_attributes": json.loads(rep.mismatched_attributes) if rep.mismatched_attributes else [],
                "critical_differences": json.loads(rep.critical_differences) if rep.critical_differences else [],
                "recommendation_reason": rep.recommendation_reason,
            })

        for ae in audit_entries:
            passport["audit_trail"].append({
                "action": ae.action, "old_value": ae.old_value, "new_value": ae.new_value,
                "reason": ae.reason, "performed_by": ae.performed_by,
                "timestamp": ae.created_at.isoformat() if ae.created_at else None,
            })
        return passport

    def passport_to_csv_rows(self, passport: dict) -> list:
        rows = []
        identity = passport.get("product_identity", {})
        base = {
            "product_id": passport.get("product_id", ""), "name": identity.get("name", ""),
            "manufacturer": identity.get("manufacturer", ""), "model_number": identity.get("model_number", ""),
            "part_number": identity.get("part_number", ""), "category": identity.get("category", ""),
            "overall_confidence": passport.get("overall_confidence", ""), "status": identity.get("status", ""),
        }
        for spec in passport.get("technical_specifications", []):
            row = dict(base)
            row.update({
                "attribute": spec.get("attribute", ""), "raw_value": spec.get("raw_value", ""),
                "normalized_value": spec.get("normalized_value", ""), "approved_value": spec.get("approved_value", ""),
                "unit": spec.get("unit", ""), "confidence": spec.get("confidence", ""),
                "validation_status": spec.get("validation_status", ""), "approval_status": spec.get("approval_status", ""),
                "is_enriched": spec.get("is_enriched", ""),
            })
            rows.append(row)
        if not rows:
            rows.append(base)
        return rows


passport_service = PassportService()
