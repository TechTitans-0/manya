import json
import uuid
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class PipelineService:
    """Orchestrates the complete product intelligence pipeline."""

    def __init__(self):
        self.stages = [
            "extraction", "identification", "normalization", "enrichment",
            "evidence", "conflict_detection", "validation", "standards_matching",
            "confidence", "explainability"
        ]

    async def process_product(self, db, product_id: str, raw_data: dict,
                               source_type: str = "manual_input",
                               groq_service=None) -> dict:
        from models import Product, ProductAttribute, AttributeSource, ValidationResult, StandardsMatch, AuditTrail
        from engines.extraction import extraction_engine
        from engines.normalization import normalization_engine
        from engines.enrichment import enrichment_engine
        from engines.validation_engine import validation_engine
        from engines.evidence import evidence_engine
        from engines.conflict_detection import conflict_engine
        from engines.standards_matching import standards_engine
        from engines.explainability import explainability_engine

        results = {"product_id": product_id, "stages": {}, "errors": []}
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return {"error": "Product not found"}

        try:
            product.processing_stage = "extraction"
            product.status = "processing"
            db.commit()

            extracted = raw_data.get("extracted_attributes", raw_data)
            results["stages"]["extraction"] = {"status": "completed", "attributes_found": len(extracted)}

            # Identification & Categorization
            product.processing_stage = "identification"
            db.commit()

            category = raw_data.get("category", "")
            if groq_service and groq_service.available and not category:
                cat_result = await groq_service.categorize_product(extracted)
                if not cat_result.get("error"):
                    category = cat_result.get("category", "general")
                    product.category = category
                    product.subcategory = cat_result.get("subcategory", "")
                    db.commit()

            if not category:
                category = self._guess_category(extracted)
                product.category = category
                db.commit()

            results["stages"]["identification"] = {"status": "completed", "category": category}

            # Normalization
            product.processing_stage = "normalization"
            db.commit()
            normalized = normalization_engine.normalize_product_attributes(extracted)
            results["stages"]["normalization"] = {"status": "completed", "normalized_count": len(normalized)}

            # Store attributes
            stored_attrs = {}
            for attr_name, value in extracted.items():
                norm_data = normalized.get(attr_name, {})
                norm_value = norm_data.get("normalized_value", value) if isinstance(norm_data, dict) else value

                attr = ProductAttribute(
                    id=str(uuid.uuid4()), product_id=product_id,
                    attribute_name=attr_name, raw_value=str(value),
                    normalized_value=str(norm_value),
                    unit=norm_data.get("unit", "") if isinstance(norm_data, dict) else "",
                    data_type="numeric" if (isinstance(norm_data, dict) and norm_data.get("numeric_value") is not None) else "text",
                    validation_status="unvalidated", approval_status="pending", is_enriched=False,
                )
                db.add(attr)
                stored_attrs[attr_name] = attr

                source = AttributeSource(
                    id=str(uuid.uuid4()), attribute_id=attr.id, product_id=product_id,
                    source_type=source_type,
                    source_name=raw_data.get("source_name", source_type),
                    source_value=str(value),
                    trust_score=evidence_engine.calculate_source_trust(source_type, attr_name),
                    extraction_method=raw_data.get("extraction_method", "manual"),
                )
                db.add(source)

                audit = AuditTrail(
                    id=str(uuid.uuid4()), product_id=product_id, attribute_id=attr.id,
                    action="extract", new_value=str(value),
                    reason=f"Extracted from {source_type}", performed_by="system",
                )
                db.add(audit)
            db.commit()

            # Enrichment
            product.processing_stage = "enrichment"
            db.commit()
            enrichment_result = await enrichment_engine.enrich_product(extracted, category, groq_service)
            enriched_attrs = enrichment_result.get("enriched_attributes", {})

            for attr_name, enrich_data in enriched_attrs.items():
                if attr_name not in stored_attrs:
                    attr = ProductAttribute(
                        id=str(uuid.uuid4()), product_id=product_id,
                        attribute_name=attr_name, raw_value=None,
                        normalized_value=str(enrich_data.get("value", "")),
                        unit=enrich_data.get("unit", ""),
                        data_type="text",
                        confidence=enrich_data.get("confidence", 0.5),
                        validation_status="unvalidated", approval_status="pending", is_enriched=True,
                    )
                    db.add(attr)
                    stored_attrs[attr_name] = attr

                    source = AttributeSource(
                        id=str(uuid.uuid4()), attribute_id=attr.id, product_id=product_id,
                        source_type="ai_enriched",
                        source_name=enrich_data.get("source", "AI enrichment"),
                        source_value=str(enrich_data.get("value", "")),
                        trust_score=evidence_engine.calculate_source_trust("ai_enriched", attr_name),
                        extraction_method="llm_extract" if groq_service else "deterministic_rule",
                    )
                    db.add(source)

                    audit = AuditTrail(
                        id=str(uuid.uuid4()), product_id=product_id, attribute_id=attr.id,
                        action="enrich", new_value=str(enrich_data.get("value", "")),
                        reason=enrich_data.get("reason", "AI enrichment"), performed_by="system",
                    )
                    db.add(audit)
            db.commit()
            results["stages"]["enrichment"] = {"status": "completed", "enriched_count": len(enriched_attrs)}

            # Validation
            product.processing_stage = "validation"
            db.commit()
            all_attrs = {name: attr.normalized_value or attr.raw_value for name, attr in stored_attrs.items()}
            validation_results = validation_engine.validate_product(category, all_attrs)

            for vr in validation_results:
                attr_obj = stored_attrs.get(vr.get("attribute_name"))
                val_record = ValidationResult(
                    id=str(uuid.uuid4()), product_id=product_id,
                    attribute_id=attr_obj.id if attr_obj else None,
                    rule_name=vr.get("rule_name", ""), rule_type=vr.get("rule_type", ""),
                    status=vr.get("status", ""), message=vr.get("message", ""),
                    details=json.dumps(vr.get("details", {})), severity=vr.get("severity", "info"),
                )
                db.add(val_record)

                attr_name_for_val = vr.get("attribute_name")
                if attr_name_for_val and attr_name_for_val in stored_attrs:
                    current_status = stored_attrs[attr_name_for_val].validation_status
                    new_status = vr.get("status", "unvalidated")
                    if new_status == "conflict" or (new_status == "warning" and current_status != "conflict"):
                        stored_attrs[attr_name_for_val].validation_status = new_status
                    elif new_status == "valid" and current_status == "unvalidated":
                        stored_attrs[attr_name_for_val].validation_status = "valid"
            db.commit()
            results["stages"]["validation"] = {
                "status": "completed", "total_rules": len(validation_results),
                "valid": sum(1 for v in validation_results if v.get("status") == "valid"),
                "warnings": sum(1 for v in validation_results if v.get("status") == "warning"),
                "conflicts": sum(1 for v in validation_results if v.get("status") == "conflict"),
            }

            # Standards Matching
            product.processing_stage = "standards_matching"
            db.commit()
            product_name = product.name or extracted.get("product_name", "")
            std_results = standards_engine.match_all_standards(category, product_name, all_attrs)

            for sr in std_results:
                match_record = StandardsMatch(
                    id=str(uuid.uuid4()), product_id=product_id,
                    standard_type=sr.get("standard_type", ""),
                    standard_code=sr.get("standard_code"),
                    standard_description=sr.get("standard_description", ""),
                    match_confidence=sr.get("match_confidence", 0),
                    match_method=sr.get("match_method", ""),
                    match_explanation=sr.get("match_explanation", ""),
                    verified=sr.get("verified", False),
                )
                db.add(match_record)
            db.commit()
            results["stages"]["standards_matching"] = {
                "status": "completed",
                "matches": [{"type": s.get("standard_type"), "code": s.get("standard_code"),
                            "confidence": s.get("match_confidence", 0)} for s in std_results]
            }

            # Confidence Calculation
            product.processing_stage = "confidence"
            db.commit()
            attr_confidences = []
            critical_names = {"voltage", "power", "current", "frequency", "manufacturer",
                              "model_number", "part_number", "bore_diameter", "outer_diameter"}
            for attr_name, attr in stored_attrs.items():
                sources = db.query(AttributeSource).filter(AttributeSource.attribute_id == attr.id).all()
                source_dicts = [{"source_value": s.source_value, "trust_score": s.trust_score or 0.5} for s in sources]
                attr_validations = [v for v in validation_results if v.get("attribute_name") == attr_name]
                conf = evidence_engine.calculate_attribute_confidence(source_dicts, attr_validations, has_evidence=len(sources) > 0)
                attr.confidence = conf
                attr_confidences.append((attr_name, conf, attr_name in critical_names))

            product_confidence = evidence_engine.calculate_product_confidence(attr_confidences)
            product.overall_confidence = product_confidence
            db.commit()
            results["stages"]["confidence"] = {
                "status": "completed", "overall_confidence": product_confidence,
                "attribute_count": len(attr_confidences),
            }

            product.processing_stage = "completed"
            product.status = "reviewed"
            product.updated_at = datetime.utcnow()
            db.commit()
            results["status"] = "completed"
            results["overall_confidence"] = product_confidence

        except Exception as e:
            logger.error(f"Pipeline error for product {product_id}: {str(e)}")
            import traceback
            traceback.print_exc()
            product.processing_stage = "error"
            product.status = "draft"
            db.commit()
            results["status"] = "error"
            results["errors"].append(str(e))

        return results

    def _guess_category(self, attributes: dict) -> str:
        text = " ".join(str(v) for v in attributes.values()).lower()
        category_keywords = {
            "motors": ["motor", "rpm", "stator", "rotor", "induction", "synchronous", "ie2", "ie3"],
            "bearings": ["bearing", "bore", "inner diameter", "outer diameter", "6205", "6206", "skf", "nsk"],
            "pumps": ["pump", "flow rate", "head", "impeller", "centrifugal", "submersible", "npsh"],
            "valves": ["valve", "gate", "globe", "ball valve", "butterfly", "solenoid", "check valve"],
            "sensors": ["sensor", "thermocouple", "rtd", "transducer", "proximity", "photoelectric"],
            "electrical": ["circuit breaker", "contactor", "relay", "switchgear", "mcb", "mccb", "fuse"],
        }
        best_category = "general"
        best_score = 0
        for cat, keywords in category_keywords.items():
            score = sum(1 for kw in keywords if kw in text)
            if score > best_score:
                best_score = score
                best_category = cat
        return best_category

    async def get_before_after(self, db, product_id: str) -> List[dict]:
        from models import ProductAttribute, AttributeSource
        from engines.explainability import explainability_engine

        attrs = db.query(ProductAttribute).filter(ProductAttribute.product_id == product_id).all()
        before_after = []
        for attr in attrs:
            sources = db.query(AttributeSource).filter(AttributeSource.attribute_id == attr.id).all()
            source_list = [{"source_type": s.source_type, "source_name": s.source_name,
                           "source_value": s.source_value, "trust_score": s.trust_score} for s in sources]
            explanation = explainability_engine.generate_before_after_explanation(
                attr.attribute_name, attr.raw_value or "",
                attr.normalized_value or attr.raw_value or "",
                f"{'Enriched' if attr.is_enriched else 'Normalized'} from {sources[0].source_type if sources else 'unknown'}",
                attr.confidence or 0.5,
            )
            before_after.append({
                "attribute_id": attr.id,
                "attribute_name": attr.attribute_name, "original_value": attr.raw_value,
                "enriched_value": attr.normalized_value or attr.raw_value,
                "reason": explanation, "evidence": source_list,
                "confidence": attr.confidence, "approval_status": attr.approval_status,
                "is_enriched": attr.is_enriched, "validation_status": attr.validation_status,
            })
        return before_after


pipeline_service = PipelineService()
