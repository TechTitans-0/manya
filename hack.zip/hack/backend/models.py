import uuid
import datetime

from sqlalchemy import (
    Column,
    String,
    Float,
    Boolean,
    Integer,
    Text,
    DateTime,
    ForeignKey,
)
from sqlalchemy.orm import relationship

from database import Base


# ---------------------------------------------------------------------------
# Helper for default UUID primary keys
# ---------------------------------------------------------------------------
_new_uuid = lambda: str(uuid.uuid4())


# ============================= Product =====================================
class Product(Base):
    __tablename__ = "products"

    id = Column(String, primary_key=True, default=_new_uuid)
    name = Column(String, nullable=False)
    manufacturer = Column(String, nullable=True)
    model_number = Column(String, nullable=True)
    part_number = Column(String, nullable=True)
    category = Column(String, nullable=True)
    subcategory = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    status = Column(String, default="draft")  # draft / processing / reviewed / approved
    processing_stage = Column(String, nullable=True)
    overall_confidence = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.datetime.utcnow,
        onupdate=datetime.datetime.utcnow,
    )

    # Relationships
    attributes = relationship(
        "ProductAttribute", back_populates="product", cascade="all, delete-orphan"
    )
    validation_results = relationship(
        "ValidationResult", back_populates="product", cascade="all, delete-orphan"
    )
    standards_matches = relationship(
        "StandardsMatch", back_populates="product", cascade="all, delete-orphan"
    )
    audit_trail = relationship(
        "AuditTrail", back_populates="product", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Product(id={self.id!r}, name={self.name!r}, status={self.status!r})>"


# ========================= ProductAttribute ================================
class ProductAttribute(Base):
    __tablename__ = "product_attributes"

    id = Column(String, primary_key=True, default=_new_uuid)
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    attribute_name = Column(String, nullable=False)
    raw_value = Column(String, nullable=True)
    normalized_value = Column(String, nullable=True)
    approved_value = Column(String, nullable=True)
    unit = Column(String, nullable=True)
    data_type = Column(String, default="text")  # numeric / text / boolean / enum
    confidence = Column(Float, nullable=True)
    validation_status = Column(
        String, default="unvalidated"
    )  # valid / warning / conflict / unvalidated
    approval_status = Column(
        String, default="pending"
    )  # pending / accepted / rejected
    is_enriched = Column(Boolean, default=False)
    is_critical = Column(Boolean, default=False)
    priority = Column(String, default="medium")  # critical / high / medium / low
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    # Relationships
    product = relationship("Product", back_populates="attributes")
    sources = relationship(
        "AttributeSource", back_populates="attribute", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return (
            f"<ProductAttribute(id={self.id!r}, name={self.attribute_name!r}, "
            f"value={self.normalized_value!r})>"
        )


# ========================== AttributeSource ================================
class AttributeSource(Base):
    __tablename__ = "attribute_sources"

    id = Column(String, primary_key=True, default=_new_uuid)
    attribute_id = Column(
        String, ForeignKey("product_attributes.id"), nullable=False
    )
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    source_type = Column(
        String, nullable=False
    )  # nameplate / datasheet / catalog / distributor / manual_input / ai_enriched
    source_name = Column(String, nullable=True)
    source_url = Column(String, nullable=True)
    source_value = Column(String, nullable=True)
    trust_score = Column(Float, nullable=True)
    extraction_method = Column(
        String, nullable=True
    )  # ocr / pdf_parse / csv_import / llm_extract / manual
    extracted_at = Column(DateTime, default=datetime.datetime.utcnow)

    # Relationships
    attribute = relationship("ProductAttribute", back_populates="sources")

    def __repr__(self):
        return (
            f"<AttributeSource(id={self.id!r}, type={self.source_type!r}, "
            f"trust={self.trust_score!r})>"
        )


# ========================= ValidationResult ================================
class ValidationResult(Base):
    __tablename__ = "validation_results"

    id = Column(String, primary_key=True, default=_new_uuid)
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    attribute_id = Column(
        String, ForeignKey("product_attributes.id"), nullable=True
    )
    rule_name = Column(String, nullable=False)
    rule_type = Column(
        String, nullable=False
    )  # unit_check / physics_check / format_check / cross_attribute / range_check
    status = Column(String, nullable=False)  # valid / warning / conflict
    message = Column(String, nullable=True)
    details = Column(Text, nullable=True)  # JSON string
    severity = Column(String, default="info")  # critical / warning / info
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    # Relationships
    product = relationship("Product", back_populates="validation_results")

    def __repr__(self):
        return (
            f"<ValidationResult(id={self.id!r}, rule={self.rule_name!r}, "
            f"status={self.status!r})>"
        )


# ========================== StandardsMatch =================================
class StandardsMatch(Base):
    __tablename__ = "standards_matches"

    id = Column(String, primary_key=True, default=_new_uuid)
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    standard_type = Column(
        String, nullable=False
    )  # unspsc / eclass / etim
    standard_code = Column(String, nullable=False)
    standard_description = Column(String, nullable=True)
    match_confidence = Column(Float, nullable=True)
    match_method = Column(
        String, nullable=True
    )  # exact_lookup / hierarchical_match / semantic_match
    match_explanation = Column(Text, nullable=True)
    verified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    # Relationships
    product = relationship("Product", back_populates="standards_matches")

    def __repr__(self):
        return (
            f"<StandardsMatch(id={self.id!r}, type={self.standard_type!r}, "
            f"code={self.standard_code!r})>"
        )


# ========================= ReplacementPart =================================
class ReplacementPart(Base):
    __tablename__ = "replacement_parts"

    id = Column(String, primary_key=True, default=_new_uuid)
    original_product_id = Column(
        String, ForeignKey("products.id"), nullable=False
    )
    replacement_product_id = Column(String, nullable=True)
    compatibility_score = Column(Float, nullable=True)
    matched_attributes = Column(Text, nullable=True)  # JSON string
    mismatched_attributes = Column(Text, nullable=True)  # JSON string
    critical_differences = Column(Text, nullable=True)  # JSON string
    recommendation_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    def __repr__(self):
        return (
            f"<ReplacementPart(id={self.id!r}, "
            f"original={self.original_product_id!r}, "
            f"replacement={self.replacement_product_id!r})>"
        )


# ============================ AuditTrail ===================================
class AuditTrail(Base):
    __tablename__ = "audit_trail"

    id = Column(String, primary_key=True, default=_new_uuid)
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    attribute_id = Column(
        String, ForeignKey("product_attributes.id"), nullable=True
    )
    action = Column(
        String, nullable=False
    )  # extract / enrich / validate / approve / reject / modify
    old_value = Column(String, nullable=True)
    new_value = Column(String, nullable=True)
    reason = Column(Text, nullable=True)
    performed_by = Column(String, default="system")  # system / user / llm
    evidence = Column(Text, nullable=True)  # JSON string
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    # Relationships
    product = relationship("Product", back_populates="audit_trail")

    def __repr__(self):
        return (
            f"<AuditTrail(id={self.id!r}, action={self.action!r}, "
            f"by={self.performed_by!r})>"
        )


# ======================== StandardsReference ===============================
class StandardsReference(Base):
    __tablename__ = "standards_reference"

    id = Column(String, primary_key=True, default=_new_uuid)
    standard_type = Column(String, nullable=False)
    code = Column(String, nullable=False)
    level = Column(Integer, nullable=True)
    description = Column(String, nullable=True)
    parent_code = Column(String, nullable=True)
    keywords = Column(String, nullable=True)
    category_path = Column(String, nullable=True)
    attributes = Column(Text, nullable=True)  # JSON string

    def __repr__(self):
        return (
            f"<StandardsReference(id={self.id!r}, type={self.standard_type!r}, "
            f"code={self.code!r})>"
        )


# ========================== CategorySchema =================================
class CategorySchema(Base):
    __tablename__ = "category_schemas"

    id = Column(String, primary_key=True, default=_new_uuid)
    category = Column(String, unique=True, nullable=False)
    display_name = Column(String, nullable=True)
    attributes = Column(Text, nullable=True)  # JSON string
    validation_rules = Column(Text, nullable=True)  # JSON string
    common_standards = Column(Text, nullable=True)  # JSON string
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    def __repr__(self):
        return (
            f"<CategorySchema(id={self.id!r}, category={self.category!r})>"
        )
