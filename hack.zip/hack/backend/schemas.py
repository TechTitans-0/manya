from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ── Source ───────────────────────────────────────────────────────────────────

class SourceResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    source_type: str
    source_name: Optional[str] = None
    source_url: Optional[str] = None
    source_value: str
    trust_score: Optional[float] = None
    extraction_method: Optional[str] = None


# ── Attribute ────────────────────────────────────────────────────────────────

class AttributeResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    product_id: int
    attribute_name: str
    raw_value: Optional[str] = None
    normalized_value: Optional[str] = None
    approved_value: Optional[str] = None
    unit: Optional[str] = None
    data_type: Optional[str] = None
    confidence: Optional[float] = None
    validation_status: Optional[str] = None
    approval_status: str
    is_enriched: bool
    is_critical: bool
    priority: Optional[int] = None
    sources: Optional[List[SourceResponse]] = None


# ── Product ──────────────────────────────────────────────────────────────────

class ProductCreate(BaseModel):
    name: Optional[str] = None
    manufacturer: Optional[str] = None
    model_number: Optional[str] = None
    part_number: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    manufacturer: Optional[str] = None
    model_number: Optional[str] = None
    part_number: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None


class ProductResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    name: str
    manufacturer: str
    model_number: str
    part_number: str
    category: str
    subcategory: str
    description: str
    status: str
    processing_stage: str
    overall_confidence: Optional[float] = None
    created_at: datetime
    updated_at: datetime
    attributes: Optional[List[AttributeResponse]] = None
    validation_summary: Optional[Dict[str, Any]] = None


class ProductListResponse(BaseModel):
    model_config = {"from_attributes": True}

    products: List[ProductResponse]
    total: int
    page: int
    per_page: int


# ── Validation ───────────────────────────────────────────────────────────────

class ValidationResultResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    product_id: int
    attribute_id: Optional[int] = None
    rule_name: str
    rule_type: str
    status: str
    message: str
    details: Optional[Dict[str, Any]] = None
    severity: str


# ── Standards Match ──────────────────────────────────────────────────────────

class StandardsMatchResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    product_id: int
    standard_type: str
    standard_code: str
    standard_description: str
    match_confidence: float
    match_method: str
    match_explanation: Optional[str] = None
    verified: bool


# ── Replacement ──────────────────────────────────────────────────────────────

class ReplacementResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    original_product_id: int
    replacement_product_id: int
    compatibility_score: float
    matched_attributes: List[Any]
    mismatched_attributes: List[Any]
    critical_differences: List[Any]
    recommendation_reason: Optional[str] = None


# ── Before / After ───────────────────────────────────────────────────────────

class BeforeAfterResponse(BaseModel):
    model_config = {"from_attributes": True}

    attribute_name: str
    original_value: Optional[str] = None
    enriched_value: Optional[str] = None
    reason: Optional[str] = None
    evidence: List[Dict[str, Any]]
    confidence: Optional[float] = None
    approval_status: str


# ── Audit Trail ──────────────────────────────────────────────────────────────

class AuditTrailResponse(BaseModel):
    model_config = {"from_attributes": True}

    id: int
    product_id: int
    action: str
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    reason: Optional[str] = None
    performed_by: str
    created_at: datetime


# ── Processing ───────────────────────────────────────────────────────────────

class ProcessingResponse(BaseModel):
    model_config = {"from_attributes": True}

    product_id: int
    stage: str
    status: str
    message: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


# ── Product Passport ────────────────────────────────────────────────────────

class PassportResponse(BaseModel):
    model_config = {"from_attributes": True}

    product_id: int
    product_identity: Dict[str, Any]
    technical_specifications: List[Dict[str, Any]]
    classifications: List[Dict[str, Any]]
    evidence_summary: List[Dict[str, Any]]
    validation_results: List[Dict[str, Any]]
    conflicts: List[Dict[str, Any]]
    missing_attributes: List[Dict[str, Any]]
    replacement_options: List[Dict[str, Any]]
    approval_status: Dict[str, Any]
    overall_confidence: float
    generated_at: datetime


# ── Catalog Stats ────────────────────────────────────────────────────────────

class CatalogStatsResponse(BaseModel):
    model_config = {"from_attributes": True}

    total_products: int
    by_status: Dict[str, Any]
    by_category: Dict[str, Any]
    avg_confidence: float
    validation_summary: Dict[str, Any]


# ── Export ───────────────────────────────────────────────────────────────────

class ExportRequest(BaseModel):
    product_ids: List[str]
    format: str = Field(..., pattern="^(json|csv|pdf)$")


# ── Comparison ───────────────────────────────────────────────────────────────

class ComparisonResponse(BaseModel):
    model_config = {"from_attributes": True}

    products: List[Dict[str, Any]]
    common_attributes: List[Any]
    differing_attributes: List[Any]
