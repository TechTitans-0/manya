# Deployment Guide — IntelliSpec

## 1. Local Development Deployment

See `README.md` Section 5 for the local development setup.

## 2. Production Deployment Options

### Option A: Single Linux Server (Cheapest)

**Requirements:**
- A VPS or cloud VM (2 vCPU, 4 GB RAM minimum)
- Ubuntu 22.04 LTS or similar
- Domain name (optional)

**Steps:**

1. Update the system:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. Install Python and Node.js:
   ```bash
   sudo apt install python3.11 python3.11-venv python3-pip -y
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt install -y nodejs
   ```

3. Clone/upload the project to `/opt/intellispec`

4. Create and configure `.env`:
   ```bash
   cd /opt/intellispec/backend
   cp .env.example .env
   nano .env
   ```

5. Set up backend:
   ```bash
   python3.11 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

6. Set up frontend:
   ```bash
   cd /opt/intellispec/frontend
   npm install
   npm run build
   ```

7. Use a process manager to run the backend:
   ```bash
   sudo apt install supervisor
   ```

   Create `/etc/supervisor/conf.d/intellispec.conf`:
   ```ini
   [program:intellispec]
   command=/opt/intellispec/backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
   directory=/opt/intellispec/backend
   autostart=true
   autorestart=true
   stderr_logfile=/var/log/intellispec.err.log
   stdout_logfile=/var/log/intellispec.out.log
   ```

8. Serve frontend with Nginx:
   ```bash
   sudo apt install nginx
   ```

   Add a server block:
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;

       location / {
           root /opt/intellispec/frontend/dist;
           try_files $uri /index.html;
       }

       location /api/ {
           proxy_pass http://127.0.0.1:8000/api/;
       }
   }
   ```

9. Restart services:
   ```bash
   sudo supervisorctl reread
   sudo supervisorctl update
   sudo systemctl restart nginx
   ```

### Option B: Docker Deployment

Create a `Dockerfile` in `backend/`:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Create a `docker-compose.yml`:
```yaml
version: '3.8'
services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    env_file:
      - .env
    volumes:
      - ./backend:/app
  frontend:
    image: node:18
    working_dir: /app
    command: sh -c "npm install && npm run dev -- --host"
    ports:
      - "5173:5173"
    volumes:
      - ./frontend:/app
```

Run:
```bash
docker-compose up --build
```

### Option C: Platform-as-a-Service (PaaS)

**Render:**
- Create two services: one for FastAPI backend, one for static frontend
- Set `DATABASE_URL` and `GROQ_API_KEY` as environment variables

**Railway:**
- Add the backend and frontend as separate services
- Use the same environment variables

**Heroku:**
- Add `Procfile` to backend:
  ```
  web: uvicorn main:app --host 0.0.0.0 --port $PORT
  ```
- Add `runtime.txt` with `python-3.11.5`

---

## 3. Scaling Considerations

- Replace SQLite with PostgreSQL for concurrent access
- Add Redis for caching LLM calls and standards lookups
- Use Celery with Redis/RabbitMQ for background batch processing
- Deploy multiple backend instances behind a load balancer
- Use S3-compatible object storage for uploaded files
- Pre-compute embeddings for the standards reference data

---

## 4. Security Checklist

- Keep `GROQ_API_KEY` in environment variables
- Do not commit `.env` to version control
- Add HTTPS with Let's Encrypt
- Implement authentication and role-based access control for production
- Sanitize file uploads and validate extensions
- Use parameterized queries (already handled by SQLAlchemy)
