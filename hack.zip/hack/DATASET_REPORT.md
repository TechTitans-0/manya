# Dataset and Data Sources Report — IntelliSpec

## 1. Purpose of This Document

This report documents every dataset and reference data source used by the IntelliSpec project. It is designed to satisfy the hackathon requirement that every data source be explicitly named, with URL, publisher, license, and usage details.

**Every dataset listed below is either freely accessible for download or freely accessible for online consultation, with no purchase required.**

---

## 2. Primary Industrial Product Dataset

### IndustryBench-MIPU

| Field | Detail |
|---|---|
| **Dataset Name** | IndustryBench-MIPU |
| **Platform** | Hugging Face Datasets |
| **Direct Download URL** | https://huggingface.co/datasets/alibaba-multimodal-industrial-ai/IndustryBench-MIPU |
| **GitHub Repository** | https://github.com/alibaba-multimodal-industrial-ai/IndustryBench-MIPU |
| **Research Paper** | https://arxiv.org/abs/2606.14383 |
| **Original Publisher** | Alibaba Multimodal Industrial AI |
| **License** | MIT License |
| **Number of Products** | 4,481 products (multi-image) + 6,000 single-image instances |
| **Images** | 26,310 images across 18 top-level categories and 2,301 leaf categories |
| **Annotations** | 95,024 product-level property-value annotations |
| **Fields** | Product images, attribute schemas, property-value pairs, category hierarchy |
| **Downloadability** | **Freely downloadable** via Hugging Face `datasets` library or direct browser download |
| **Suitability** | Ideal for evaluating attribute extraction accuracy and demonstrating real-world industrial products |
| **Limitations** | Focused on image extraction; does not contain standards codes or replacement-part relationships. Used in this prototype for evaluation, demo images, and accuracy benchmarking. |

### How to Download IndustryBench-MIPU

**Option A — Using the Hugging Face `datasets` library:**
```python
pip install datasets
python -c "from datasets import load_dataset; ds = load_dataset('alibaba-multimodal-industrial-ai/IndustryBench-MIPU'); print(ds)"
```

**Option B — Direct browser download:**
1. Visit https://huggingface.co/datasets/alibaba-multimodal-industrial-ai/IndustryBench-MIPU/tree/main
2. Click on any file (e.g., `data/multi_image_level.jsonl`)
3. Click the **Download** button

**Option C — Using `git-lfs`:**
```bash
git lfs install
git clone https://huggingface.co/datasets/alibaba-multimodal-industrial-ai/IndustryBench-MIPU
```

### Usage in IntelliSpec
- Evaluation benchmark for attribute extraction accuracy
- Source of realistic industrial product images for demo scenarios
- Ground truth for precision/recall/F1 measurement

---

## 3. Standards Reference Data

### 3.1 UNSPSC (United Nations Standard Products and Services Code)

| Field | Detail |
|---|---|
| **Standard Name** | UNSPSC |
| **Owner** | United Nations Development Programme (UNDP) |
| **Official URL** | https://www.undp.org/unspsc |
| **Download URL** | https://store.unspsc.org/collections/codeset-downloads |
| **Access Terms** | Free PDF download available without membership |
| **Publisher** | United Nations Development Programme |
| **Coverage** | 158,448+ codes across all products and services |
| **Suitability** | Primary standards matching for procurement classification |

### How to Download UNSPSC
1. Go to https://www.undp.org/unspsc
2. Click the "download the codeset" link
3. Create a free account if prompted
4. Download the latest PDF or Excel/CSV version
5. The project includes a curated subset of industrial-relevant UNSPSC codes in `backend/data/standards/unspsc_reference.json`

### 3.2 eCl@ss

| Field | Detail |
|---|---|
| **Standard Name** | eCl@ss |
| **Owner** | eCl@ss e.V. |
| **Official URL** | https://eclass.eu/en/eclass-standard |
| **Search Content URL** | https://eclass.eu/en/eclass-standard/search-content |
| **Access Terms** | Free online search and browsing; full data download requires a license |
| **Publisher** | eCl@ss e.V. |
| **Coverage** | ~45,000 classes and properties |
| **Suitability** | Secondary standards matching; publicly searchable hierarchy used |

### How to Access eCl@ss
1. Visit https://eclass.eu/en/eclass-standard/search-content
2. Search for classes, properties, or values by name
3. The project includes representative eCl@ss codes in `backend/data/standards/eclass_reference.json`
4. For unverified classes, the system explicitly reports `classification unavailable`

### 3.3 ETIM (European Technical Information Model)

| Field | Detail |
|---|---|
| **Standard Name** | ETIM |
| **Owner** | ETIM International |
| **Official URL** | https://www.etim-international.com |
| **Release Policy URL** | https://www.etim-international.com/classification/release-policy/ |
| **License** | Open Data Commons Attribution License (ODC-By 1.0) |
| **Access Terms** | Free to use and download |
| **Publisher** | ETIM International |
| **Coverage** | ~5,000 product classes for technical products |
| **Suitability** | Standards matching for electrical/electronic/technical products |

### How to Access ETIM
1. Visit https://www.etim-international.com/downloads/
2. Download the current release in CSV, Excel, or XML format
3. The project includes representative ETIM codes in `backend/data/standards/etim_reference.json`

---

## 4. Curated Prototype Data

| Field | Detail |
|---|---|
| **Type** | Curated prototype dataset |
| **Source** | Public manufacturer websites, product catalogs, and technical datasheets |
| **Companies Represented** | ABB, SKF, Grundfos, Siemens, Endress+Hauser, WEG |
| **File Location** | `backend/data/seed_products/demo_products.json` |
| **License** | Specifications are publicly available; compiled for educational/hackathon demonstration |
| **Purpose** | Demonstrate multi-source evidence, conflict detection, enrichment, validation, and replacement finding |
| **Data Labeling** | Curated data; one attribute in some products explicitly labeled `SYNTHETIC conflict` to demonstrate conflict resolution |

### Curated Data Disclaimers
- All product specifications in the demo file are representative of publicly available manufacturer information
- Some values have been intentionally altered (with `SYNTHETIC conflict` labels) to demonstrate conflict detection
- These are **not** real live product catalog snapshots and should not be used for procurement

---

## 5. Synthetic Data

| Field | Detail |
|---|---|
| **Type** | Synthetic scenarios |
| **File Location** | Embedded in `backend/data/seed_products/demo_products.json` |
| **Purpose** | Simulate missing fields, conflicting sources, and discontinued-product replacement scenarios |
| **Labeling** | All synthetic modifications clearly marked with `"notes": "SYNTHETIC conflict ..."` |
| **Honesty Policy** | Synthetic data is never presented as real manufacturer information |

---

## 6. What Is NOT Used

The project does **NOT** use:
- Amazon, Flipkart, Walmart, eBay, or other e-commerce/retail product datasets
- Fashion, consumer shopping, or product-review datasets
- Datasets scraped from shopping websites
- Proprietary or paid-only manufacturer databases without license

---

## 7. Data Provenance Summary Table

| Data Source | Platform / URL | License | Usage in Project |
|---|---|---|---|
| IndustryBench-MIPU | https://huggingface.co/datasets/alibaba-multimodal-industrial-ai/IndustryBench-MIPU | MIT | Evaluation, demo images, extraction accuracy benchmark |
| UNSPSC | https://www.undp.org/unspsc | Free public download | Industrial product classification |
| eCl@ss | https://eclass.eu/en/eclass-standard/search-content | Free search; full data requires license | Representative classification lookup |
| ETIM | https://www.etim-international.com | ODC-By 1.0 open data | Technical product classification |
| Curated demo products | Compiled from public manufacturer specs | Educational/demonstration | Seed data for demo scenarios |
| Synthetic conflicts | Generated for demonstration | N/A | Conflict detection and enrichment demos |

---

## 8. Honesty and No-Hallucination Policy

- Industry standards codes are only assigned when verified against the reference data files in `backend/data/standards/`
- If no verified code is found, the system returns `standard_code: null` with an explicit `classification unavailable` message
- Confidence scores are calculated from actual evidence, source agreement, and validation results
- The system prefers `insufficient evidence` over inventing product specifications
