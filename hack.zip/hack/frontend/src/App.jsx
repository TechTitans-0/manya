import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import ProductAnalyzer from './pages/ProductAnalyzer'
import ValidationCenter from './pages/ValidationCenter'
import StandardsMatching from './pages/StandardsMatching'
import ReplacementFinder from './pages/ReplacementFinder'
import ProductCatalog from './pages/ProductCatalog'
import ProductPassport from './pages/ProductPassport'
import About from './pages/About'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/analyze" element={<ProductAnalyzer />} />
        <Route path="/validation" element={<ValidationCenter />} />
        <Route path="/standards" element={<StandardsMatching />} />
        <Route path="/replacements" element={<ReplacementFinder />} />
        <Route path="/catalog" element={<ProductCatalog />} />
        <Route path="/passport/:id" element={<ProductPassport />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </Layout>
  )
}

export default App
