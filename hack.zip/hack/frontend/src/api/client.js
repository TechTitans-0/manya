import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_URL || '/api/v1'

const api = axios.create({
  baseURL: API_BASE,
  timeout: 120000,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const productsApi = {
  list: (params = {}) => api.get('/products', { params }).then(r => r.data),
  get: (id) => api.get(`/products/${id}`).then(r => r.data),
  create: (data) => api.post('/products', data).then(r => r.data),
  upload: (file, sourceType = 'nameplate') => {
    const form = new FormData()
    form.append('file', file)
    form.append('source_type', sourceType)
    return api.post('/products/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } }).then(r => r.data)
  },
  process: (id) => api.post(`/products/${id}/process`).then(r => r.data),
  beforeAfter: (id) => api.get(`/products/${id}/before-after`).then(r => r.data),
  approve: (pid, aid) => api.post(`/products/${pid}/attributes/${aid}/approve`).then(r => r.data),
  reject: (pid, aid) => api.post(`/products/${pid}/attributes/${aid}/reject`).then(r => r.data),
}

export const validationApi = {
  get: (id) => api.get(`/products/${id}/validation`).then(r => r.data),
  run: (id) => api.post(`/products/${id}/validation`).then(r => r.data),
}

export const standardsApi = {
  get: (id) => api.get(`/products/${id}/standards`).then(r => r.data),
  match: (id) => api.post(`/products/${id}/match-standards`).then(r => r.data),
  search: (q, type) => api.get('/standards/search', { params: { q, standard_type: type } }).then(r => r.data),
}

export const replacementApi = {
  find: (id, topN = 5) => api.get(`/products/${id}/replacements`, { params: { top_n: topN } }).then(r => r.data),
}

export const catalogApi = {
  list: (params = {}) => api.get('/catalog', { params }).then(r => r.data),
  stats: () => api.get('/catalog/stats').then(r => r.data),
  export: (format = 'json') => api.get('/catalog/export', { params: { format } }).then(r => r.data),
}

export const passportApi = {
  get: (id) => api.get(`/products/${id}/passport`).then(r => r.data),
  export: (id, format) => window.open(`${API_BASE}/products/${id}/export?format=${format}`),
}

export const systemApi = {
  health: () => api.get('/health').then(r => r.data),
  categories: () => api.get('/categories').then(r => r.data),
  categorySchema: (cat) => api.get(`/categories/${cat}/schema`).then(r => r.data),
}

export default api
