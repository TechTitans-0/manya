import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { passportApi } from '../api/client'
import ConfidenceBadge from '../components/ConfidenceBadge'
import ValidationStatus from '../components/ValidationStatus'

export default function ProductPassport() {
  const { id } = useParams()
  const [passport, setPassport] = useState(null)

  useEffect(() => {
    if (id) passportApi.get(id).then(setPassport)
  }, [id])

  if (!passport) return <div className="p-8 text-slate-500">Loading passport...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Product Intelligence Passport</h2>
          <p className="text-slate-500">{passport.product_identity?.name || id}</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => passportApi.export(id, 'json')} className="bg-slate-100 text-slate-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-200">
            Export JSON
          </button>
          <button onClick={() => passportApi.export(id, 'csv')} className="bg-primary-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary-700">
            Export CSV
          </button>
        </div>
      </div>

      <div className="card">
        <h3 className="font-semibold text-lg mb-4">Product Identity</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          {Object.entries(passport.product_identity || {}).map(([k, v]) => (
            <div key={k}>
              <span className="text-slate-500 capitalize block">{k.replace('_', ' ')}</span>
              <span className="font-medium">{v || '-'}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h3 className="font-semibold text-lg mb-4">Technical Specifications</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
              <tr>
                <th className="px-4 py-2">Attribute</th>
                <th className="px-4 py-2">Raw Value</th>
                <th className="px-4 py-2">Normalized</th>
                <th className="px-4 py-2">Confidence</th>
                <th className="px-4 py-2">Validation</th>
              </tr>
            </thead>
            <tbody>
              {passport.technical_specifications?.map((s) => (
                <tr key={s.attribute} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium">{s.attribute}</td>
                  <td className="px-4 py-3 text-slate-500">{s.raw_value || '-'}</td>
                  <td className="px-4 py-3">{s.normalized_value || '-'}</td>
                  <td className="px-4 py-3"><ConfidenceBadge value={s.confidence} /></td>
                  <td className="px-4 py-3"><ValidationStatus status={s.validation_status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-semibold text-lg mb-4">Classifications</h3>
          <div className="space-y-3">
            {passport.classifications?.map((c, i) => (
              <div key={i} className="border border-slate-200 rounded-lg p-3 text-sm">
                <div className="font-medium uppercase">{c.standard_type}</div>
                {c.code ? (
                  <div>
                    <div className="font-mono text-primary-700">{c.code}</div>
                    <div className="text-slate-600">{c.description}</div>
                  </div>
                ) : (
                  <div className="text-amber-700 text-sm mt-1">{c.explanation}</div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3 className="font-semibold text-lg mb-4">Missing Attributes</h3>
          <ul className="space-y-2 text-sm">
            {passport.missing_attributes?.map((m, i) => (
              <li key={i} className="flex items-center justify-between border-b border-slate-100 py-2">
                <span>{m.attribute_name}</span>
                <span className="badge badge-gray capitalize">{m.priority}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
