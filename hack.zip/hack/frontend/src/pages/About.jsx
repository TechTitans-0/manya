export default function About() {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">About IntelliSpec</h2>
        <p className="text-slate-500">Evidence-driven industrial product intelligence for commerce</p>
      </div>

      <div className="card">
        <h3 className="font-semibold text-lg mb-3">What is IntelliSpec?</h3>
        <p className="text-slate-700 leading-relaxed">
          IntelliSpec is an AI-powered industrial product intelligence platform that does not merely extract data.
          It builds trustworthy product records by validating every specification against engineering rules,
          tracking evidence from every source, mapping to real industry standards, and explaining every decision
          before making data commerce-ready.
        </p>
      </div>

      <div className="card">
        <h3 className="font-semibold text-lg mb-3">Core Capabilities</h3>
        <ul className="list-disc list-inside space-y-2 text-slate-700">
          <li>Scan & Extract from images, PDFs, CSVs, and manual input</li>
          <li>Engineering/Common-Sense Validation with deterministic Python rules</li>
          <li>Trusted Source Scoring and evidence-based confidence</li>
          <li>Standards Matching to UNSPSC, eCl@ss, and ETIM</li>
          <li>Before & After Intelligence with human approval workflow</li>
          <li>Replacement Part Finder using technical compatibility</li>
          <li>Product Intelligence Passport generation and export</li>
        </ul>
      </div>

      <div className="card">
        <h3 className="font-semibold text-lg mb-3">Technology Stack</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-700">
          <div><strong>Backend:</strong> FastAPI + Python 3.11</div>
          <div><strong>Frontend:</strong> React 18 + Vite + TailwindCSS</div>
          <div><strong>Database:</strong> SQLite via SQLAlchemy</div>
          <div><strong>LLM:</strong> Groq API (llama-3.3-70b-versatile)</div>
          <div><strong>Vision/OCR:</strong> Groq Vision + Tesseract fallback</div>
          <div><strong>Embeddings:</strong> sentence-transformers</div>
        </div>
      </div>
    </div>
  )
}
