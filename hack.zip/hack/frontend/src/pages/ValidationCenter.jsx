import { useEffect, useState } from 'react'
import { productsApi, validationApi, catalogApi } from '../api/client'
import ValidationStatus from '../components/ValidationStatus'
import { AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react'

export default function ValidationCenter() {
  const [products, setProducts] = useState([])
  const [selected, setSelected] = useState(null)
  const [validation, setValidation] = useState(null)

  useEffect(() => {
    catalogApi.list({ per_page: 100 }).then((res) => setProducts(res.items || []))
  }, [])

  const loadValidation = async (id) => {
    const res = await validationApi.get(id)
    setSelected(id)
    setValidation(res)
  }

  const runValidation = async (id) => {
    const res = await validationApi.run(id)
    setValidation(res)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Validation Center</h2>
        <p className="text-slate-500">Engineering and common-sense validation results across products</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card lg:col-span-1">
          <h3 className="font-semibold mb-4">Products</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {products.map((p) => (
              <button
                key={p.id}
                onClick={() => loadValidation(p.id)}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm border ${
                  selected === p.id ? 'border-primary-500 bg-primary-50' : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="font-medium truncate">{p.name || p.model_number || p.id}</div>
                <div className="text-xs text-slate-500 capitalize">{p.category || 'general'} · {p.status}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="card lg:col-span-2">
          {selected ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">Validation Results</h3>
                <button
                  onClick={() => runValidation(selected)}
                  className="flex items-center gap-2 text-sm bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700"
                >
                  <RefreshCw className="w-4 h-4" />
                  Re-validate
                </button>
              </div>
              {validation?.validation_results?.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
                      <tr>
                        <th className="px-4 py-2">Rule</th>
                        <th className="px-4 py-2">Type</th>
                        <th className="px-4 py-2">Status</th>
                        <th className="px-4 py-2">Severity</th>
                        <th className="px-4 py-2">Message</th>
                      </tr>
                    </thead>
                    <tbody>
                      {validation.validation_results.map((r, idx) => (
                        <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50">
                          <td className="px-4 py-3 font-medium">{r.rule_name}</td>
                          <td className="px-4 py-3 text-slate-500">{r.rule_type}</td>
                          <td className="px-4 py-3"><ValidationStatus status={r.status} /></td>
                          <td className="px-4 py-3 capitalize">{r.severity}</td>
                          <td className="px-4 py-3">{r.message}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-10 text-slate-500">No validation results yet. Run validation first.</div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 text-slate-400">Select a product to view validation results</div>
          )}
        </div>
      </div>
    </div>
  )
}
