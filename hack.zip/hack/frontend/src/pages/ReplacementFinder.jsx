import { useEffect, useState } from 'react'
import { catalogApi, replacementApi } from '../api/client'
import ConfidenceBadge from '../components/ConfidenceBadge'

export default function ReplacementFinder() {
  const [products, setProducts] = useState([])
  const [selected, setSelected] = useState(null)
  const [replacements, setReplacements] = useState(null)

  useEffect(() => {
    catalogApi.list({ per_page: 100 }).then((res) => setProducts(res.items || []))
  }, [])

  const loadReplacements = async (id) => {
    const res = await replacementApi.find(id)
    setSelected(id)
    setReplacements(res)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Replacement Part Finder</h2>
        <p className="text-slate-500">Find technically compatible alternatives for industrial products</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card lg:col-span-1">
          <h3 className="font-semibold mb-4">Products</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {products.map((p) => (
              <button
                key={p.id}
                onClick={() => loadReplacements(p.id)}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm border ${
                  selected === p.id ? 'border-primary-500 bg-primary-50' : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="font-medium truncate">{p.name || p.model_number || p.id}</div>
                <div className="text-xs text-slate-500 capitalize">{p.category || 'general'}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="card lg:col-span-2">
          {selected ? (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Recommended Replacements</h3>
              {replacements?.replacements?.length > 0 ? (
                <div className="space-y-4">
                  {replacements.replacements.map((r, idx) => (
                    <div key={idx} className="border border-slate-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold">{r.replacement_product_id}</span>
                        <ConfidenceBadge value={r.compatibility_score} />
                      </div>
                      <p className="text-sm text-slate-600 mb-3">{r.recommendation_reason}</p>
                      {r.critical_differences?.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium text-red-600">Critical differences:</span>
                          <ul className="list-disc list-inside text-slate-600 ml-1">
                            {r.critical_differences.map((c, i) => (
                              <li key={i}>
                                {typeof c === 'string' ? c : `${c.attribute}: ${c.original} vs ${c.replacement}`}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-slate-500">No replacements found. Try another product.</div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 text-slate-400">Select a product to find replacements</div>
          )}
        </div>
      </div>
    </div>
  )
}
