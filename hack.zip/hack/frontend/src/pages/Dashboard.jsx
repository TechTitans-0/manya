import { useEffect, useState } from 'react'
import { catalogApi, systemApi } from '../api/client'
import { Activity, AlertTriangle, CheckCircle, Database, Search, FileText } from 'lucide-react'

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const [health, setHealth] = useState(null)

  useEffect(() => {
    catalogApi.stats().then(setStats)
    systemApi.health().then(setHealth)
  }, [])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Dashboard</h2>
        <p className="text-slate-500">Overview of product intelligence status and system health</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">Total Products</p>
              <p className="text-3xl font-bold">{stats?.total_products || 0}</p>
            </div>
            <Database className="w-8 h-8 text-primary-500" />
          </div>
        </div>
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">Valid Attributes</p>
              <p className="text-3xl font-bold">{stats?.validation_summary?.valid || 0}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">Conflicts</p>
              <p className="text-3xl font-bold">{stats?.validation_summary?.conflict || 0}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
        </div>
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">Avg Confidence</p>
              <p className="text-3xl font-bold">{stats ? (stats.average_confidence * 100).toFixed(1) : 0}%</p>
            </div>
            <Activity className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-semibold mb-4">System Health</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-slate-600">API Status</span>
              <span className="badge badge-green">{health?.status || 'unknown'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Groq API</span>
              <span className={`badge ${health?.groq_available ? 'badge-green' : 'badge-yellow'}`}>
                {health?.groq_available ? 'Available' : 'Fallback Mode'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Version</span>
              <span className="text-slate-900 font-medium">{health?.version || '1.0.0'}</span>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="font-semibold mb-4">Products by Category</h3>
          <div className="space-y-2">
            {stats?.by_category && Object.entries(stats.by_category).map(([cat, count]) => (
              <div key={cat} className="flex items-center justify-between text-sm">
                <span className="capitalize text-slate-600">{cat}</span>
                <span className="font-medium">{count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
