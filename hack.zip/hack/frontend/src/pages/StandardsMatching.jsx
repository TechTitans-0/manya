import { useEffect, useState } from 'react'
import { catalogApi, standardsApi } from '../api/client'

export default function StandardsMatching() {
  const [products, setProducts] = useState([])
  const [selected, setSelected] = useState(null)
  const [matches, setMatches] = useState(null)

  useEffect(() => {
    catalogApi.list({ per_page: 100 }).then((res) => setProducts(res.items || []))
  }, [])

  const loadMatches = async (id) => {
    const res = await standardsApi.get(id)
    setSelected(id)
    setMatches(res)
  }

  const runMatch = async (id) => {
    const res = await standardsApi.match(id)
    setMatches(res)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Standards Matching</h2>
        <p className="text-slate-500">Verified UNSPSC, eCl@ss, and ETIM classification matches</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card lg:col-span-1">
          <h3 className="font-semibold mb-4">Products</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {products.map((p) => (
              <button
                key={p.id}
                onClick={() => loadMatches(p.id)}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm border ${
                  selected === p.id ? 'border-primary-500 bg-primary-50' : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="font-medium truncate">{p.name || p.model_number || p.id}</div>
                <div className="text-xs text-slate-500 capitalize">{p.category || 'general'}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="card lg:col-span-2">
          {selected ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">Standards Matches</h3>
                <button
                  onClick={() => runMatch(selected)}
                  className="text-sm bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700"
                >
                  Match Standards
                </button>
              </div>
              {matches?.standards_matches?.length > 0 ? (
                <div className="space-y-3">
                  {matches.standards_matches.map((m, idx) => (
                    <div key={idx} className="border border-slate-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold uppercase text-slate-700">{m.standard_type}</span>
                        <span className="text-sm text-slate-500">
                          {m.match_confidence ? (m.match_confidence * 100).toFixed(0) + '%' : ''}
                        </span>
                      </div>
                      <div className="mt-2">
                        {m.standard_code ? (
                          <div>
                            <p className="text-lg font-mono font-semibold text-primary-700">{m.standard_code}</p>
                            <p className="text-slate-700">{m.standard_description}</p>
                            <p className="text-sm text-slate-500 mt-1">{m.match_method} · {m.verified ? 'Verified' : 'Unverified'}</p>
                          </div>
                        ) : (
                          <div className="text-amber-700 bg-amber-50 p-3 rounded-lg">
                            <p className="font-medium">Classification unavailable</p>
                            <p className="text-sm mt-1">{m.match_explanation}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-slate-500">No standards matches yet. Run matching first.</div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 text-slate-400">Select a product to view standards matches</div>
          )}
        </div>
      </div>
    </div>
  )
}
