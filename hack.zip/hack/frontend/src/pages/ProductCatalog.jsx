import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { catalogApi } from '../api/client'
import ConfidenceBadge from '../components/ConfidenceBadge'
import ValidationStatus from '../components/ValidationStatus'

export default function ProductCatalog() {
  const [data, setData] = useState({ items: [], total: 0 })
  const [filters, setFilters] = useState({ category: '', status: '', search: '', page: 1 })
  const navigate = useNavigate()

  useEffect(() => {
    catalogApi.list(filters).then(setData)
  }, [filters])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Product Catalog</h2>
        <p className="text-slate-500">Browse, filter, and inspect commerce-ready product records</p>
      </div>

      <div className="card">
        <div className="flex flex-wrap gap-3 mb-4">
          <input
            type="text"
            placeholder="Search name, manufacturer, model..."
            className="border border-slate-300 rounded-lg px-4 py-2 text-sm"
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value, page: 1 })}
          />
          <select
            className="border border-slate-300 rounded-lg px-4 py-2 text-sm"
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value, page: 1 })}
          >
            <option value="">All Categories</option>
            <option value="motors">Motors</option>
            <option value="bearings">Bearings</option>
            <option value="pumps">Pumps</option>
            <option value="valves">Valves</option>
            <option value="sensors">Sensors</option>
            <option value="electrical">Electrical</option>
          </select>
          <select
            className="border border-slate-300 rounded-lg px-4 py-2 text-sm"
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
          >
            <option value="">All Status</option>
            <option value="draft">Draft</option>
            <option value="reviewed">Reviewed</option>
            <option value="approved">Approved</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
              <tr>
                <th className="px-4 py-2">Name</th>
                <th className="px-4 py-2">Manufacturer</th>
                <th className="px-4 py-2">Category</th>
                <th className="px-4 py-2">Confidence</th>
                <th className="px-4 py-2">Status</th>
                <th className="px-4 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.items?.map((p) => (
                <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium">{p.name || p.model_number || p.id}</td>
                  <td className="px-4 py-3">{p.manufacturer || '-'}</td>
                  <td className="px-4 py-3 capitalize">{p.category || 'general'}</td>
                  <td className="px-4 py-3"><ConfidenceBadge value={p.overall_confidence} /></td>
                  <td className="px-4 py-3"><ValidationStatus status={p.status} /></td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => navigate(`/passport/${p.id}`)}
                      className="text-primary-600 hover:underline text-xs font-medium"
                    >
                      View Passport
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {data.total === 0 && <div className="text-center py-10 text-slate-500">No products found.</div>}
      </div>
    </div>
  )
}
