import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { productsApi } from '../api/client'
import ConfidenceBadge from '../components/ConfidenceBadge'
import ValidationStatus from '../components/ValidationStatus'
import { Upload, FileText, Check, X, AlertCircle } from 'lucide-react'

export default function ProductAnalyzer() {
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [beforeAfter, setBeforeAfter] = useState([])
  const [error, setError] = useState('')

  const onDrop = useCallback((acceptedFiles) => {
    setFile(acceptedFiles[0])
    setError('')
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop })

  const handleUpload = async () => {
    if (!file) return
    setLoading(true)
    setError('')
    try {
      const res = await productsApi.upload(file)
      setResult(res)
      if (res.product_id) {
        const ba = await productsApi.beforeAfter(res.product_id)
        setBeforeAfter(ba)
      }
    } catch (err) {
      setError(err.response?.data?.detail || err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (pid, aid) => {
    await productsApi.approve(pid, aid)
    const ba = await productsApi.beforeAfter(pid)
    setBeforeAfter(ba)
  }

  const handleReject = async (pid, aid) => {
    await productsApi.reject(pid, aid)
    const ba = await productsApi.beforeAfter(pid)
    setBeforeAfter(ba)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Product Analyzer</h2>
        <p className="text-slate-500">Upload a nameplate image, PDF, or CSV to extract and validate product intelligence</p>
      </div>

      <div className="card">
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition ${
            isDragActive ? 'border-primary-500 bg-primary-50' : 'border-slate-300 hover:border-primary-400'
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-700 font-medium">Drop image, PDF, or CSV here, or click to browse</p>
          <p className="text-slate-500 text-sm mt-1">Supported: JPG, PNG, PDF, CSV</p>
          {file && <p className="text-primary-600 font-medium mt-3">{file.name}</p>}
        </div>
        <div className="mt-4 flex justify-end">
          <button
            onClick={handleUpload}
            disabled={!file || loading}
            className="bg-primary-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Processing...' : 'Analyze Product'}
          </button>
        </div>
      </div>

      {error && (
        <div className="card bg-red-50 border-red-200 flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {result && (
        <div className="space-y-6">
          <div className="card">
            <h3 className="font-semibold text-lg mb-2">Analysis Result</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-slate-500">Product ID</span>
                <p className="font-medium">{result.product_id}</p>
              </div>
              <div>
                <span className="text-slate-500">Status</span>
                <p className="font-medium capitalize">{result.status}</p>
              </div>
              <div>
                <span className="text-slate-500">Overall Confidence</span>
                <p className="font-medium">{result.overall_confidence ? (result.overall_confidence * 100).toFixed(1) + '%' : 'N/A'}</p>
              </div>
            </div>
          </div>

          {beforeAfter.length > 0 && (
            <div className="card">
              <h3 className="font-semibold text-lg mb-4">Before & After Intelligence</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
                    <tr>
                      <th className="px-4 py-2">Attribute</th>
                      <th className="px-4 py-2">Original</th>
                      <th className="px-4 py-2">Enriched</th>
                      <th className="px-4 py-2">Confidence</th>
                      <th className="px-4 py-2">Status</th>
                      <th className="px-4 py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {beforeAfter.map((item) => (
                      <tr key={item.attribute_name} className="border-b border-slate-100 hover:bg-slate-50">
                        <td className="px-4 py-3 font-medium">{item.attribute_name}</td>
                        <td className="px-4 py-3 text-slate-500">{item.original_value || '-'}</td>
                        <td className="px-4 py-3">{item.enriched_value || '-'}</td>
                        <td className="px-4 py-3"><ConfidenceBadge value={item.confidence} /></td>
                        <td className="px-4 py-3"><ValidationStatus status={item.validation_status} /></td>
                        <td className="px-4 py-3">
                          {item.is_enriched && item.approval_status === 'pending' && (
                            <div className="flex gap-2">
                              <button onClick={() => handleApprove(result.product_id, item.attribute_id)}
                                className="p-1 bg-green-100 text-green-700 rounded hover:bg-green-200">
                                <Check className="w-4 h-4" />
                              </button>
                              <button onClick={() => handleReject(result.product_id, item.attribute_id)}
                                className="p-1 bg-red-100 text-red-700 rounded hover:bg-red-200">
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
