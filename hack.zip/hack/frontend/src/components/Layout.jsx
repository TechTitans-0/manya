import { Link, useLocation } from 'react-router-dom'
import { Activity, Box, FileSearch, Search, ShieldCheck, RefreshCw, Database, Settings, Home } from 'lucide-react'

const navItems = [
  { label: 'Dashboard', path: '/', icon: Home },
  { label: 'Product Analyzer', path: '/analyze', icon: FileSearch },
  { label: 'Validation Center', path: '/validation', icon: ShieldCheck },
  { label: 'Standards Matching', path: '/standards', icon: Box },
  { label: 'Replacement Finder', path: '/replacements', icon: RefreshCw },
  { label: 'Catalog', path: '/catalog', icon: Database },
  { label: 'About', path: '/about', icon: Settings },
]

export default function Layout({ children }) {
  const { pathname } = useLocation()

  return (
    <div className="min-h-screen flex">
      <aside className="w-64 bg-slate-900 text-white flex flex-col fixed h-full">
        <div className="p-6 border-b border-slate-800">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Activity className="w-6 h-6 text-primary-500" />
            IntelliSpec
          </h1>
          <p className="text-xs text-slate-400 mt-1">Industrial Product Intelligence</p>
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon
            const active = pathname === item.path
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition ${
                  active ? 'bg-primary-600 text-white' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>
        <div className="p-4 border-t border-slate-800 text-xs text-slate-500">
          Evidence-Driven Intelligence
        </div>
      </aside>
      <main className="flex-1 ml-64 p-8 max-w-7xl mx-auto w-full">
        {children}
      </main>
    </div>
  )
}
