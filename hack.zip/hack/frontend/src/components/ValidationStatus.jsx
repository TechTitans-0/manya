export default function ValidationStatus({ status }) {
  if (status === 'valid') return <span className="badge badge-green">Valid</span>
  if (status === 'warning') return <span className="badge badge-yellow">Warning</span>
  if (status === 'conflict') return <span className="badge badge-red">Conflict</span>
  return <span className="badge badge-gray">Unvalidated</span>
}
