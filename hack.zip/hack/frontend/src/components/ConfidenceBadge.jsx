export default function ConfidenceBadge({ value }) {
  const score = Number(value || 0)
  let cls = 'badge-gray'
  let label = `${(score * 100).toFixed(0)}%`
  if (score >= 0.8) cls = 'badge-green'
  else if (score >= 0.5) cls = 'badge-yellow'
  else cls = 'badge-red'
  return <span className={`badge ${cls}`}>{label}</span>
}
